/**
 * Panels that can be mounted on their own.
 *
 * Each one reads what it needs from `<TerminalProvider>`, so an application can
 * compose the pieces it wants — a chart alone, a chart with its own order form,
 * or the full `<Terminal />` layout — without passing forty props around or
 * forking the project.
 */
/** The chart: candles, indicators, drawings, position overlays, replay. */
export declare function Chart(): import('react').JSX.Element;
/** Market / limit / stop order entry for the charted symbol. */
export declare function OrderTicket(): import('react').JSX.Element;
/** Depth ladder around the live mid price. */
export declare function DepthLadder(): import('react').JSX.Element;
/** Instrument list with live prices. */
export declare function Watchlist(): import('react').JSX.Element;
/** Open positions, with close / partial close / modify wired up. */
export declare function Positions(): import('react').JSX.Element;
/** Working orders, with cancel and modify wired up. */
export declare function Orders(): import('react').JSX.Element;
