import { ReactNode } from 'react';
export declare function TerminalProvider({ children }: {
    children: ReactNode;
}): import('react').JSX.Element;
