/**
 * The full terminal: chart, toolbar, order ticket, depth, watchlist, positions
 * and replay in the standard layout.
 *
 * ```tsx
 * <OpenChartsProvider adapter={myAdapter}>
 *   <Terminal />
 * </OpenChartsProvider>
 * ```
 *
 * For a different arrangement, use `<TerminalProvider>` with the individual
 * panels instead of this component.
 */
export declare function Terminal(): import('react').JSX.Element;
