export type TraderPrefs = Record<string, string>;
export declare function getTraderPrefsStorageKey(userId?: string | null): string;
export declare function readTraderPrefs(userId?: string | null): TraderPrefs;
export declare function writeTraderPrefs(prefs: TraderPrefs, userId?: string | null): void;
export declare function applyAccentColorFromPrefs(prefs: TraderPrefs): void;
export declare function useTraderPreferences(): {
    prefs: TraderPrefs;
    loaded: boolean;
    savePreference: (key: string, value: string) => void;
    savePreferences: (next: TraderPrefs) => void;
};
