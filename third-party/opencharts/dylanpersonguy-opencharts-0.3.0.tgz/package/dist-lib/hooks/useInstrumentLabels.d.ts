type InstrumentType = "FOREX" | "FUTURES" | "CRYPTO" | "EQUITIES";
/**
 * Returns display labels and formatters that adapt to the current account's
 * instrument type. Futures accounts show "contracts" instead of "lots", and
 * quantity is formatted as an integer.
 *
 * Subscribes only to the active account's instrumentType — NOT the entire
 * accounts array — so it does not re-render on every equity/balance tick.
 */
export declare function useInstrumentLabels(): {
    instrumentType: InstrumentType;
    isFutures: boolean;
    /** "lots" for forex/crypto, "contracts" for futures, "shares" for equities */
    unitLabel: string;
    /** Capitalised version for use at sentence start */
    unitLabelCap: string;
    /**
     * Format a quantity with its unit label.
     * Futures quantities are shown as integers; forex as decimals.
     */
    formatQty: (qty: number) => string;
};
export {};
