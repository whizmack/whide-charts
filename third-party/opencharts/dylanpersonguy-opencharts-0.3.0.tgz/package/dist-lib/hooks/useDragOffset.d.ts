import { CSSProperties, PointerEvent } from 'react';
/**
 * Drag-to-move for floating dialogs/panels (TradingView-style).
 *
 * Attach `onPointerDown` to the drag handle (usually the dialog header) and
 * spread `style` onto the floating element. The offset accumulates across
 * drags and `reset()` re-centres (call it when the dialog closes so it
 * reopens centred).
 */
export declare function useDragOffset(): {
    style: CSSProperties;
    onPointerDown: (e: PointerEvent<HTMLElement>) => void;
    reset: () => void;
};
