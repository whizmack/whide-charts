/**
 * Hook that manages a trade execution sound effect with mute/unmute toggle.
 * Mute preference is persisted in localStorage.
 *
 * The sound is generated programmatically using the Web Audio API —
 * a short, satisfying "cha-ching" tone (no external audio file needed).
 */
export declare function useTradeSound(): {
    readonly muted: boolean;
    readonly toggleMute: () => void;
    readonly playTradeSound: () => void;
};
