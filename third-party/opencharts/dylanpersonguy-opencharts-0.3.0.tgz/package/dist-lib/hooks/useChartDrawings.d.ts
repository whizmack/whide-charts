import { DrawingLine } from '../pages/trading/constants';
export declare function useChartDrawings(symbol: string, timeframe: string): {
    drawings: DrawingLine[];
    addDrawing: (d: DrawingLine) => void;
    updateDrawing: (d: DrawingLine) => void;
    removeDrawing: (id: string) => void;
    clearDrawings: () => void;
    undo: () => void;
    redo: () => void;
};
