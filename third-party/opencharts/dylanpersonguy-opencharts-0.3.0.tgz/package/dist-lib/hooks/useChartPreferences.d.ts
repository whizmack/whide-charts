import { MagnetMode } from '../pages/trading/constants.ts';
export interface ChartPreferences {
    showBidLine: boolean;
    showAskLine: boolean;
    overlayPositionsOnChart: boolean;
    /** Snap drawing anchors to nearby candle O/H/L/C values. */
    drawingMagnet: boolean;
    /** Magnet mode: off / weak (snap near) / strong (always snap to OHLC). */
    magnetMode: MagnetMode;
    /** Keep the drawing tool armed after each placement. */
    stayInDrawingMode: boolean;
    /** Plugin IDs that are currently active (persisted across page loads). */
    activePlugins: string[];
    /** Hex override for up candles; empty string = theme default. */
    candleUpColor: string;
    /** Hex override for down candles; empty string = theme default. */
    candleDownColor: string;
    /** Independent candle colors used by the TradingView-style Symbol tab. */
    candleBullBodyColor: string;
    candleBearBodyColor: string;
    candleBullBorderColor: string;
    candleBearBorderColor: string;
    candleBullWickColor: string;
    candleBearWickColor: string;
    /** Color bars by their close relative to the previous candle close. */
    colorBarsByPreviousClose: boolean;
    colorBackground: string;
    colorGrid: string;
    colorVerticalGrid: string;
    colorHorizontalGrid: string;
    colorScaleText: string;
    colorCrosshair: string;
    colorBidLine: string;
    colorAskLine: string;
    colorPositionLong: string;
    colorPositionShort: string;
    colorOrderLine: string;
    colorTpLine: string;
    colorSlLine: string;
    /** Name of the template the chart currently tracks ("" = none). */
    activeChartTemplate: string;
    /** Auto-save settings changes back to the active template. */
    chartTemplateAutosave: boolean;
    showWicks: boolean;
    showCandleBorders: boolean;
    showVolume: boolean;
    showGrid: boolean;
    showVerticalGrid: boolean;
    showHorizontalGrid: boolean;
    showWatermark: boolean;
    showCountdown: boolean;
    showOhlcLegend: boolean;
    showStatusLineSymbol: boolean;
    showStatusLineMarketState: boolean;
    showStatusLineChange: boolean;
    showStatusLineVolume: boolean;
    showStatusLineStudyTitle: boolean;
    showStatusLineStudyInputs: boolean;
    showStatusLineStudyValues: boolean;
    showStatusLineStudyBackground: boolean;
    displayTimezone: string;
    pricePrecision: PricePrecision;
    priceScaleMode: PriceScaleModePreference;
    priceScaleSide: PriceScaleSidePreference;
    priceScaleInverted: boolean;
    noOverlappingLabels: boolean;
    showPriceScale: boolean;
    showTimeScale: boolean;
    showPriceLine: boolean;
    showLastValue: boolean;
    priceScaleTopMargin: number;
    priceScaleBottomMargin: number;
    timeScaleDateFormat: TimeScaleDateFormat;
    timeScaleShowDayOfWeek: boolean;
    timeScaleTimeFormat: TimeScaleTimeFormat;
    timeScaleSecondsVisible: "auto" | boolean;
    timeScaleRightOffset: "default" | number;
    watermarkMode: WatermarkMode;
    crosshairLineStyle: CrosshairLineStyle;
    scaleTextSize: number;
    showScaleBorder: boolean;
    chartBackgroundMode: "solid" | "transparent";
    enableChartScroll: boolean;
    enableChartScale: boolean;
    /** Master switch for rule-derived price lines (daily loss / max DD / target). */
    challengeOverlay: boolean;
    challengeDailyLossLine: boolean;
    challengeMaxDrawdownLine: boolean;
    challengeProfitTargetLine: boolean;
}
export type PricePrecision = "default" | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;
export type PriceScaleModePreference = "normal" | "logarithmic" | "percentage" | "indexedTo100";
export type PriceScaleSidePreference = "right" | "left";
export type TimeScaleDateFormat = "locale" | "yyyy-MM-dd" | "dd MMM yyyy" | "MMM dd, yyyy";
export type TimeScaleTimeFormat = "24-hour" | "12-hour";
export type WatermarkMode = "none" | "symbol" | "symbol-timeframe";
export type CrosshairLineStyle = "solid" | "dotted" | "dashed" | "large-dashed";
type TraderPrefs = Record<string, string>;
export declare function getDefaultChartPreferences(): ChartPreferences;
/**
 * Preference keys captured in a chart template snapshot — appearance, colors
 * and overlay choices. Deliberately excludes input behavior (magnet, stay-in-
 * drawing-mode) and the template bookkeeping keys themselves.
 */
export declare const TEMPLATE_PREF_KEYS: readonly ["showBidLine", "showAskLine", "overlayPositionsOnChart", "showWicks", "showCandleBorders", "showVolume", "showGrid", "showVerticalGrid", "showHorizontalGrid", "showWatermark", "showCountdown", "showOhlcLegend", "challengeOverlay", "challengeDailyLossLine", "challengeMaxDrawdownLine", "challengeProfitTargetLine", "candleUpColor", "candleDownColor", "candleBullBodyColor", "candleBearBodyColor", "candleBullBorderColor", "candleBearBorderColor", "candleBullWickColor", "candleBearWickColor", "colorBarsByPreviousClose", "colorBackground", "colorGrid", "colorVerticalGrid", "colorHorizontalGrid", "colorScaleText", "colorCrosshair", "colorBidLine", "colorAskLine", "colorPositionLong", "colorPositionShort", "colorOrderLine", "colorTpLine", "colorSlLine", "showStatusLineSymbol", "showStatusLineMarketState", "showStatusLineChange", "showStatusLineVolume", "showStatusLineStudyTitle", "showStatusLineStudyInputs", "showStatusLineStudyValues", "showStatusLineStudyBackground", "displayTimezone", "pricePrecision", "priceScaleMode", "priceScaleSide", "priceScaleInverted", "noOverlappingLabels", "showPriceScale", "showTimeScale", "showPriceLine", "showLastValue", "priceScaleTopMargin", "priceScaleBottomMargin", "timeScaleDateFormat", "timeScaleShowDayOfWeek", "timeScaleTimeFormat", "timeScaleSecondsVisible", "timeScaleRightOffset", "watermarkMode", "crosshairLineStyle", "scaleTextSize", "showScaleBorder", "chartBackgroundMode", "enableChartScroll", "enableChartScale"];
export type TemplatePrefKey = (typeof TEMPLATE_PREF_KEYS)[number];
export declare function getChartPreferencesFromStorage(): ChartPreferences;
export declare function updateChartPreferences(patch: Partial<ChartPreferences>): TraderPrefs;
export declare function notifyChartPreferencesUpdated(): void;
/** Apply modal draft settings to subscribers without touching persistent storage. */
export declare function setChartPreferencesPreview(prefs: ChartPreferences): void;
/** Persist supported chart settings in one trader-preference write. */
export declare function commitChartPreferencesPreview(prefs: ChartPreferences): void;
/** Restore persistent preferences after cancel, Escape, or backdrop dismissal. */
export declare function discardChartPreferencesPreview(): void;
export declare function useChartPreferences(): ChartPreferences;
export {};
