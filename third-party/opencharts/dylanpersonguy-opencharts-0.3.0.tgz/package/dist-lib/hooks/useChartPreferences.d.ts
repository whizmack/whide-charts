import { MagnetMode } from '../pages/trading/constants.ts';
export interface ChartPreferences {
    showBidLine: boolean;
    showAskLine: boolean;
    overlayPositionsOnChart: boolean;
    /** Snap drawing anchors to nearby candle O/H/L/C values. */
    drawingMagnet: boolean;
    /** Magnet mode: off / weak (snap near) / strong (always snap to OHLC). */
    magnetMode: MagnetMode;
    /** Keep the drawing tool armed after each placement. */
    stayInDrawingMode: boolean;
    /** Plugin IDs that are currently active (persisted across page loads). */
    activePlugins: string[];
    /** Hex override for up candles; empty string = theme default. */
    candleUpColor: string;
    /** Hex override for down candles; empty string = theme default. */
    candleDownColor: string;
    colorBackground: string;
    colorGrid: string;
    colorScaleText: string;
    colorCrosshair: string;
    colorBidLine: string;
    colorAskLine: string;
    colorPositionLong: string;
    colorPositionShort: string;
    colorOrderLine: string;
    colorTpLine: string;
    colorSlLine: string;
    /** Name of the template the chart currently tracks ("" = none). */
    activeChartTemplate: string;
    /** Auto-save settings changes back to the active template. */
    chartTemplateAutosave: boolean;
    showWicks: boolean;
    showCandleBorders: boolean;
    showVolume: boolean;
    showGrid: boolean;
    showWatermark: boolean;
    showCountdown: boolean;
    showOhlcLegend: boolean;
    /** Master switch for rule-derived price lines (daily loss / max DD / target). */
    challengeOverlay: boolean;
    challengeDailyLossLine: boolean;
    challengeMaxDrawdownLine: boolean;
    challengeProfitTargetLine: boolean;
}
type TraderPrefs = Record<string, string>;
/**
 * Preference keys captured in a chart template snapshot — appearance, colors
 * and overlay choices. Deliberately excludes input behavior (magnet, stay-in-
 * drawing-mode) and the template bookkeeping keys themselves.
 */
export declare const TEMPLATE_PREF_KEYS: readonly ["showBidLine", "showAskLine", "overlayPositionsOnChart", "showWicks", "showCandleBorders", "showVolume", "showGrid", "showWatermark", "showCountdown", "showOhlcLegend", "challengeOverlay", "challengeDailyLossLine", "challengeMaxDrawdownLine", "challengeProfitTargetLine", "candleUpColor", "candleDownColor", "colorBackground", "colorGrid", "colorScaleText", "colorCrosshair", "colorBidLine", "colorAskLine", "colorPositionLong", "colorPositionShort", "colorOrderLine", "colorTpLine", "colorSlLine"];
export type TemplatePrefKey = (typeof TEMPLATE_PREF_KEYS)[number];
export declare function getChartPreferencesFromStorage(): ChartPreferences;
export declare function updateChartPreferences(patch: Partial<ChartPreferences>): TraderPrefs;
export declare function notifyChartPreferencesUpdated(): void;
export declare function useChartPreferences(): ChartPreferences;
export {};
