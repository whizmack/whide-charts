function pick(kind) {
  try {
    if (typeof window === "undefined") return null;
    return kind === "local" ? window.localStorage : window.sessionStorage;
  } catch {
    return null;
  }
}
function makeStore(kind) {
  const storage = () => pick(kind);
  return {
    getItem(key) {
      var _a;
      try {
        return ((_a = storage()) == null ? void 0 : _a.getItem(key)) ?? null;
      } catch {
        return null;
      }
    },
    setItem(key, value) {
      try {
        const store = storage();
        if (!store) return false;
        store.setItem(key, value);
        return true;
      } catch {
        return false;
      }
    },
    removeItem(key) {
      try {
        const store = storage();
        if (!store) return false;
        store.removeItem(key);
        return true;
      } catch {
        return false;
      }
    },
    getJSON(key, fallback) {
      const raw = this.getItem(key);
      if (raw == null) return fallback;
      try {
        const parsed = JSON.parse(raw);
        return parsed ?? fallback;
      } catch {
        return fallback;
      }
    },
    setJSON(key, value) {
      try {
        return this.setItem(key, JSON.stringify(value));
      } catch {
        return false;
      }
    }
  };
}
const safeStorage = makeStore("local");
const safeSession = makeStore("session");
const DEMO_CHANNELS = {
  ticks: "demo:ticks",
  positions: "demo:positions",
  orders: "demo:orders",
  account: "demo:account"
};
const channels = /* @__PURE__ */ new Map();
function subscribeChannel(channel, handler) {
  let set = channels.get(channel);
  if (!set) {
    set = /* @__PURE__ */ new Set();
    channels.set(channel, set);
  }
  set.add(handler);
  return () => {
    set == null ? void 0 : set.delete(handler);
  };
}
function publish(channel, event) {
  const set = channels.get(channel);
  if (!set || set.size === 0) return;
  for (const handler of [...set]) {
    try {
      handler(event);
    } catch (err) {
      console.error(`[bus] subscriber on "${channel}" threw`, err);
    }
  }
}
function uid() {
  const c = typeof globalThis === "undefined" ? void 0 : globalThis.crypto;
  if (typeof (c == null ? void 0 : c.randomUUID) === "function") {
    try {
      return c.randomUUID();
    } catch {
    }
  }
  if (typeof (c == null ? void 0 : c.getRandomValues) === "function") {
    const bytes = c.getRandomValues(new Uint8Array(16));
    bytes[6] = (bytes[6] ?? 0) & 15 | 64;
    bytes[8] = (bytes[8] ?? 0) & 63 | 128;
    const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }
  return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}
export {
  DEMO_CHANNELS as D,
  subscribeChannel as a,
  safeSession as b,
  publish as p,
  safeStorage as s,
  uid as u
};
//# sourceMappingURL=uid-Cv5r25IO.js.map
