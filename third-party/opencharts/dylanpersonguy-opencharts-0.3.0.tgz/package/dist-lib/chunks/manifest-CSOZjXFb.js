const symbols = ["BTCUSD", "ETHUSD", "SOLUSD", "BNBUSD", "XRPUSD", "ADAUSD"];
const timeframes = ["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"];
const generatedAt = "2026-06-13T07:41:36.274Z";
const manifest = {
  symbols,
  timeframes,
  generatedAt
};
export {
  manifest as default,
  generatedAt,
  symbols,
  timeframes
};
//# sourceMappingURL=manifest-CSOZjXFb.js.map
