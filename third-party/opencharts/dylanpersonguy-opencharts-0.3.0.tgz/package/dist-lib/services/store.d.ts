import { Account, Order, Position, Symbol, User } from './schemas.ts';
interface AuthState {
    accessToken: string | null;
    refreshToken: string | null;
    user: User | null;
    isDemo: boolean;
    mfaPending: {
        mfaToken: string;
        userId: string;
    } | null;
    login: (email: string, password: string) => Promise<void>;
    googleLogin: (credential: string, firmSlug: string) => Promise<void>;
    demoLogin: () => Promise<void>;
    completeMfa: (code: string) => Promise<void>;
    cancelMfa: () => void;
    logout: () => void;
    restoreSession: () => Promise<void>;
}
export declare const useAuthStore: import('zustand').UseBoundStore<import('zustand').StoreApi<AuthState>>;
interface CandleBar {
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
    timestamp: number;
}
export type TickEntry = {
    bid: number;
    ask: number;
    timestamp: number;
    /** Pre-formatted with symbol-correct decimal places — avoids toFixed() during renders */
    bidFmt: string;
    askFmt: string;
};
interface TradingState {
    activeAccountId: string | null;
    accounts: Account[];
    positions: Position[];
    orders: Order[];
    symbols: Symbol[];
    selectedSymbol: string;
    /** Delayed ticks — HFT lag applied; what the account "sees" */
    ticks: Record<string, TickEntry>;
    /** Live (undelayed) ticks — pushed as HftLiveTick by ws-handler for HFT clients.
     *  Empty for non-HFT users. Replaces the 500ms REST poll for gap detection. */
    liveTicks: Record<string, TickEntry>;
    /** Latest WS candle update keyed by "symbol:timeframe" */
    liveCandleUpdates: Record<string, CandleBar>;
    /** Monotonic counter bumped on each ReplayStateChanged event — included in
     *  the candle query key so React Query treats every replay session as a
     *  brand-new query, eliminating any stale-data / structural-sharing issues. */
    replayVersion: number;
    /** Whether the market-data adapter is currently in replay mode (started, paused, or playing). */
    isReplaying: boolean;
    /** True only when replay is active but paused. */
    replayPaused: boolean;
    /** Current playback speed multiplier. */
    replaySpeed: number;
    /** Cursor position in the replay timeline (epoch ms). */
    replayCursorTimestamp: number | null;
    /** Session date (YYYY-MM-DD) of the active replay, set when replay starts. */
    replaySessionDate: string | null;
    setActiveAccount: (id: string) => void;
    loadAccounts: () => Promise<void>;
    updateAccountInStore: (updated: Partial<Account> & Pick<Account, "id">) => void;
    loadPositions: () => Promise<void>;
    loadOrders: () => Promise<void>;
    loadSymbols: () => Promise<void>;
    updateTick: (symbolName: string, bid: number, ask: number, timestamp: number) => void;
    updateLiveTick: (symbolName: string, bid: number, ask: number, timestamp: number) => void;
    updateCandleFromWs: (symbol: string, timeframe: string, bar: CandleBar) => void;
    setSelectedSymbol: (symbol: string) => void;
    setPositions: (positions: Position[]) => void;
    setOrders: (orders: Order[]) => void;
    setReplaySessionDate: (date: string | null) => void;
    /** Bump replay version and update replay state — call on ReplayStateChanged WS events */
    onReplayStateChanged: (action: string, opts?: {
        speed?: number;
        cursorTimestamp?: number;
    }) => void;
}
export declare const useTradingStore: import('zustand').UseBoundStore<import('zustand').StoreApi<TradingState>>;
export {};
