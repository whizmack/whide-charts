export interface ChartTemplateContent {
    version: 1;
    /** Snapshot of the TEMPLATE_PREF_KEYS subset of ChartPreferences. */
    prefs: Record<string, string | boolean>;
    indicators: string[];
    plugins: string[];
}
export interface ChartTemplate {
    id: string;
    name: string;
    layoutType: string;
    isDefault: boolean;
    panels: ChartTemplateContent[];
    updatedAt: string;
}
export declare const chartTemplatesApi: {
    list: () => Promise<ChartTemplate[]>;
    /** Upserts by name (unique per user). */
    save: (name: string, content: ChartTemplateContent, isDefault?: boolean) => Promise<ChartTemplate>;
    remove: (id: string) => Promise<{
        deleted: boolean;
    }>;
};
