import { User } from '../schemas';
type AuthPayload = {
    accessToken: string;
    refreshToken: string;
    user: User;
};
type ChangePasswordResponse = {
    success?: boolean;
    message?: string;
};
export interface AccountMetricsResponse {
    accountId: string;
    equity: number;
    balance: number;
    freeMargin: number;
    marginUsed: number;
    floatingPnl: number;
    dailyPnl: number;
    ddDaily: number | null;
    ddDailyMax: number | null;
    ddTotal: number | null;
    ddTotalMax: number | null;
    ddTrailing: number | null;
    ddTrailingMax: number | null;
    trailingDrawdownFloor: number | null;
    trailingDrawdownPeak: number | null;
    trailingDrawdownMode: string | null;
    trailingDrawdownTrailMode: string | null;
    trailingDrawdownFloorLocked: boolean;
    trailingDrawdownTrailToBreakeven: boolean;
    profitTargetPercent: number | null;
    profitTargetProgress: number;
    minTradingDays: number | null;
    tradingDaysCompleted: number;
    minDaysProgress: number;
    status: string;
    phase: string | null;
    highWaterMark: number | null;
    startingBalance: number;
    currency: string;
    lastMarkTs: string | null;
}
type TrustedDevice = {
    id: string;
    name?: string | null;
    ipAddress?: string | null;
    isTrusted?: boolean;
    lastSeenAt?: string;
};
type ActiveSession = {
    id: string;
    ipAddress?: string | null;
    userAgent?: string | null;
    createdAt: string;
    expiresAt: string;
};
export declare const authApi: {
    login: (email: string, password: string) => Promise<AuthPayload>;
    demoLogin: () => Promise<{
        accessToken: string;
        refreshToken: string;
        user: User;
        isDemo: boolean;
    }>;
    register: (data: {
        email: string;
        password: string;
        firstName: string;
        lastName: string;
        firmSlug?: string;
    }) => Promise<AuthPayload>;
    refreshToken: (refreshToken: string) => Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    logout: (refreshToken?: string) => Promise<void>;
    forgotPassword: (email: string) => Promise<{
        message: string;
        expiresIn: number;
    }>;
    resetPassword: (resetToken: string, newPassword: string) => Promise<{
        message: string;
    }>;
    changePassword: (currentPassword: string, newPassword: string) => Promise<ChangePasswordResponse>;
    getPreferences: () => Promise<Record<string, string>>;
    savePreferences: (prefs: Record<string, string>) => Promise<Record<string, string>>;
    getAccountMetrics: (accountId: string) => Promise<AccountMetricsResponse>;
    getMfaStatus: () => Promise<{
        enabled: boolean;
        enabledAt: string | null;
        backupCodesRemaining: number;
    }>;
    setupMfa: () => Promise<{
        secret: string;
        otpauthUrl: string;
        qrData: string;
    }>;
    verifyMfaSetup: (token: string) => Promise<{
        backupCodes: string[];
    }>;
    disableMfa: (token: string) => Promise<{
        message: string;
    }>;
    regenerateBackupCodes: (token: string) => Promise<{
        backupCodes: string[];
    }>;
    completeMfaLogin: (mfaToken: string, code: string) => Promise<AuthPayload>;
    getDevices: () => Promise<TrustedDevice[]>;
    trustDevice: (deviceId: string) => Promise<TrustedDevice>;
    revokeDevice: (deviceId: string) => Promise<void>;
    getActiveSessions: () => Promise<ActiveSession[]>;
    revokeSession: (sessionId: string) => Promise<void>;
    revokeAllSessions: () => Promise<{
        revokedCount: number;
    }>;
};
export {};
