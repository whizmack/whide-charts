export interface JournalEntry {
    id: string;
    accountId: string;
    positionId?: string | null;
    symbolName?: string | null;
    side?: "BUY" | "SELL" | string | null;
    entryPrice?: number | null;
    exitPrice?: number | null;
    pnl?: number | null;
    emotion?: string | null;
    setupType?: string | null;
    rating?: number | null;
    tags: string[];
    notes: string;
    createdAt: string;
}
export interface JournalEntriesResponse {
    entries: JournalEntry[];
    total: number;
}
export interface CreateJournalEntryInput {
    accountId: string;
    positionId?: string;
    symbolName?: string;
    side?: string;
    entryPrice?: number;
    exitPrice?: number;
    pnl?: number;
    emotion?: string;
    rating?: number;
    tags?: string[];
    notes?: string;
}
export interface UpdateJournalEntryInput {
    emotion?: string;
    rating?: number;
    tags?: string[];
    notes?: string;
}
type AnyRecord = Record<string, unknown>;
type AnalyticsSnapshotsParams = {
    accountId?: string;
    startDate?: string;
    endDate?: string;
    page?: number;
    limit?: number;
};
export declare const journalApi: {
    getJournalEntries: (accountId: string, opts?: {
        limit?: number;
        offset?: number;
        symbol?: string;
    }) => Promise<JournalEntriesResponse>;
    createJournalEntry: (data: CreateJournalEntryInput) => Promise<JournalEntry>;
    updateJournalEntry: (id: string, data: UpdateJournalEntryInput) => Promise<JournalEntry>;
    deleteJournalEntry: (id: string) => Promise<void>;
    getAnalyticsSnapshots: (params?: AnalyticsSnapshotsParams) => Promise<AnyRecord>;
    getAnalyticsAggregate: (accountId?: string) => Promise<AnyRecord>;
    exportAnalyticsPdf: (accountId?: string) => Promise<void>;
    getPatterns: (accountId: string, lookbackDays?: number) => Promise<AnyRecord>;
};
export {};
