import { LedgerEntry } from '../schemas';
import { PnlCalendarResponse } from '../../vendor/types.ts';
export type PayoutCalculation = {
    grossProfit: number;
    profitSplit: number;
    firmShare: number;
    traderPayout: number;
    fees: number;
    netPayout: number;
    consistencyScore: number | null;
    consistencyThreshold: number | null;
    consistencyGated: boolean;
};
export type PayoutAccountRef = {
    label?: string | null;
};
export type PayoutRecord = {
    id: string;
    accountId: string;
    status: string;
    grossProfit: number;
    profitSplit?: number | null;
    traderPayout: number;
    netPayout: number;
    fees?: number | null;
    payoutMethod?: string | null;
    payoutDetails?: Record<string, unknown> | null;
    adminNote?: string | null;
    createdAt: string;
    processedAt?: string | null;
    account?: PayoutAccountRef | null;
};
export type AllPayoutsResponse = {
    payouts: PayoutRecord[];
    summary: {
        totalPaidOut: number;
        pendingCount: number;
        totalRequests: number;
    };
};
export declare const accountsApi: {
    getMyAccounts: () => Promise<{
        id: string;
        status: string;
        createdAt: string;
        userId: string;
        templateId: string;
        label: string | null;
        balance: number;
        equity: number;
        margin: number;
        freeMargin: number;
        phase: string;
        startDate: string;
        updatedAt: string;
        isHftMode: boolean;
        template?: {
            name: string;
            startingBalance: number;
            instrumentType?: "FOREX" | "FUTURES" | "CRYPTO" | "EQUITIES" | undefined;
        } | undefined;
    }[]>;
    getAccount: (id: string) => Promise<{
        id: string;
        status: string;
        createdAt: string;
        userId: string;
        templateId: string;
        label: string | null;
        balance: number;
        equity: number;
        margin: number;
        freeMargin: number;
        phase: string;
        startDate: string;
        updatedAt: string;
        isHftMode: boolean;
        template?: {
            name: string;
            startingBalance: number;
            instrumentType?: "FOREX" | "FUTURES" | "CRYPTO" | "EQUITIES" | undefined;
        } | undefined;
    }>;
    createAccount: (templateId: string, userId: string, label?: string) => Promise<{
        id: string;
        status: string;
        createdAt: string;
        userId: string;
        templateId: string;
        label: string | null;
        balance: number;
        equity: number;
        margin: number;
        freeMargin: number;
        phase: string;
        startDate: string;
        updatedAt: string;
        isHftMode: boolean;
        template?: {
            name: string;
            startingBalance: number;
            instrumentType?: "FOREX" | "FUTURES" | "CRYPTO" | "EQUITIES" | undefined;
        } | undefined;
    }>;
    getLedger: (id: string, page?: number, pageSize?: number) => Promise<{
        data: LedgerEntry[];
        total: number;
        page: number;
        pageSize: number;
        totalPages: number;
    }>;
    setAccountLabel: (id: string, label: string) => Promise<{
        id: string;
        status: string;
        createdAt: string;
        userId: string;
        templateId: string;
        label: string | null;
        balance: number;
        equity: number;
        margin: number;
        freeMargin: number;
        phase: string;
        startDate: string;
        updatedAt: string;
        isHftMode: boolean;
        template?: {
            name: string;
            startingBalance: number;
            instrumentType?: "FOREX" | "FUTURES" | "CRYPTO" | "EQUITIES" | undefined;
        } | undefined;
    }>;
    getEquityHistory: (id: string, limit?: number) => Promise<{
        balance: number;
        equity: number;
        timestamp: string;
    }[]>;
    getAccountStats: (id: string) => Promise<{
        totalTrades: number;
        winRate: number;
        avgWin: number;
        avgLoss: number;
        profitFactor: number;
        bestTrade: number;
        worstTrade: number;
        sharpeRatio?: number | undefined;
        maxDrawdown?: number | undefined;
        expectancy?: number | undefined;
    }>;
    calculatePayout: (accountId: string) => Promise<PayoutCalculation>;
    requestPayout: (accountId: string, payoutMethod?: string, payoutDetails?: Record<string, string>) => Promise<PayoutRecord>;
    getPayoutHistory: (accountId: string) => Promise<PayoutRecord[]>;
    getAllPayouts: () => Promise<AllPayoutsResponse>;
    getDailyPnl: (accountIds: string[], from: string, to: string) => Promise<PnlCalendarResponse>;
    replayGetSession: (accountId: string, date: string) => Promise<{
        replaySession: {
            id: string;
            status: string;
            speed: number;
            cursorTimestamp: string | null;
            sessionDate: string;
        };
        tickBuffer: Array<{
            t: number;
            o: number;
            h: number;
            l: number;
            c: number;
            v: number;
        }>;
        tradeEvents: Array<{
            id: string;
            type: "entry" | "exit" | "violation";
            timestamp: string;
            symbolName: string | null;
            side: string | null;
            price: number | null;
            pnl: number | null;
            ruleCode?: string;
        }>;
        meta: {
            primarySymbol: string | null;
            sessionDate: string;
            tickCount: number;
        };
    }>;
    replayStart: (accountId: string, sessionDate: string, speed?: number) => Promise<{
        speed: number;
        seed: number | null;
    }>;
    replayPause: (accountId: string, sessionDate: string) => Promise<void>;
    replayResume: (accountId: string, sessionDate: string) => Promise<void>;
    replayStop: (accountId: string, sessionDate: string) => Promise<void>;
    replaySetSpeed: (accountId: string, sessionDate: string, speed: number) => Promise<{
        speed: number;
    }>;
    replaySeek: (accountId: string, sessionDate: string, timestamp: string) => Promise<{
        cursorTimestamp: string;
    }>;
    replayPatchSession: (accountId: string, patch: {
        sessionDate: string;
        cursorTimestamp?: number;
        speed?: number;
        status?: string;
    }) => Promise<void>;
};
