/** API base URL — uses VITE_API_URL env var (for direct gateway access) or /api (nginx proxy) */
export declare const API_BASE: string;
export declare class ApiError extends Error {
    status: number;
    code: string;
    details?: Record<string, unknown> | undefined;
    constructor(status: number, code: string, message: string, details?: Record<string, unknown> | undefined);
}
export interface RequestOptions extends RequestInit {
    /** Request timeout in milliseconds. Defaults to 20 000 ms. Pass 0 to disable. */
    timeoutMs?: number;
}
export declare function request<T>(path: string, opts?: RequestOptions): Promise<T>;
