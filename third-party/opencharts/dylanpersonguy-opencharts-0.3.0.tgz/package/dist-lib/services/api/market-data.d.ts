export interface MarketDataSymbol {
    id: string;
    name: string;
    displayName: string | null;
    category: string;
    contractSize: number;
    tickSize: number;
    tickValue: number;
    marginPercent: number;
    maxLeverage: number;
    commission: number;
    swapLong: number;
    swapShort: number;
    tradingHoursStart: string | null;
    tradingHoursEnd: string | null;
    isActive: boolean;
    symbol?: string;
    digits?: number;
    pipDigits?: number;
    [key: string]: unknown;
}
export interface MarketDataCandle {
    time: number;
    timestamp: number | string;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
}
export interface MarketDataCandleMetadata {
    historicalCoverageStart: number | null;
    isPartial: boolean;
    backfillQueued: boolean;
}
export interface MarketDataCandlesPayload {
    candles: MarketDataCandle[];
    metadata: MarketDataCandleMetadata;
}
export interface MarketDataTick {
    symbol: string;
    bid: number;
    ask: number;
    timestamp?: number | string;
}
export interface EconomicEvent {
    id: string;
    time: string;
    currency: string;
    event: string;
    impact: "low" | "medium" | "high";
    forecast?: string;
    previous?: string;
    actual?: string;
    country: string;
    [key: string]: unknown;
}
export declare const marketdataApi: {
    getSymbols: () => Promise<MarketDataSymbol[]>;
    getTick: (symbol: string) => Promise<MarketDataTick>;
    getTicks: () => Promise<Record<string, MarketDataTick>>;
    getCandles: (symbol: string, timeframe: string, limit?: number, range?: {
        fromMs: number;
        toMs: number;
    }) => Promise<MarketDataCandle[]>;
    getCandlesWithMeta: (symbol: string, timeframe: string, limit?: number, range?: {
        fromMs: number;
        toMs: number;
    }) => Promise<MarketDataCandlesPayload>;
    getMarketDataHealth: () => Promise<Record<string, unknown>>;
    getEconomicCalendar: (currencies?: string[], from?: string, to?: string) => Promise<EconomicEvent[]>;
    getMarketDataStaleness: () => Promise<Record<string, unknown>>;
};
