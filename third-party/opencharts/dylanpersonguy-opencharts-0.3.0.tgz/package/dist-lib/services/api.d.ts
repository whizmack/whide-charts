import { OrderModification, PositionModification } from '../adapter/types.ts';
import { DrawingLine } from '../pages/trading/constants.ts';
import { AccountMetricsResponse } from './api/auth.ts';
import { CreateJournalEntryInput, JournalEntriesResponse, JournalEntry, UpdateJournalEntryInput } from './api/journal.ts';
import { MarketDataCandlesPayload } from './api/market-data.ts';
import { Account, Candle, Order, PlaceOrderInput, Position, Symbol } from './schemas.ts';
import * as replay from "./replay.ts";
/**
 * Internal data facade.
 *
 * Everything in the terminal reads and writes through this object, and every
 * method here resolves against whatever adapter is installed (see
 * `src/adapter/`). Applications never implement this shape — they implement
 * the much smaller `OpenChartsAdapter` contract, and this layer maps it onto
 * the calls the UI has always made.
 *
 * Keeping the mapping in one place means the public contract can stay small and
 * stable while the internals are free to change.
 */
export declare const API_BASE = "";
export declare class ApiError extends Error {
    status: number;
    code: string;
    constructor(message: string, status?: number, code?: string);
}
declare const DEMO_USER: {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    roles: string[];
    status: string;
    createdAt: string;
};
type AuthResponse = {
    accessToken: string;
    refreshToken: string;
    user: typeof DEMO_USER;
};
export declare const api: {
    login: (_email: string, _password: string) => Promise<AuthResponse>;
    demoLogin: () => Promise<AuthResponse>;
    completeMfaLogin: (_token: string, _code: string) => Promise<AuthResponse>;
    logout: (_refreshToken?: string) => Promise<{
        success: boolean;
    }>;
    refreshToken: (_token: string) => Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    getSymbols: () => Promise<Symbol[]>;
    getCandles: (symbol: string, timeframe: string, limit?: number, range?: {
        fromMs?: number;
        toMs?: number;
    }) => Promise<Candle[]>;
    getCandlesWithMeta: (symbol: string, timeframe: string, limit?: number, range?: {
        fromMs?: number;
        toMs?: number;
    }) => Promise<MarketDataCandlesPayload>;
    getTick: (symbol: string) => Promise<import('../index.ts').Quote>;
    getMarketDataHealth: () => Promise<{
        status: "ok";
    }>;
    /** No calendar provider in the contract; hosts render their own if they have one. */
    getEconomicCalendar: (_currencies: string[], _from?: string, _to?: string) => Promise<never[]>;
    getMyAccounts: () => Promise<Account[]>;
    getAccountMetrics: (accountId: string) => Promise<AccountMetricsResponse>;
    getPositions: (accountId: string) => Promise<Position[]>;
    getOrders: (accountId: string, status?: string) => Promise<Order[]>;
    getClosedPositions: (accountId: string, page?: number) => Promise<import('../index.ts').Page<{
        id: string;
        symbolName: string;
        side: string;
        quantity: number;
        entryPrice: number;
        openedAt: string;
        commission: number;
        realizedPnl: number;
        exitPrice: number;
        swap: number;
        closedAt: string | null;
        accountId?: string | undefined;
        isPartialClose?: boolean | undefined;
    }>>;
    placeOrder: (input: PlaceOrderInput) => Promise<Order>;
    modifyOrder: (orderId: string, modification: OrderModification) => Promise<Order>;
    cancelOrder: (orderId: string) => Promise<{
        success: boolean;
    }>;
    cancelAllOrders: (accountId?: string) => Promise<{
        success: boolean;
    }>;
    closePosition: (positionId: string, quantity?: number) => Promise<{
        success: boolean;
    }>;
    closeAllPositions: (accountId?: string) => Promise<{
        success: boolean;
    }>;
    modifyPosition: (positionId: string, modification: PositionModification) => Promise<Position>;
    chartDrawings: {
        list: (symbol: string) => Promise<DrawingLine[]>;
        save: (symbol: string, _timeframe: string, drawing: DrawingLine) => Promise<{
            saved: boolean;
        }>;
        remove: (drawingId: string) => Promise<{
            deleted: boolean;
        }>;
        clear: (symbol: string) => Promise<{
            cleared: boolean;
        }>;
    };
    getPreferences: () => Promise<Record<string, string> | null>;
    savePreferences: (_prefs: Record<string, string>) => Promise<{
        success: boolean;
    }>;
    getJournalEntries: (accountId: string, opts?: {
        limit?: number;
        symbol?: string;
    }) => Promise<JournalEntriesResponse>;
    createJournalEntry: (data: CreateJournalEntryInput) => Promise<JournalEntry>;
    updateJournalEntry: (id: string, data: UpdateJournalEntryInput) => Promise<JournalEntry | null>;
    deleteJournalEntry: (id: string) => Promise<{
        success: boolean;
    }>;
    replayGetSession: (_accountId: string, sessionDate: string, symbol?: string) => Promise<replay.ReplaySessionPayload>;
    replayStart: (_accountId: string, sessionDate: string, speed?: number, symbol?: string) => Promise<{
        speed: number;
        seed: null;
    }>;
    replayPause: (_accountId: string, _sessionDate: string) => Promise<{
        success: boolean;
    }>;
    replayResume: (_accountId: string, _sessionDate: string) => Promise<{
        success: boolean;
    }>;
    replayStop: (_accountId: string, _sessionDate: string) => Promise<{
        success: boolean;
    }>;
    replaySetSpeed: (_accountId: string, _sessionDate: string, speed: number) => Promise<{
        speed: number;
    }>;
    replaySeek: (_accountId: string, _sessionDate: string, timestamp: string) => Promise<{
        cursorTimestamp: string;
    }>;
    replayPatchSession: (_accountId: string, patch: {
        sessionDate?: string;
        cursorTimestamp?: number;
    }) => Promise<{
        success: boolean;
    }>;
};
export {};
