import { JournalEntriesResponse } from './api/journal';
import { ClosedPosition } from './schemas';
export declare const queryKeys: {
    readonly accounts: {
        readonly all: readonly ["accounts"];
        readonly mine: () => readonly ["accounts", "mine"];
        readonly detail: (id: string) => readonly ["accounts", string];
        readonly stats: (id: string) => readonly ["accounts", string, "stats"];
        readonly ledger: (id: string, page: number) => readonly ["accounts", string, "ledger", number];
        readonly equity: (id: string) => readonly ["accounts", string, "equity"];
    };
    readonly trading: {
        readonly positions: (accountId: string) => readonly ["positions", string];
        readonly orders: (accountId: string, status?: string) => readonly ["orders", string, string | undefined];
        readonly fills: (accountId: string, page: number) => readonly ["fills", string, number];
        readonly closedPositions: (accountId: string, page: number) => readonly ["closedPositions", string, number];
    };
    readonly market: {
        readonly symbols: readonly ["symbols"];
        readonly candles: (symbol: string, tf: string) => readonly ["candles", string, string];
        readonly economicCalendar: (currencies: string[]) => readonly ["economicCalendar", ...string[]];
    };
    readonly replay: {
        readonly session: (accountId: string, date: string) => readonly ["replay", "session", string, string];
    };
};
export declare function usePositions(accountId: string | null): import('@tanstack/react-query').UseQueryResult<NoInfer<{
    id: string;
    margin: number;
    accountId: string;
    symbolName: string;
    side: "LONG" | "SHORT";
    quantity: number;
    takeProfit: number | null;
    stopLoss: number | null;
    entryPrice: number;
    unrealizedPnl: number;
    openedAt: string;
    currentPrice?: number | undefined;
    contractSize?: number | undefined;
}[]>, Error>;
/** Cross-account total open position count */
export declare function useOrders(accountId: string | null, status?: string): import('@tanstack/react-query').UseQueryResult<NoInfer<{
    type: "MARKET" | "LIMIT" | "STOP";
    id: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    accountId: string;
    symbolName: string;
    side: "BUY" | "SELL";
    quantity: number;
    price: number | null;
    stopPrice: number | null;
    takeProfit: number | null;
    stopLoss: number | null;
    filledQuantity: number;
    avgFillPrice: number | null;
    comment: string | null;
}[]>, Error>;
export declare function useClosedPositions(accountId: string | null, page?: number): import('@tanstack/react-query').UseQueryResult<NoInfer<{
    data: ClosedPosition[];
    total: number;
    page: number;
    pageSize: number;
    totalPages: number;
}>, Error>;
export declare function useSymbols(): import('@tanstack/react-query').UseQueryResult<NoInfer<{
    name: string;
    id: string;
    displayName: string | null;
    contractSize: number;
    commission: number;
    category: string;
    tickSize: number;
    tickValue: number;
    marginPercent: number;
    maxLeverage: number;
    swapLong: number;
    swapShort: number;
    tradingHoursStart: string | null;
    tradingHoursEnd: string | null;
    isActive: boolean;
}[]>, Error>;
export interface EconomicCalendarEvent {
    id: string;
    time: string;
    currency: string;
    impact: "low" | "medium" | "high";
    event: string;
    forecast?: string;
    previous?: string;
    actual?: string;
    country: string;
}
export declare function useEconomicCalendar(currencies: string[]): import('@tanstack/react-query').UseQueryResult<NoInfer<EconomicCalendarEvent[]>, Error>;
export declare function useCandles(symbol: string, timeframe: string, limit?: number, replayVersion?: number): import('@tanstack/react-query').UseQueryResult<NoInfer<{
    open: number;
    time: number;
    high: number;
    low: number;
    close: number;
    volume: number;
    timestamp?: string | number | undefined;
}[]>, Error>;
export declare function useAccountMetrics(accountId: string | null): import('@tanstack/react-query').UseQueryResult<NoInfer<import('./api/auth').AccountMetricsResponse>, Error>;
export declare function useMarketDataHealth(): import('@tanstack/react-query').UseQueryResult<NoInfer<{
    status: "ok";
}>, Error>;
export declare function usePlaceOrder(): import('@tanstack/react-query').UseMutationResult<{
    type: "MARKET" | "LIMIT" | "STOP";
    id: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    accountId: string;
    symbolName: string;
    side: "BUY" | "SELL";
    quantity: number;
    price: number | null;
    stopPrice: number | null;
    takeProfit: number | null;
    stopLoss: number | null;
    filledQuantity: number;
    avgFillPrice: number | null;
    comment: string | null;
}, Error, {
    symbol: string;
    type: "MARKET" | "LIMIT" | "STOP" | "STOP_LIMIT";
    accountId: string;
    side: "BUY" | "SELL";
    quantity: number;
    price?: number | undefined;
    stopPrice?: number | undefined;
    takeProfit?: number | undefined;
    stopLoss?: number | undefined;
}, unknown>;
export declare function useCancelOrder(): import('@tanstack/react-query').UseMutationResult<{
    success: boolean;
}, Error, {
    orderId: string;
    accountId: string;
}, {
    prev: {
        type: "MARKET" | "LIMIT" | "STOP";
        id: string;
        status: string;
        createdAt: string;
        updatedAt: string;
        accountId: string;
        symbolName: string;
        side: "BUY" | "SELL";
        quantity: number;
        price: number | null;
        stopPrice: number | null;
        takeProfit: number | null;
        stopLoss: number | null;
        filledQuantity: number;
        avgFillPrice: number | null;
        comment: string | null;
    }[] | undefined;
}>;
export declare function useClosePosition(): import('@tanstack/react-query').UseMutationResult<{
    success: boolean;
}, Error, {
    positionId: string;
    accountId: string;
    quantity?: number;
}, unknown>;
export declare function useCloseAllPositions(): import('@tanstack/react-query').UseMutationResult<{
    success: boolean;
}, Error, string, unknown>;
export declare function useJournalEntries(accountId: string | null, opts?: {
    symbol?: string;
}): import('@tanstack/react-query').UseQueryResult<NoInfer<JournalEntriesResponse>, Error>;
export declare function useCreateJournalEntry(): import('@tanstack/react-query').UseMutationResult<import('./api/journal').JournalEntry, Error, import('./api/journal').CreateJournalEntryInput, unknown>;
export declare function useUpdateJournalEntry(): import('@tanstack/react-query').UseMutationResult<import('./api/journal').JournalEntry | null, Error, {
    id: string;
    accountId: string;
    emotion?: string;
    rating?: number;
    tags?: string[];
    notes?: string;
}, unknown>;
export declare function useDeleteJournalEntry(): import('@tanstack/react-query').UseMutationResult<{
    success: boolean;
}, Error, {
    id: string;
    accountId: string;
}, unknown>;
export declare function useReplaySession(accountId: string | null, sessionDate: string | null, symbol?: string): import('@tanstack/react-query').UseQueryResult<NoInfer<import('./replay').ReplaySessionPayload>, Error>;
