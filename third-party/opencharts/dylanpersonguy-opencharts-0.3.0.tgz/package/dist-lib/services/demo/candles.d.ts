import { Candle } from '../schemas.ts';
/**
 * Load one series, caching both the result and the in-flight promise. Missing
 * or corrupt bundles resolve to an empty series rather than rejecting — a
 * missing timeframe must not blank the terminal.
 */
export declare function loadSeries(symbol: string, timeframe: string): Promise<Candle[]>;
export interface HistoryRange {
    /** Inclusive lower bound in epoch milliseconds. */
    fromMs?: number;
    /** Exclusive upper bound in epoch milliseconds. */
    toMs?: number;
}
/**
 * Real history for a symbol/timeframe, shifted so the last bar is the current
 * period. `range` narrows to a window (used by the chart's scroll-back
 * pagination); `limit` keeps the most recent N bars of whatever remains.
 */
export declare function getHistory(symbol: string, timeframe: string, limit?: number, range?: HistoryRange): Promise<Candle[]>;
/** Fine-grained close series (1m) the feed replays as ticks. Empty until loaded. */
export declare function getTickPrices(symbol: string): number[];
/** Preload the 1m series the feed needs before it starts ticking. */
export declare function primeTickPrices(symbols: readonly string[]): Promise<void>;
/** Latest real close — seed price before the feed starts streaming. */
export declare function getSeedPrice(symbol: string): number;
