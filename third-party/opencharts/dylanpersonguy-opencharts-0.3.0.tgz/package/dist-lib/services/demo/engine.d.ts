import { Account, ClosedPosition, Fill, Order, Position } from '../schemas.ts';
/** Engine rejections carry a stable `code` so callers can branch without string matching. */
export declare class EngineError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare function getAccount(): Account;
export declare function getAccounts(): Account[];
export declare function getPositions(): Position[];
export declare function getOrders(): Order[];
export declare function getClosedPositions(): ClosedPosition[];
export declare function getFills(): Fill[];
export declare function getLastPrice(symbol: string): number;
export declare function getClosedPositionsSummary(): {
    realizedPnl: number;
    trades: number;
    wins: number;
    losses: number;
};
export declare function closePosition(positionId: string, quantity?: number): {
    success: boolean;
};
export declare function closeAllPositions(): {
    success: boolean;
};
export declare function modifyPosition(positionId: string, mods: {
    takeProfit?: number | null;
    stopLoss?: number | null;
}): Position;
export type PlaceOrderArgs = {
    accountId: string;
    symbol: string;
    side: string;
    type: string;
    quantity: number;
    price?: number;
    stopPrice?: number;
    takeProfit?: number;
    stopLoss?: number;
};
export type OrderModifications = {
    price?: number;
    stopPrice?: number;
    quantity?: number;
    takeProfit?: number | null;
    stopLoss?: number | null;
};
export declare function placeOrder(input: PlaceOrderArgs): Order;
export declare function modifyOrder(orderId: string, mods: OrderModifications): Order;
export declare function cancelOrder(orderId: string): {
    success: boolean;
};
export declare function cancelAllOrders(): {
    success: boolean;
};
/** Called by the feed on every replayed tick: fills pending orders, marks positions, fires SL/TP. */
export declare function mark(symbol: string, price: number): void;
/** Test seam: reset every engine mutable so suites start from a clean account. */
export declare function __resetForTests(): void;
