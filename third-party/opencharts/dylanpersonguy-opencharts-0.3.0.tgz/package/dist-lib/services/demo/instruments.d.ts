import { Symbol } from '../schemas.ts';
export declare const DEMO_SYMBOLS: Symbol[];
export declare const DEMO_SYMBOL_NAMES: string[];
export declare function getDemoSymbol(name: string): Symbol | undefined;
