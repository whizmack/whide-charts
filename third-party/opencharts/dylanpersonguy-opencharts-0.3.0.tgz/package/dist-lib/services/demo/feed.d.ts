export declare function startDemoFeed(): void;
export declare function stopDemoFeed(): void;
/** True while the replay interval is running (used by tests and the ws client). */
export declare function isDemoFeedRunning(): boolean;
