/**
 * Tiny in-process channel event bus used by the demo backend.
 *
 * The demo wsClient (services/ws.ts) and the paper-trading engine publish
 * events here; MarketDataBridge subscribes through wsClient.subscribe(), which
 * is backed by this bus. Mirrors the real WebSocket pub/sub contract so no
 * consumer code had to change.
 */
export type ChannelHandler = (event: unknown) => void;
/**
 * Channels the demo backend publishes on.
 *
 * Deliberately distinct from the UI-facing channel names ("market-data",
 * "positions", ...) that services/ws.ts owns: the demo adapter subscribes to
 * these and the ws client republishes onto the UI channels, so sharing a name
 * makes an event loop straight back into itself.
 */
export declare const DEMO_CHANNELS: {
    readonly ticks: "demo:ticks";
    readonly positions: "demo:positions";
    readonly orders: "demo:orders";
    readonly account: "demo:account";
};
export declare function subscribeChannel(channel: string, handler: ChannelHandler): () => void;
export declare function publish(channel: string, event: unknown): void;
/** Test seam: drop every subscription. */
export declare function __resetBus(): void;
