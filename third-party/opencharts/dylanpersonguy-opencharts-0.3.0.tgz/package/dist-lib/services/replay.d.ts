/**
 * Session replay.
 *
 * The replay UI drives its own clock (useReplayPlayback runs a rAF loop over
 * the tick buffer); this module supplies the buffer and owns the transport
 * state, broadcasting `ReplayStateChanged` so the store and HUD stay in sync.
 *
 * The buffer comes from the installed adapter's `getCandles`, so replay works
 * against any backend rather than needing one of its own. A "session" is the
 * 1-minute history for the charted symbol on the requested date.
 */
export type ReplaySessionPayload = {
    replaySession: {
        id: string;
        status: string;
        speed: number;
        cursorTimestamp: string | null;
        sessionDate: string;
    };
    tickBuffer: Array<{
        t: number;
        o: number;
        h: number;
        l: number;
        c: number;
        v: number;
    }>;
    tradeEvents: Array<{
        id: string;
        type: "entry" | "exit" | "violation";
        timestamp: string;
        symbolName: string | null;
        side: string | null;
        price: number | null;
        pnl: number | null;
        ruleCode?: string;
    }>;
    meta: {
        primarySymbol: string | null;
        sessionDate: string;
        tickCount: number;
    };
};
export declare function getSession(sessionDate: string, symbol?: string, accountId?: string): Promise<ReplaySessionPayload>;
export declare function start(sessionDate: string, speed?: number, symbol?: string, accountId?: string): Promise<{
    speed: number;
    seed: null;
}>;
export declare function pause(): void;
export declare function resume(): void;
export declare function stop(): void;
export declare function setSpeed(speed: number): {
    speed: number;
};
export declare function seek(timestamp: string | number): {
    cursorTimestamp: string;
};
/** Cursor persistence — in-memory only; a reload starts the session fresh. */
export declare function patchSession(patch: {
    sessionDate?: string;
    cursorTimestamp?: number;
}): void;
/** Test seam. */
export declare function __resetReplay(): void;
