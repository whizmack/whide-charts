export interface ToastPayload {
    type: "info" | "success" | "warning" | "error";
    title: string;
    message: string;
}
type Listener = (t: ToastPayload) => void;
export declare const toast: {
    /** Fire a toast (the ToastContainer picks it up). */
    fire(type: ToastPayload["type"], title: string, message: string): void;
    success(title: string, message: string): void;
    error(title: string, message: string): void;
    info(title: string, message: string): void;
    warning(title: string, message: string): void;
    /** Subscribe — returns unsubscribe function. */
    subscribe(fn: Listener): () => void;
};
export {};
