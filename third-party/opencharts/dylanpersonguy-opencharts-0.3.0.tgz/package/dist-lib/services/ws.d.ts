import { ConnectionState } from '../adapter/types.ts';
import { ChannelHandler } from './demo/bus.ts';
/**
 * Streaming client.
 *
 * Adapters expose one `subscribe` per concern (market data, trading). The
 * terminal consumes four named channels — `market-data`, `positions`, `orders`
 * and `account` — so this translates between the two, and owns the connection
 * lifecycle. It exposes the same surface the app has always used, so no
 * consumer had to change when the adapter layer landed.
 */
export type { ConnectionState };
export type WsHandler = ChannelHandler;
declare class AdapterWsClient {
    private _state;
    private stateListeners;
    private teardown;
    private connected;
    constructor();
    get state(): ConnectionState;
    private setState;
    private attach;
    private detach;
    connect(_token?: string): void;
    disconnect(): void;
    reauthenticate(_token: string): void;
    subscribe(channel: string, handler: WsHandler): () => void;
    subscribeAccounts(_accountIds: string[]): void;
    setSymbolInterest(symbols: string[]): void;
    onStateChange(cb: (s: ConnectionState) => void): () => void;
    /** Push an event onto a channel directly (used by tests and tooling). */
    emit(channel: string, event: unknown): void;
}
export declare const wsClient: AdapterWsClient;
