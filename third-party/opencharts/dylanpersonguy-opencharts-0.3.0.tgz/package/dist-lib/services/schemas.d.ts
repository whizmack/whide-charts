import { z } from 'zod';
export declare const UserSchema: z.ZodObject<{
    id: z.ZodString;
    email: z.ZodString;
    firstName: z.ZodNullable<z.ZodString>;
    lastName: z.ZodNullable<z.ZodString>;
    roles: z.ZodArray<z.ZodString, "many">;
    status: z.ZodString;
    createdAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    id: string;
    status: string;
    email: string;
    firstName: string | null;
    lastName: string | null;
    roles: string[];
    createdAt: string;
}, {
    id: string;
    status: string;
    email: string;
    firstName: string | null;
    lastName: string | null;
    roles: string[];
    createdAt: string;
}>;
export type User = z.infer<typeof UserSchema>;
export declare const AuthResponseSchema: z.ZodObject<{
    accessToken: z.ZodString;
    refreshToken: z.ZodString;
    user: z.ZodObject<{
        id: z.ZodString;
        email: z.ZodString;
        firstName: z.ZodNullable<z.ZodString>;
        lastName: z.ZodNullable<z.ZodString>;
        roles: z.ZodArray<z.ZodString, "many">;
        status: z.ZodString;
        createdAt: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
        status: string;
        email: string;
        firstName: string | null;
        lastName: string | null;
        roles: string[];
        createdAt: string;
    }, {
        id: string;
        status: string;
        email: string;
        firstName: string | null;
        lastName: string | null;
        roles: string[];
        createdAt: string;
    }>;
}, "strip", z.ZodTypeAny, {
    accessToken: string;
    refreshToken: string;
    user: {
        id: string;
        status: string;
        email: string;
        firstName: string | null;
        lastName: string | null;
        roles: string[];
        createdAt: string;
    };
}, {
    accessToken: string;
    refreshToken: string;
    user: {
        id: string;
        status: string;
        email: string;
        firstName: string | null;
        lastName: string | null;
        roles: string[];
        createdAt: string;
    };
}>;
export type AuthResponse = z.infer<typeof AuthResponseSchema>;
export declare const AccountSchema: z.ZodObject<{
    id: z.ZodString;
    userId: z.ZodString;
    templateId: z.ZodString;
    label: z.ZodNullable<z.ZodString>;
    status: z.ZodString;
    balance: z.ZodNumber;
    equity: z.ZodNumber;
    margin: z.ZodNumber;
    freeMargin: z.ZodNumber;
    phase: z.ZodString;
    startDate: z.ZodString;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
    isHftMode: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
    template: z.ZodOptional<z.ZodObject<{
        name: z.ZodString;
        startingBalance: z.ZodNumber;
        instrumentType: z.ZodOptional<z.ZodEnum<["FOREX", "FUTURES", "CRYPTO", "EQUITIES"]>>;
    }, "strip", z.ZodTypeAny, {
        name: string;
        startingBalance: number;
        instrumentType?: "FOREX" | "FUTURES" | "CRYPTO" | "EQUITIES" | undefined;
    }, {
        name: string;
        startingBalance: number;
        instrumentType?: "FOREX" | "FUTURES" | "CRYPTO" | "EQUITIES" | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    id: string;
    status: string;
    createdAt: string;
    userId: string;
    templateId: string;
    label: string | null;
    balance: number;
    equity: number;
    margin: number;
    freeMargin: number;
    phase: string;
    startDate: string;
    updatedAt: string;
    isHftMode: boolean;
    template?: {
        name: string;
        startingBalance: number;
        instrumentType?: "FOREX" | "FUTURES" | "CRYPTO" | "EQUITIES" | undefined;
    } | undefined;
}, {
    id: string;
    status: string;
    createdAt: string;
    userId: string;
    templateId: string;
    label: string | null;
    balance: number;
    equity: number;
    margin: number;
    freeMargin: number;
    phase: string;
    startDate: string;
    updatedAt: string;
    isHftMode?: boolean | undefined;
    template?: {
        name: string;
        startingBalance: number;
        instrumentType?: "FOREX" | "FUTURES" | "CRYPTO" | "EQUITIES" | undefined;
    } | undefined;
}>;
export type Account = z.infer<typeof AccountSchema>;
export declare const AccountStatsSchema: z.ZodObject<{
    totalTrades: z.ZodNumber;
    winRate: z.ZodNumber;
    avgWin: z.ZodNumber;
    avgLoss: z.ZodNumber;
    profitFactor: z.ZodNumber;
    bestTrade: z.ZodNumber;
    worstTrade: z.ZodNumber;
    sharpeRatio: z.ZodOptional<z.ZodNumber>;
    maxDrawdown: z.ZodOptional<z.ZodNumber>;
    expectancy: z.ZodOptional<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    totalTrades: number;
    winRate: number;
    avgWin: number;
    avgLoss: number;
    profitFactor: number;
    bestTrade: number;
    worstTrade: number;
    sharpeRatio?: number | undefined;
    maxDrawdown?: number | undefined;
    expectancy?: number | undefined;
}, {
    totalTrades: number;
    winRate: number;
    avgWin: number;
    avgLoss: number;
    profitFactor: number;
    bestTrade: number;
    worstTrade: number;
    sharpeRatio?: number | undefined;
    maxDrawdown?: number | undefined;
    expectancy?: number | undefined;
}>;
export type AccountStats = z.infer<typeof AccountStatsSchema>;
export declare const LedgerEntrySchema: z.ZodObject<{
    id: z.ZodString;
    accountId: z.ZodString;
    type: z.ZodString;
    amount: z.ZodNumber;
    balance: z.ZodNumber;
    description: z.ZodNullable<z.ZodString>;
    referenceId: z.ZodNullable<z.ZodString>;
    createdAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    type: string;
    id: string;
    createdAt: string;
    balance: number;
    accountId: string;
    amount: number;
    description: string | null;
    referenceId: string | null;
}, {
    type: string;
    id: string;
    createdAt: string;
    balance: number;
    accountId: string;
    amount: number;
    description: string | null;
    referenceId: string | null;
}>;
export type LedgerEntry = z.infer<typeof LedgerEntrySchema>;
export declare const EquityPointSchema: z.ZodObject<{
    equity: z.ZodNumber;
    balance: z.ZodNumber;
    timestamp: z.ZodString;
}, "strip", z.ZodTypeAny, {
    balance: number;
    equity: number;
    timestamp: string;
}, {
    balance: number;
    equity: number;
    timestamp: string;
}>;
export type EquityPoint = z.infer<typeof EquityPointSchema>;
export declare const OrderSchema: z.ZodObject<{
    id: z.ZodString;
    accountId: z.ZodString;
    symbolName: z.ZodString;
    side: z.ZodEnum<["BUY", "SELL"]>;
    type: z.ZodEnum<["MARKET", "LIMIT", "STOP"]>;
    quantity: z.ZodNumber;
    price: z.ZodNullable<z.ZodNumber>;
    stopPrice: z.ZodNullable<z.ZodNumber>;
    takeProfit: z.ZodNullable<z.ZodNumber>;
    stopLoss: z.ZodNullable<z.ZodNumber>;
    status: z.ZodString;
    filledQuantity: z.ZodNumber;
    avgFillPrice: z.ZodNullable<z.ZodNumber>;
    comment: z.ZodNullable<z.ZodString>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    type: "MARKET" | "LIMIT" | "STOP";
    id: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    accountId: string;
    symbolName: string;
    side: "BUY" | "SELL";
    quantity: number;
    price: number | null;
    stopPrice: number | null;
    takeProfit: number | null;
    stopLoss: number | null;
    filledQuantity: number;
    avgFillPrice: number | null;
    comment: string | null;
}, {
    type: "MARKET" | "LIMIT" | "STOP";
    id: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    accountId: string;
    symbolName: string;
    side: "BUY" | "SELL";
    quantity: number;
    price: number | null;
    stopPrice: number | null;
    takeProfit: number | null;
    stopLoss: number | null;
    filledQuantity: number;
    avgFillPrice: number | null;
    comment: string | null;
}>;
export type Order = z.infer<typeof OrderSchema>;
export declare const PositionSchema: z.ZodObject<{
    id: z.ZodString;
    accountId: z.ZodString;
    symbolName: z.ZodString;
    side: z.ZodEnum<["LONG", "SHORT"]>;
    quantity: z.ZodNumber;
    entryPrice: z.ZodNumber;
    currentPrice: z.ZodOptional<z.ZodNumber>;
    unrealizedPnl: z.ZodNumber;
    margin: z.ZodDefault<z.ZodNumber>;
    contractSize: z.ZodOptional<z.ZodNumber>;
    openedAt: z.ZodString;
    takeProfit: z.ZodNullable<z.ZodNumber>;
    stopLoss: z.ZodNullable<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    id: string;
    margin: number;
    accountId: string;
    symbolName: string;
    side: "LONG" | "SHORT";
    quantity: number;
    takeProfit: number | null;
    stopLoss: number | null;
    entryPrice: number;
    unrealizedPnl: number;
    openedAt: string;
    currentPrice?: number | undefined;
    contractSize?: number | undefined;
}, {
    id: string;
    accountId: string;
    symbolName: string;
    side: "LONG" | "SHORT";
    quantity: number;
    takeProfit: number | null;
    stopLoss: number | null;
    entryPrice: number;
    unrealizedPnl: number;
    openedAt: string;
    margin?: number | undefined;
    currentPrice?: number | undefined;
    contractSize?: number | undefined;
}>;
export type Position = z.infer<typeof PositionSchema>;
export declare const FillSchema: z.ZodObject<{
    id: z.ZodString;
    orderId: z.ZodString;
    accountId: z.ZodString;
    symbolName: z.ZodString;
    side: z.ZodString;
    quantity: z.ZodNumber;
    price: z.ZodNumber;
    commission: z.ZodNumber;
    realizedPnl: z.ZodNullable<z.ZodNumber>;
    createdAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    id: string;
    createdAt: string;
    accountId: string;
    symbolName: string;
    side: string;
    quantity: number;
    price: number;
    orderId: string;
    commission: number;
    realizedPnl: number | null;
}, {
    id: string;
    createdAt: string;
    accountId: string;
    symbolName: string;
    side: string;
    quantity: number;
    price: number;
    orderId: string;
    commission: number;
    realizedPnl: number | null;
}>;
export type Fill = z.infer<typeof FillSchema>;
export declare const ClosedPositionSchema: z.ZodObject<{
    id: z.ZodString;
    accountId: z.ZodOptional<z.ZodString>;
    symbolName: z.ZodString;
    side: z.ZodString;
    quantity: z.ZodNumber;
    entryPrice: z.ZodNumber;
    exitPrice: z.ZodNumber;
    realizedPnl: z.ZodNumber;
    commission: z.ZodNumber;
    swap: z.ZodNumber;
    openedAt: z.ZodString;
    closedAt: z.ZodNullable<z.ZodString>;
    isPartialClose: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    id: string;
    symbolName: string;
    side: string;
    quantity: number;
    entryPrice: number;
    openedAt: string;
    commission: number;
    realizedPnl: number;
    exitPrice: number;
    swap: number;
    closedAt: string | null;
    accountId?: string | undefined;
    isPartialClose?: boolean | undefined;
}, {
    id: string;
    symbolName: string;
    side: string;
    quantity: number;
    entryPrice: number;
    openedAt: string;
    commission: number;
    realizedPnl: number;
    exitPrice: number;
    swap: number;
    closedAt: string | null;
    accountId?: string | undefined;
    isPartialClose?: boolean | undefined;
}>;
export type ClosedPosition = z.infer<typeof ClosedPositionSchema>;
export declare const SymbolSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    displayName: z.ZodNullable<z.ZodString>;
    category: z.ZodString;
    contractSize: z.ZodNumber;
    tickSize: z.ZodNumber;
    tickValue: z.ZodNumber;
    marginPercent: z.ZodNumber;
    maxLeverage: z.ZodNumber;
    commission: z.ZodNumber;
    swapLong: z.ZodNumber;
    swapShort: z.ZodNumber;
    tradingHoursStart: z.ZodNullable<z.ZodString>;
    tradingHoursEnd: z.ZodNullable<z.ZodString>;
    isActive: z.ZodBoolean;
}, "strip", z.ZodTypeAny, {
    name: string;
    id: string;
    displayName: string | null;
    contractSize: number;
    commission: number;
    category: string;
    tickSize: number;
    tickValue: number;
    marginPercent: number;
    maxLeverage: number;
    swapLong: number;
    swapShort: number;
    tradingHoursStart: string | null;
    tradingHoursEnd: string | null;
    isActive: boolean;
}, {
    name: string;
    id: string;
    displayName: string | null;
    contractSize: number;
    commission: number;
    category: string;
    tickSize: number;
    tickValue: number;
    marginPercent: number;
    maxLeverage: number;
    swapLong: number;
    swapShort: number;
    tradingHoursStart: string | null;
    tradingHoursEnd: string | null;
    isActive: boolean;
}>;
export type Symbol = z.infer<typeof SymbolSchema>;
export declare const CandleSchema: z.ZodObject<{
    time: z.ZodNumber;
    open: z.ZodNumber;
    high: z.ZodNumber;
    low: z.ZodNumber;
    close: z.ZodNumber;
    volume: z.ZodNumber;
    timestamp: z.ZodOptional<z.ZodUnion<[z.ZodNumber, z.ZodString]>>;
}, "strip", z.ZodTypeAny, {
    open: number;
    time: number;
    high: number;
    low: number;
    close: number;
    volume: number;
    timestamp?: string | number | undefined;
}, {
    open: number;
    time: number;
    high: number;
    low: number;
    close: number;
    volume: number;
    timestamp?: string | number | undefined;
}>;
export type Candle = z.infer<typeof CandleSchema>;
export declare const PaginatedSchema: <T extends z.ZodTypeAny>(itemSchema: T) => z.ZodObject<{
    data: z.ZodArray<T, "many">;
    total: z.ZodNumber;
    page: z.ZodNumber;
    pageSize: z.ZodNumber;
    totalPages: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    data: T["_output"][];
    total: number;
    page: number;
    pageSize: number;
    totalPages: number;
}, {
    data: T["_input"][];
    total: number;
    page: number;
    pageSize: number;
    totalPages: number;
}>;
export declare const PlaceOrderInputSchema: z.ZodObject<{
    accountId: z.ZodString;
    symbol: z.ZodString;
    side: z.ZodEnum<["BUY", "SELL"]>;
    type: z.ZodEnum<["MARKET", "LIMIT", "STOP", "STOP_LIMIT"]>;
    quantity: z.ZodNumber;
    price: z.ZodOptional<z.ZodNumber>;
    stopPrice: z.ZodOptional<z.ZodNumber>;
    takeProfit: z.ZodOptional<z.ZodNumber>;
    stopLoss: z.ZodOptional<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    symbol: string;
    type: "MARKET" | "LIMIT" | "STOP" | "STOP_LIMIT";
    accountId: string;
    side: "BUY" | "SELL";
    quantity: number;
    price?: number | undefined;
    stopPrice?: number | undefined;
    takeProfit?: number | undefined;
    stopLoss?: number | undefined;
}, {
    symbol: string;
    type: "MARKET" | "LIMIT" | "STOP" | "STOP_LIMIT";
    accountId: string;
    side: "BUY" | "SELL";
    quantity: number;
    price?: number | undefined;
    stopPrice?: number | undefined;
    takeProfit?: number | undefined;
    stopLoss?: number | undefined;
}>;
export type PlaceOrderInput = z.infer<typeof PlaceOrderInputSchema>;
export declare const LoginInputSchema: z.ZodObject<{
    email: z.ZodString;
    password: z.ZodString;
}, "strip", z.ZodTypeAny, {
    email: string;
    password: string;
}, {
    email: string;
    password: string;
}>;
export type LoginInput = z.infer<typeof LoginInputSchema>;
export declare const RegisterInputSchema: z.ZodObject<{
    email: z.ZodString;
    password: z.ZodString;
    firstName: z.ZodString;
    lastName: z.ZodString;
}, "strip", z.ZodTypeAny, {
    email: string;
    firstName: string;
    lastName: string;
    password: string;
}, {
    email: string;
    firstName: string;
    lastName: string;
    password: string;
}>;
export type RegisterInput = z.infer<typeof RegisterInputSchema>;
