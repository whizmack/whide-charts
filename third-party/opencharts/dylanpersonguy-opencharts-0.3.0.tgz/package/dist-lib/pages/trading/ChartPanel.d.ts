import { IChartApi, ISeriesApi } from 'lightweight-charts';
import { IndicatorType } from '../../lib/indicators.ts';
import { Candle, Order, Position, Symbol } from '../../services/schemas.ts';
import { DrawingLine, DrawingTool, MagnetMode, Timeframe } from './constants.ts';
export interface ChartPanelProps {
    candles: Candle[];
    selectedSymbol: string;
    timeframe: Timeframe;
    isDark: boolean;
    activeIndicators: IndicatorType[];
    drawingTool: DrawingTool;
    drawings: DrawingLine[];
    onAddDrawing: (d: DrawingLine) => void;
    onUpdateDrawing?: (d: DrawingLine) => void;
    onRemoveDrawing?: (id: string) => void;
    /** Called when a drawing completes/cancels so the parent can disarm the tool. */
    onDrawingComplete?: () => void;
    /** Alt+T/H/F/R keyboard shortcut pressed — arm the given tool. */
    onDrawingToolSelect?: (t: DrawingTool) => void;
    onUndoDrawing?: () => void;
    onRedoDrawing?: () => void;
    /** Snap drawing anchors to candle O/H/L/C — off / weak (near) / strong (always). */
    magnetMode?: MagnetMode;
    /** Keep the drawing tool armed after each placement. */
    stayInDrawingMode?: boolean;
    positions: Position[];
    orders: Order[];
    tick?: {
        bid: number;
        ask: number;
        timestamp: number;
    };
    liveCandle?: {
        open: number;
        high: number;
        low: number;
        close: number;
        volume: number;
        timestamp: number;
    };
    pipDigits: number;
    symbolInfo?: Symbol;
    onModifyPosition?: (positionId: string, mods: {
        takeProfit?: number | null;
        stopLoss?: number | null;
    }) => void;
    replayTradeEvents?: Array<{
        id: string;
        type: "entry" | "exit" | "violation";
        timestamp: string;
        symbolName: string | null;
        side: string | null;
        price: number | null;
        pnl: number | null;
        ruleCode?: string;
    }>;
    activePlugins?: string[];
    /** Toggle a chart plugin (session breaks etc.) — used by the settings dialog. */
    onTogglePlugin?: (id: string) => void;
    /** Account equity — feeds the position tool's $-risk / size readout. */
    accountEquity?: number;
    /** Active account — enables the challenge-aware level overlay. */
    accountId?: string | null;
    /** Context-menu quick order at the clicked price (opens the confirm dialog). */
    onQuickOrder?: (side: "BUY" | "SELL", type: "LIMIT" | "STOP", price: number) => void;
    /** Context-menu "Remove N drawings". */
    onClearDrawings?: () => void;
    /** Context-menu "Remove N indicators". */
    onClearIndicators?: () => void;
    /**
     * Session replay is active — candles are a historical slice, so the
     * staleness watchdog must not treat the old last-bar as a data gap.
     */
    isReplaying?: boolean;
    /** Host has no calendar source. */
    showNews?: boolean;
    /** Last traded candle close when the host does not supply bid/ask quotes. */
    showLastPrice?: boolean;
    onChartReady?: (value: {
        chart: IChartApi;
        series: ISeriesApi<"Candlestick">;
    } | null) => void;
    keyboardEnabled?: boolean;
    showDrawingTools?: boolean;
    drawingRailHost?: HTMLElement | null;
    onMagnetToggle?: () => void;
    onStayInDrawingModeToggle?: () => void;
}
export declare function ChartPanel({ candles, selectedSymbol, timeframe, isDark, activeIndicators, drawingTool, drawings, onAddDrawing, onUpdateDrawing, onRemoveDrawing, onDrawingComplete, onDrawingToolSelect, onUndoDrawing, onRedoDrawing, magnetMode, stayInDrawingMode, positions, orders, tick, liveCandle, pipDigits, symbolInfo, onModifyPosition, replayTradeEvents, activePlugins, onTogglePlugin, accountEquity, accountId, onQuickOrder, onClearDrawings, onClearIndicators, isReplaying, showNews, showLastPrice, onChartReady, keyboardEnabled, showDrawingTools, drawingRailHost, onMagnetToggle, onStayInDrawingModeToggle, }: ChartPanelProps): import('react').JSX.Element;
