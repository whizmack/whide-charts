import { ISeriesApi } from 'lightweight-charts';
import { RefObject } from 'react';
import { Position } from '../../services/schemas.ts';
export interface ChallengeLevelFlags {
    /** Master switch — when false nothing renders and metrics aren't fetched. */
    enabled: boolean;
    dailyLoss: boolean;
    maxDrawdown: boolean;
    profitTarget: boolean;
}
export declare function useChallengeLevels(opts: {
    accountId: string | null | undefined;
    selectedSymbol: string;
    positions: Position[];
    tick: {
        bid: number;
        ask: number;
    } | undefined;
    contractSize: number;
    accountEquity: number;
    candleSeriesRef: RefObject<ISeriesApi<"Candlestick"> | null>;
    flags: ChallengeLevelFlags;
    chartEpoch: number;
}): void;
