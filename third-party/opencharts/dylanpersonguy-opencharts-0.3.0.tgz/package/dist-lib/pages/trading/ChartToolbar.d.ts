import { LucideIcon } from 'lucide-react';
import { IndicatorType } from '../../lib/indicators.ts';
import { DrawingLine, DrawingTool, MagnetMode, Timeframe } from './constants.ts';
export interface ChartToolbarProps {
    selectedSymbol: string;
    symbols: Array<{
        id?: string;
        name: string;
        displayName?: string | null;
        assetClass?: string;
        baseCurrency?: string;
        quoteCurrency?: string;
        category?: string;
        isActive?: boolean;
    }>;
    onSymbolChange: (s: string) => void;
    timeframe: Timeframe;
    onTimeframeChange: (tf: Timeframe) => void;
    activeIndicators: IndicatorType[];
    onToggleIndicator: (type: IndicatorType) => void;
    showIndicatorMenu: boolean;
    onToggleIndicatorMenu: () => void;
    drawingTool: DrawingTool;
    onDrawingTool: (t: DrawingTool) => void;
    drawings: DrawingLine[];
    onClearDrawings: () => void;
    rightPanel: string;
    onRightPanel: (p: "order" | "dom" | "watchlist" | "news" | "tv-analysis") => void;
    showRightPanel: boolean;
    onToggleRightPanel: () => void;
    tick?: {
        bid: number;
        ask: number;
        timestamp: number;
    };
    symbolInfo?: {
        tickSize?: number;
        pipSize?: number;
        lotSize?: number;
        minLot?: number;
        maxLot?: number;
        lotStep?: number;
        contractSize?: number;
        marginPercent?: number;
        commission?: number;
    };
    isReplaying?: boolean;
    /** Account whose sessions can be replayed — mounts the replay HUD when set. */
    replayAccountId?: string | null;
    activePlugins?: string[];
    onTogglePlugin?: (id: string) => void;
    /** Replace the full indicator list (template load). Enables the templates menu. */
    onSetIndicators?: (indicators: IndicatorType[]) => void;
    /** Replace the full plugin list (template load). Enables the templates menu. */
    onSetPlugins?: (ids: string[]) => void;
    magnetMode?: MagnetMode;
    onCycleMagnet?: () => void;
    stayInDrawingMode?: boolean;
    onToggleStayInDrawingMode?: () => void;
}
export declare function ChartToolbar({ selectedSymbol, symbols, onSymbolChange, timeframe, onTimeframeChange, activeIndicators, onToggleIndicator, showIndicatorMenu, onToggleIndicatorMenu, drawingTool, onDrawingTool, drawings, onClearDrawings, rightPanel, onRightPanel, showRightPanel, onToggleRightPanel, tick, symbolInfo, isReplaying, replayAccountId, activePlugins, onTogglePlugin, onSetIndicators, onSetPlugins, magnetMode, onCycleMagnet, stayInDrawingMode, onToggleStayInDrawingMode, }: ChartToolbarProps): import('react').JSX.Element;
export declare function ToolButton({ icon: Icon, tooltip, active, onClick, }: {
    icon: LucideIcon;
    tooltip: string;
    active: boolean;
    onClick: () => void;
}): import('react').JSX.Element;
