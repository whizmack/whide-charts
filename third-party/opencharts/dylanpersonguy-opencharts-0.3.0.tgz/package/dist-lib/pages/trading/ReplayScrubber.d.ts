export declare function ReplayScrubber({ accountId }: {
    accountId: string;
}): import('react').JSX.Element | null;
