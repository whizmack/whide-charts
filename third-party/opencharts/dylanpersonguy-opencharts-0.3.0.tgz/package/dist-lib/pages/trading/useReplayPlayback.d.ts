/**
 * Drives the client-side replay clock using requestAnimationFrame.
 *
 * - Advances replayCursorTimestamp at replaySpeed × real time.
 * - Throttles Zustand writes to STORE_SYNC_MS to avoid per-frame re-renders.
 * - Debounces server PATCH to SERVER_SYNC_MS for cursor persistence.
 * - Advances up to MAX_TICKS_PER_FRAME tick indices per frame (chunked).
 * - Detects external seeks by comparing store cursor to local cursor ref.
 * - Auto-stops and emits "stopped" when the cursor reaches the end of the buffer.
 */
export declare function useReplayPlayback(accountId: string): void;
