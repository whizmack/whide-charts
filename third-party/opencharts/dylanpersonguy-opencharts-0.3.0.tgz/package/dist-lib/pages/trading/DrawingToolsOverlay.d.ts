import { DrawingLine } from './constants.ts';
export interface DrawingToolbarProps {
    drawing: DrawingLine;
    onUpdate: (d: DrawingLine) => void;
    onClone: () => void;
    onRemove: () => void;
    onOpenSettings: () => void;
}
export declare function DrawingFloatingToolbar({ drawing, onUpdate, onClone, onRemove, onOpenSettings, }: DrawingToolbarProps): import('react').JSX.Element;
export interface DrawingSettingsProps {
    drawing: DrawingLine;
    /** Current chart timeframe — stamped as createdTf when scoping visibility. */
    currentTf: string;
    onUpdate: (d: DrawingLine) => void;
    onRemove: () => void;
    onClose: () => void;
}
export declare function DrawingSettingsDialog({ drawing, currentTf, onUpdate, onRemove, onClose, }: DrawingSettingsProps): import('react').JSX.Element;
export interface DrawingContextMenuProps {
    drawing: DrawingLine;
    x: number;
    y: number;
    onClose: () => void;
    onSettings: () => void;
    onDuplicate: () => void;
    onReorder: (dir: "front" | "back") => void;
    onToggleLock: () => void;
    onToggleAlert: () => void;
    onRemove: () => void;
}
export declare function DrawingContextMenu({ drawing, x, y, onClose, onSettings, onDuplicate, onReorder, onToggleLock, onToggleAlert, onRemove, }: DrawingContextMenuProps): import('react').JSX.Element;
