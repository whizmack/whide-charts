import { RefObject } from 'react';
import { IChartApi, ISeriesApi, IPriceLine } from 'lightweight-charts';
import { DrawingTool } from './constants.ts';
export interface DragPriceState {
    price: number;
    y: number;
    field: "TP" | "SL";
    pnlUsd: number;
}
export interface SlTpLineEntry {
    positionId: string;
    field: "takeProfit" | "stopLoss";
    line: IPriceLine;
    price: number;
    entryPrice: number;
    quantity: number;
    side: string;
}
export interface SymbolInfo {
    contractSize?: number;
    [key: string]: unknown;
}
export declare function useSlTpDrag(containerRef: RefObject<HTMLDivElement | null>, chartRef: RefObject<IChartApi | null>, candleSeriesRef: RefObject<ISeriesApi<"Candlestick"> | null>, slTpLinesRef: RefObject<Map<string, SlTpLineEntry>>, drawingTool: DrawingTool, onModifyPosition: ((posId: string, mods: {
    takeProfit?: number | null;
    stopLoss?: number | null;
}) => void) | undefined, pipDigits: number, symbolInfo: SymbolInfo | null | undefined, chartEpoch: number): DragPriceState | null;
