import { PlaceOrderInput } from '../../services/schemas.ts';
type ConfirmableOrder = PlaceOrderInput & {
    _submit: () => Promise<unknown>;
};
export interface OrderPanelProps {
    symbol: string;
    symbolInfo?: {
        name?: string;
        description?: string;
        pipSize?: number;
        pricescale?: number;
        contractSize?: number;
        marginPercent?: number;
        commission?: number;
        [k: string]: unknown;
    };
    tick?: {
        bid: number;
        ask: number;
        timestamp: number;
    };
    accountId: string | null;
    oneClick?: boolean;
    onToggleOneClick?: () => void;
    onConfirmOrder?: (order: ConfirmableOrder) => void;
    accountBalance?: number;
    isFeedConnected?: boolean;
    soundMuted?: boolean;
    onToggleMute?: () => void;
    onOrderSuccess?: () => void;
}
export declare function OrderPanel({ symbol, symbolInfo, tick, accountId, oneClick, onToggleOneClick, onConfirmOrder, accountBalance, isFeedConnected, soundMuted, onToggleMute, onOrderSuccess, }: OrderPanelProps): import('react').JSX.Element;
export {};
