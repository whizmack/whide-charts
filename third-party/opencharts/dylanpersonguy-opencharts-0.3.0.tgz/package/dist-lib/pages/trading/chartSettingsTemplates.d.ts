import { ChartPreferences } from '../../hooks/useChartPreferences.ts';
export interface ChartSettingsTemplate {
    id: string;
    name: string;
    preferences: Partial<ChartPreferences>;
}
export declare function readChartSettingsTemplates(): ChartSettingsTemplate[];
export declare function saveChartSettingsTemplate(name: string, prefs: ChartPreferences): ChartSettingsTemplate[];
export declare function deleteChartSettingsTemplate(id: string): ChartSettingsTemplate[];
