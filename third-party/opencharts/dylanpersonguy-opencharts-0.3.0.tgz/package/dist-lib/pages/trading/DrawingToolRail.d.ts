import { DrawingTool } from './constants.ts';
export declare function DrawingToolRail({ drawingTool, onDrawingTool, }: {
    drawingTool: DrawingTool;
    onDrawingTool: (t: DrawingTool) => void;
}): import('react').JSX.Element;
