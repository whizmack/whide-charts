import { DrawingTool } from './constants.ts';
export declare function DrawingToolRail({ drawingTool, onDrawingTool, magnetActive, onMagnetToggle, stayActive, onStayToggle, }: {
    magnetActive?: boolean;
    onMagnetToggle?: () => void;
    stayActive?: boolean;
    onStayToggle?: () => void;
    drawingTool: DrawingTool;
    onDrawingTool: (t: DrawingTool) => void;
}): import('react').JSX.Element;
