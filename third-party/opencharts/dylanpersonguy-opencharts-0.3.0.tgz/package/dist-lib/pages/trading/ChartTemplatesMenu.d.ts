import { IndicatorType } from '../../lib/indicators.ts';
export interface ChartTemplatesMenuProps {
    activeIndicators: IndicatorType[];
    onSetIndicators: (indicators: IndicatorType[]) => void;
    activePlugins: string[];
    onSetPlugins: (ids: string[]) => void;
}
export declare function ChartTemplatesMenu(props: ChartTemplatesMenuProps): import('react').JSX.Element;
