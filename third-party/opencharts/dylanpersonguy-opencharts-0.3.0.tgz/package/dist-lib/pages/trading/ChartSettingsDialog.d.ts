import { ChartPreferences } from '../../hooks/useChartPreferences.ts';
export interface ChartSettingsDialogProps {
    open: boolean;
    onClose: () => void;
    prefs: ChartPreferences;
    isDark: boolean;
    activePlugins: string[];
    onTogglePlugin?: (id: string) => void;
    onOpenNewsConfig: () => void;
    /** Whether the account has challenge metrics (controls the Challenge tab note). */
    hasAccount: boolean;
}
export declare function ChartSettingsDialog(props: ChartSettingsDialogProps): import('react').ReactPortal | null;
