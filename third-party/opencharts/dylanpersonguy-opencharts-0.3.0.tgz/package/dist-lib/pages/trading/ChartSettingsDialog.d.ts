import { ChartPreferences } from '../../hooks/useChartPreferences.ts';
export interface ChartSettingsDialogProps {
    open: boolean;
    onClose: () => void;
    prefs: ChartPreferences;
    isDark: boolean;
    activePlugins: string[];
    onTogglePlugin?: (id: string) => void;
    onOpenNewsConfig: () => void;
    hasAccount: boolean;
}
export declare function ChartSettingsDialog(props: ChartSettingsDialogProps): import('react').ReactPortal | null;
