import { DrawingLine } from './constants.ts';
export interface ObjectTreePanelProps {
    drawings: DrawingLine[];
    selectedIds: string[];
    pipDigits: number;
    currentTf: string;
    onSelect: (d: DrawingLine) => void;
    onUpdate: (d: DrawingLine) => void;
    onRemove: (id: string) => void;
    onReorder: (d: DrawingLine, dir: "front" | "back") => void;
    onClose: () => void;
}
/** TradingView-style object tree: every drawing on the symbol, managed per row. */
export declare function ObjectTreePanel({ drawings, selectedIds, pipDigits, currentTf, onSelect, onUpdate, onRemove, onReorder, onClose, }: ObjectTreePanelProps): import('react').JSX.Element;
