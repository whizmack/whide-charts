export declare function DOMPanel({ symbol, tick, }: {
    symbol: string;
    tick?: {
        bid: number;
        ask: number;
    };
}): import('react').JSX.Element;
