import { api } from '../../services/api.ts';
import { Candle } from '../../services/schemas.ts';
type ReplaySessionData = NonNullable<Awaited<ReturnType<typeof api.replayGetSession>>>;
type ReplayTradeEvents = ReplaySessionData["tradeEvents"];
/**
 * Bridges a replay session into chart-ready data.
 *
 * - Focuses the chart on the session's primary symbol when replay starts.
 * - Slices the 1m tick buffer up to the playback cursor, so the chart reveals
 *   bars progressively as `useReplayPlayback` advances the cursor.
 * - Detects empty sessions (no trades / no stored candles for that day) and
 *   stops the replay with an explanatory toast instead of silently idling.
 *
 * While `replayCandles` is non-null the caller must suppress the live feed
 * (tick / liveCandle props) so real-time data can't paint over the playback.
 */
export declare function useReplayChartData(accountId: string | null): {
    replayCandles: Candle[] | null;
    replayTradeEvents: ReplayTradeEvents | undefined;
};
export {};
