import { DrawingSettingsDraft, DrawingSettingsErrors } from '../drawingSettingsModel.ts';
type Update = (patch: Partial<DrawingSettingsDraft>) => void;
export declare function CoordinatesTab({ draft, errors, update }: {
    draft: DrawingSettingsDraft;
    errors: DrawingSettingsErrors;
    update: Update;
}): import('react').JSX.Element;
export {};
