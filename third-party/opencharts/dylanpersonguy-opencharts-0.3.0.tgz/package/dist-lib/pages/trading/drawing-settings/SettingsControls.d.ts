import { ReactNode, RefObject } from 'react';
import { DrawingLineStyle } from '../constants.ts';
import { DrawingSettingsTab } from '../drawingSettingsModel.ts';
export declare function SettingsField({ label, children, className }: {
    label: ReactNode;
    children: ReactNode;
    className?: string;
}): import('react').JSX.Element;
export declare function NumberField({ label, value, onChange, error, step }: {
    label: string;
    value: number | undefined;
    onChange: (value: number) => void;
    error?: string;
    step?: number | "any";
}): import('react').JSX.Element;
export declare function SelectField({ label, value, onChange, children }: {
    label: string;
    value: string | number;
    onChange: (value: string) => void;
    children: ReactNode;
}): import('react').JSX.Element;
export declare function CheckboxField({ label, checked, onChange, children }: {
    label: string;
    checked: boolean;
    onChange: (checked: boolean) => void;
    children?: ReactNode;
}): import('react').JSX.Element;
export declare function ColorControl({ label, value, onChange, opacity, onOpacity }: {
    label: string;
    value: string;
    onChange: (value: string) => void;
    opacity?: number;
    onOpacity?: (value: number) => void;
}): import('react').JSX.Element;
export declare function LineControl({ label, color, width, style, opacity, onChange }: {
    label: string;
    color: string;
    width: number;
    style: DrawingLineStyle;
    opacity: number;
    onChange: (patch: {
        color?: string;
        width?: number;
        lineStyle?: DrawingLineStyle;
        opacity?: number;
    }) => void;
}): import('react').JSX.Element;
export declare function SectionLabel({ children }: {
    children: ReactNode;
}): import('react').JSX.Element;
export declare function TabList({ tabs, active, onChange, initialFocusRef }: {
    tabs: DrawingSettingsTab[];
    active: DrawingSettingsTab;
    onChange: (tab: DrawingSettingsTab) => void;
    initialFocusRef: RefObject<HTMLButtonElement | null>;
}): import('react').JSX.Element;
