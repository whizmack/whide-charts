export declare function drawingPortalRoot(): Element;
