import { DrawingSettingsDraft } from '../drawingSettingsModel.ts';
export declare function TextTab({ draft, update }: {
    draft: DrawingSettingsDraft;
    update: (patch: Partial<DrawingSettingsDraft>) => void;
}): import('react').JSX.Element;
