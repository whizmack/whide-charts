import { DrawingSettingsDraft } from '../drawingSettingsModel.ts';
export declare function VisibilityTab({ draft, currentTf, update }: {
    draft: DrawingSettingsDraft;
    currentTf: string;
    update: (patch: Partial<DrawingSettingsDraft>) => void;
}): import('react').JSX.Element;
