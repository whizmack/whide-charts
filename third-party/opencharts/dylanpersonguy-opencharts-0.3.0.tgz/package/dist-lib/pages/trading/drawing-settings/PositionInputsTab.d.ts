import { DrawingSettingsDraft } from '../drawingSettingsModel.ts';
export declare function PositionInputsTab({ draft, errors, update }: {
    draft: DrawingSettingsDraft;
    errors: Partial<Record<keyof DrawingSettingsDraft, string>>;
    update: (patch: Partial<DrawingSettingsDraft>) => void;
}): import('react').JSX.Element;
