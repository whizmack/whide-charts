import { DrawingLine } from '../constants.ts';
export interface DrawingSettingsDialogProps {
    drawing: DrawingLine;
    currentTf: string;
    onPreview: (drawing: DrawingLine) => void;
    onCommit: (drawing: DrawingLine) => void;
    onClose: () => void;
}
export declare function DrawingSettingsDialog({ drawing, currentTf: _currentTf, onPreview, onCommit, onClose, }: DrawingSettingsDialogProps): import('react').ReactPortal;
