export declare function observeToolbarLayout(element: HTMLElement, onChange: () => void): () => void;
