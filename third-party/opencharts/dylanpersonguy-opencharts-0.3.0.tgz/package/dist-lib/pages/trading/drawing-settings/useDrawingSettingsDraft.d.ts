import { DrawingLine } from '../constants.ts';
import { DrawingSettingsDraft, validateDrawingSettings } from '../drawingSettingsModel.ts';
export interface DrawingSettingsDraftController {
    draft: DrawingSettingsDraft;
    errors: ReturnType<typeof validateDrawingSettings>;
    canCommit: boolean;
    update: (patch: Partial<DrawingSettingsDraft>) => void;
    cancel: () => void;
    commit: () => void;
}
export declare function useDrawingSettingsDraft(drawing: DrawingLine, onPreview: (drawing: DrawingLine) => void, onCommit: (drawing: DrawingLine) => void, onClose: () => void): DrawingSettingsDraftController;
