import { DrawingLine } from '../constants.ts';
import { ToolbarBounds, ToolbarPoint } from './toolbarModel.ts';
export interface DrawingToolbarProps {
    drawing: DrawingLine;
    anchor: ToolbarPoint;
    bounds: ToolbarBounds;
    onUpdate: (drawing: DrawingLine) => void;
    onClone: () => void;
    onRemove: () => void;
    onOpenSettings: () => void;
}
export declare function DrawingFloatingToolbar({ drawing, anchor, bounds, onUpdate, onClone, onRemove, onOpenSettings }: DrawingToolbarProps): import('react').ReactPortal;
