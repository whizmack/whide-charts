import { DrawingLine } from '../constants.ts';
import { ToolbarBounds, ToolbarPoint } from './toolbarModel.ts';
export interface DrawingToolbarProps {
    drawing: DrawingLine;
    position: ToolbarPoint;
    bounds: ToolbarBounds;
    onPositionChange: (position: ToolbarPoint) => void;
    onUpdate: (drawing: DrawingLine) => void;
    onClone: () => void;
    onRemove: () => void;
    onOpenSettings: () => void;
}
export declare function DrawingFloatingToolbar({ drawing, position, bounds, onPositionChange, onUpdate, onClone, onRemove, onOpenSettings }: DrawingToolbarProps): import('react').ReactPortal;
