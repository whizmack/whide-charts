import { DrawingLine } from '../constants.ts';
export type DrawingToolbarControl = "line" | "border" | "fill" | "text" | "extend" | "smooth" | "close" | "stop-color" | "target-color" | "stats" | "positive-color" | "negative-color" | "text-color" | "font-size" | "bold" | "italic" | "visibility" | "order" | "clone" | "settings" | "lock" | "delete" | "more";
export declare function toolbarControlsFor(drawing: DrawingLine): DrawingToolbarControl[];
export interface ToolbarPoint {
    x: number;
    y: number;
}
export interface ToolbarBounds {
    left: number;
    top: number;
    width: number;
    height: number;
}
export interface ToolbarSize {
    width: number;
    height: number;
}
export interface ToolbarPlacement extends ToolbarPoint {
    side: "above" | "below";
    maxWidth: number;
}
export declare function preserveDrawingToolbarPosition(current: ToolbarPoint | null, initial: ToolbarPoint | null): ToolbarPoint | null;
/** Clamp a chart-local top-left point without incorporating the cell's viewport offset. */
export declare function clampDrawingToolbarPosition(position: ToolbarPoint, bounds: ToolbarBounds, size: ToolbarSize): ToolbarPoint;
export declare function clampDrawingToolbar(anchor: ToolbarPoint, bounds: ToolbarBounds, size: ToolbarSize): ToolbarPlacement;
