export declare function WatchlistPanel({ symbols, ticks, selectedSymbol, onSelect, oneClick, accountId, isFeedConnected, }: {
    symbols: Array<{
        id?: string;
        name: string;
        displayName?: string | null;
        assetClass?: string;
        category?: string;
        isActive?: boolean;
    }>;
    ticks: Record<string, {
        bid: number;
        ask: number;
        timestamp: number;
    }>;
    selectedSymbol: string;
    onSelect: (s: string) => void;
    oneClick?: boolean;
    accountId?: string | null;
    isFeedConnected?: boolean;
}): import('react').JSX.Element;
