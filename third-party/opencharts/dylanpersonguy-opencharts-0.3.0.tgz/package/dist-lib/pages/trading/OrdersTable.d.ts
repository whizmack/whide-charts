interface OrderRow {
    id: string;
    symbolName: string;
    side: "BUY" | "SELL" | string;
    type: string;
    quantity: number;
    price?: number | null;
    stopPrice?: number | null;
    stopLoss?: number | null;
    takeProfit?: number | null;
    status: string;
    createdAt: string | Date;
}
export declare function OrdersTable({ orders, onCancel, onModify, onSelectSymbol, }: {
    orders: OrderRow[];
    onCancel: (id: string) => void;
    onModify?: (order: OrderRow) => void;
    onSelectSymbol?: (symbolName: string) => void;
}): import('react').JSX.Element;
export {};
