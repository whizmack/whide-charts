import { LucideIcon } from 'lucide-react';
import { DrawingTool } from './constants.ts';
export interface DrawingToolDefinition {
    tool: DrawingTool;
    icon: LucideIcon;
    label: string;
}
export interface DrawingToolGroup {
    id: string;
    icon: LucideIcon;
    label: string;
    tools: DrawingToolDefinition[];
}
/** Single source of truth for the fixed rail and the forthcoming Favorites bar. */
export declare const DRAWING_TOOL_GROUPS: DrawingToolGroup[];
