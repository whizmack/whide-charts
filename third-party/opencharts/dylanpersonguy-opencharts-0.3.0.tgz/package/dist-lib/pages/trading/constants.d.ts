export declare const TIMEFRAMES: readonly ["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"];
export type Timeframe = (typeof TIMEFRAMES)[number];
/**
 * Master switch for session replay (HUD + scrubber). Backed by the demo replay
 * provider in services/demo/replay.ts: the buffer is the bundled 1m history for
 * the charted symbol and the transport state is broadcast on the same channel
 * the real backend used.
 */
export declare const REPLAY_ENABLED = true;
export declare const CHART_COLORS: {
    dark: {
        background: string;
        text: string;
        grid: string;
        crosshair: string;
        up: string;
        down: string;
        volumeUp: string;
        volumeDown: string;
        bidLine: string;
        askLine: string;
        bidLabelBg: string;
        askLabelBg: string;
        watermark: string;
        lastPriceUp: string;
        lastPriceDown: string;
        orderLine: string;
        positionLong: string;
        positionShort: string;
        tpLine: string;
        slLine: string;
    };
    light: {
        background: string;
        text: string;
        grid: string;
        crosshair: string;
        up: string;
        down: string;
        volumeUp: string;
        volumeDown: string;
        bidLine: string;
        askLine: string;
        bidLabelBg: string;
        askLabelBg: string;
        watermark: string;
        lastPriceUp: string;
        lastPriceDown: string;
        orderLine: string;
        positionLong: string;
        positionShort: string;
        tpLine: string;
        slLine: string;
    };
};
export type ChartColors = (typeof CHART_COLORS)["dark"];
/**
 * Per-user color overrides (Chart Settings → Colors). Empty string = use the
 * theme default. Keys map 1:1 onto `ChartColors` fields via COLOR_OVERRIDE_MAP.
 */
export interface ChartColorOverrides {
    colorBackground: string;
    colorGrid: string;
    colorScaleText: string;
    colorCrosshair: string;
    colorBidLine: string;
    colorAskLine: string;
    colorPositionLong: string;
    colorPositionShort: string;
    colorOrderLine: string;
    colorTpLine: string;
    colorSlLine: string;
    /** Candle body colors (also drive wicks/borders unless overridden). */
    candleUpColor: string;
    candleDownColor: string;
}
/** Theme colors with the user's non-empty overrides applied on top. */
export declare function mergeChartColors(theme: ChartColors, overrides: ChartColorOverrides): ChartColors;
/**
 * Armable tools. Some are placement-only aliases that commit a different stored
 * `type`: "ray"/"extended" store a "trendline" with extend flags;
 * "long-position"/"short-position" store a "position" with `side`; "measure" is
 * a transient gesture that never commits.
 */
export type DrawingTool = "none" | "trendline" | "horizontal" | "fibonacci" | "rectangle" | "vertical" | "ray" | "extended" | "channel" | "text" | "fibextension" | "ellipse" | "arrow" | "triangle" | "position" | "long-position" | "short-position" | "measure";
/** Stored drawing kinds (excludes placement-only aliases). */
export type DrawingType = Exclude<DrawingTool, "none" | "ray" | "extended" | "long-position" | "short-position" | "measure">;
export type DrawingLineStyle = "solid" | "dashed" | "dotted";
/** Magnet snapping mode: off, weak (snap within a few px), or strong (always). */
export type MagnetMode = "none" | "weak" | "strong";
export interface DrawingLine {
    id: string;
    type: DrawingType;
    price: number;
    price2?: number;
    time?: number;
    time2?: number;
    /** Third anchor — parallel-channel offset line. */
    price3?: number;
    time3?: number;
    color: string;
    /** Line width in px (default 2). */
    width?: number;
    lineStyle?: DrawingLineStyle;
    /** Locked drawings can be selected but not moved or resized. */
    locked?: boolean;
    /** Trendline only: extend the line to the pane edges. */
    extendLeft?: boolean;
    extendRight?: boolean;
    /** Hidden drawings stay in the object tree but don't render or hit-test. */
    hidden?: boolean;
    /** Render order — higher draws on top. Defaults to creation order. */
    zIndex?: number;
    /** Timeframe the drawing was created on (used by visibility "tf"). */
    createdTf?: string;
    /** "all" (default) shows on every timeframe; "tf" only on createdTf. */
    visibility?: "all" | "tf";
    /** Fill colour for shapes / channel / fib bands (defaults to `color`). */
    fillColor?: string;
    /** Fill opacity 0–1 (defaults per drawing kind). */
    fillOpacity?: number;
    /** Arrowheads on line ends (trendline / arrow). */
    arrowStart?: boolean;
    arrowEnd?: boolean;
    /** Text content + size for text/callout drawings and attachable labels. */
    text?: string;
    fontSize?: number;
    /** Bold / italic styling for text drawings. */
    bold?: boolean;
    italic?: boolean;
    /** Optional text-box background (text drawings). */
    textBg?: boolean;
    textBgColor?: string;
    /** Optional text-box border (text drawings). */
    textBorder?: boolean;
    textBorderColor?: string;
    /** Custom fibonacci levels (fractions); defaults applied when absent. */
    fibLevels?: number[];
    side?: "long" | "short";
    /** Stop-loss price (position tool). */
    stopPrice?: number;
    /** Take-profit price (position tool). */
    targetPrice?: number;
    /** % of account equity risked — drives size/$ readout (default 1). */
    riskPct?: number;
    /** When set, the platform alerts when price crosses this line. */
    alertEnabled?: boolean;
    alertMessage?: string;
}
/** Swatch palette for the floating drawing toolbar (TradingView-style). */
export declare const DRAWING_COLORS: readonly ["#2196F3", "#f0b90b", "#0ecb81", "#f6465d", "#9c27b0", "#ff9800", "#787b86", "#ffffff"];
export declare const DRAWING_WIDTHS: readonly [1, 2, 3, 4];
/** Timeframe interval in milliseconds */
export declare const TF_INTERVAL_MS: Record<Timeframe, number>;
export declare const KNOWN_CURRENCIES: string[];
export interface NewsOverlayConfig {
    enabled: boolean;
    lineColor: string;
    showPast: boolean;
    showFuture: boolean;
    showHigh: boolean;
    showMedium: boolean;
    showLow: boolean;
}
export interface EconomicEvent {
    time: string;
    currency: string;
    impact: "low" | "medium" | "high";
    event: string;
    forecast?: string;
    previous?: string;
    actual?: string;
}
/**
 * Placeholder economic events for the fallback calendar view. The default
 * calendar is TradingView's live widget; this table is what the toggle shows
 * when that is turned off, and is labelled as sample data in the UI.
 */
export declare const MOCK_EVENTS: EconomicEvent[];
export interface NewsItem {
    time: string;
    title: string;
    source: string;
    impact: "bullish" | "bearish" | "neutral";
}
/**
 * Placeholder headlines for the News tab. OpenCharts ships no news feed, so
 * these exist only to show the panel's shape — they carry a "Sample" source
 * rather than a real outlet's name, and the tab labels them as sample data.
 */
export declare const MOCK_NEWS: NewsItem[];
