import { ReactNode } from 'react';
export interface SettingsTabProps<P> {
    prefs: P;
    onChange: (patch: Partial<P>) => void;
}
export declare function SettingsSection({ children }: {
    children: ReactNode;
}): import('react').JSX.Element;
export declare function SettingsCheckRow({ label, checked, onChange, hint, indent, }: {
    label: string;
    checked: boolean;
    onChange: (value: boolean) => void;
    hint?: string;
    indent?: boolean;
}): import('react').JSX.Element;
export declare function SettingsSelectRow({ label, value, options, onChange, }: {
    label: string;
    value: string;
    options: Array<{
        value: string;
        label: string;
    }>;
    onChange: (value: string) => void;
}): import('react').JSX.Element;
export declare function SettingsColorRow({ label, value, fallback, onChange, }: {
    label: string;
    value: string;
    fallback: string;
    onChange: (value: string) => void;
}): import('react').JSX.Element;
export declare function SettingsColorPair({ label, bullish, bearish, bullishFallback, bearishFallback, onBullishChange, onBearishChange, }: {
    label: string;
    bullish: string;
    bearish: string;
    bullishFallback: string;
    bearishFallback: string;
    onBullishChange: (value: string) => void;
    onBearishChange: (value: string) => void;
}): import('react').JSX.Element;
export declare function SettingsNumberRow({ label, value, min, max, step, unit, onChange, }: {
    label: string;
    value: number;
    min: number;
    max: number;
    step?: number;
    unit?: string;
    onChange: (value: number) => void;
}): import('react').JSX.Element;
