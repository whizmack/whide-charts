import { ChartPreferences } from '../../../hooks/useChartPreferences.ts';
import { SettingsTabProps } from './SettingsControls.tsx';
export declare function SymbolTab({ prefs, onChange }: SettingsTabProps<ChartPreferences>): import('react').JSX.Element;
