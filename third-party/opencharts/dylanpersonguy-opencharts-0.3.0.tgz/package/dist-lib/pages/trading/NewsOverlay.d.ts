import { Dispatch, RefObject, SetStateAction } from 'react';
import { NewsOverlayConfig } from './constants.ts';
import { NewsPopupState } from './useNewsOverlay.ts';
interface NewsOverlayProps {
    newsConfig: NewsOverlayConfig;
    setNewsConfig: Dispatch<SetStateAction<NewsOverlayConfig>>;
    showNewsConfigDialog: boolean;
    setShowNewsConfigDialog: Dispatch<SetStateAction<boolean>>;
    newsPopup: NewsPopupState | null;
    setNewsPopup: Dispatch<SetStateAction<NewsPopupState | null>>;
    isDark: boolean;
    pipDigits: number;
    containerRef: RefObject<HTMLDivElement | null>;
}
export declare function NewsOverlay({ newsConfig, setNewsConfig, showNewsConfigDialog, setShowNewsConfigDialog, newsPopup, setNewsPopup, isDark, containerRef, }: NewsOverlayProps): import('react').JSX.Element;
export {};
