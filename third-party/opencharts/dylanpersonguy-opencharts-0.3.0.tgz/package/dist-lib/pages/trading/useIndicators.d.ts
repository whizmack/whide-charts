import { IChartApi, ISeriesApi, CandlestickData, Time } from 'lightweight-charts';
import { IndicatorType } from '../../lib/indicators.ts';
export declare function useIndicators(chartRef: React.RefObject<IChartApi | null>, candleSeriesRef: React.RefObject<ISeriesApi<"Candlestick"> | null>, chartData: CandlestickData<Time>[], activeIndicators: IndicatorType[], isDark: boolean): void;
