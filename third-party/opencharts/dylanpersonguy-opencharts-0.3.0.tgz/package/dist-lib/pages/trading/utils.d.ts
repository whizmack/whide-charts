import { CandlestickData, Time } from 'lightweight-charts';
import { CandleData } from '../../lib/indicators.ts';
import { Timeframe } from './constants.ts';
/** Derive pip (decimal) precision from symbolInfo.tickSize or symbol name */
export declare function getPipDigits(symbolInfo?: {
    tickSize?: number | string;
}, symbolName?: string): number;
/** Get the minMove for lightweight-charts priceFormat from pip digits */
export declare function getMinMove(pipDigits: number): number;
/** Parse timestamp to unix seconds */
export declare function toUnixSeconds(ts: number | string | Date): number;
/** Normalise a numeric timestamp to unix milliseconds (accepts seconds or ms) */
export declare function toUnixMs(ts: number): number;
/** Convert candles for indicator lib */
export declare function toIndicatorCandles(candles: CandlestickData<Time>[]): CandleData[];
/** Format seconds remaining as M:SS or H:MM:SS */
export declare function formatCountdown(totalSec: number): string;
/** Extract currency codes from a symbol name */
export declare function extractCurrencies(symbol: string): string[];
/** Return the candle-bucket start (unix seconds) for a given timestamp */
export declare function getCandleBucketTime(timestampMs: number, tf: Timeframe): number;
