import { TickMarkType, CandlestickSeriesOptions, ChartOptions, DeepPartial, Time } from 'lightweight-charts';
import { ChartColors, Timeframe } from './constants.ts';
import { ChartPreferences } from '../../hooks/useChartPreferences.ts';
export declare function formatChartTimeLabel(time: Time, timezone: string, timeFormat: ChartPreferences["timeScaleTimeFormat"], dateFormat: ChartPreferences["timeScaleDateFormat"], locale: string, tickMarkType: TickMarkType, showDayOfWeek?: boolean): string;
export declare function buildChartSettingsOptions(prefs: ChartPreferences, colors: ChartColors, timeframe: Timeframe): DeepPartial<ChartOptions>;
export declare function buildCandlestickSettingsOptions(prefs: ChartPreferences, colors: ChartColors, pipDigits: number, minMove: number): DeepPartial<CandlestickSeriesOptions>;
