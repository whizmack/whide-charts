export declare function ReplayHUD({ accountId }: {
    accountId: string;
}): import('react').JSX.Element;
