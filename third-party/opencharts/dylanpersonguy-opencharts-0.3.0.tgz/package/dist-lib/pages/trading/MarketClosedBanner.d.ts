import { Symbol } from '../../services/schemas';
interface Props {
    symbolInfo: Symbol | undefined;
}
export declare function MarketClosedBanner({ symbolInfo }: Props): import('react').JSX.Element | null;
export {};
