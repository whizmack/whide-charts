import { JournalEntry, CreateJournalEntryInput, UpdateJournalEntryInput } from '../../services/api/journal.ts';
import { Order, Position } from '../../services/schemas.ts';
export interface BottomPanelProps {
    tab: "positions" | "orders" | "history" | "journal" | "calendar" | "news";
    onTabChange: (t: "positions" | "orders" | "history" | "journal" | "calendar" | "news") => void;
    positions: Position[];
    orders: Order[];
    accountId: string | null;
    onModifyPosition?: (position: Position) => void;
    onModifyOrder?: (order: Order) => void;
    onSelectPositionSymbol?: (symbolName: string) => void;
    onSelectOrderSymbol?: (symbolName: string) => void;
    journalEntries: JournalEntry[];
    journalLoading: boolean;
    onCreateJournal: (data: CreateJournalEntryInput) => void;
    onUpdateJournal: (id: string, data: UpdateJournalEntryInput) => void;
    onDeleteJournal: (id: string) => void;
    height?: number;
    isFeedConnected?: boolean;
}
export declare function BottomPanel({ tab, onTabChange, positions, orders, accountId, onModifyPosition, onModifyOrder, onSelectPositionSymbol, onSelectOrderSymbol, journalEntries, journalLoading, onCreateJournal, onUpdateJournal, onDeleteJournal, height, isFeedConnected, }: BottomPanelProps): import('react').JSX.Element;
