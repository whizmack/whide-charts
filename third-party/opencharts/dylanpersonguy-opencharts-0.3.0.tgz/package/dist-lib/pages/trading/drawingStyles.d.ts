import { DrawingLine } from './constants.ts';
export type StylePatch = Partial<Pick<DrawingLine, "color" | "width" | "lineStyle" | "fillColor" | "fillOpacity" | "arrowStart" | "arrowEnd" | "fontSize">>;
export interface DrawingTemplate {
    name: string;
    style: StylePatch;
}
export declare const DRAWING_STYLES_EVENT = "drawing-styles-updated";
/** Style-only fields of a drawing (drops anchors/visibility/alert state). */
export declare function pickStyle(d: DrawingLine): StylePatch;
export declare function getStyleDefaults(): Record<string, StylePatch>;
export declare function setTypeDefault(type: string, d: DrawingLine): void;
export declare function getTemplates(): DrawingTemplate[];
export declare function saveTemplate(name: string, d: DrawingLine): void;
export declare function deleteTemplate(name: string): void;
