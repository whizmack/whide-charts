import { RefObject, Dispatch, SetStateAction } from 'react';
import { IChartApi, CandlestickData, Time } from 'lightweight-charts';
import { EconomicCalendarEvent } from '../../services/queries.ts';
import { NewsOverlayConfig } from './constants.ts';
export interface NewsPopupState {
    event: EconomicCalendarEvent;
    x: number;
    y: number;
}
export interface UseNewsOverlayReturn {
    newsConfig: NewsOverlayConfig;
    setNewsConfig: Dispatch<SetStateAction<NewsOverlayConfig>>;
    showNewsConfigDialog: boolean;
    setShowNewsConfigDialog: Dispatch<SetStateAction<boolean>>;
    newsPopup: NewsPopupState | null;
    setNewsPopup: Dispatch<SetStateAction<NewsPopupState | null>>;
}
export declare function useNewsOverlay(containerRef: RefObject<HTMLDivElement | null>, chartRef: RefObject<IChartApi | null>, selectedSymbol: string, isDark: boolean, chartData: CandlestickData<Time>[]): UseNewsOverlayReturn;
