export interface ChartContextMenuProps {
    x: number;
    y: number;
    /** Price under the cursor (null when the click landed off the price scale). */
    price: number | null;
    pipDigits: number;
    symbol: string;
    tick?: {
        bid: number;
        ask: number;
    };
    drawingsCount: number;
    indicatorsCount: number;
    onClose: () => void;
    onResetView: () => void;
    onCopyPrice: (price: number) => void;
    onAddAlert?: (price: number) => void;
    onQuickOrder?: (side: "BUY" | "SELL", type: "LIMIT" | "STOP", price: number) => void;
    onOpenObjectTree: () => void;
    onRemoveAllDrawings?: () => void;
    onClearIndicators?: () => void;
    onOpenSettings: () => void;
}
export declare function ChartContextMenu(props: ChartContextMenuProps): import('react').JSX.Element;
