interface PositionRow {
    id: string;
    symbolName: string;
    side: "LONG" | "SHORT" | string;
    quantity: number;
    entryPrice: number;
    currentPrice?: number | null;
    unrealizedPnl: number;
    stopLoss?: number | null;
    takeProfit?: number | null;
    openedAt: string | Date;
}
export declare function PositionsTable({ positions, onClose, onModify, onPartialClose, onSelectSymbol, }: {
    positions: PositionRow[];
    onClose: (id: string) => void;
    onModify?: (p: PositionRow) => void;
    onPartialClose?: (id: string, quantity: number) => void;
    onSelectSymbol?: (symbolName: string) => void;
}): import('react').JSX.Element;
export {};
