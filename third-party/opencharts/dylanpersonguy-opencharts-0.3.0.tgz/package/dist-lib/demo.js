var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import { p as publish, D as DEMO_CHANNELS, u as uid, s as safeStorage, a as subscribeChannel } from "./chunks/uid-Cv5r25IO.js";
const loaders = /* @__PURE__ */ Object.assign({ "./data/ADAUSD_15m.json": () => import("./chunks/ADAUSD_15m-D4cmVVt_.js"), "./data/ADAUSD_1d.json": () => import("./chunks/ADAUSD_1d-CUbOxKwu.js"), "./data/ADAUSD_1h.json": () => import("./chunks/ADAUSD_1h-Dz-nN7pr.js"), "./data/ADAUSD_1m.json": () => import("./chunks/ADAUSD_1m-BwIXq0TY.js"), "./data/ADAUSD_1w.json": () => import("./chunks/ADAUSD_1w-DL5J5hhi.js"), "./data/ADAUSD_30m.json": () => import("./chunks/ADAUSD_30m-2-xEdNwZ.js"), "./data/ADAUSD_4h.json": () => import("./chunks/ADAUSD_4h-BleKIJzM.js"), "./data/ADAUSD_5m.json": () => import("./chunks/ADAUSD_5m-tI9-Cys6.js"), "./data/BNBUSD_15m.json": () => import("./chunks/BNBUSD_15m-OT6bK-K8.js"), "./data/BNBUSD_1d.json": () => import("./chunks/BNBUSD_1d-DfoAf7fs.js"), "./data/BNBUSD_1h.json": () => import("./chunks/BNBUSD_1h-CoOWwfCg.js"), "./data/BNBUSD_1m.json": () => import("./chunks/BNBUSD_1m-Dqab4-aM.js"), "./data/BNBUSD_1w.json": () => import("./chunks/BNBUSD_1w-BjTRe5X0.js"), "./data/BNBUSD_30m.json": () => import("./chunks/BNBUSD_30m-yTe_YVt4.js"), "./data/BNBUSD_4h.json": () => import("./chunks/BNBUSD_4h-C5ThE4YP.js"), "./data/BNBUSD_5m.json": () => import("./chunks/BNBUSD_5m-DImCegU_.js"), "./data/BTCUSD_15m.json": () => import("./chunks/BTCUSD_15m-CkAUE5q7.js"), "./data/BTCUSD_1d.json": () => import("./chunks/BTCUSD_1d-D_YEul13.js"), "./data/BTCUSD_1h.json": () => import("./chunks/BTCUSD_1h-kUWu4zqX.js"), "./data/BTCUSD_1m.json": () => import("./chunks/BTCUSD_1m-CZ8KVglj.js"), "./data/BTCUSD_1w.json": () => import("./chunks/BTCUSD_1w-Ct8Xo0zh.js"), "./data/BTCUSD_30m.json": () => import("./chunks/BTCUSD_30m-S34vJG-O.js"), "./data/BTCUSD_4h.json": () => import("./chunks/BTCUSD_4h-Be7Mj8xD.js"), "./data/BTCUSD_5m.json": () => import("./chunks/BTCUSD_5m-ByHCvNTG.js"), "./data/ETHUSD_15m.json": () => import("./chunks/ETHUSD_15m-CLLKTt0N.js"), "./data/ETHUSD_1d.json": () => import("./chunks/ETHUSD_1d-Dn2k_7QF.js"), "./data/ETHUSD_1h.json": () => import("./chunks/ETHUSD_1h-Bip0H7cB.js"), "./data/ETHUSD_1m.json": () => import("./chunks/ETHUSD_1m-B6u3A7bB.js"), "./data/ETHUSD_1w.json": () => import("./chunks/ETHUSD_1w-Bg-Bp5wE.js"), "./data/ETHUSD_30m.json": () => import("./chunks/ETHUSD_30m-D79o2wGy.js"), "./data/ETHUSD_4h.json": () => import("./chunks/ETHUSD_4h-Dy2q8bzz.js"), "./data/ETHUSD_5m.json": () => import("./chunks/ETHUSD_5m-CFgYpSLv.js"), "./data/SOLUSD_15m.json": () => import("./chunks/SOLUSD_15m-DQ7bNwmm.js"), "./data/SOLUSD_1d.json": () => import("./chunks/SOLUSD_1d-0yqNy6fS.js"), "./data/SOLUSD_1h.json": () => import("./chunks/SOLUSD_1h-pUYWk2mp.js"), "./data/SOLUSD_1m.json": () => import("./chunks/SOLUSD_1m-BhP9GwAz.js"), "./data/SOLUSD_1w.json": () => import("./chunks/SOLUSD_1w-CP_zRlC6.js"), "./data/SOLUSD_30m.json": () => import("./chunks/SOLUSD_30m-BU-KB8mL.js"), "./data/SOLUSD_4h.json": () => import("./chunks/SOLUSD_4h-Cov6xZGX.js"), "./data/SOLUSD_5m.json": () => import("./chunks/SOLUSD_5m-DaZeaa8W.js"), "./data/XRPUSD_15m.json": () => import("./chunks/XRPUSD_15m-vFmgb6Qq.js"), "./data/XRPUSD_1d.json": () => import("./chunks/XRPUSD_1d-D28AuRtR.js"), "./data/XRPUSD_1h.json": () => import("./chunks/XRPUSD_1h-uTxrXFcT.js"), "./data/XRPUSD_1m.json": () => import("./chunks/XRPUSD_1m-sU3l_hyD.js"), "./data/XRPUSD_1w.json": () => import("./chunks/XRPUSD_1w-DruTqh49.js"), "./data/XRPUSD_30m.json": () => import("./chunks/XRPUSD_30m-C4OtE3eG.js"), "./data/XRPUSD_4h.json": () => import("./chunks/XRPUSD_4h-CXIiZz7-.js"), "./data/XRPUSD_5m.json": () => import("./chunks/XRPUSD_5m-B8WRfRmq.js"), "./data/manifest.json": () => import("./chunks/manifest-CSOZjXFb.js") });
const cache = /* @__PURE__ */ new Map();
const inflight = /* @__PURE__ */ new Map();
function isUsableBar(bar) {
  if (!bar || typeof bar !== "object") return false;
  const c = bar;
  return Number.isFinite(c.time) && Number.isFinite(c.open) && Number.isFinite(c.high) && Number.isFinite(c.low) && Number.isFinite(c.close);
}
function seriesKey(symbol, timeframe) {
  return `${symbol}_${timeframe}`;
}
function loadSeries(symbol, timeframe) {
  const key = seriesKey(symbol, timeframe);
  const cached = cache.get(key);
  if (cached) return Promise.resolve(cached);
  const pending = inflight.get(key);
  if (pending) return pending;
  const loader = loaders[`./data/${key}.json`];
  if (!loader) {
    cache.set(key, []);
    return Promise.resolve([]);
  }
  const promise = loader().then((mod) => {
    const bars = Array.isArray(mod.default) ? mod.default.filter(isUsableBar) : [];
    cache.set(key, bars);
    return bars;
  }).catch(() => {
    cache.set(key, []);
    return [];
  }).finally(() => {
    inflight.delete(key);
  });
  inflight.set(key, promise);
  return promise;
}
const TF_SECONDS = {
  "1m": 60,
  "5m": 300,
  "15m": 900,
  "30m": 1800,
  "1h": 3600,
  "4h": 14400,
  "1d": 86400,
  "1w": 604800
};
function currentBucketSec(timeframe) {
  const interval = TF_SECONDS[timeframe] ?? 60;
  const nowSec = Math.floor(Date.now() / 1e3);
  return nowSec - nowSec % interval;
}
function shiftDelta(bars, timeframe) {
  if (bars.length === 0) return 0;
  const lastReal = bars[bars.length - 1].time;
  return currentBucketSec(timeframe) - lastReal;
}
async function getHistory(symbol, timeframe, limit, range) {
  const raw = await loadSeries(symbol, timeframe);
  if (raw.length === 0) return [];
  const delta = shiftDelta(raw, timeframe);
  let bars = raw.map((c) => ({ ...c, time: c.time + delta }));
  if (range) {
    const fromSec = range.fromMs != null ? Math.floor(range.fromMs / 1e3) : null;
    const toSec = range.toMs != null ? Math.floor(range.toMs / 1e3) : null;
    bars = bars.filter(
      (c) => (fromSec == null || c.time >= fromSec) && (toSec == null || c.time < toSec)
    );
  }
  if (limit != null && Number.isFinite(limit) && limit > 0 && limit < bars.length) {
    return bars.slice(-Math.floor(limit));
  }
  return bars;
}
function getTickPrices(symbol) {
  const bars = cache.get(seriesKey(symbol, "1m")) ?? [];
  return bars.map((c) => c.close).filter((price) => Number.isFinite(price) && price > 0);
}
async function primeTickPrices(symbols) {
  await Promise.all(symbols.map((s) => loadSeries(s, "1m")));
}
function crypto(name, displayName, tickSize) {
  return {
    id: name,
    name,
    displayName,
    category: "CRYPTO",
    contractSize: 1,
    tickSize,
    tickValue: tickSize,
    marginPercent: 1,
    maxLeverage: 100,
    commission: 0,
    swapLong: 0,
    swapShort: 0,
    tradingHoursStart: null,
    tradingHoursEnd: null,
    isActive: true
  };
}
const DEMO_SYMBOLS = [
  crypto("BTCUSD", "Bitcoin", 0.01),
  crypto("ETHUSD", "Ethereum", 0.01),
  crypto("SOLUSD", "Solana", 0.01),
  crypto("BNBUSD", "BNB", 0.01),
  crypto("XRPUSD", "XRP", 1e-4),
  crypto("ADAUSD", "Cardano", 1e-4)
];
DEMO_SYMBOLS.map((s) => s.name);
function getDemoSymbol(name) {
  return DEMO_SYMBOLS.find((s) => s.name === name);
}
const STARTING_BALANCE = 1e5;
const DEFAULT_LEVERAGE = 100;
const MAX_QUANTITY = 1e6;
class EngineError extends Error {
  constructor(code, message) {
    super(message);
    __publicField(this, "code");
    this.name = "EngineError";
    this.code = code;
  }
}
const account = {
  id: uid(),
  userId: "demo-user",
  templateId: "demo",
  label: "Demo Account",
  status: "ACTIVE",
  balance: STARTING_BALANCE,
  equity: STARTING_BALANCE,
  margin: 0,
  freeMargin: STARTING_BALANCE,
  phase: "LIVE",
  startDate: (/* @__PURE__ */ new Date()).toISOString(),
  createdAt: (/* @__PURE__ */ new Date()).toISOString(),
  updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
  isHftMode: false,
  template: { name: "Demo Account", startingBalance: STARTING_BALANCE, instrumentType: "CRYPTO" }
};
const positions = [];
const orders = [];
const closed = [];
const fills = [];
const lastPrice = /* @__PURE__ */ new Map();
function money(value) {
  return Math.round(value * 100) / 100;
}
function toTick(price, tickSize) {
  if (!Number.isFinite(tickSize) || tickSize <= 0) return price;
  const snapped = Math.round(price / tickSize) * tickSize;
  const decimals = Math.min(10, Math.max(0, Math.ceil(-Math.log10(tickSize))));
  return Number(snapped.toFixed(decimals));
}
function getAccount() {
  return { ...account };
}
function getAccounts() {
  return [getAccount()];
}
function getPositions() {
  return positions.map((p) => ({ ...p }));
}
function getOrders() {
  return orders.map((o) => ({ ...o }));
}
function getClosedPositions() {
  return closed.map((c) => ({ ...c }));
}
function getLastPrice(symbol) {
  return lastPrice.get(symbol) ?? 0;
}
function requireSymbol(name) {
  const symbol = getDemoSymbol(name);
  if (!symbol) throw new EngineError("UNKNOWN_SYMBOL", `Unknown symbol: ${name}`);
  return symbol;
}
function requireQuantity(quantity) {
  if (!Number.isFinite(quantity) || quantity <= 0) {
    throw new EngineError("INVALID_QUANTITY", "Quantity must be a positive number");
  }
  if (quantity > MAX_QUANTITY) {
    throw new EngineError("INVALID_QUANTITY", `Quantity exceeds the ${MAX_QUANTITY} limit`);
  }
  return quantity;
}
function requirePrice(price, label) {
  if (price == null || !Number.isFinite(price) || price <= 0) {
    throw new EngineError("INVALID_PRICE", `${label} must be a positive number`);
  }
  return price;
}
function requireMarketPrice(symbolName) {
  const price = lastPrice.get(symbolName);
  if (price == null || !Number.isFinite(price) || price <= 0) {
    throw new EngineError(
      "NO_MARKET_PRICE",
      `No price for ${symbolName} yet — wait for the feed to connect`
    );
  }
  return price;
}
function validateProtection(side, reference, takeProfit, stopLoss) {
  const isLong = side === "BUY";
  if (takeProfit != null) {
    if (!Number.isFinite(takeProfit) || takeProfit <= 0) {
      throw new EngineError("INVALID_PRICE", "Take-profit must be a positive number");
    }
    if (isLong ? takeProfit <= reference : takeProfit >= reference) {
      throw new EngineError(
        "INVALID_TAKE_PROFIT",
        `Take-profit must be ${isLong ? "above" : "below"} ${reference}`
      );
    }
  }
  if (stopLoss != null) {
    if (!Number.isFinite(stopLoss) || stopLoss <= 0) {
      throw new EngineError("INVALID_PRICE", "Stop-loss must be a positive number");
    }
    if (isLong ? stopLoss >= reference : stopLoss <= reference) {
      throw new EngineError(
        "INVALID_STOP_LOSS",
        `Stop-loss must be ${isLong ? "below" : "above"} ${reference}`
      );
    }
  }
}
function notional(symbol, qty, price) {
  var _a;
  const contractSize = ((_a = getDemoSymbol(symbol)) == null ? void 0 : _a.contractSize) ?? 1;
  return price * qty * contractSize;
}
function marginFor(symbol, qty, price) {
  return notional(symbol, qty, price) / DEFAULT_LEVERAGE;
}
function pnlOf(pos, price) {
  var _a;
  const contractSize = ((_a = getDemoSymbol(pos.symbolName)) == null ? void 0 : _a.contractSize) ?? 1;
  const dir = pos.side === "LONG" ? 1 : -1;
  return (price - pos.entryPrice) * pos.quantity * contractSize * dir;
}
function recomputeEquity() {
  let unrealized = 0;
  let margin = 0;
  for (const p of positions) {
    const price = lastPrice.get(p.symbolName) ?? p.entryPrice;
    p.currentPrice = price;
    p.unrealizedPnl = pnlOf(p, price);
    unrealized += p.unrealizedPnl;
    margin += p.margin;
  }
  account.margin = money(margin);
  account.equity = money(account.balance + unrealized);
  account.freeMargin = money(account.equity - account.margin);
  account.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
}
function emitEquity() {
  publish(DEMO_CHANNELS.account, {
    eventType: "EquityUpdated",
    accountId: account.id,
    equity: account.equity,
    balance: account.balance,
    freeMargin: account.freeMargin,
    marginUsed: account.margin
  });
}
function settle() {
  recomputeEquity();
  emitEquity();
}
function openPosition(symbol, side, qty, price, tp, sl) {
  var _a;
  const isLong = side === "BUY";
  const pos = {
    id: uid(),
    accountId: account.id,
    symbolName: symbol,
    side: isLong ? "LONG" : "SHORT",
    quantity: qty,
    entryPrice: price,
    currentPrice: price,
    unrealizedPnl: 0,
    margin: money(marginFor(symbol, qty, price)),
    contractSize: ((_a = getDemoSymbol(symbol)) == null ? void 0 : _a.contractSize) ?? 1,
    openedAt: (/* @__PURE__ */ new Date()).toISOString(),
    takeProfit: tp ?? null,
    stopLoss: sl ?? null
  };
  positions.push(pos);
  publish(DEMO_CHANNELS.positions, {
    eventType: "PositionOpened",
    accountId: account.id,
    positionId: pos.id,
    _entity: { ...pos }
  });
  return pos;
}
function recordClose(pos, qty, exitPrice, realized) {
  const now = (/* @__PURE__ */ new Date()).toISOString();
  closed.unshift({
    id: uid(),
    accountId: account.id,
    symbolName: pos.symbolName,
    side: pos.side,
    quantity: qty,
    entryPrice: pos.entryPrice,
    exitPrice,
    realizedPnl: realized,
    commission: 0,
    swap: 0,
    openedAt: pos.openedAt,
    closedAt: now,
    isPartialClose: qty < pos.quantity
  });
  fills.unshift({
    id: uid(),
    orderId: pos.id,
    accountId: account.id,
    symbolName: pos.symbolName,
    side: pos.side === "LONG" ? "SELL" : "BUY",
    quantity: qty,
    price: exitPrice,
    commission: 0,
    realizedPnl: realized,
    createdAt: now
  });
}
function closeAt(pos, qty, exitPrice) {
  const idx = positions.indexOf(pos);
  const realized = money(pnlOf({ ...pos, quantity: qty }, exitPrice));
  account.balance = money(account.balance + realized);
  recordClose(pos, qty, exitPrice, realized);
  if (qty >= pos.quantity) {
    if (idx >= 0) positions.splice(idx, 1);
    publish(DEMO_CHANNELS.positions, {
      eventType: "PositionClosed",
      accountId: account.id,
      positionId: pos.id
    });
  } else {
    const remaining = pos.quantity - qty;
    pos.margin = money(pos.margin * (remaining / pos.quantity));
    pos.quantity = remaining;
    publish(DEMO_CHANNELS.positions, {
      eventType: "PositionUpdated",
      accountId: account.id,
      positionId: pos.id,
      unrealizedPnl: pos.unrealizedPnl,
      quantity: pos.quantity,
      averagePrice: pos.entryPrice
    });
  }
  return realized;
}
function closePosition(positionId, quantity) {
  const pos = positions.find((p) => p.id === positionId);
  if (!pos) throw new EngineError("POSITION_NOT_FOUND", "Position not found");
  let qty = pos.quantity;
  if (quantity != null) {
    if (!Number.isFinite(quantity) || quantity <= 0) {
      throw new EngineError("INVALID_QUANTITY", "Close quantity must be a positive number");
    }
    qty = Math.min(quantity, pos.quantity);
  }
  const price = lastPrice.get(pos.symbolName) ?? pos.currentPrice ?? pos.entryPrice;
  closeAt(pos, qty, price);
  settle();
  return { success: true };
}
function closeAllPositions() {
  if (positions.length === 0) return { success: true };
  for (const p of [...positions]) {
    const price = lastPrice.get(p.symbolName) ?? p.currentPrice ?? p.entryPrice;
    closeAt(p, p.quantity, price);
  }
  settle();
  return { success: true };
}
function modifyPosition(positionId, mods) {
  const pos = positions.find((p) => p.id === positionId);
  if (!pos) throw new EngineError("POSITION_NOT_FOUND", "Position not found");
  const reference = lastPrice.get(pos.symbolName) ?? pos.currentPrice ?? pos.entryPrice;
  validateProtection(
    pos.side === "LONG" ? "BUY" : "SELL",
    reference,
    mods.takeProfit,
    mods.stopLoss
  );
  if (mods.takeProfit !== void 0) pos.takeProfit = mods.takeProfit;
  if (mods.stopLoss !== void 0) pos.stopLoss = mods.stopLoss;
  publish(DEMO_CHANNELS.positions, {
    eventType: "PositionUpdated",
    accountId: account.id,
    positionId,
    unrealizedPnl: pos.unrealizedPnl,
    quantity: pos.quantity,
    averagePrice: pos.entryPrice
  });
  return { ...pos };
}
const ORDER_TYPES = /* @__PURE__ */ new Set(["MARKET", "LIMIT", "STOP"]);
function publishOrder(eventType, order) {
  publish(DEMO_CHANNELS.orders, {
    eventType,
    accountId: account.id,
    orderId: order.id,
    _entity: { ...order }
  });
}
function newOrder(input, side, type, qty, limitPrice, stopPrice) {
  const now = (/* @__PURE__ */ new Date()).toISOString();
  return {
    id: uid(),
    accountId: account.id,
    symbolName: input.symbol,
    side,
    type,
    quantity: qty,
    price: limitPrice,
    stopPrice,
    takeProfit: input.takeProfit ?? null,
    stopLoss: input.stopLoss ?? null,
    status: "PENDING",
    filledQuantity: 0,
    avgFillPrice: null,
    comment: null,
    createdAt: now,
    updatedAt: now
  };
}
function fillOrder(order, price) {
  order.status = "FILLED";
  order.filledQuantity = order.quantity;
  order.avgFillPrice = price;
  order.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  publishOrder("OrderFilled", order);
  openPosition(order.symbolName, order.side, order.quantity, price, order.takeProfit, order.stopLoss);
}
function placeOrder(input) {
  const symbol = requireSymbol(input.symbol);
  const qty = requireQuantity(input.quantity);
  const side = input.side === "SELL" ? "SELL" : "BUY";
  if (input.side !== "BUY" && input.side !== "SELL") {
    throw new EngineError("INVALID_SIDE", `Unknown order side: ${input.side}`);
  }
  const type = (input.type || "MARKET").toUpperCase();
  if (!ORDER_TYPES.has(type)) {
    throw new EngineError("INVALID_ORDER_TYPE", `Unsupported order type: ${input.type}`);
  }
  const orderType = type;
  const market = requireMarketPrice(symbol.name);
  let limitPrice = null;
  let stopPrice = null;
  let reference = market;
  if (orderType === "LIMIT") {
    limitPrice = toTick(requirePrice(input.price, "Limit price"), symbol.tickSize);
    reference = limitPrice;
  } else if (orderType === "STOP") {
    stopPrice = toTick(requirePrice(input.stopPrice, "Stop price"), symbol.tickSize);
    reference = stopPrice;
    if (side === "BUY" ? stopPrice <= market : stopPrice >= market) {
      throw new EngineError(
        "INVALID_STOP_PRICE",
        `A ${side} stop must be ${side === "BUY" ? "above" : "below"} the market (${market})`
      );
    }
  }
  validateProtection(side, reference, input.takeProfit, input.stopLoss);
  const order = newOrder(input, side, orderType, qty, limitPrice, stopPrice);
  orders.unshift(order);
  publishOrder("OrderPlaced", order);
  if (orderType === "MARKET") {
    const required = marginFor(symbol.name, qty, market);
    if (required > account.freeMargin) {
      order.status = "REJECTED";
      order.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      publishOrder("OrderRejected", order);
      throw new EngineError(
        "INSUFFICIENT_MARGIN",
        `Order needs ${required.toFixed(2)} margin, only ${account.freeMargin.toFixed(2)} free`
      );
    }
    fillOrder(order, market);
    settle();
    return { ...order };
  }
  const limit = limitPrice;
  if (limit != null && (side === "BUY" ? market <= limit : market >= limit)) {
    const fillPrice = side === "BUY" ? Math.min(market, limit) : Math.max(market, limit);
    fillOrder(order, fillPrice);
    settle();
  }
  return { ...order };
}
function modifyOrder(orderId, mods) {
  const order = orders.find((o) => o.id === orderId);
  if (!order) throw new EngineError("ORDER_NOT_FOUND", "Order not found");
  if (order.status !== "PENDING") {
    throw new EngineError("ORDER_NOT_PENDING", `Cannot modify a ${order.status.toLowerCase()} order`);
  }
  const symbol = requireSymbol(order.symbolName);
  const market = lastPrice.get(order.symbolName) ?? order.price ?? order.stopPrice ?? 0;
  if (mods.quantity !== void 0) order.quantity = requireQuantity(mods.quantity);
  if (mods.price !== void 0 && order.type === "LIMIT") {
    order.price = toTick(requirePrice(mods.price, "Limit price"), symbol.tickSize);
  }
  if (mods.stopPrice !== void 0 && order.type === "STOP") {
    order.stopPrice = toTick(requirePrice(mods.stopPrice, "Stop price"), symbol.tickSize);
  }
  const reference = order.price ?? order.stopPrice ?? market;
  const takeProfit = mods.takeProfit !== void 0 ? mods.takeProfit : order.takeProfit;
  const stopLoss = mods.stopLoss !== void 0 ? mods.stopLoss : order.stopLoss;
  validateProtection(order.side, reference, takeProfit, stopLoss);
  order.takeProfit = takeProfit;
  order.stopLoss = stopLoss;
  order.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  publishOrder("OrderModified", order);
  return { ...order };
}
function cancelOrder(orderId) {
  const order = orders.find((o) => o.id === orderId);
  if (!order) throw new EngineError("ORDER_NOT_FOUND", "Order not found");
  if (order.status !== "PENDING") {
    throw new EngineError(
      "ORDER_NOT_PENDING",
      `Cannot cancel a ${order.status.toLowerCase()} order`
    );
  }
  order.status = "CANCELED";
  order.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  publishOrder("OrderCanceled", order);
  return { success: true };
}
function cancelAllOrders() {
  for (const order of orders) {
    if (order.status !== "PENDING") continue;
    order.status = "CANCELED";
    order.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    publishOrder("OrderCanceled", order);
  }
  return { success: true };
}
function triggeredOrders(symbolName, price) {
  return orders.filter((o) => {
    if (o.status !== "PENDING" || o.symbolName !== symbolName) return false;
    if (o.type === "LIMIT" && o.price != null) {
      return o.side === "BUY" ? price <= o.price : price >= o.price;
    }
    if (o.type === "STOP" && o.stopPrice != null) {
      return o.side === "BUY" ? price >= o.stopPrice : price <= o.stopPrice;
    }
    return false;
  });
}
function fillTriggered(symbolName, price) {
  const triggered = triggeredOrders(symbolName, price);
  let filledAny = false;
  for (const order of triggered) {
    const required = marginFor(symbolName, order.quantity, price);
    if (required > account.freeMargin) {
      order.status = "REJECTED";
      order.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      publishOrder("OrderRejected", order);
      continue;
    }
    const fillPrice = order.type === "LIMIT" && order.price != null ? order.side === "BUY" ? Math.min(price, order.price) : Math.max(price, order.price) : price;
    fillOrder(order, fillPrice);
    filledAny = true;
  }
  return filledAny;
}
function stopExit(pos, price) {
  const isLong = pos.side === "LONG";
  if (pos.takeProfit != null && (isLong ? price >= pos.takeProfit : price <= pos.takeProfit)) {
    return pos.takeProfit;
  }
  if (pos.stopLoss != null && (isLong ? price <= pos.stopLoss : price >= pos.stopLoss)) {
    return price;
  }
  return null;
}
function mark(symbol, price) {
  if (!Number.isFinite(price) || price <= 0) return;
  lastPrice.set(symbol, price);
  let changed = fillTriggered(symbol, price);
  for (const pos of positions.filter((p) => p.symbolName === symbol)) {
    const exit = stopExit(pos, price);
    if (exit != null) {
      closeAt(pos, pos.quantity, exit);
      changed = true;
      continue;
    }
    pos.currentPrice = price;
    pos.unrealizedPnl = pnlOf(pos, price);
    changed = true;
    publish(DEMO_CHANNELS.positions, {
      eventType: "PositionUpdated",
      accountId: account.id,
      positionId: pos.id,
      unrealizedPnl: pos.unrealizedPnl,
      quantity: pos.quantity,
      averagePrice: pos.entryPrice
    });
  }
  if (changed) settle();
}
const TICK_MS = 600;
let timer = null;
let cursors = [];
function buildCursors() {
  return DEMO_SYMBOLS.map((s) => {
    const prices = getTickPrices(s.name);
    const seed = prices[prices.length - 1] ?? 0;
    return {
      symbol: s.name,
      prices,
      index: Math.max(0, prices.length - 1),
      direction: -1,
      spread: Math.max(s.tickSize, seed * 1e-4)
    };
  });
}
function emitTick(cursor) {
  const price = cursor.prices[cursor.index];
  if (price == null || !Number.isFinite(price) || price <= 0) return;
  const half = cursor.spread / 2;
  publish(DEMO_CHANNELS.ticks, {
    eventType: "MarketTick",
    symbol: cursor.symbol,
    bid: price - half,
    ask: price + half,
    occurredAt: Date.now()
  });
  mark(cursor.symbol, price);
}
function advance(cursor) {
  if (cursor.prices.length <= 1) return;
  const next = cursor.index + cursor.direction;
  if (next < 0 || next >= cursor.prices.length) {
    cursor.direction = cursor.direction === 1 ? -1 : 1;
    cursor.index += cursor.direction;
  } else {
    cursor.index = next;
  }
}
let starting = false;
function startDemoFeed() {
  if (timer || starting) return;
  starting = true;
  void primeTickPrices(DEMO_SYMBOLS.map((s) => s.name)).then(() => {
    starting = false;
    if (timer) return;
    cursors = buildCursors();
    for (const c of cursors) emitTick(c);
    timer = setInterval(() => {
      for (const c of cursors) {
        advance(c);
        emitTick(c);
      }
    }, TICK_MS);
  }).catch(() => {
    starting = false;
  });
}
function stopDemoFeed() {
  if (timer) clearInterval(timer);
  timer = null;
  starting = false;
  cursors = [];
}
const POSITION_EVENTS = {
  PositionOpened: "position.opened",
  PositionUpdated: "position.updated",
  PositionClosed: "position.closed"
};
const ORDER_EVENTS = {
  OrderPlaced: "order.placed",
  OrderFilled: "order.filled",
  OrderCanceled: "order.canceled",
  OrderRejected: "order.rejected",
  OrderModified: "order.placed"
};
function createDemoAdapter() {
  return {
    name: "demo",
    marketData: {
      getSymbols: () => Promise.resolve(DEMO_SYMBOLS),
      getCandles: ({ symbol, timeframe, limit, fromMs, toMs }) => getHistory(
        symbol,
        timeframe,
        limit,
        fromMs != null || toMs != null ? { fromMs, toMs } : void 0
      ),
      getQuote: (symbol) => {
        const price = getLastPrice(symbol);
        if (!price) return Promise.resolve(null);
        return Promise.resolve({ symbol, bid: price, ask: price, timestamp: Date.now() });
      },
      connect: () => startDemoFeed(),
      disconnect: () => stopDemoFeed(),
      subscribe: (handler) => subscribeChannel(DEMO_CHANNELS.ticks, (raw) => {
        const event = raw;
        if (event.eventType !== "MarketTick") return;
        handler({
          type: "tick",
          symbol: event.symbol,
          bid: event.bid,
          ask: event.ask,
          timestamp: event.occurredAt
        });
      })
    },
    trading: {
      getAccounts: () => Promise.resolve(getAccounts()),
      getPositions: () => Promise.resolve(getPositions()),
      getOrders: (_accountId, status) => {
        const all = getOrders();
        return Promise.resolve(status ? all.filter((o) => o.status === status) : all);
      },
      getClosedPositions: (_accountId, page = 1) => {
        const rows = getClosedPositions();
        const pageSize = 50;
        const safePage = Number.isFinite(page) && page > 0 ? Math.floor(page) : 1;
        const start = (safePage - 1) * pageSize;
        return Promise.resolve({
          data: rows.slice(start, start + pageSize),
          total: rows.length,
          page: safePage,
          pageSize,
          totalPages: Math.max(1, Math.ceil(rows.length / pageSize))
        });
      },
      // The engine throws EngineError with a trader-readable message. These are
      // `async` so that surfaces as a rejected promise: the contract says every
      // method returns one, and a synchronous throw would skip a caller's
      // `.catch()` entirely.
      placeOrder: async (input) => placeOrder(input),
      modifyOrder: async (orderId, modification) => modifyOrder(orderId, modification),
      cancelOrder: async (orderId) => {
        cancelOrder(orderId);
      },
      cancelAllOrders: async () => {
        cancelAllOrders();
      },
      closePosition: async (positionId, quantity) => {
        closePosition(positionId, quantity);
      },
      closeAllPositions: async () => {
        closeAllPositions();
      },
      modifyPosition: async (positionId, modification) => modifyPosition(positionId, modification),
      subscribe: (handler) => {
        const unsubPositions = subscribeChannel(DEMO_CHANNELS.positions, (raw) => {
          const event = raw;
          const type = POSITION_EVENTS[event.eventType];
          if (!type) return;
          handler({
            type,
            accountId: event.accountId,
            positionId: event.positionId,
            entity: event._entity,
            unrealizedPnl: event.unrealizedPnl,
            quantity: event.quantity,
            averagePrice: event.averagePrice
          });
        });
        const unsubOrders = subscribeChannel(DEMO_CHANNELS.orders, (raw) => {
          const event = raw;
          const type = ORDER_EVENTS[event.eventType];
          if (!type) return;
          handler({
            type,
            accountId: event.accountId,
            orderId: event.orderId,
            entity: event._entity
          });
        });
        const unsubAccount = subscribeChannel(DEMO_CHANNELS.account, (raw) => {
          const event = raw;
          if (event.eventType !== "EquityUpdated") return;
          handler({
            type: "account.updated",
            accountId: event.accountId,
            equity: event.equity,
            balance: event.balance,
            freeMargin: event.freeMargin,
            marginUsed: event.marginUsed
          });
        });
        return () => {
          unsubPositions();
          unsubOrders();
          unsubAccount();
        };
      }
    },
    // Drawings, templates and journal entries persist to this device. Swap in
    // your own driver to keep them with the user's account instead.
    storage: {
      get: (key) => safeStorage.getItem(key),
      set: (key, value) => {
        safeStorage.setItem(key, value);
      },
      remove: (key) => {
        safeStorage.removeItem(key);
      }
    }
  };
}
export {
  createDemoAdapter
};
//# sourceMappingURL=demo.js.map
