var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { createPortal } from "react-dom";
import { useQuery, useQueryClient, useMutation, QueryClientProvider, QueryClient } from "@tanstack/react-query";
import { isUTCTimestamp, isBusinessDay, CrosshairMode, ColorType, TickMarkType, LineStyle, PriceScaleMode, createChart } from "lightweight-charts";
import { AlertTriangle, RefreshCw, XCircle, CheckCircle2, Info, X, WifiOff, TrendingUp, TrendingDown, SlidersHorizontal, ArrowLeftRight, Target, Shield, BookOpen, Plus, Star, Pencil, Trash2, Globe, Clock, Scissors, History, Newspaper, RotateCcw, ClipboardCopy, ListTree, Settings, Bell, ArrowUpFromLine, ArrowDownToLine, CandlestickChart, List, Scaling, Paintbrush, ChevronDown, Bold, Italic, GripVertical, Type, EyeOff, Eye, BringToFront, Copy, Settings2, Lock, LockOpen, Ellipsis, ChevronsUp, ChevronsDown, MoveUpRight, Spline, Minus, MoveVertical, Equal, Waypoints, Brush, Highlighter, Route, Layers, Layers3, Square, Circle, Triangle, ArrowRight, Ruler, ChartNoAxesColumnIncreasing, CalendarRange, MoveDiagonal2, ArrowUpRight, ArrowDownRight, StickyNote, PenTool, MousePointer2, Magnet, PencilLine, ArrowUpToLine, CloudUpload, Save, Check, Play, Pause, Search, BarChart3, ArrowUpDown, Maximize2, Repeat, Crosshair, CalendarDays, AlignCenter, Activity, VolumeX, Volume2, Zap } from "lucide-react";
import * as React from "react";
import { Component, useEffect, startTransition, useState, useRef, useCallback, useSyncExternalStore, useContext, createContext, useMemo, memo, useLayoutEffect, useId } from "react";
import { create } from "zustand";
import { b as safeSession, u as uid, p as publish, a as subscribeChannel, s as safeStorage } from "./chunks/uid-Cv5r25IO.js";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { Slot } from "@radix-ui/react-slot";
import { cva } from "class-variance-authority";
import * as TooltipPrimitive$1 from "@radix-ui/react-tooltip";
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
function formatCurrency(value, decimals = 2) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  }).format(value);
}
function formatNumber(value, decimals = 2) {
  return new Intl.NumberFormat("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  }).format(value);
}
function formatDate(date) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(date));
}
function pnlClass(value) {
  if (value > 0) return "text-success";
  if (value < 0) return "text-destructive";
  return "text-muted-foreground";
}
function toLocalDateString(date = /* @__PURE__ */ new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
const buttonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border border-border bg-background hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
        buy: "bg-buy text-white hover:bg-buy/90",
        sell: "bg-sell text-white hover:bg-sell/90",
        success: "bg-success text-white hover:bg-success/90",
        warning: "bg-warning text-white hover:bg-warning/90"
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-7 rounded-md px-3 text-xs",
        lg: "h-10 rounded-md px-8",
        icon: "h-8 w-8"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const Button = React.forwardRef(
  ({ className, variant, size, asChild = false, loading, children, disabled, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsx(
      Comp,
      {
        className: cn(buttonVariants({ variant, size, className })),
        ref,
        disabled: disabled || loading,
        ...props,
        children: loading ? /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsxs("svg", { className: "mr-2 h-4 w-4 animate-spin", viewBox: "0 0 24 24", fill: "none", children: [
            /* @__PURE__ */ jsx(
              "circle",
              {
                className: "opacity-25",
                cx: "12",
                cy: "12",
                r: "10",
                stroke: "currentColor",
                strokeWidth: "4"
              }
            ),
            /* @__PURE__ */ jsx(
              "path",
              {
                className: "opacity-75",
                fill: "currentColor",
                d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
              }
            )
          ] }),
          children
        ] }) : children
      }
    );
  }
);
Button.displayName = "Button";
const Card = React.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx(
    "div",
    {
      ref,
      className: cn(
        "rounded-lg border border-border bg-card text-card-foreground shadow-sm",
        className
      ),
      ...props
    }
  )
);
Card.displayName = "Card";
const CardHeader = React.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx("div", { ref, className: cn("flex flex-col space-y-1.5 p-4", className), ...props })
);
CardHeader.displayName = "CardHeader";
const CardTitle = React.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx(
    "h3",
    {
      ref,
      className: cn("text-sm font-semibold leading-none tracking-tight", className),
      ...props
    }
  )
);
CardTitle.displayName = "CardTitle";
const CardDescription = React.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsx("p", { ref, className: cn("text-xs text-muted-foreground", className), ...props }));
CardDescription.displayName = "CardDescription";
const CardContent = React.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx("div", { ref, className: cn("p-4 pt-0", className), ...props })
);
CardContent.displayName = "CardContent";
const CardFooter = React.forwardRef(
  ({ className, ...props }, ref) => /* @__PURE__ */ jsx("div", { ref, className: cn("flex items-center p-4 pt-0", className), ...props })
);
CardFooter.displayName = "CardFooter";
class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    __publicField(this, "handleReset", () => {
      this.setState({ hasError: false, error: void 0 });
    });
    __publicField(this, "handleReload", () => {
      window.location.reload();
    });
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, info) {
    console.error("[ErrorBoundary] Caught error:", error, info.componentStack);
    const message = (error == null ? void 0 : error.message) || String(error);
    const isChunkLoadError = message.includes("Failed to fetch dynamically imported module") || message.includes("Importing a module script failed") || message.includes("ChunkLoadError") || /Failed to fetch.*\.(js|css)/.test(message);
    if (isChunkLoadError) {
      const RELOAD_KEY = "vite_chunk_reload_attempted";
      const last = safeSession.getItem(RELOAD_KEY);
      if (!last || Date.now() - Number(last) > 1e4) {
        safeSession.setItem(RELOAD_KEY, String(Date.now()));
        window.location.reload();
      }
    }
  }
  render() {
    var _a;
    if (this.state.hasError) {
      if (this.props.fallback) return this.props.fallback;
      return /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center min-h-[400px] p-6", children: /* @__PURE__ */ jsx(Card, { className: "max-w-md w-full", children: /* @__PURE__ */ jsxs(CardContent, { className: "pt-6 text-center space-y-4", children: [
        /* @__PURE__ */ jsx(AlertTriangle, { className: "h-12 w-12 text-warning mx-auto" }),
        /* @__PURE__ */ jsx("h2", { className: "text-lg font-semibold", children: "Something went wrong" }),
        /* @__PURE__ */ jsx("p", { className: "text-sm text-muted-foreground", children: ((_a = this.state.error) == null ? void 0 : _a.message) || "An unexpected error occurred" }),
        /* @__PURE__ */ jsxs("div", { className: "flex gap-2 justify-center", children: [
          /* @__PURE__ */ jsxs(Button, { variant: "outline", onClick: this.handleReset, children: [
            /* @__PURE__ */ jsx(RefreshCw, { className: "h-4 w-4 mr-1" }),
            "Try Again"
          ] }),
          /* @__PURE__ */ jsx(Button, { onClick: this.handleReload, children: "Reload Page" })
        ] })
      ] }) }) });
    }
    return this.props.children;
  }
}
let current = null;
const listeners$1 = /* @__PURE__ */ new Set();
function setAdapter(adapter) {
  const previous = current;
  current = adapter;
  for (const listener of [...listeners$1]) {
    try {
      listener(adapter);
    } catch (err) {
      console.error("[opencharts] adapter listener threw", err);
    }
  }
  return () => {
    if (current === adapter) current = previous;
  };
}
function getAdapter() {
  if (!current) {
    throw new Error(
      "[opencharts] No adapter installed. Wrap the terminal in <OpenChartsProvider adapter={...}>, or call setAdapter() before rendering. createDemoAdapter() runs against bundled data."
    );
  }
  return current;
}
function hasAdapter() {
  return current !== null;
}
function onAdapterChange(listener) {
  listeners$1.add(listener);
  return () => {
    listeners$1.delete(listener);
  };
}
let session = null;
const DEFAULT_SYMBOL = "BTCUSD";
const SESSION_BAR_LIMIT = 2e3;
const WARMUP_BARS = 30;
function emit(action, opts = {}) {
  publish("market-data", { eventType: "ReplayStateChanged", action, ...opts });
}
function dayBounds(sessionDate) {
  const startMs = (/* @__PURE__ */ new Date(`${sessionDate}T00:00:00`)).getTime();
  return { startMs, endMs: startMs + 24 * 60 * 60 * 1e3 };
}
async function getSession(sessionDate, symbol = DEFAULT_SYMBOL, accountId) {
  const adapter = getAdapter();
  const { startMs, endMs } = dayBounds(sessionDate);
  const bars = await adapter.marketData.getCandles({
    symbol,
    timeframe: "1m",
    limit: SESSION_BAR_LIMIT,
    fromMs: startMs,
    toMs: endMs
  });
  const tickBuffer = bars.filter((c) => {
    const ms = c.time * 1e3;
    return ms >= startMs && ms < endMs;
  }).map((c) => ({
    t: c.time * 1e3,
    o: c.open,
    h: c.high,
    l: c.low,
    c: c.close,
    v: c.volume ?? 0
  }));
  let tradeEvents = [];
  if (adapter.trading && accountId) ;
  return {
    replaySession: {
      id: (session == null ? void 0 : session.id) ?? uid(),
      status: (session == null ? void 0 : session.status) ?? "IDLE",
      speed: (session == null ? void 0 : session.speed) ?? 1,
      cursorTimestamp: (session == null ? void 0 : session.cursorTimestamp) != null ? new Date(session.cursorTimestamp).toISOString() : null,
      sessionDate
    },
    tickBuffer,
    tradeEvents,
    meta: {
      primarySymbol: tickBuffer.length > 0 ? symbol : null,
      sessionDate,
      tickCount: tickBuffer.length
    }
  };
}
async function start(sessionDate, speed = 1, symbol = DEFAULT_SYMBOL, accountId) {
  var _a;
  const payload = await getSession(sessionDate, symbol, accountId);
  const buffer = payload.tickBuffer;
  const first = buffer.length > 0 ? ((_a = buffer[Math.min(WARMUP_BARS, buffer.length - 1)]) == null ? void 0 : _a.t) ?? null : null;
  session = { id: uid(), status: "PLAYING", speed, cursorTimestamp: first, sessionDate };
  emit("started", { speed, ...first != null ? { cursorTimestamp: first } : {} });
  return { speed, seed: null };
}
function pause() {
  if (!session) return;
  session.status = "PAUSED";
  emit("paused");
}
function resume() {
  if (!session) return;
  session.status = "PLAYING";
  emit("resumed");
}
function stop() {
  if (session) session.status = "STOPPED";
  session = null;
  emit("stopped");
}
function setSpeed(speed) {
  if (session) session.speed = speed;
  emit("speed", { speed });
  return { speed };
}
function seek(timestamp) {
  const ms = typeof timestamp === "number" ? timestamp : Date.parse(timestamp);
  if (session && Number.isFinite(ms)) session.cursorTimestamp = ms;
  emit("seek", { cursorTimestamp: ms });
  return { cursorTimestamp: new Date(ms).toISOString() };
}
function patchSession(patch) {
  if (!session) return;
  if (patch.cursorTimestamp != null) session.cursorTimestamp = patch.cursorTimestamp;
  if (patch.sessionDate) session.sessionDate = patch.sessionDate;
}
class ApiError extends Error {
  constructor(message, status = 0, code = "API_ERROR") {
    super(message);
    __publicField(this, "status");
    __publicField(this, "code");
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}
function trading() {
  const gateway = getAdapter().trading;
  if (!gateway) {
    throw new ApiError(
      "This OpenCharts adapter provides market data only — trading is not available.",
      501,
      "TRADING_UNSUPPORTED"
    );
  }
  return gateway;
}
async function readJSON(key, fallback) {
  const storage = getAdapter().storage;
  if (!storage) return fallback;
  try {
    const raw = await storage.get(key);
    if (raw == null) return fallback;
    const parsed = JSON.parse(raw);
    return parsed ?? fallback;
  } catch {
    return fallback;
  }
}
async function writeJSON(key, value) {
  const storage = getAdapter().storage;
  if (!storage) return;
  try {
    await storage.set(key, JSON.stringify(value));
  } catch {
  }
}
const DRAW_KEY = (symbol) => `oc_drawings_${symbol}`;
const JOURNAL_KEY = "oc_journal_entries";
const chartDrawings = {
  list: async (symbol) => {
    const list = await readJSON(DRAW_KEY(symbol), []);
    return Array.isArray(list) ? list : [];
  },
  save: async (symbol, _timeframe, drawing) => {
    const list = (await chartDrawings.list(symbol)).filter((d) => d.id !== drawing.id);
    list.push(drawing);
    await writeJSON(DRAW_KEY(symbol), list);
    return { saved: true };
  },
  remove: async (drawingId) => {
    const symbols = await api.getSymbols();
    for (const symbol of symbols) {
      const list = await chartDrawings.list(symbol.name);
      if (list.some((d) => d.id === drawingId)) {
        await writeJSON(
          DRAW_KEY(symbol.name),
          list.filter((d) => d.id !== drawingId)
        );
      }
    }
    return { deleted: true };
  },
  clear: async (symbol) => {
    await writeJSON(DRAW_KEY(symbol), []);
    return { cleared: true };
  }
};
function metricsFrom(account) {
  var _a;
  return {
    accountId: account.id,
    equity: account.equity,
    balance: account.balance,
    freeMargin: account.freeMargin,
    marginUsed: account.margin,
    floatingPnl: account.equity - account.balance,
    dailyPnl: 0,
    ddDaily: null,
    ddDailyMax: null,
    ddTotal: null,
    ddTotalMax: null,
    ddTrailing: null,
    ddTrailingMax: null,
    trailingDrawdownFloor: null,
    trailingDrawdownPeak: null,
    trailingDrawdownMode: null,
    trailingDrawdownTrailMode: null,
    trailingDrawdownFloorLocked: false,
    trailingDrawdownTrailToBreakeven: false,
    profitTargetPercent: null,
    profitTargetProgress: 0,
    minTradingDays: null,
    tradingDaysCompleted: 0,
    minDaysProgress: 0,
    status: account.status,
    phase: account.phase,
    highWaterMark: account.balance,
    startingBalance: ((_a = account.template) == null ? void 0 : _a.startingBalance) ?? account.balance,
    currency: "USD",
    lastMarkTs: (/* @__PURE__ */ new Date()).toISOString()
  };
}
const candlesPayload = (candles) => ({
  candles: candles.map((c) => ({ ...c, timestamp: c.time * 1e3 })),
  metadata: { isPartial: false, backfillQueued: false, historicalCoverageStart: null }
});
const DEMO_USER = {
  id: "demo-user",
  email: "demo@opencharts.dev",
  firstName: "Demo",
  lastName: "Trader",
  roles: ["trader"],
  status: "ACTIVE",
  createdAt: (/* @__PURE__ */ new Date()).toISOString()
};
const authResponse = () => ({
  accessToken: "local",
  refreshToken: "local",
  user: DEMO_USER
});
const api = {
  // ── Session ──
  // OpenCharts ships no authentication: the host application owns identity and
  // decides what its adapter exposes. These keep the existing store happy.
  login: (_email, _password) => Promise.resolve(authResponse()),
  demoLogin: () => Promise.resolve(authResponse()),
  completeMfaLogin: (_token, _code) => Promise.resolve(authResponse()),
  logout: (_refreshToken) => Promise.resolve({ success: true }),
  refreshToken: (_token) => Promise.resolve({ accessToken: "local", refreshToken: "local" }),
  // ── Market data ──
  getSymbols: async () => getAdapter().marketData.getSymbols(),
  getCandles: async (symbol, timeframe, limit, range) => getAdapter().marketData.getCandles({
    symbol,
    timeframe,
    limit,
    fromMs: range == null ? void 0 : range.fromMs,
    toMs: range == null ? void 0 : range.toMs
  }),
  getCandlesWithMeta: async (symbol, timeframe, limit, range) => api.getCandles(symbol, timeframe, limit, range).then(candlesPayload),
  getTick: async (symbol) => {
    var _a, _b;
    const quote = await ((_b = (_a = getAdapter().marketData).getQuote) == null ? void 0 : _b.call(_a, symbol));
    return quote ?? { symbol, bid: 0, ask: 0, timestamp: Date.now() };
  },
  getMarketDataHealth: () => Promise.resolve({ status: "ok" }),
  /** No calendar provider in the contract; hosts render their own if they have one. */
  getEconomicCalendar: (_currencies, _from, _to) => Promise.resolve([]),
  // ── Accounts ──
  // These are `async` so a missing gateway (or a throwing one) rejects rather
  // than throwing synchronously past the caller's .catch().
  getMyAccounts: async () => trading().getAccounts(),
  getAccountMetrics: async (accountId) => {
    const accounts = await trading().getAccounts();
    const account = accounts.find((a) => a.id === accountId) ?? accounts[0];
    if (!account) throw new ApiError("No trading account available", 404, "NO_ACCOUNT");
    return metricsFrom(account);
  },
  // ── Trading ──
  getPositions: async (accountId) => trading().getPositions(accountId),
  getOrders: async (accountId, status) => trading().getOrders(accountId, status),
  getClosedPositions: async (accountId, page = 1) => trading().getClosedPositions(accountId, page),
  placeOrder: async (input) => trading().placeOrder(input),
  modifyOrder: async (orderId, modification) => trading().modifyOrder(orderId, modification),
  cancelOrder: async (orderId) => {
    await trading().cancelOrder(orderId);
    return { success: true };
  },
  cancelAllOrders: async (accountId) => {
    await trading().cancelAllOrders(accountId);
    return { success: true };
  },
  closePosition: async (positionId, quantity) => {
    await trading().closePosition(positionId, quantity);
    return { success: true };
  },
  closeAllPositions: async (accountId) => {
    await trading().closeAllPositions(accountId);
    return { success: true };
  },
  modifyPosition: async (positionId, modification) => trading().modifyPosition(positionId, modification),
  // ── Chart persistence ──
  chartDrawings,
  getPreferences: () => Promise.resolve(null),
  savePreferences: (_prefs) => Promise.resolve({ success: true }),
  // ── Trade journal ──
  getJournalEntries: async (accountId, opts) => {
    const all = await readJSON(JOURNAL_KEY, []);
    let entries = (Array.isArray(all) ? all : []).filter((e) => e.accountId === accountId);
    if (opts == null ? void 0 : opts.symbol) entries = entries.filter((e) => e.symbolName === opts.symbol);
    const total = entries.length;
    if ((opts == null ? void 0 : opts.limit) != null && opts.limit > 0) entries = entries.slice(0, opts.limit);
    return { entries, total };
  },
  createJournalEntry: async (data) => {
    const entry = {
      id: uid(),
      accountId: data.accountId,
      positionId: data.positionId ?? null,
      symbolName: data.symbolName ?? null,
      side: data.side ?? null,
      entryPrice: data.entryPrice ?? null,
      exitPrice: data.exitPrice ?? null,
      pnl: data.pnl ?? null,
      emotion: data.emotion ?? null,
      setupType: null,
      rating: data.rating ?? null,
      tags: data.tags ?? [],
      notes: data.notes ?? "",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    const all = await readJSON(JOURNAL_KEY, []);
    await writeJSON(JOURNAL_KEY, [entry, ...Array.isArray(all) ? all : []]);
    return entry;
  },
  updateJournalEntry: async (id, data) => {
    const all = await readJSON(JOURNAL_KEY, []);
    const list = Array.isArray(all) ? [...all] : [];
    const idx = list.findIndex((e) => e.id === id);
    if (idx < 0) return null;
    const updated = {
      ...list[idx],
      ...data.emotion !== void 0 ? { emotion: data.emotion } : {},
      ...data.rating !== void 0 ? { rating: data.rating } : {},
      ...data.tags !== void 0 ? { tags: data.tags } : {},
      ...data.notes !== void 0 ? { notes: data.notes } : {}
    };
    list[idx] = updated;
    await writeJSON(JOURNAL_KEY, list);
    return updated;
  },
  deleteJournalEntry: async (id) => {
    const all = await readJSON(JOURNAL_KEY, []);
    const list = Array.isArray(all) ? all : [];
    await writeJSON(
      JOURNAL_KEY,
      list.filter((e) => e.id !== id)
    );
    return { success: true };
  },
  // ── Session replay ──
  // Built on top of `marketData.getCandles`, so replay works against any
  // adapter rather than needing one of its own.
  replayGetSession: (_accountId, sessionDate, symbol) => getSession(sessionDate, symbol),
  replayStart: (_accountId, sessionDate, speed = 1, symbol) => start(sessionDate, speed, symbol),
  replayPause: (_accountId, _sessionDate) => {
    pause();
    return Promise.resolve({ success: true });
  },
  replayResume: (_accountId, _sessionDate) => {
    resume();
    return Promise.resolve({ success: true });
  },
  replayStop: (_accountId, _sessionDate) => {
    stop();
    return Promise.resolve({ success: true });
  },
  replaySetSpeed: (_accountId, _sessionDate, speed) => Promise.resolve(setSpeed(speed)),
  replaySeek: (_accountId, _sessionDate, timestamp) => Promise.resolve(seek(timestamp)),
  replayPatchSession: (_accountId, patch) => {
    patchSession(patch);
    return Promise.resolve({ success: true });
  }
};
const TRADING_EVENT_CHANNEL = {
  "position.opened": "positions",
  "position.updated": "positions",
  "position.closed": "positions",
  "order.placed": "orders",
  "order.filled": "orders",
  "order.canceled": "orders",
  "order.rejected": "orders",
  "account.updated": "account"
};
const LEGACY_EVENT_NAME = {
  "position.opened": "PositionOpened",
  "position.updated": "PositionUpdated",
  "position.closed": "PositionClosed",
  "order.placed": "OrderPlaced",
  "order.filled": "OrderFilled",
  "order.canceled": "OrderCanceled",
  "order.rejected": "OrderRejected",
  "account.updated": "EquityUpdated"
};
function toChannelEvent(event) {
  const base = { eventType: LEGACY_EVENT_NAME[event.type], accountId: event.accountId };
  if (event.type === "account.updated") {
    return {
      ...base,
      equity: event.equity,
      balance: event.balance,
      freeMargin: event.freeMargin,
      marginUsed: event.marginUsed
    };
  }
  if (event.type.startsWith("order.")) {
    const order = event;
    return { ...base, orderId: order.orderId, _entity: order.entity };
  }
  const position = event;
  return {
    ...base,
    positionId: position.positionId,
    _entity: "entity" in position ? position.entity : void 0,
    unrealizedPnl: "unrealizedPnl" in position ? position.unrealizedPnl : void 0,
    quantity: "quantity" in position ? position.quantity : void 0,
    averagePrice: "averagePrice" in position ? position.averagePrice : void 0
  };
}
class AdapterWsClient {
  constructor() {
    __publicField(this, "_state", "disconnected");
    __publicField(this, "stateListeners", /* @__PURE__ */ new Set());
    __publicField(this, "teardown", []);
    __publicField(this, "connected", false);
    onAdapterChange(() => {
      if (!this.connected) return;
      this.detach();
      this.attach();
    });
  }
  get state() {
    return this._state;
  }
  setState(next) {
    if (this._state === next) return;
    this._state = next;
    for (const cb of [...this.stateListeners]) {
      try {
        cb(next);
      } catch (err) {
        console.error("[ws] connection listener threw", err);
      }
    }
  }
  attach() {
    var _a, _b;
    if (!hasAdapter()) return;
    const adapter = getAdapter();
    this.teardown.push(
      adapter.marketData.subscribe((event) => {
        if (event.type === "tick") {
          publish("market-data", {
            eventType: "MarketTick",
            symbol: event.symbol,
            bid: event.bid,
            ask: event.ask,
            occurredAt: event.timestamp ?? Date.now()
          });
          return;
        }
        publish("market-data", {
          eventType: "CandleUpdate",
          symbol: event.symbol,
          timeframe: event.timeframe,
          open: event.open,
          high: event.high,
          low: event.low,
          close: event.close,
          volume: event.volume,
          timestamp: event.timestamp
        });
      })
    );
    if (adapter.trading) {
      this.teardown.push(
        adapter.trading.subscribe((event) => {
          const channel = TRADING_EVENT_CHANNEL[event.type];
          if (channel) publish(channel, toChannelEvent(event));
        })
      );
    }
    if (adapter.marketData.onConnectionChange) {
      this.teardown.push(adapter.marketData.onConnectionChange((s) => this.setState(s)));
    }
    void ((_b = (_a = adapter.marketData).connect) == null ? void 0 : _b.call(_a));
    if (!adapter.marketData.onConnectionChange) {
      setTimeout(() => this.setState("connected"), 0);
    }
  }
  detach() {
    for (const off of this.teardown.splice(0)) {
      try {
        off();
      } catch (err) {
        console.error("[ws] failed to unsubscribe", err);
      }
    }
  }
  connect(_token) {
    if (this.connected) return;
    this.connected = true;
    this.setState("connecting");
    this.attach();
  }
  disconnect() {
    var _a, _b;
    if (!this.connected) return;
    this.connected = false;
    this.detach();
    if (hasAdapter()) (_b = (_a = getAdapter().marketData).disconnect) == null ? void 0 : _b.call(_a);
    this.setState("disconnected");
  }
  reauthenticate(_token) {
  }
  subscribe(channel, handler) {
    return subscribeChannel(channel, handler);
  }
  subscribeAccounts(_accountIds) {
  }
  setSymbolInterest(symbols) {
    var _a, _b;
    if (!hasAdapter()) return;
    (_b = (_a = getAdapter().marketData).setSymbolInterest) == null ? void 0 : _b.call(_a, symbols);
  }
  onStateChange(cb) {
    this.stateListeners.add(cb);
    cb(this._state);
    return () => {
      this.stateListeners.delete(cb);
    };
  }
  /** Push an event onto a channel directly (used by tests and tooling). */
  emit(channel, event) {
    publish(channel, event);
  }
}
const wsClient = new AdapterWsClient();
const useAuthStore = create((set, get) => ({
  accessToken: safeStorage.getItem("access_token"),
  refreshToken: safeStorage.getItem("refresh_token"),
  user: safeStorage.getJSON("user", null),
  isDemo: safeStorage.getItem("is_demo") === "true",
  mfaPending: null,
  login: async (email, password) => {
    const data = await api.login(email, password);
    if ("mfaRequired" in data && data.mfaRequired) {
      const mfaData = data;
      set({
        mfaPending: {
          mfaToken: mfaData.mfaToken,
          userId: mfaData.userId
        }
      });
      return;
    }
    safeStorage.setItem("access_token", data.accessToken);
    safeStorage.setItem("refresh_token", data.refreshToken);
    safeStorage.setItem("user", JSON.stringify(data.user));
    safeStorage.removeItem("is_demo");
    set({
      accessToken: data.accessToken,
      refreshToken: data.refreshToken,
      user: data.user,
      isDemo: false,
      mfaPending: null
    });
    wsClient.connect(data.accessToken);
  },
  googleLogin: async (credential, firmSlug) => {
    var _a;
    const BASE = "";
    const res = await fetch(`${BASE}/api/auth/google`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ credential, firmSlug })
    });
    const json = await res.json().catch(() => null);
    if (!res.ok) throw new Error(((_a = json == null ? void 0 : json.error) == null ? void 0 : _a.message) || "Google login failed");
    const data = (json == null ? void 0 : json.data) ?? json;
    safeStorage.setItem("access_token", data.accessToken);
    safeStorage.setItem("refresh_token", data.refreshToken);
    safeStorage.setItem("user", JSON.stringify(data.user));
    safeStorage.removeItem("is_demo");
    set({
      accessToken: data.accessToken,
      refreshToken: data.refreshToken,
      user: data.user,
      isDemo: false,
      mfaPending: null
    });
    wsClient.connect(data.accessToken);
  },
  demoLogin: async () => {
    safeStorage.removeItem("active_account");
    safeStorage.setItem("theme", "dark");
    const data = await api.demoLogin();
    safeStorage.setItem("access_token", data.accessToken);
    safeStorage.setItem("refresh_token", data.refreshToken);
    safeStorage.setItem("user", JSON.stringify(data.user));
    safeStorage.setItem("is_demo", "true");
    set({
      accessToken: data.accessToken,
      refreshToken: data.refreshToken,
      user: data.user,
      isDemo: true,
      mfaPending: null
    });
    wsClient.connect(data.accessToken);
  },
  completeMfa: async (code) => {
    const pending = get().mfaPending;
    if (!pending) throw new Error("No MFA pending");
    const data = await api.completeMfaLogin(pending.mfaToken, code);
    safeStorage.setItem("access_token", data.accessToken);
    safeStorage.setItem("refresh_token", data.refreshToken);
    safeStorage.setItem("user", JSON.stringify(data.user));
    set({
      accessToken: data.accessToken,
      refreshToken: data.refreshToken,
      user: data.user,
      mfaPending: null
    });
    wsClient.connect(data.accessToken);
  },
  cancelMfa: () => {
    set({ mfaPending: null });
  },
  logout: () => {
    const rt = safeStorage.getItem("refresh_token");
    api.logout(rt || void 0).catch(() => {
    });
    safeStorage.removeItem("access_token");
    safeStorage.removeItem("refresh_token");
    safeStorage.removeItem("user");
    safeStorage.removeItem("is_demo");
    safeStorage.removeItem("active_account");
    set({ accessToken: null, refreshToken: null, user: null, isDemo: false });
    wsClient.disconnect();
  },
  restoreSession: async () => {
    const token = safeStorage.getItem("access_token");
    if (!token) return;
    const rt = safeStorage.getItem("refresh_token");
    if (rt && isTokenStale(token)) {
      try {
        const result = await api.refreshToken(rt);
        safeStorage.setItem("access_token", result.accessToken);
        safeStorage.setItem("refresh_token", result.refreshToken);
        set({ accessToken: result.accessToken, refreshToken: result.refreshToken });
        wsClient.connect(result.accessToken);
        startTokenRefresh();
      } catch {
        get().logout();
      }
      return;
    }
    wsClient.connect(token);
    if (rt) startTokenRefresh();
  }
}));
let refreshTimer = null;
function isTokenStale(token, thresholdMs = 5 * 60 * 1e3) {
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    return payload.exp * 1e3 - Date.now() < thresholdMs;
  } catch {
    return true;
  }
}
function getTokenExpiresIn(token) {
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    const exp = payload.exp;
    if (typeof exp !== "number") return 13 * 60 * 1e3;
    const msRemaining = exp * 1e3 - Date.now();
    return Math.max(msRemaining - 6e4, 6e4);
  } catch {
    return 13 * 60 * 1e3;
  }
}
function startTokenRefresh() {
  stopTokenRefresh();
  let retries = 0;
  const MAX_RETRIES = 3;
  const doRefresh = async () => {
    const rt = safeStorage.getItem("refresh_token");
    if (!rt) return;
    try {
      const result = await api.refreshToken(rt);
      retries = 0;
      safeStorage.setItem("access_token", result.accessToken);
      safeStorage.setItem("refresh_token", result.refreshToken);
      useAuthStore.setState({
        accessToken: result.accessToken,
        refreshToken: result.refreshToken
      });
      wsClient.reauthenticate(result.accessToken);
      const nextDelay = getTokenExpiresIn(result.accessToken);
      refreshTimer = setTimeout(doRefresh, nextDelay);
    } catch {
      retries++;
      if (retries <= MAX_RETRIES) {
        const backoff = retries * 5e3;
        refreshTimer = setTimeout(doRefresh, backoff);
      } else {
        useAuthStore.getState().logout();
      }
    }
  };
  const currentToken = safeStorage.getItem("access_token");
  const firstDelay = currentToken ? getTokenExpiresIn(currentToken) : 13 * 60 * 1e3;
  refreshTimer = setTimeout(doRefresh, firstDelay);
}
function stopTokenRefresh() {
  if (refreshTimer) {
    clearTimeout(refreshTimer);
    refreshTimer = null;
  }
}
const _pendingTicks = /* @__PURE__ */ new Map();
let _tickRafId = null;
const _pendingLiveTicks = /* @__PURE__ */ new Map();
let _liveTickRafId = null;
const _symbolDecimals = /* @__PURE__ */ new Map();
function _pipDecimals(tickSize) {
  if (!tickSize || !Number.isFinite(tickSize) || tickSize <= 0) return 5;
  const fixed = tickSize.toFixed(20).replace(/0+$/, "");
  const dot = fixed.indexOf(".");
  if (dot < 0) return 0;
  return Math.min(10, fixed.length - dot - 1);
}
const useTradingStore = create((set, get) => ({
  activeAccountId: safeStorage.getItem("active_account"),
  accounts: [],
  positions: [],
  orders: [],
  symbols: [],
  selectedSymbol: "BTCUSD",
  ticks: {},
  liveTicks: {},
  liveCandleUpdates: {},
  replayVersion: 0,
  isReplaying: false,
  replayPaused: false,
  replaySpeed: 1,
  replayCursorTimestamp: null,
  replaySessionDate: null,
  setActiveAccount: (id) => {
    safeStorage.setItem("active_account", id);
    set({ activeAccountId: id });
  },
  loadAccounts: async () => {
    var _a;
    const accounts = await api.getMyAccounts();
    set({ accounts });
    const currentId = get().activeAccountId;
    const currentValid = currentId && accounts.some((account) => account.id === currentId);
    if (!currentValid && accounts.length > 0) {
      const firstAccountId = (_a = accounts[0]) == null ? void 0 : _a.id;
      if (firstAccountId) get().setActiveAccount(firstAccountId);
    }
    wsClient.subscribeAccounts(accounts.map((account) => account.id));
  },
  updateAccountInStore: (updated) => {
    set((state) => ({
      accounts: state.accounts.map(
        (account) => account.id === updated.id ? { ...account, ...updated } : account
      )
    }));
  },
  loadPositions: async () => {
    const id = get().activeAccountId;
    if (!id) return;
    const positions = await api.getPositions(id);
    set({ positions });
  },
  loadOrders: async () => {
    const id = get().activeAccountId;
    if (!id) return;
    const orders = await api.getOrders(id);
    set({ orders });
  },
  loadSymbols: async () => {
    const symbols = await api.getSymbols();
    set({ symbols });
  },
  updateTick: (symbolName, bid, ask, timestamp) => {
    const pending = _pendingTicks.get(symbolName);
    if (pending && pending.bid === bid && pending.ask === ask && pending.timestamp >= timestamp)
      return;
    if (!pending) {
      const committed = get().ticks[symbolName];
      if (committed && committed.bid === bid && committed.ask === ask && committed.timestamp >= timestamp)
        return;
    }
    if (!_symbolDecimals.has(symbolName)) {
      const sym = get().symbols.find((s) => s.name === symbolName);
      if (sym) _symbolDecimals.set(symbolName, _pipDecimals(sym.tickSize));
    }
    const decimals = _symbolDecimals.get(symbolName) ?? 5;
    _pendingTicks.set(symbolName, {
      bid,
      ask,
      timestamp,
      bidFmt: bid.toFixed(decimals),
      askFmt: ask.toFixed(decimals)
    });
    if (_tickRafId === null) {
      _tickRafId = requestAnimationFrame(() => {
        const updates = Object.fromEntries(_pendingTicks);
        _pendingTicks.clear();
        _tickRafId = null;
        set((s) => ({ ticks: { ...s.ticks, ...updates } }));
      });
    }
  },
  updateLiveTick: (symbolName, bid, ask, timestamp) => {
    const pending = _pendingLiveTicks.get(symbolName);
    if (pending && pending.bid === bid && pending.ask === ask && pending.timestamp >= timestamp)
      return;
    if (!pending) {
      const committed = get().liveTicks[symbolName];
      if (committed && committed.bid === bid && committed.ask === ask && committed.timestamp >= timestamp)
        return;
    }
    if (!_symbolDecimals.has(symbolName)) {
      const sym = get().symbols.find((s) => s.name === symbolName);
      if (sym) _symbolDecimals.set(symbolName, _pipDecimals(sym.tickSize));
    }
    const decimals = _symbolDecimals.get(symbolName) ?? 5;
    _pendingLiveTicks.set(symbolName, {
      bid,
      ask,
      timestamp,
      bidFmt: bid.toFixed(decimals),
      askFmt: ask.toFixed(decimals)
    });
    if (_liveTickRafId === null) {
      _liveTickRafId = requestAnimationFrame(() => {
        const updates = Object.fromEntries(_pendingLiveTicks);
        _pendingLiveTicks.clear();
        _liveTickRafId = null;
        set((s) => ({ liveTicks: { ...s.liveTicks, ...updates } }));
      });
    }
  },
  updateCandleFromWs: (symbol, timeframe, bar) => {
    const key = `${symbol}:${timeframe}`;
    set((state) => ({
      liveCandleUpdates: { ...state.liveCandleUpdates, [key]: bar }
    }));
  },
  setSelectedSymbol: (symbol) => set(
    (state) => state.selectedSymbol === symbol ? { selectedSymbol: symbol } : { selectedSymbol: symbol, liveCandleUpdates: {} }
  ),
  setPositions: (positions) => set({ positions }),
  setOrders: (orders) => set({ orders }),
  setReplaySessionDate: (date) => set({ replaySessionDate: date }),
  onReplayStateChanged: (action, opts) => {
    set((state) => nextReplayState(state, action, opts));
  }
}));
function replayPausedAfter(action, prevPaused) {
  if (action === "stopped" || action === "started" || action === "resumed") return false;
  if (action === "paused") return true;
  return prevPaused;
}
function nextReplayState(state, action, opts) {
  const isStopped = action === "stopped";
  return {
    replayVersion: state.replayVersion + 1,
    isReplaying: !isStopped,
    replayPaused: replayPausedAfter(action, state.replayPaused),
    replaySpeed: isStopped ? 1 : (opts == null ? void 0 : opts.speed) ?? state.replaySpeed,
    replayCursorTimestamp: isStopped ? null : (opts == null ? void 0 : opts.cursorTimestamp) ?? state.replayCursorTimestamp,
    replaySessionDate: isStopped ? null : state.replaySessionDate,
    liveCandleUpdates: {}
  };
}
let wasWsConnected = wsClient.state === "connected";
wsClient.onStateChange((state) => {
  if (state === "connected" && !wasWsConnected) {
    const accountIds = useTradingStore.getState().accounts.map((a) => a.id);
    if (accountIds.length > 0) wsClient.subscribeAccounts(accountIds);
  }
  wasWsConnected = state === "connected";
});
const queryKeys = {
  accounts: {
    all: ["accounts"],
    mine: () => [...queryKeys.accounts.all, "mine"],
    detail: (id) => [...queryKeys.accounts.all, id],
    stats: (id) => [...queryKeys.accounts.all, id, "stats"],
    ledger: (id, page) => [...queryKeys.accounts.all, id, "ledger", page],
    equity: (id) => [...queryKeys.accounts.all, id, "equity"]
  },
  trading: {
    positions: (accountId) => ["positions", accountId],
    orders: (accountId, status) => ["orders", accountId, status],
    fills: (accountId, page) => ["fills", accountId, page],
    closedPositions: (accountId, page) => ["closedPositions", accountId, page]
  },
  market: {
    symbols: ["symbols"],
    candles: (symbol, tf) => ["candles", symbol, tf],
    economicCalendar: (currencies) => ["economicCalendar", ...currencies]
  },
  replay: {
    session: (accountId, date) => ["replay", "session", accountId, date]
  }
};
function usePositions(accountId) {
  return useQuery({
    queryKey: queryKeys.trading.positions(accountId),
    queryFn: () => api.getPositions(accountId),
    enabled: !!accountId,
    // WS push (MarketDataBridge setQueryData) is the primary update path.
    // 10s staleTime prevents the cache from being considered stale during burst fills,
    // so rapid invalidations don't all trigger fresh fetches.
    // 30s refetchInterval is a safety-net sync in case a WS event is missed; it is
    // NOT the primary update mechanism and must not be lowered back to 2s.
    staleTime: 1e4,
    refetchInterval: 3e4,
    refetchOnWindowFocus: false
  });
}
function useOrders(accountId, status) {
  return useQuery({
    queryKey: queryKeys.trading.orders(accountId, status),
    queryFn: () => api.getOrders(accountId, status),
    enabled: !!accountId,
    staleTime: 1e4,
    refetchInterval: 3e4,
    refetchOnWindowFocus: false
  });
}
function useClosedPositions(accountId, page = 1) {
  return useQuery({
    queryKey: queryKeys.trading.closedPositions(accountId, page),
    queryFn: () => api.getClosedPositions(accountId, page),
    enabled: !!accountId,
    staleTime: 3e4
  });
}
function useSymbols() {
  return useQuery({
    queryKey: queryKeys.market.symbols,
    queryFn: () => api.getSymbols(),
    staleTime: 5 * 6e4
    // 5min
  });
}
function useEconomicCalendar(currencies) {
  return useQuery({
    queryKey: queryKeys.market.economicCalendar(currencies),
    queryFn: async () => {
      const now = /* @__PURE__ */ new Date();
      const from = new Date(now);
      from.setDate(from.getDate() - 14);
      const to = new Date(now);
      to.setDate(to.getDate() + 14);
      const res = await api.getEconomicCalendar(
        currencies,
        from.toISOString().split("T")[0],
        to.toISOString().split("T")[0]
      );
      return res;
    },
    enabled: currencies.length > 0,
    staleTime: 10 * 6e4
    // refresh every 10min
  });
}
function useCandles(symbol, timeframe, limit, replayVersion) {
  return useQuery({
    // Include replayVersion in the query key so each replay session forces a
    // completely fresh query — React Query won't reuse structural sharing or
    // stale cache from a previous replay / normal session.
    queryKey: [...queryKeys.market.candles(symbol, timeframe), limit ?? "auto", replayVersion ?? 0],
    queryFn: () => api.getCandlesWithMeta(symbol, timeframe, limit),
    // Extract just the candles array for consumers — raw payload (with isPartial)
    // is still accessible via query.state.data inside refetchInterval below.
    select: (data) => data.candles,
    staleTime: 3e4,
    // Keep previously-fetched candles visible while a new depth query (different
    // limit in the key) is in-flight. Without this, switching from firstPaint
    // → deep limit causes a momentary empty array, which lets a live WS candle
    // paint as the only bar before history arrives.
    placeholderData: (prev) => prev,
    // When the server signals the response is partial (backfill queued), poll
    // at 3 s until data fills in. Otherwise use the 5-min safety-net cadence.
    refetchInterval: (query) => {
      var _a, _b;
      return ((_b = (_a = query.state.data) == null ? void 0 : _a.metadata) == null ? void 0 : _b.isPartial) ? 3e3 : 5 * 6e4;
    }
  });
}
function useAccountMetrics(accountId) {
  return useQuery({
    queryKey: ["account-metrics", accountId],
    queryFn: () => api.getAccountMetrics(accountId),
    enabled: !!accountId,
    staleTime: 1e4,
    refetchInterval: 3e4
  });
}
function usePlaceOrder() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input) => api.placeOrder(input),
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({
        queryKey: queryKeys.trading.orders(vars.accountId)
      });
      qc.invalidateQueries({
        queryKey: queryKeys.trading.positions(vars.accountId)
      });
      qc.invalidateQueries({
        queryKey: queryKeys.accounts.detail(vars.accountId)
      });
    }
  });
}
function useCancelOrder() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ orderId }) => api.cancelOrder(orderId),
    onMutate: async ({ orderId, accountId }) => {
      await qc.cancelQueries({ queryKey: queryKeys.trading.orders(accountId) });
      const prev = qc.getQueryData(queryKeys.trading.orders(accountId));
      if (prev) {
        qc.setQueryData(
          queryKeys.trading.orders(accountId),
          prev.map((o) => o.id === orderId ? { ...o, status: "CANCELLED" } : o)
        );
      }
      return { prev };
    },
    onError: (_err, { accountId }, ctx) => {
      if (ctx == null ? void 0 : ctx.prev) qc.setQueryData(queryKeys.trading.orders(accountId), ctx.prev);
    },
    onSettled: (_data, _err, { accountId }) => {
      qc.invalidateQueries({ queryKey: queryKeys.trading.orders(accountId) });
    }
  });
}
function useClosePosition() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({
      positionId,
      quantity
    }) => api.closePosition(positionId, quantity),
    onSuccess: (_data, { accountId }) => {
      qc.invalidateQueries({
        queryKey: queryKeys.trading.positions(accountId)
      });
      qc.invalidateQueries({ queryKey: queryKeys.accounts.detail(accountId) });
      qc.invalidateQueries({ queryKey: ["fills", accountId] });
    }
  });
}
function useCloseAllPositions() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (accountId) => api.closeAllPositions(accountId),
    onSuccess: (_data, accountId) => {
      qc.invalidateQueries({
        queryKey: queryKeys.trading.positions(accountId)
      });
      qc.invalidateQueries({ queryKey: queryKeys.accounts.detail(accountId) });
    }
  });
}
function useJournalEntries(accountId, opts) {
  return useQuery({
    queryKey: ["journal", accountId, opts == null ? void 0 : opts.symbol],
    queryFn: () => api.getJournalEntries(accountId, { limit: 100, symbol: opts == null ? void 0 : opts.symbol }),
    enabled: !!accountId,
    staleTime: 1e4
  });
}
function useCreateJournalEntry() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data) => api.createJournalEntry(data),
    onSuccess: (_d, vars) => qc.invalidateQueries({ queryKey: ["journal", vars.accountId] })
  });
}
function useUpdateJournalEntry() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      ...data
    }) => api.updateJournalEntry(id, data),
    onSuccess: (_d, vars) => qc.invalidateQueries({ queryKey: ["journal", vars.accountId] })
  });
}
function useDeleteJournalEntry() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id }) => api.deleteJournalEntry(id),
    onSuccess: (_d, vars) => qc.invalidateQueries({ queryKey: ["journal", vars.accountId] })
  });
}
function useReplaySession(accountId, sessionDate, symbol) {
  return useQuery({
    queryKey: [...queryKeys.replay.session(accountId, sessionDate), symbol ?? "auto"],
    queryFn: () => api.replayGetSession(accountId, sessionDate, symbol),
    enabled: !!accountId && !!sessionDate,
    // 30s, not Infinity — replaying *today* a second time must pick up trades
    // and candles recorded since the previous run.
    staleTime: 3e4,
    gcTime: 5 * 60 * 1e3
  });
}
const _invalidateTimers = /* @__PURE__ */ new Map();
function coalesceInvalidation(queryClient, queryKey, delayMs = 150) {
  const key = JSON.stringify(queryKey);
  const existing = _invalidateTimers.get(key);
  if (existing) clearTimeout(existing);
  _invalidateTimers.set(
    key,
    setTimeout(() => {
      _invalidateTimers.delete(key);
      queryClient.invalidateQueries({ queryKey });
    }, delayMs)
  );
}
const _positionBatchBuffers = /* @__PURE__ */ new Map();
const _positionBatchTimers = /* @__PURE__ */ new Map();
function bufferPositionOpened(accountId, entity, queryClient, posKey) {
  const existing = _positionBatchBuffers.get(accountId) ?? [];
  existing.push(entity);
  _positionBatchBuffers.set(accountId, existing);
  const prev = _positionBatchTimers.get(accountId);
  if (prev) clearTimeout(prev);
  _positionBatchTimers.set(
    accountId,
    setTimeout(() => {
      const entities = _positionBatchBuffers.get(accountId) ?? [];
      _positionBatchBuffers.delete(accountId);
      _positionBatchTimers.delete(accountId);
      if (entities.length === 0) return;
      startTransition(() => {
        queryClient.setQueryData(posKey, (old) => {
          let next = [...old ?? []];
          for (const e of entities) {
            next = next.filter(
              (p) => !(p.id.startsWith("opt-") && p.symbolName === e.symbolName && p.side === e.side)
            );
            const idx = next.findIndex((p) => p.id === e.id);
            if (idx >= 0) {
              const arr = [...next];
              arr[idx] = e;
              next = arr;
            } else {
              next = [...next, e];
            }
          }
          return next;
        });
      });
    }, 50)
  );
}
function toTimestamp(value) {
  if (typeof value === "number") return value;
  if (typeof value === "string") {
    const parsed = Date.parse(value);
    return Number.isNaN(parsed) ? Date.now() : parsed;
  }
  return Date.now();
}
function MarketDataBridge() {
  const updateTick = useTradingStore((s) => s.updateTick);
  const updateLiveTick = useTradingStore((s) => s.updateLiveTick);
  const updateCandleFromWs = useTradingStore((s) => s.updateCandleFromWs);
  const onReplayStateChanged = useTradingStore((s) => s.onReplayStateChanged);
  const updateAccountInStore = useTradingStore((s) => s.updateAccountInStore);
  const loadAccounts = useTradingStore((s) => s.loadAccounts);
  const queryClient = useQueryClient();
  useEffect(() => {
    const unsub = wsClient.subscribe("market-data", (event) => {
      var _a;
      const wsEvent = event;
      if (wsEvent.eventType === "MarketTick") {
        updateTick(wsEvent.symbol, wsEvent.bid, wsEvent.ask, toTimestamp(wsEvent.occurredAt));
      } else if (wsEvent.eventType === "HftLiveTick") {
        const liveTick = wsEvent;
        updateLiveTick(liveTick.symbol, liveTick.bid, liveTick.ask, toTimestamp(liveTick.occurredAt));
      } else if (wsEvent.eventType === "CandleUpdate") {
        updateCandleFromWs(wsEvent.symbol, wsEvent.timeframe, {
          open: wsEvent.open,
          high: wsEvent.high,
          low: wsEvent.low,
          close: wsEvent.close,
          volume: wsEvent.volume,
          timestamp: wsEvent.timestamp
        });
      } else if (wsEvent.eventType === "CandleClosed") {
        queryClient.invalidateQueries({
          queryKey: queryKeys.market.candles(wsEvent.symbol, wsEvent.timeframe)
        });
      } else if (wsEvent.eventType === "ReplayStateChanged") {
        const currentUserId = (_a = useAuthStore.getState().user) == null ? void 0 : _a.id;
        if (wsEvent.userId && currentUserId && wsEvent.userId !== currentUserId) return;
        onReplayStateChanged(wsEvent.action || "started", {
          speed: wsEvent.speed,
          cursorTimestamp: wsEvent.cursorTimestamp
        });
        queryClient.invalidateQueries({ queryKey: ["candles"] });
      }
    });
    return () => {
      unsub();
    };
  }, [updateTick, updateLiveTick, updateCandleFromWs, onReplayStateChanged, queryClient]);
  useEffect(() => {
    const unsub = wsClient.subscribe("account", (event) => {
      const wsEvent = event;
      if (wsEvent.eventType === "EquityUpdated" && wsEvent.accountId) {
        updateAccountInStore({
          id: wsEvent.accountId,
          equity: wsEvent.equity,
          balance: wsEvent.balance,
          freeMargin: wsEvent.freeMargin,
          margin: wsEvent.marginUsed
        });
      }
      if (["AccountFailed", "AccountPassed", "AccountFrozen"].includes(wsEvent.eventType)) {
        loadAccounts();
      }
    });
    return unsub;
  }, [loadAccounts, updateAccountInStore, queryClient]);
  useEffect(() => {
    const unsub = wsClient.subscribe("positions", (event) => {
      const ev = event;
      if (!ev.accountId) return;
      const posKey = queryKeys.trading.positions(ev.accountId);
      if (ev.eventType === "PositionOpened") {
        if (ev._entity) {
          bufferPositionOpened(ev.accountId, ev._entity, queryClient, posKey);
        } else {
          coalesceInvalidation(queryClient, posKey);
        }
        return;
      }
      if (ev.eventType === "PositionUpdated") {
        startTransition(() => {
          queryClient.setQueryData(
            posKey,
            (old) => (old ?? []).map(
              (p) => p.id === ev.positionId ? {
                ...p,
                unrealizedPnl: ev.unrealizedPnl ?? p.unrealizedPnl,
                quantity: ev.quantity ?? p.quantity,
                entryPrice: ev.averagePrice ?? p.entryPrice
              } : p
            )
          );
        });
        return;
      }
      if (ev.eventType === "PositionClosed") {
        startTransition(() => {
          queryClient.setQueryData(
            posKey,
            (old) => (old ?? []).filter((p) => p.id !== ev.positionId)
          );
        });
        coalesceInvalidation(queryClient, ["closedPositions", ev.accountId]);
        return;
      }
      coalesceInvalidation(queryClient, posKey);
    });
    return unsub;
  }, [queryClient]);
  useEffect(() => {
    const unsub = wsClient.subscribe("orders", (event) => {
      const ev = event;
      if (!ev.accountId) return;
      const ordKey = queryKeys.trading.orders(ev.accountId);
      if (ev._entity && (ev.eventType === "OrderPlaced" || ev.eventType === "OrderFilled" || ev.eventType === "OrderCanceled")) {
        const entity = ev._entity;
        startTransition(() => {
          queryClient.setQueryData(ordKey, (old) => {
            if (!old) return [entity];
            const idx = old.findIndex((o) => o.id === entity.id);
            if (idx >= 0) {
              const next = [...old];
              next[idx] = entity;
              return next;
            }
            return [entity, ...old];
          });
        });
        return;
      }
      coalesceInvalidation(queryClient, ordKey);
    });
    return unsub;
  }, [queryClient]);
  useEffect(() => {
    return () => {
      for (const timer of _invalidateTimers.values()) clearTimeout(timer);
      _invalidateTimers.clear();
      for (const timer of _positionBatchTimers.values()) clearTimeout(timer);
      _positionBatchTimers.clear();
      _positionBatchBuffers.clear();
    };
  }, []);
  useEffect(() => {
    let wasConnected = wsClient.state === "connected";
    return wsClient.onStateChange((state) => {
      if (state === "connected" && !wasConnected) {
        queryClient.invalidateQueries({ queryKey: ["candles"] });
        queryClient.invalidateQueries({ queryKey: ["positions"] });
        queryClient.invalidateQueries({ queryKey: ["orders"] });
        queryClient.invalidateQueries({ queryKey: ["accounts"] });
      }
      wasConnected = state === "connected";
    });
  }, [queryClient]);
  return null;
}
const listeners = /* @__PURE__ */ new Set();
const toast = {
  /** Fire a toast (the ToastContainer picks it up). */
  fire(type, title, message) {
    for (const fn of [...listeners]) {
      try {
        fn({ type, title, message });
      } catch (err) {
        console.error("[toast] listener threw", err);
      }
    }
  },
  success(title, message) {
    toast.fire("success", title, message);
  },
  error(title, message) {
    toast.fire("error", title, message);
  },
  info(title, message) {
    toast.fire("info", title, message);
  },
  warning(title, message) {
    toast.fire("warning", title, message);
  },
  /** Subscribe — returns unsubscribe function. */
  subscribe(fn) {
    listeners.add(fn);
    return () => {
      listeners.delete(fn);
    };
  }
};
const DURATION_MS = {
  info: 4e3,
  success: 3500,
  warning: 6e3,
  error: 8e3
};
const DEDUPE_WINDOW_MS = 1500;
const ICON = {
  info: Info,
  success: CheckCircle2,
  warning: AlertTriangle,
  error: XCircle
};
const ACCENT = {
  info: "text-accent",
  success: "text-success",
  warning: "text-warning",
  error: "text-destructive"
};
function ToastViewport() {
  const [toasts, setToasts] = useState([]);
  const nextId = useRef(1);
  const timers = useRef(/* @__PURE__ */ new Map());
  const lastSeen = useRef(/* @__PURE__ */ new Map());
  const dismiss = useCallback((id) => {
    const timer = timers.current.get(id);
    if (timer) clearTimeout(timer);
    timers.current.delete(id);
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);
  const schedule = useCallback(
    (id, type) => {
      const existing = timers.current.get(id);
      if (existing) clearTimeout(existing);
      timers.current.set(
        id,
        setTimeout(() => dismiss(id), DURATION_MS[type])
      );
    },
    [dismiss]
  );
  useEffect(() => {
    const unsubscribe = toast.subscribe((payload) => {
      const key = `${payload.type}|${payload.title}|${payload.message}`;
      const now = Date.now();
      const recent = lastSeen.current.get(key);
      if (recent && now - recent.at < DEDUPE_WINDOW_MS) {
        lastSeen.current.set(key, { id: recent.id, at: now });
        setToasts(
          (prev) => prev.map((t) => t.id === recent.id ? { ...t, count: t.count + 1 } : t)
        );
        schedule(recent.id, payload.type);
        return;
      }
      const id = nextId.current++;
      lastSeen.current.set(key, { id, at: now });
      setToasts((prev) => [...prev, { ...payload, id, count: 1 }].slice(-4));
      schedule(id, payload.type);
    });
    const pending = timers.current;
    return () => {
      unsubscribe();
      for (const timer of pending.values()) clearTimeout(timer);
      pending.clear();
    };
  }, [schedule]);
  if (toasts.length === 0) return null;
  return /* @__PURE__ */ jsx(
    "div",
    {
      className: "pointer-events-none fixed bottom-4 right-4 z-[1000] flex w-[min(360px,calc(100vw-2rem))] flex-col gap-2",
      "aria-label": "Notifications",
      children: toasts.map((t) => {
        const Icon = ICON[t.type];
        const urgent = t.type === "error" || t.type === "warning";
        return /* @__PURE__ */ jsxs(
          "div",
          {
            role: urgent ? "alert" : "status",
            "aria-live": urgent ? "assertive" : "polite",
            className: "pointer-events-auto flex items-start gap-2.5 rounded-md border border-border bg-card px-3 py-2.5 text-card-foreground shadow-xl",
            children: [
              /* @__PURE__ */ jsx(Icon, { className: cn("mt-0.5 h-4 w-4 shrink-0", ACCENT[t.type]), "aria-hidden": "true" }),
              /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1", children: [
                /* @__PURE__ */ jsxs("p", { className: "text-xs font-semibold leading-tight", children: [
                  t.title,
                  t.count > 1 && /* @__PURE__ */ jsxs("span", { className: "ml-1.5 font-normal text-muted-foreground", children: [
                    "×",
                    t.count
                  ] })
                ] }),
                t.message && /* @__PURE__ */ jsx("p", { className: "mt-0.5 break-words text-xs leading-snug text-muted-foreground", children: t.message })
              ] }),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => dismiss(t.id),
                  className: "shrink-0 rounded p-0.5 text-muted-foreground hover:text-foreground",
                  "aria-label": "Dismiss notification",
                  children: /* @__PURE__ */ jsx(X, { className: "h-3.5 w-3.5", "aria-hidden": "true" })
                }
              )
            ]
          },
          t.id
        );
      })
    }
  );
}
const TooltipProvider = TooltipPrimitive$1.Provider;
const TooltipContent = React.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ jsx(
  TooltipPrimitive$1.Content,
  {
    ref,
    sideOffset,
    className: cn(
      "z-50 overflow-hidden rounded-md border border-border bg-card px-3 py-1.5 text-xs text-foreground shadow-md animate-in fade-in-0 zoom-in-95",
      className
    ),
    ...props
  }
));
TooltipContent.displayName = TooltipPrimitive$1.Content.displayName;
function createQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: { retry: 2, refetchOnWindowFocus: false, staleTime: 5e3 }
    }
  });
}
const LOCAL_USER = {
  id: "local-user",
  email: "",
  firstName: "Trader",
  lastName: "",
  roles: ["trader"],
  status: "ACTIVE",
  createdAt: (/* @__PURE__ */ new Date(0)).toISOString()
};
function useBoot(adapter, attempt) {
  const [state, setState] = useState({
    key: null,
    boot: { status: "loading" }
  });
  const key = `${attempt}`;
  useEffect(() => {
    let cancelled = false;
    useAuthStore.setState({
      isDemo: false,
      user: LOCAL_USER,
      accessToken: "local"
    });
    wsClient.connect();
    const load = async () => {
      const { loadSymbols, loadAccounts } = useTradingStore.getState();
      await loadSymbols();
      if (adapter.trading) await loadAccounts();
    };
    load().then(() => {
      if (!cancelled) setState({ key: adapter, boot: { status: "ready" } });
    }).catch((err) => {
      if (cancelled) return;
      const error = err instanceof Error ? err : new Error(String(err));
      console.error("[opencharts] adapter failed to load", error);
      setState({ key: adapter, boot: { status: "error", error } });
    });
    return () => {
      cancelled = true;
      wsClient.disconnect();
    };
  }, [adapter, key]);
  return state.key === adapter ? state.boot : { status: "loading" };
}
function DefaultFallback() {
  return /* @__PURE__ */ jsx("div", { className: "flex h-full w-full items-center justify-center text-xs text-muted-foreground", children: "Loading OpenCharts…" });
}
function BootError({ error, onRetry }) {
  return /* @__PURE__ */ jsxs(
    "div",
    {
      role: "alert",
      className: "flex h-full w-full flex-col items-center justify-center gap-2 p-6 text-center",
      children: [
        /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold text-foreground", children: "The market data adapter failed to load" }),
        /* @__PURE__ */ jsx("p", { className: "max-w-md break-words text-xs text-muted-foreground", children: error.message }),
        /* @__PURE__ */ jsx(
          "button",
          {
            type: "button",
            onClick: onRetry,
            className: "mt-1 rounded-md border border-border px-3 py-1 text-xs text-foreground hover:bg-secondary",
            children: "Retry"
          }
        )
      ]
    }
  );
}
function Runtime({
  adapter,
  fallback,
  children
}) {
  const [attempt, setAttempt] = useState(0);
  const boot = useBoot(adapter, attempt);
  if (boot.status === "error") {
    return /* @__PURE__ */ jsx(BootError, { error: boot.error, onRetry: () => setAttempt((n) => n + 1) });
  }
  if (boot.status === "loading") return /* @__PURE__ */ jsx(Fragment, { children: fallback });
  return /* @__PURE__ */ jsx(Fragment, { children });
}
function OpenChartsProvider({
  adapter,
  children,
  fallback = /* @__PURE__ */ jsx(DefaultFallback, {}),
  className,
  style,
  queryClient,
  showNotifications = true
}) {
  const [ownClient] = useState(createQueryClient);
  const client = queryClient ?? ownClient;
  const [installed, setInstalled] = useState(null);
  if (installed !== adapter) {
    setAdapter(adapter);
    setInstalled(adapter);
  }
  useEffect(() => {
    return setAdapter(adapter);
  }, [adapter]);
  return /* @__PURE__ */ jsx(QueryClientProvider, { client, children: /* @__PURE__ */ jsx(TooltipProvider, { delayDuration: 300, children: /* @__PURE__ */ jsx(
    "div",
    {
      className: cn("opencharts", className),
      style: { position: "relative", height: "100%", width: "100%", ...style },
      children: installed === adapter && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(MarketDataBridge, {}),
        /* @__PURE__ */ jsx(ErrorBoundary, { children: /* @__PURE__ */ jsx(Runtime, { adapter, fallback, children }) }),
        showNotifications && /* @__PURE__ */ jsx(ToastViewport, {})
      ] })
    }
  ) }) });
}
function subscribeToWsState(callback) {
  return wsClient.onStateChange(() => callback());
}
function getWsSnapshot() {
  return wsClient.state;
}
function useConnectionState() {
  return useSyncExternalStore(subscribeToWsState, getWsSnapshot);
}
function useIsFeedConnected() {
  const state = useConnectionState();
  return state === "connected";
}
function DisconnectedTradingBanner({ className }) {
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: cn(
        "bg-destructive/10 border border-destructive/30 rounded px-3 py-2 text-center",
        className
      ),
      children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-center gap-1.5 text-destructive text-xs font-semibold", children: [
          /* @__PURE__ */ jsx(WifiOff, { className: "h-3.5 w-3.5" }),
          "Data Feed Disconnected"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-[10px] text-muted-foreground mt-0.5", children: "Trading is disabled until the connection is restored" })
      ]
    }
  );
}
const TerminalContext = createContext(null);
function useTerminal() {
  const value = useContext(TerminalContext);
  if (!value) {
    throw new Error(
      "[opencharts] Terminal panels must be rendered inside <TerminalProvider>. Use <Terminal /> for the standard layout, or wrap your own composition."
    );
  }
  return value;
}
function useInstrumentLabels() {
  const instrumentType = useTradingStore((s) => {
    var _a;
    const active = s.accounts.find((a) => a.id === s.activeAccountId);
    return ((_a = active == null ? void 0 : active.template) == null ? void 0 : _a.instrumentType) ?? "FOREX";
  });
  const isFutures = instrumentType === "FUTURES";
  return {
    instrumentType,
    isFutures,
    /** "lots" for forex/crypto, "contracts" for futures, "shares" for equities */
    unitLabel: isFutures ? "contracts" : instrumentType === "EQUITIES" ? "shares" : "lots",
    /** Capitalised version for use at sentence start */
    unitLabelCap: isFutures ? "Contracts" : instrumentType === "EQUITIES" ? "Shares" : "Lots",
    /**
     * Format a quantity with its unit label.
     * Futures quantities are shown as integers; forex as decimals.
     */
    formatQty: (qty) => isFutures ? `${Math.round(qty)} contracts` : instrumentType === "EQUITIES" ? `${Math.round(qty)} shares` : `${qty.toFixed(2)} lots`
  };
}
function PositionModifyDialog({
  position,
  onClose,
  onSaved,
  tick,
  isFeedConnected = true
}) {
  const { formatQty, unitLabel, isFutures, instrumentType } = useInstrumentLabels();
  const [tp, setTp] = useState(
    () => (position == null ? void 0 : position.takeProfit) != null ? String(position.takeProfit) : ""
  );
  const [sl, setSl] = useState(() => (position == null ? void 0 : position.stopLoss) != null ? String(position.stopLoss) : "");
  const [partialQty, setPartialQty] = useState("");
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState("modify");
  if (!position) return null;
  const currentPrice = tick ? position.side === "LONG" ? tick.bid : tick.ask : position.currentPrice || position.entryPrice;
  const pnlPerUnit = position.side === "LONG" ? currentPrice - position.entryPrice : position.entryPrice - currentPrice;
  const handleModify = async () => {
    if (!isFeedConnected) {
      toast.error("No Data Feed", "Cannot modify positions while disconnected from the data feed");
      return;
    }
    const mods = {};
    if (tp === "" && position.takeProfit != null) {
      mods.takeProfit = null;
    } else if (tp !== "" && parseFloat(tp) !== position.takeProfit) {
      mods.takeProfit = parseFloat(tp);
    }
    if (sl === "" && position.stopLoss != null) {
      mods.stopLoss = null;
    } else if (sl !== "" && parseFloat(sl) !== position.stopLoss) {
      mods.stopLoss = parseFloat(sl);
    }
    if (Object.keys(mods).length === 0) {
      toast.info("No Changes", "No modifications to apply");
      return;
    }
    setSaving(true);
    try {
      await api.modifyPosition(position.id, mods);
      toast.success("Position Modified", "TP/SL updated successfully");
      onSaved();
      onClose();
    } catch (err) {
      const e = err;
      if ((e == null ? void 0 : e.code) === "REQUEST_TIMEOUT") {
        toast.error(
          "Request Timed Out",
          "The server didn't respond in time. Check your connection and try again."
        );
      } else {
        toast.error("Modify Failed", e.message || "Could not modify position");
      }
    } finally {
      setSaving(false);
    }
  };
  const handlePartialClose = async () => {
    if (!isFeedConnected) {
      toast.error("No Data Feed", "Cannot close positions while disconnected from the data feed");
      return;
    }
    const qty = parseFloat(partialQty);
    if (isNaN(qty) || qty <= 0 || qty > position.quantity) {
      toast.warning("Invalid Quantity", `Enter a value between 0.01 and ${position.quantity}`);
      return;
    }
    setSaving(true);
    try {
      await api.closePosition(position.id, qty);
      toast.success("Partial Close", `Closed ${formatQty(qty)} of ${formatQty(position.quantity)}`);
      onSaved();
      onClose();
    } catch (err) {
      const e = err;
      if ((e == null ? void 0 : e.code) === "REQUEST_TIMEOUT") {
        toast.error(
          "Request Timed Out",
          "The server didn't respond in time. Check your connection and try again."
        );
      } else {
        toast.error("Close Failed", e.message || "Could not partially close position");
      }
    } finally {
      setSaving(false);
    }
  };
  const handleSetBreakeven = () => {
    setSl(String(position.entryPrice));
    toast.info("Breakeven", "Stop Loss set to entry price — click Save to apply");
  };
  const tpVal = parseFloat(tp);
  const slVal = parseFloat(sl);
  const riskReward = !isNaN(tpVal) && !isNaN(slVal) && slVal !== position.entryPrice ? Math.abs((tpVal - position.entryPrice) / (position.entryPrice - slVal)) : null;
  const contractSize = position.contractSize ?? 1e5;
  const tpPnl = !isNaN(tpVal) ? (position.side === "LONG" ? tpVal - position.entryPrice : position.entryPrice - tpVal) * position.quantity * contractSize : null;
  const slPnl = !isNaN(slVal) ? (position.side === "LONG" ? slVal - position.entryPrice : position.entryPrice - slVal) * position.quantity * contractSize : null;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 bg-black/50 backdrop-blur-sm", onClick: onClose }),
    /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4", children: /* @__PURE__ */ jsxs("div", { className: "w-full max-w-md bg-card border border-border rounded-xl shadow-2xl shadow-black/40 overflow-hidden", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-5 py-3 border-b border-border/60 bg-secondary/50", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx(
            "div",
            {
              className: cn(
                "p-1.5 rounded-lg",
                position.side === "LONG" ? "bg-buy/15 text-buy" : "bg-sell/15 text-sell"
              ),
              children: position.side === "LONG" ? /* @__PURE__ */ jsx(TrendingUp, { className: "h-4 w-4" }) : /* @__PURE__ */ jsx(TrendingDown, { className: "h-4 w-4" })
            }
          ),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("h3", { className: "text-sm font-semibold", children: [
              "Modify ",
              position.symbolName
            ] }),
            /* @__PURE__ */ jsxs("p", { className: "text-[10px] text-muted-foreground", children: [
              position.side,
              " ",
              position.quantity,
              " @ ",
              formatNumber(position.entryPrice, 5)
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "sm", className: "h-7 w-7 p-0", onClick: onClose, children: /* @__PURE__ */ jsx(X, { className: "h-4 w-4" }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "px-5 py-3 grid grid-cols-3 gap-3 border-b border-border/40 text-center", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "text-[10px] text-muted-foreground", children: "Current" }),
          /* @__PURE__ */ jsx("div", { className: "text-sm font-mono font-semibold", children: formatNumber(currentPrice, 5) })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "text-[10px] text-muted-foreground", children: "P&L" }),
          /* @__PURE__ */ jsxs(
            "div",
            {
              className: cn(
                "text-sm font-mono font-semibold",
                (position.unrealizedPnl || 0) >= 0 ? "text-buy" : "text-sell"
              ),
              children: [
                (position.unrealizedPnl || 0) >= 0 ? "+" : "",
                formatCurrency(position.unrealizedPnl || 0)
              ]
            }
          )
        ] }),
        instrumentType === "FOREX" && /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "text-[10px] text-muted-foreground", children: "Pips" }),
          /* @__PURE__ */ jsx(
            "div",
            {
              className: cn(
                "text-sm font-mono font-semibold",
                pnlPerUnit >= 0 ? "text-buy" : "text-sell"
              ),
              children: (pnlPerUnit * 1e4).toFixed(1)
            }
          )
        ] })
      ] }),
      !isFeedConnected && /* @__PURE__ */ jsxs("div", { className: "mx-5 mt-3 bg-destructive/10 border border-destructive/30 rounded px-3 py-2 text-center", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-center gap-1.5 text-destructive text-xs font-semibold", children: [
          /* @__PURE__ */ jsx(WifiOff, { className: "h-3.5 w-3.5" }),
          "Data Feed Disconnected"
        ] }),
        /* @__PURE__ */ jsx("p", { className: "text-[10px] text-muted-foreground mt-0.5", children: "Modifications disabled until connection is restored" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex border-b border-border/40", children: [
        /* @__PURE__ */ jsxs(
          "button",
          {
            className: cn(
              "flex-1 py-2 text-xs font-medium",
              activeTab === "modify" ? "text-accent border-b-2 border-accent" : "text-muted-foreground"
            ),
            onClick: () => setActiveTab("modify"),
            children: [
              /* @__PURE__ */ jsx(SlidersHorizontal, { className: "h-3 w-3 inline mr-1" }),
              " Modify TP/SL"
            ]
          }
        ),
        /* @__PURE__ */ jsxs(
          "button",
          {
            className: cn(
              "flex-1 py-2 text-xs font-medium",
              activeTab === "partial" ? "text-accent border-b-2 border-accent" : "text-muted-foreground"
            ),
            onClick: () => setActiveTab("partial"),
            children: [
              /* @__PURE__ */ jsx(ArrowLeftRight, { className: "h-3 w-3 inline mr-1" }),
              " Partial Close"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "px-5 py-4 space-y-3", children: [
        activeTab === "modify" && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1", children: [
              /* @__PURE__ */ jsxs("label", { className: "text-[10px] text-muted-foreground uppercase tracking-wider flex items-center gap-1", children: [
                /* @__PURE__ */ jsx(Target, { className: "h-3 w-3 text-buy" }),
                " Take Profit"
              ] }),
              tpPnl !== null && /* @__PURE__ */ jsxs(
                "span",
                {
                  className: cn(
                    "text-[10px] font-mono",
                    tpPnl >= 0 ? "text-buy" : "text-sell"
                  ),
                  children: [
                    "Est: ",
                    tpPnl >= 0 ? "+" : "",
                    formatCurrency(tpPnl)
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: tp,
                onChange: (e) => setTp(e.target.value),
                placeholder: position.takeProfit ? String(position.takeProfit) : "Not set",
                className: "w-full text-sm font-mono",
                step: "0.00001"
              }
            ),
            tp && /* @__PURE__ */ jsx(
              Button,
              {
                variant: "ghost",
                size: "sm",
                className: "text-[10px] h-5 mt-1 text-muted-foreground",
                onClick: () => setTp(""),
                children: "Remove TP"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1", children: [
              /* @__PURE__ */ jsxs("label", { className: "text-[10px] text-muted-foreground uppercase tracking-wider flex items-center gap-1", children: [
                /* @__PURE__ */ jsx(Shield, { className: "h-3 w-3 text-sell" }),
                " Stop Loss"
              ] }),
              slPnl !== null && /* @__PURE__ */ jsxs(
                "span",
                {
                  className: cn(
                    "text-[10px] font-mono",
                    slPnl >= 0 ? "text-buy" : "text-sell"
                  ),
                  children: [
                    "Est: ",
                    slPnl >= 0 ? "+" : "",
                    formatCurrency(slPnl)
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: sl,
                onChange: (e) => setSl(e.target.value),
                placeholder: position.stopLoss ? String(position.stopLoss) : "Not set",
                className: "w-full text-sm font-mono",
                step: "0.00001"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "flex gap-1 mt-1", children: [
              /* @__PURE__ */ jsxs(
                Button,
                {
                  variant: "ghost",
                  size: "sm",
                  className: "text-[10px] h-5 text-muted-foreground",
                  onClick: handleSetBreakeven,
                  children: [
                    "Breakeven (",
                    formatNumber(position.entryPrice, 5),
                    ")"
                  ]
                }
              ),
              sl && /* @__PURE__ */ jsx(
                Button,
                {
                  variant: "ghost",
                  size: "sm",
                  className: "text-[10px] h-5 text-muted-foreground",
                  onClick: () => setSl(""),
                  children: "Remove SL"
                }
              )
            ] })
          ] }),
          riskReward !== null && /* @__PURE__ */ jsxs("div", { className: "bg-secondary/50 rounded-lg p-2 text-center", children: [
            /* @__PURE__ */ jsx("span", { className: "text-[10px] text-muted-foreground", children: "Risk:Reward" }),
            /* @__PURE__ */ jsxs(
              "span",
              {
                className: cn(
                  "text-sm font-mono font-semibold ml-2",
                  riskReward >= 2 ? "text-buy" : riskReward >= 1 ? "text-foreground" : "text-sell"
                ),
                children: [
                  "1:",
                  riskReward.toFixed(2)
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsx(
            Button,
            {
              className: "w-full",
              onClick: handleModify,
              disabled: saving || !isFeedConnected,
              loading: saving,
              children: saving ? "Saving..." : !isFeedConnected ? "Disconnected" : "Save Changes"
            }
          )
        ] }),
        activeTab === "partial" && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("label", { className: "text-[10px] text-muted-foreground uppercase tracking-wider", children: [
              "Close Volume (",
              unitLabel,
              ")"
            ] }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: partialQty,
                onChange: (e) => setPartialQty(e.target.value),
                placeholder: `Max: ${position.quantity}`,
                className: "w-full mt-1 text-sm font-mono",
                step: isFutures ? "1" : "0.01",
                min: isFutures ? "1" : "0.01",
                max: position.quantity
              }
            )
          ] }),
          /* @__PURE__ */ jsx("div", { className: "grid grid-cols-4 gap-1", children: [25, 50, 75, 100].map((pct) => {
            const rawAmt = position.quantity * pct / 100;
            const amt = isFutures ? Math.min(position.quantity, Math.max(1, Math.round(rawAmt))) : rawAmt;
            return /* @__PURE__ */ jsxs(
              "button",
              {
                onClick: () => setPartialQty(isFutures ? String(amt) : amt.toFixed(2)),
                className: cn(
                  "text-[10px] py-1.5 rounded border border-border transition-colors",
                  parseFloat(partialQty) === amt ? "bg-accent/15 text-accent border-accent/30" : "hover:bg-secondary"
                ),
                children: [
                  pct,
                  "%",
                  /* @__PURE__ */ jsx("div", { className: "text-[9px] text-muted-foreground", children: isFutures ? amt : amt.toFixed(2) })
                ]
              },
              pct
            );
          }) }),
          /* @__PURE__ */ jsx(
            Button,
            {
              variant: "destructive",
              className: "w-full",
              onClick: handlePartialClose,
              disabled: saving || !partialQty || !isFeedConnected,
              loading: saving,
              children: saving ? "Closing..." : !isFeedConnected ? "Disconnected" : `Close ${partialQty || "?"} ${unitLabel}`
            }
          )
        ] })
      ] })
    ] }) })
  ] });
}
function OrderConfirmDialog({
  isOpen,
  onConfirm,
  onCancel,
  order,
  tick,
  symbolInfo,
  loading
}) {
  const { formatQty } = useInstrumentLabels();
  if (!isOpen || !order) return null;
  const executionPrice = order.type === "MARKET" ? order.side === "BUY" ? tick == null ? void 0 : tick.ask : tick == null ? void 0 : tick.bid : order.price || order.stopPrice;
  const marginRequired = executionPrice && symbolInfo ? order.quantity * (symbolInfo.contractSize || 1e5) * executionPrice * ((symbolInfo.marginPercent || 1) / 100) : null;
  const commission = symbolInfo ? (symbolInfo.commission || 0) * order.quantity : null;
  const tpPnl = order.takeProfit && executionPrice ? (order.side === "BUY" ? order.takeProfit - executionPrice : executionPrice - order.takeProfit) * order.quantity * ((symbolInfo == null ? void 0 : symbolInfo.contractSize) || 1e5) : null;
  const slPnl = order.stopLoss && executionPrice ? (order.side === "BUY" ? order.stopLoss - executionPrice : executionPrice - order.stopLoss) * order.quantity * ((symbolInfo == null ? void 0 : symbolInfo.contractSize) || 1e5) : null;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-[70] bg-black/50 backdrop-blur-sm", onClick: onCancel }),
    /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-[70] flex items-center justify-center p-4", children: /* @__PURE__ */ jsxs("div", { className: "w-full max-w-sm bg-card border border-border rounded-xl shadow-2xl overflow-hidden", children: [
      /* @__PURE__ */ jsx(
        "div",
        {
          className: cn(
            "px-5 py-3 border-b",
            order.side === "BUY" ? "bg-buy/10 border-buy/20" : "bg-sell/10 border-sell/20"
          ),
          children: /* @__PURE__ */ jsxs("h3", { className: "text-sm font-semibold flex items-center gap-2", children: [
            order.side === "BUY" ? /* @__PURE__ */ jsx(TrendingUp, { className: "h-4 w-4 text-buy" }) : /* @__PURE__ */ jsx(TrendingDown, { className: "h-4 w-4 text-sell" }),
            "Confirm ",
            order.side,
            " Order"
          ] })
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "px-5 py-4 space-y-2 text-sm", children: [
        /* @__PURE__ */ jsx(Row, { label: "Symbol", value: order.symbol, bold: true }),
        /* @__PURE__ */ jsx(
          Row,
          {
            label: "Side",
            value: order.side,
            valueClass: order.side === "BUY" ? "text-buy" : "text-sell"
          }
        ),
        /* @__PURE__ */ jsx(Row, { label: "Type", value: order.type }),
        /* @__PURE__ */ jsx(Row, { label: "Volume", value: formatQty(order.quantity) }),
        executionPrice && /* @__PURE__ */ jsx(Row, { label: "Price", value: formatNumber(executionPrice, 5) }),
        order.takeProfit && /* @__PURE__ */ jsx(
          Row,
          {
            label: "Take Profit",
            value: formatNumber(order.takeProfit, 5),
            extra: tpPnl !== null ? `(${tpPnl >= 0 ? "+" : ""}${formatCurrency(tpPnl)})` : void 0,
            valueClass: "text-buy"
          }
        ),
        order.stopLoss && /* @__PURE__ */ jsx(
          Row,
          {
            label: "Stop Loss",
            value: formatNumber(order.stopLoss, 5),
            extra: slPnl !== null ? `(${slPnl >= 0 ? "+" : ""}${formatCurrency(slPnl)})` : void 0,
            valueClass: "text-sell"
          }
        ),
        marginRequired !== null && /* @__PURE__ */ jsx(Row, { label: "Margin Required", value: formatCurrency(marginRequired) }),
        commission !== null && /* @__PURE__ */ jsx(Row, { label: "Commission", value: formatCurrency(commission) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "px-5 py-3 border-t border-border/40 flex gap-2", children: [
        /* @__PURE__ */ jsx(Button, { variant: "outline", className: "flex-1", onClick: onCancel, children: "Cancel" }),
        /* @__PURE__ */ jsx(
          Button,
          {
            variant: order.side === "BUY" ? "buy" : "sell",
            className: "flex-1",
            onClick: onConfirm,
            loading,
            disabled: loading,
            children: loading ? "Placing..." : `Confirm ${order.side}`
          }
        )
      ] })
    ] }) })
  ] });
}
function Row({
  label,
  value,
  valueClass,
  bold,
  extra
}) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between py-0.5", children: [
    /* @__PURE__ */ jsx("span", { className: "text-muted-foreground text-xs", children: label }),
    /* @__PURE__ */ jsxs("span", { className: cn("font-mono text-xs", valueClass, bold && "font-semibold text-sm"), children: [
      value,
      extra && /* @__PURE__ */ jsx("span", { className: "text-[10px] ml-1 opacity-70", children: extra })
    ] })
  ] });
}
function OrderModifyDialog({ order, onClose, onSaved, tick }) {
  const { unitLabelCap, isFutures } = useInstrumentLabels();
  const [price, setPrice] = useState(
    () => (order == null ? void 0 : order.price) != null ? String(order.price) : (order == null ? void 0 : order.stopPrice) != null ? String(order.stopPrice) : ""
  );
  const [quantity, setQuantity] = useState(() => order ? String(order.quantity) : "");
  const [tp, setTp] = useState(() => (order == null ? void 0 : order.takeProfit) != null ? String(order.takeProfit) : "");
  const [sl, setSl] = useState(() => (order == null ? void 0 : order.stopLoss) != null ? String(order.stopLoss) : "");
  const [saving, setSaving] = useState(false);
  if (!order) return null;
  const handleSave = async () => {
    setSaving(true);
    try {
      const modifications = {};
      const newPrice = parseFloat(price);
      const newQty = parseFloat(quantity);
      const newTp = tp ? parseFloat(tp) : null;
      const newSl = sl ? parseFloat(sl) : null;
      if (!isNaN(newPrice) && newPrice > 0) modifications.price = newPrice;
      if (!isNaN(newQty) && newQty > 0 && newQty !== order.quantity)
        modifications.quantity = newQty;
      if (tp !== "" && newTp !== order.takeProfit) modifications.takeProfit = newTp;
      if (sl !== "" && newSl !== order.stopLoss) modifications.stopLoss = newSl;
      if (tp === "" && order.takeProfit != null) modifications.takeProfit = null;
      if (sl === "" && order.stopLoss != null) modifications.stopLoss = null;
      if (Object.keys(modifications).length === 0) {
        toast.info("No Changes", "No modifications to apply");
        setSaving(false);
        return;
      }
      await api.modifyOrder(order.id, modifications);
      toast.success("Order Modified", "Pending order has been updated");
      onSaved();
    } catch (err) {
      const e = err;
      if ((e == null ? void 0 : e.code) === "REQUEST_TIMEOUT") {
        toast.error(
          "Request Timed Out",
          "The server didn't respond in time. Check your connection and try again."
        );
      } else {
        toast.error("Modify Failed", (e == null ? void 0 : e.message) || "Could not modify order");
      }
    } finally {
      setSaving(false);
    }
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 bg-black/50 backdrop-blur-sm", onClick: onClose }),
    /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4", children: /* @__PURE__ */ jsxs("div", { className: "w-full max-w-sm bg-card border border-border rounded-xl shadow-2xl overflow-hidden", children: [
      /* @__PURE__ */ jsxs(
        "div",
        {
          className: cn(
            "px-5 py-3 border-b flex items-center justify-between",
            order.side === "BUY" ? "bg-buy/10 border-buy/20" : "bg-sell/10 border-sell/20"
          ),
          children: [
            /* @__PURE__ */ jsxs("h3", { className: "text-sm font-semibold flex items-center gap-2", children: [
              /* @__PURE__ */ jsx(SlidersHorizontal, { className: "h-4 w-4" }),
              "Modify ",
              order.side,
              " ",
              order.type,
              " — ",
              order.symbolName
            ] }),
            /* @__PURE__ */ jsx("button", { onClick: onClose, className: "text-muted-foreground hover:text-foreground", children: /* @__PURE__ */ jsx(X, { className: "h-4 w-4" }) })
          ]
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "px-5 py-4 space-y-3", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground uppercase tracking-wider", children: "Price" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "number",
              value: price,
              onChange: (e) => setPrice(e.target.value),
              className: "w-full mt-1 text-sm font-mono",
              step: "0.00001"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsxs("label", { className: "text-[10px] text-muted-foreground uppercase tracking-wider", children: [
            "Quantity (",
            unitLabelCap,
            ")"
          ] }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "number",
              value: quantity,
              onChange: (e) => setQuantity(e.target.value),
              className: "w-full mt-1 text-sm font-mono",
              step: isFutures ? "1" : "0.01",
              min: isFutures ? "1" : "0.01"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-2", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground uppercase tracking-wider", children: "Take Profit" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: tp,
                onChange: (e) => setTp(e.target.value),
                className: "w-full mt-1 text-sm font-mono",
                step: "0.00001"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground uppercase tracking-wider", children: "Stop Loss" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: sl,
                onChange: (e) => setSl(e.target.value),
                className: "w-full mt-1 text-sm font-mono",
                step: "0.00001"
              }
            )
          ] })
        ] }),
        tick && /* @__PURE__ */ jsxs("div", { className: "text-[10px] text-muted-foreground flex gap-3", children: [
          /* @__PURE__ */ jsxs("span", { children: [
            "Bid: ",
            /* @__PURE__ */ jsx("span", { className: "font-mono text-sell", children: formatNumber(tick.bid, 5) })
          ] }),
          /* @__PURE__ */ jsxs("span", { children: [
            "Ask: ",
            /* @__PURE__ */ jsx("span", { className: "font-mono text-buy", children: formatNumber(tick.ask, 5) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "px-5 py-3 border-t border-border/40 flex gap-2", children: [
        /* @__PURE__ */ jsx(Button, { variant: "outline", className: "flex-1", onClick: onClose, children: "Cancel" }),
        /* @__PURE__ */ jsx(
          Button,
          {
            variant: "default",
            className: "flex-1",
            onClick: handleSave,
            disabled: saving,
            loading: saving,
            children: saving ? "Saving..." : "Save Changes"
          }
        )
      ] })
    ] }) })
  ] });
}
const EMOTIONS = [
  "Calm",
  "Confident",
  "Anxious",
  "Greedy",
  "Fearful",
  "FOMO",
  "Revenge",
  "Bored"
];
function TradeJournalPanel({
  entries,
  isLoading,
  accountId,
  onCreateEntry,
  onUpdateEntry,
  onDeleteEntry
}) {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [symbolName, setSymbolName] = useState("");
  const [side, setSide] = useState("BUY");
  const [entryPrice, setEntryPrice] = useState("");
  const [exitPrice, setExitPrice] = useState("");
  const [pnl, setPnl] = useState("");
  const [emotion, setEmotion] = useState("");
  const [rating, setRating] = useState(0);
  const [tags, setTags] = useState("");
  const [notes, setNotes] = useState("");
  const resetForm = () => {
    setSymbolName("");
    setSide("BUY");
    setEntryPrice("");
    setExitPrice("");
    setPnl("");
    setEmotion("");
    setRating(0);
    setTags("");
    setNotes("");
    setEditingId(null);
    setShowForm(false);
  };
  const startEdit = (entry) => {
    setEditingId(entry.id);
    setSymbolName(entry.symbolName || "");
    setSide(entry.side || "BUY");
    setEntryPrice(entry.entryPrice != null ? String(entry.entryPrice) : "");
    setExitPrice(entry.exitPrice != null ? String(entry.exitPrice) : "");
    setPnl(entry.pnl != null ? String(entry.pnl) : "");
    setEmotion(entry.emotion || "");
    setRating(entry.rating || 0);
    setTags(entry.tags.join(", "));
    setNotes(entry.notes);
    setShowForm(true);
  };
  const handleSubmit = () => {
    if (!accountId) return;
    const data = {
      notes,
      emotion: emotion || void 0,
      rating: rating || void 0,
      tags: tags ? tags.split(",").map((t) => t.trim()).filter(Boolean) : []
    };
    if (editingId) {
      onUpdateEntry(editingId, data);
    } else {
      data.accountId = accountId;
      data.symbolName = symbolName || void 0;
      data.side = side;
      data.entryPrice = entryPrice ? parseFloat(entryPrice) : void 0;
      data.exitPrice = exitPrice ? parseFloat(exitPrice) : void 0;
      data.pnl = pnl ? parseFloat(pnl) : void 0;
      onCreateEntry(data);
    }
    resetForm();
  };
  if (isLoading) {
    return /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center h-full text-muted-foreground text-xs", children: "Loading journal..." });
  }
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col h-full", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-3 py-2 border-b border-border bg-secondary", children: [
      /* @__PURE__ */ jsxs("h3", { className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5", children: [
        /* @__PURE__ */ jsx(BookOpen, { className: "h-3 w-3" }),
        "Trade Journal"
      ] }),
      /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: () => {
            resetForm();
            setShowForm(true);
          },
          className: "flex items-center gap-1 px-2 py-0.5 text-[10px] rounded bg-primary/10 text-primary hover:bg-primary/20",
          children: [
            /* @__PURE__ */ jsx(Plus, { className: "h-3 w-3" }),
            " New"
          ]
        }
      )
    ] }),
    showForm && /* @__PURE__ */ jsxs("div", { className: "px-3 py-2 border-b border-border/50 bg-secondary/30 space-y-2 text-xs", children: [
      !editingId && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3 gap-1", children: [
          /* @__PURE__ */ jsxs("div", { className: "col-span-2", children: [
            /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground", children: "Symbol" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                value: symbolName,
                onChange: (e) => setSymbolName(e.target.value),
                className: "w-full mt-0.5 text-xs",
                placeholder: "e.g. EURUSD"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground", children: "Side" }),
            /* @__PURE__ */ jsxs(
              "select",
              {
                value: side,
                onChange: (e) => setSide(e.target.value),
                className: "w-full mt-0.5 text-xs",
                children: [
                  /* @__PURE__ */ jsx("option", { value: "BUY", children: "BUY" }),
                  /* @__PURE__ */ jsx("option", { value: "SELL", children: "SELL" })
                ]
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3 gap-1", children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground", children: "Entry" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: entryPrice,
                onChange: (e) => setEntryPrice(e.target.value),
                className: "w-full mt-0.5 text-xs font-mono",
                step: "0.00001"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground", children: "Exit" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: exitPrice,
                onChange: (e) => setExitPrice(e.target.value),
                className: "w-full mt-0.5 text-xs font-mono",
                step: "0.00001"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground", children: "P&L" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: pnl,
                onChange: (e) => setPnl(e.target.value),
                className: "w-full mt-0.5 text-xs font-mono"
              }
            )
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground", children: "Emotion" }),
        /* @__PURE__ */ jsx("div", { className: "flex gap-1 flex-wrap mt-0.5", children: EMOTIONS.map((em) => /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => setEmotion(emotion === em ? "" : em),
            className: cn(
              "px-1.5 py-0.5 rounded text-[10px] border border-border",
              emotion === em ? "bg-primary text-primary-foreground border-primary" : "hover:bg-secondary"
            ),
            children: em
          },
          em
        )) })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground", children: "Rating" }),
        /* @__PURE__ */ jsx("div", { className: "flex gap-0.5 mt-0.5", children: [1, 2, 3, 4, 5].map((r) => /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => setRating(rating === r ? 0 : r),
            className: cn(
              "text-sm",
              r <= rating ? "text-yellow-400" : "text-muted-foreground/30"
            ),
            children: /* @__PURE__ */ jsx(Star, { className: "h-3.5 w-3.5", fill: r <= rating ? "currentColor" : "none" })
          },
          r
        )) })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground", children: "Tags (comma-separated)" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            value: tags,
            onChange: (e) => setTags(e.target.value),
            className: "w-full mt-0.5 text-xs",
            placeholder: "e.g. breakout, trend"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground", children: "Notes" }),
        /* @__PURE__ */ jsx(
          "textarea",
          {
            value: notes,
            onChange: (e) => setNotes(e.target.value),
            className: "w-full mt-0.5 text-xs min-h-[60px] resize-y",
            placeholder: "What happened? What did you learn?"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-1", children: [
        /* @__PURE__ */ jsx(Button, { size: "sm", variant: "outline", className: "text-[10px] h-6", onClick: resetForm, children: "Cancel" }),
        /* @__PURE__ */ jsx(Button, { size: "sm", className: "text-[10px] h-6", onClick: handleSubmit, children: editingId ? "Update" : "Save Entry" })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex-1 overflow-y-auto", children: entries.length === 0 ? /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center justify-center h-full text-muted-foreground text-xs gap-2", children: [
      /* @__PURE__ */ jsx(BookOpen, { className: "h-8 w-8 opacity-30" }),
      /* @__PURE__ */ jsx("span", { children: "No journal entries yet" }),
      /* @__PURE__ */ jsx("span", { className: "text-[10px]", children: 'Click "New" to record your first trade' })
    ] }) : /* @__PURE__ */ jsx("div", { className: "divide-y divide-border/30", children: entries.map((entry) => /* @__PURE__ */ jsxs("div", { className: "px-3 py-2 hover:bg-secondary/30 group text-xs", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          entry.symbolName && /* @__PURE__ */ jsx("span", { className: "font-semibold", children: entry.symbolName }),
          entry.side && /* @__PURE__ */ jsx(
            "span",
            {
              className: cn(
                "text-[10px] font-medium",
                entry.side === "BUY" ? "text-buy" : "text-sell"
              ),
              children: entry.side
            }
          ),
          entry.pnl != null && /* @__PURE__ */ jsxs(
            "span",
            {
              className: cn(
                "font-mono text-[10px] font-semibold",
                entry.pnl >= 0 ? "text-buy" : "text-sell"
              ),
              children: [
                entry.pnl >= 0 ? "+" : "",
                formatCurrency(entry.pnl)
              ]
            }
          ),
          entry.emotion && /* @__PURE__ */ jsx("span", { className: "px-1 py-0.5 rounded bg-accent/10 text-accent text-[9px]", children: entry.emotion }),
          entry.rating != null && entry.rating > 0 && /* @__PURE__ */ jsx("span", { className: "text-yellow-400 text-[10px]", children: "★".repeat(entry.rating) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity", children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => startEdit(entry),
              className: "p-0.5 rounded hover:bg-secondary",
              children: /* @__PURE__ */ jsx(Pencil, { className: "h-3 w-3 text-muted-foreground" })
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => onDeleteEntry(entry.id),
              className: "p-0.5 rounded hover:bg-destructive/20",
              children: /* @__PURE__ */ jsx(Trash2, { className: "h-3 w-3 text-destructive" })
            }
          )
        ] })
      ] }),
      entry.tags.length > 0 && /* @__PURE__ */ jsx("div", { className: "flex gap-1 mb-1", children: entry.tags.map((tag) => /* @__PURE__ */ jsx(
        "span",
        {
          className: "px-1 py-0.5 rounded bg-secondary text-[9px] text-muted-foreground",
          children: tag
        },
        tag
      )) }),
      entry.notes && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-foreground/80 leading-relaxed", children: entry.notes }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 mt-1 text-[10px] text-muted-foreground", children: [
        entry.entryPrice != null && /* @__PURE__ */ jsxs("span", { children: [
          "Entry: ",
          formatNumber(entry.entryPrice, 5)
        ] }),
        entry.exitPrice != null && /* @__PURE__ */ jsxs("span", { children: [
          "Exit: ",
          formatNumber(entry.exitPrice, 5)
        ] }),
        /* @__PURE__ */ jsx("span", { children: formatDate(entry.createdAt) })
      ] })
    ] }, entry.id)) }) })
  ] });
}
const HISTORY_LIMIT = 100;
function sortByZ(list) {
  return [...list].sort((a, b) => (a.zIndex ?? 0) - (b.zIndex ?? 0));
}
const NO_DRAWINGS = [];
function useChartDrawings(symbol, timeframe) {
  const [loaded, setLoaded] = useState({
    symbol,
    list: NO_DRAWINGS
  });
  const drawings = loaded.symbol === symbol ? loaded.list : NO_DRAWINGS;
  const setDrawings = useCallback(
    (list) => setLoaded({ symbol, list }),
    [symbol]
  );
  const drawingsRef = useRef([]);
  const undoStackRef = useRef([]);
  const redoStackRef = useRef([]);
  useEffect(() => {
    let cancelled = false;
    api.chartDrawings.list(symbol).then((data) => {
      if (cancelled) return;
      const sorted = sortByZ(data ?? []);
      drawingsRef.current = sorted;
      undoStackRef.current = [];
      redoStackRef.current = [];
      setLoaded({ symbol, list: sorted });
    }).catch(() => {
    });
    return () => {
      cancelled = true;
    };
  }, [symbol]);
  const applyAdd = useCallback((d) => {
    drawingsRef.current = sortByZ([...drawingsRef.current, d]);
    setDrawings(drawingsRef.current);
    api.chartDrawings.save(symbol, timeframe, d).catch(() => {
    });
  }, [setDrawings, symbol, timeframe]);
  const applyUpdate = useCallback((d) => {
    drawingsRef.current = sortByZ(drawingsRef.current.map((x) => x.id === d.id ? d : x));
    setDrawings(drawingsRef.current);
    api.chartDrawings.save(symbol, timeframe, d).catch(() => {
    });
  }, [setDrawings, symbol, timeframe]);
  const applyRemove = useCallback((id) => {
    drawingsRef.current = drawingsRef.current.filter((x) => x.id !== id);
    setDrawings(drawingsRef.current);
    api.chartDrawings.remove(id).catch(() => {
    });
  }, [setDrawings]);
  const pushHistory = useCallback((op) => {
    undoStackRef.current.push(op);
    if (undoStackRef.current.length > HISTORY_LIMIT) undoStackRef.current.shift();
    redoStackRef.current = [];
  }, []);
  const addDrawing = useCallback(
    (d) => {
      pushHistory({ kind: "add", drawing: d });
      applyAdd(d);
    },
    [pushHistory, applyAdd]
  );
  const updateDrawing = useCallback(
    (d) => {
      const before = drawingsRef.current.find((x) => x.id === d.id);
      if (before) pushHistory({ kind: "update", before, after: d });
      applyUpdate(d);
    },
    [pushHistory, applyUpdate]
  );
  const removeDrawing = useCallback(
    (id) => {
      const drawing = drawingsRef.current.find((x) => x.id === id);
      if (drawing) pushHistory({ kind: "remove", drawing });
      applyRemove(id);
    },
    [pushHistory, applyRemove]
  );
  const clearDrawings = useCallback(() => {
    if (drawingsRef.current.length > 0) {
      pushHistory({ kind: "clear", drawings: drawingsRef.current });
    }
    drawingsRef.current = [];
    setDrawings([]);
    api.chartDrawings.clear(symbol).catch(() => {
    });
  }, [pushHistory, setDrawings, symbol]);
  const revertOp = useCallback(
    (op) => {
      if (op.kind === "add") applyRemove(op.drawing.id);
      else if (op.kind === "update") applyUpdate(op.before);
      else if (op.kind === "remove") applyAdd(op.drawing);
      else for (const d of op.drawings) applyAdd(d);
    },
    [applyAdd, applyUpdate, applyRemove]
  );
  const replayOp = useCallback(
    (op) => {
      if (op.kind === "add") applyAdd(op.drawing);
      else if (op.kind === "update") applyUpdate(op.after);
      else if (op.kind === "remove") applyRemove(op.drawing.id);
      else for (const d of op.drawings) applyRemove(d.id);
    },
    [applyAdd, applyUpdate, applyRemove]
  );
  const undo = useCallback(() => {
    const op = undoStackRef.current.pop();
    if (!op) return;
    revertOp(op);
    redoStackRef.current.push(op);
  }, [revertOp]);
  const redo = useCallback(() => {
    const op = redoStackRef.current.pop();
    if (!op) return;
    replayOp(op);
    undoStackRef.current.push(op);
  }, [replayOp]);
  return { drawings, addDrawing, updateDrawing, removeDrawing, clearDrawings, undo, redo };
}
const TIMEFRAMES = ["1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"];
const CHART_SETTINGS_DEFAULTS = {
  displayTimezone: "Etc/UTC",
  priceScaleTopMargin: 0.2,
  priceScaleBottomMargin: 0.1,
  scaleTextSize: 12,
  rightOffset: 6,
  oneMinuteRightOffset: 10
};
const CHART_COLORS = {
  dark: {
    background: "#101010",
    text: "#9298a5",
    grid: "#1b1b1b",
    crosshair: "#555c68",
    up: "#26a69a",
    down: "#ef5350",
    volumeUp: "rgba(14, 203, 129, 0.18)",
    volumeDown: "rgba(246, 70, 93, 0.18)",
    bidLine: "#0ecb81",
    askLine: "#f6465d",
    bidLabelBg: "#0ecb81",
    askLabelBg: "#f6465d",
    watermark: "rgba(255, 255, 255, 0.03)",
    lastPriceUp: "#0ecb81",
    lastPriceDown: "#f6465d",
    orderLine: "#f0b90b",
    positionLong: "#0ecb81",
    positionShort: "#f6465d",
    tpLine: "#0ecb81",
    slLine: "#f6465d"
  },
  light: {
    background: "#ffffff",
    text: "#5d6068",
    grid: "#f0f2f5",
    crosshair: "#999",
    up: "#26a69a",
    down: "#ef5350",
    volumeUp: "rgba(14, 203, 129, 0.25)",
    volumeDown: "rgba(246, 70, 93, 0.25)",
    bidLine: "#0ecb81",
    askLine: "#f6465d",
    bidLabelBg: "#0ecb81",
    askLabelBg: "#f6465d",
    watermark: "rgba(0, 0, 0, 0.03)",
    lastPriceUp: "#0ecb81",
    lastPriceDown: "#f6465d",
    orderLine: "#f0b90b",
    positionLong: "#0ecb81",
    positionShort: "#f6465d",
    tpLine: "#0ecb81",
    slLine: "#f6465d"
  }
};
const COLOR_OVERRIDE_MAP = [
  ["colorBackground", "background"],
  ["colorGrid", "grid"],
  ["colorScaleText", "text"],
  ["colorCrosshair", "crosshair"],
  ["colorBidLine", "bidLine"],
  ["colorAskLine", "askLine"],
  ["colorPositionLong", "positionLong"],
  ["colorPositionShort", "positionShort"],
  ["colorOrderLine", "orderLine"],
  ["colorTpLine", "tpLine"],
  ["colorSlLine", "slLine"],
  ["candleUpColor", "up"],
  ["candleDownColor", "down"]
];
function mergeChartColors(theme, overrides) {
  const merged = { ...theme };
  for (const [overrideKey, themeKey] of COLOR_OVERRIDE_MAP) {
    const value = overrides[overrideKey];
    if (value) merged[themeKey] = value;
  }
  return merged;
}
const TF_INTERVAL_MS = {
  "1m": 6e4,
  "5m": 5 * 6e4,
  "15m": 15 * 6e4,
  "30m": 30 * 6e4,
  "1h": 60 * 6e4,
  "4h": 4 * 60 * 6e4,
  "1d": 24 * 60 * 6e4,
  "1w": 7 * 24 * 60 * 6e4
};
const KNOWN_CURRENCIES = [
  "EUR",
  "USD",
  "GBP",
  "JPY",
  "AUD",
  "NZD",
  "CAD",
  "CHF",
  "CNY",
  "HKD",
  "SGD",
  "SEK",
  "NOK",
  "MXN",
  "ZAR",
  "TRY",
  "PLN",
  "CZK",
  "HUF",
  "DKK"
];
const MOCK_EVENTS = [
  {
    time: "08:30",
    currency: "USD",
    impact: "high",
    event: "Non-Farm Payrolls",
    forecast: "180K",
    previous: "175K"
  },
  {
    time: "10:00",
    currency: "USD",
    impact: "medium",
    event: "ISM Manufacturing PMI",
    forecast: "49.8",
    previous: "49.2"
  },
  {
    time: "14:00",
    currency: "EUR",
    impact: "high",
    event: "ECB Interest Rate Decision",
    forecast: "4.50%",
    previous: "4.50%"
  },
  {
    time: "08:00",
    currency: "GBP",
    impact: "medium",
    event: "GDP m/m",
    forecast: "0.2%",
    previous: "0.1%"
  },
  {
    time: "21:30",
    currency: "JPY",
    impact: "low",
    event: "Unemployment Rate",
    forecast: "2.5%",
    previous: "2.5%"
  },
  { time: "15:30", currency: "USD", impact: "high", event: "FOMC Statement" },
  {
    time: "02:00",
    currency: "CNY",
    impact: "medium",
    event: "CPI y/y",
    forecast: "0.3%",
    previous: "0.2%"
  }
];
const MOCK_NEWS = [
  {
    time: "2m ago",
    title: "Fed signals potential rate cut in September meeting",
    source: "Sample",
    impact: "bullish"
  },
  {
    time: "15m ago",
    title: "EUR/USD breaks above key resistance at 1.0950",
    source: "Sample",
    impact: "bullish"
  },
  {
    time: "32m ago",
    title: "Oil prices surge on OPEC+ production cut extension",
    source: "Sample",
    impact: "neutral"
  },
  {
    time: "1h ago",
    title: "Bank of Japan maintains ultra-loose monetary policy",
    source: "Sample",
    impact: "bearish"
  },
  {
    time: "2h ago",
    title: "US Treasury yields climb ahead of jobs data",
    source: "Sample",
    impact: "bearish"
  },
  {
    time: "3h ago",
    title: "Gold hits record high amid geopolitical tensions",
    source: "Sample",
    impact: "bullish"
  }
];
const LEGACY_TRADER_PREFS_KEY = "trader_prefs";
function getTraderPrefsStorageKey(userId2) {
  return userId2 ? `${LEGACY_TRADER_PREFS_KEY}:${userId2}` : LEGACY_TRADER_PREFS_KEY;
}
function parsePrefs(raw) {
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}
function readTraderPrefs$1(userId2) {
  const scoped = parsePrefs(safeStorage.getItem(getTraderPrefsStorageKey(userId2)));
  if (Object.keys(scoped).length > 0) return scoped;
  return parsePrefs(safeStorage.getItem(LEGACY_TRADER_PREFS_KEY));
}
function writeTraderPrefs(prefs, userId2) {
  safeStorage.setItem(getTraderPrefsStorageKey(userId2), JSON.stringify(prefs));
}
const CHART_PREFS_UPDATED_EVENT = "chart-preferences-updated";
let chartPreferencesPreview = null;
const DEFAULT_CHART_PREFS = {
  showBidLine: true,
  showAskLine: true,
  overlayPositionsOnChart: true,
  drawingMagnet: false,
  magnetMode: "none",
  stayInDrawingMode: false,
  activePlugins: [],
  candleUpColor: "",
  candleDownColor: "",
  candleBullBodyColor: "",
  candleBearBodyColor: "",
  candleBullBorderColor: "",
  candleBearBorderColor: "",
  candleBullWickColor: "",
  candleBearWickColor: "",
  colorBarsByPreviousClose: false,
  colorBackground: "",
  colorGrid: "",
  colorVerticalGrid: "",
  colorHorizontalGrid: "",
  colorScaleText: "",
  colorCrosshair: "",
  colorBidLine: "",
  colorAskLine: "",
  colorPositionLong: "",
  colorPositionShort: "",
  colorOrderLine: "",
  colorTpLine: "",
  colorSlLine: "",
  activeChartTemplate: "",
  chartTemplateAutosave: false,
  showWicks: true,
  showCandleBorders: true,
  showVolume: true,
  showGrid: true,
  showVerticalGrid: true,
  showHorizontalGrid: true,
  showWatermark: true,
  showCountdown: true,
  showOhlcLegend: true,
  showStatusLineSymbol: true,
  showStatusLineMarketState: false,
  showStatusLineChange: true,
  showStatusLineVolume: true,
  showStatusLineStudyTitle: true,
  showStatusLineStudyInputs: true,
  showStatusLineStudyValues: true,
  showStatusLineStudyBackground: true,
  displayTimezone: CHART_SETTINGS_DEFAULTS.displayTimezone,
  pricePrecision: "default",
  priceScaleMode: "normal",
  priceScaleSide: "right",
  priceScaleInverted: false,
  noOverlappingLabels: true,
  showPriceScale: true,
  showTimeScale: true,
  showPriceLine: true,
  showLastValue: true,
  priceScaleTopMargin: CHART_SETTINGS_DEFAULTS.priceScaleTopMargin,
  priceScaleBottomMargin: CHART_SETTINGS_DEFAULTS.priceScaleBottomMargin,
  timeScaleDateFormat: "locale",
  timeScaleShowDayOfWeek: true,
  timeScaleTimeFormat: "24-hour",
  timeScaleSecondsVisible: "auto",
  timeScaleRightOffset: "default",
  watermarkMode: "symbol",
  crosshairLineStyle: "large-dashed",
  scaleTextSize: CHART_SETTINGS_DEFAULTS.scaleTextSize,
  showScaleBorder: true,
  chartBackgroundMode: "solid",
  enableChartScroll: true,
  enableChartScale: true,
  challengeOverlay: false,
  challengeDailyLossLine: false,
  challengeMaxDrawdownLine: false,
  challengeProfitTargetLine: false
};
function getDefaultChartPreferences() {
  return { ...DEFAULT_CHART_PREFS, activePlugins: [] };
}
const BOOL_PREF_KEYS = [
  "showBidLine",
  "showAskLine",
  "overlayPositionsOnChart",
  "drawingMagnet",
  "stayInDrawingMode",
  "showWicks",
  "showCandleBorders",
  "showVolume",
  "showGrid",
  "showVerticalGrid",
  "showHorizontalGrid",
  "showWatermark",
  "showCountdown",
  "showOhlcLegend",
  "challengeOverlay",
  "challengeDailyLossLine",
  "challengeMaxDrawdownLine",
  "challengeProfitTargetLine",
  "chartTemplateAutosave",
  "colorBarsByPreviousClose",
  "showStatusLineSymbol",
  "showStatusLineMarketState",
  "showStatusLineChange",
  "showStatusLineVolume",
  "showStatusLineStudyTitle",
  "showStatusLineStudyInputs",
  "showStatusLineStudyValues",
  "showStatusLineStudyBackground",
  "showPriceScale",
  "showTimeScale",
  "priceScaleInverted",
  "noOverlappingLabels",
  "showPriceLine",
  "showLastValue",
  "timeScaleShowDayOfWeek",
  "showScaleBorder",
  "enableChartScroll",
  "enableChartScale"
];
const STRING_PREF_KEYS = [
  "candleUpColor",
  "candleDownColor",
  "candleBullBodyColor",
  "candleBearBodyColor",
  "candleBullBorderColor",
  "candleBearBorderColor",
  "candleBullWickColor",
  "candleBearWickColor",
  "colorBackground",
  "colorGrid",
  "colorVerticalGrid",
  "colorHorizontalGrid",
  "colorScaleText",
  "colorCrosshair",
  "colorBidLine",
  "colorAskLine",
  "colorPositionLong",
  "colorPositionShort",
  "colorOrderLine",
  "colorTpLine",
  "colorSlLine",
  "activeChartTemplate",
  "displayTimezone",
  "priceScaleMode",
  "priceScaleSide",
  "timeScaleDateFormat",
  "timeScaleTimeFormat",
  "watermarkMode",
  "crosshairLineStyle",
  "chartBackgroundMode"
];
const NUMBER_PREF_KEYS = [
  "priceScaleTopMargin",
  "priceScaleBottomMargin",
  "scaleTextSize"
];
const TEMPLATE_PREF_KEYS = [
  "showBidLine",
  "showAskLine",
  "overlayPositionsOnChart",
  "showWicks",
  "showCandleBorders",
  "showVolume",
  "showGrid",
  "showVerticalGrid",
  "showHorizontalGrid",
  "showWatermark",
  "showCountdown",
  "showOhlcLegend",
  "challengeOverlay",
  "challengeDailyLossLine",
  "challengeMaxDrawdownLine",
  "challengeProfitTargetLine",
  "candleUpColor",
  "candleDownColor",
  "candleBullBodyColor",
  "candleBearBodyColor",
  "candleBullBorderColor",
  "candleBearBorderColor",
  "candleBullWickColor",
  "candleBearWickColor",
  "colorBarsByPreviousClose",
  "colorBackground",
  "colorGrid",
  "colorVerticalGrid",
  "colorHorizontalGrid",
  "colorScaleText",
  "colorCrosshair",
  "colorBidLine",
  "colorAskLine",
  "colorPositionLong",
  "colorPositionShort",
  "colorOrderLine",
  "colorTpLine",
  "colorSlLine",
  "showStatusLineSymbol",
  "showStatusLineMarketState",
  "showStatusLineChange",
  "showStatusLineVolume",
  "showStatusLineStudyTitle",
  "showStatusLineStudyInputs",
  "showStatusLineStudyValues",
  "showStatusLineStudyBackground",
  "displayTimezone",
  "pricePrecision",
  "priceScaleMode",
  "priceScaleSide",
  "priceScaleInverted",
  "noOverlappingLabels",
  "showPriceScale",
  "showTimeScale",
  "showPriceLine",
  "showLastValue",
  "priceScaleTopMargin",
  "priceScaleBottomMargin",
  "timeScaleDateFormat",
  "timeScaleShowDayOfWeek",
  "timeScaleTimeFormat",
  "timeScaleSecondsVisible",
  "timeScaleRightOffset",
  "watermarkMode",
  "crosshairLineStyle",
  "scaleTextSize",
  "showScaleBorder",
  "chartBackgroundMode",
  "enableChartScroll",
  "enableChartScale"
];
function toMagnetMode(input) {
  return input === "weak" || input === "strong" || input === "none" ? input : void 0;
}
function readTraderPrefs() {
  var _a;
  const userId2 = (_a = useAuthStore.getState().user) == null ? void 0 : _a.id;
  return readTraderPrefs$1(userId2);
}
function dispatchChartPrefsUpdated() {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new Event(CHART_PREFS_UPDATED_EVENT));
}
function toBool(input, fallback) {
  if (input == null) return fallback;
  if (input === "true") return true;
  if (input === "false") return false;
  return fallback;
}
function toStringArray(input, fallback) {
  if (input == null) return fallback;
  try {
    const parsed = JSON.parse(input);
    return Array.isArray(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}
function oneOf(input, values, fallback) {
  return values.find((value) => value === input) ?? fallback;
}
function toFiniteNumber(input, fallback, min, max) {
  if (input == null || input.trim() === "") return fallback;
  const value = Number(input);
  return Number.isFinite(value) && value >= min && value <= max ? value : fallback;
}
function toPricePrecision(input) {
  if (input === "default") return "default";
  const value = Number(input);
  return Number.isInteger(value) && value >= 0 && value <= 8 ? value : DEFAULT_CHART_PREFS.pricePrecision;
}
function toColor(input, fallback) {
  if (input == null) return fallback;
  if (input === "") return "";
  return /^#(?:[\da-f]{3}|[\da-f]{6}|[\da-f]{8})$/i.test(input) ? input : "";
}
function isTimeZone(input) {
  try {
    new Intl.DateTimeFormat("en", { timeZone: input });
    return true;
  } catch {
    return false;
  }
}
function getChartPreferencesFromStorage() {
  const prefs = readTraderPrefs();
  const result = { ...DEFAULT_CHART_PREFS };
  for (const key of BOOL_PREF_KEYS) {
    result[key] = toBool(prefs[key], DEFAULT_CHART_PREFS[key]);
  }
  for (const key of STRING_PREF_KEYS) {
    Object.assign(result, { [key]: prefs[key] ?? DEFAULT_CHART_PREFS[key] });
  }
  for (const key of NUMBER_PREF_KEYS) {
    result[key] = toFiniteNumber(
      prefs[key],
      DEFAULT_CHART_PREFS[key],
      key === "scaleTextSize" ? 8 : 0,
      key === "scaleTextSize" ? 20 : 0.45
    );
  }
  const legacyUpColor = result.candleUpColor;
  const legacyDownColor = result.candleDownColor;
  result.candleBullBodyColor = toColor(prefs.candleBullBodyColor, legacyUpColor);
  result.candleBullBorderColor = toColor(prefs.candleBullBorderColor, legacyUpColor);
  result.candleBullWickColor = toColor(prefs.candleBullWickColor, legacyUpColor);
  result.candleBearBodyColor = toColor(prefs.candleBearBodyColor, legacyDownColor);
  result.candleBearBorderColor = toColor(prefs.candleBearBorderColor, legacyDownColor);
  result.candleBearWickColor = toColor(prefs.candleBearWickColor, legacyDownColor);
  result.displayTimezone = prefs.displayTimezone && isTimeZone(prefs.displayTimezone) ? prefs.displayTimezone : DEFAULT_CHART_PREFS.displayTimezone;
  result.pricePrecision = toPricePrecision(prefs.pricePrecision);
  result.priceScaleMode = oneOf(
    prefs.priceScaleMode,
    ["normal", "logarithmic", "percentage", "indexedTo100"],
    DEFAULT_CHART_PREFS.priceScaleMode
  );
  result.priceScaleSide = oneOf(
    prefs.priceScaleSide,
    ["right", "left"],
    DEFAULT_CHART_PREFS.priceScaleSide
  );
  result.timeScaleDateFormat = oneOf(
    prefs.timeScaleDateFormat,
    ["locale", "yyyy-MM-dd", "dd MMM yyyy", "MMM dd, yyyy"],
    DEFAULT_CHART_PREFS.timeScaleDateFormat
  );
  result.timeScaleTimeFormat = oneOf(
    prefs.timeScaleTimeFormat,
    ["24-hour", "12-hour"],
    DEFAULT_CHART_PREFS.timeScaleTimeFormat
  );
  result.timeScaleSecondsVisible = prefs.timeScaleSecondsVisible == null || prefs.timeScaleSecondsVisible === "auto" ? "auto" : prefs.timeScaleSecondsVisible === "true" ? true : prefs.timeScaleSecondsVisible === "false" ? false : DEFAULT_CHART_PREFS.timeScaleSecondsVisible;
  const rightOffset = prefs.timeScaleRightOffset === "default" ? NaN : Number(prefs.timeScaleRightOffset);
  result.timeScaleRightOffset = Number.isInteger(rightOffset) && rightOffset >= 0 && rightOffset <= 50 ? rightOffset : DEFAULT_CHART_PREFS.timeScaleRightOffset;
  result.watermarkMode = oneOf(
    prefs.watermarkMode,
    ["none", "symbol", "symbol-timeframe"],
    result.showWatermark ? "symbol" : "none"
  );
  result.crosshairLineStyle = oneOf(
    prefs.crosshairLineStyle,
    ["solid", "dotted", "dashed", "large-dashed"],
    DEFAULT_CHART_PREFS.crosshairLineStyle
  );
  result.chartBackgroundMode = oneOf(
    prefs.chartBackgroundMode,
    ["solid", "transparent"],
    DEFAULT_CHART_PREFS.chartBackgroundMode
  );
  result.colorVerticalGrid = toColor(prefs.colorVerticalGrid, result.colorGrid);
  result.colorHorizontalGrid = toColor(prefs.colorHorizontalGrid, result.colorGrid);
  result.showVerticalGrid = toBool(prefs.showVerticalGrid, result.showGrid);
  result.showHorizontalGrid = toBool(prefs.showHorizontalGrid, result.showGrid);
  if (prefs.showVerticalGrid != null || prefs.showHorizontalGrid != null) {
    result.showGrid = result.showVerticalGrid && result.showHorizontalGrid;
  }
  result.showWatermark = result.watermarkMode !== "none";
  result.magnetMode = toMagnetMode(prefs.magnetMode) ?? (toBool(prefs.drawingMagnet, false) ? "weak" : "none");
  result.activePlugins = toStringArray(prefs.activePlugins, DEFAULT_CHART_PREFS.activePlugins);
  return result;
}
function updateChartPreferences(patch) {
  var _a;
  const next = { ...readTraderPrefs() };
  for (const [key, value] of Object.entries(patch)) {
    if (value == null) continue;
    next[key] = typeof value === "string" ? value : JSON.stringify(value);
  }
  if (patch.showGrid != null || patch.showVerticalGrid != null || patch.showHorizontalGrid != null) {
    const current2 = getChartPreferencesFromStorage();
    const vertical = patch.showVerticalGrid ?? patch.showGrid ?? current2.showVerticalGrid;
    const horizontal = patch.showHorizontalGrid ?? patch.showGrid ?? current2.showHorizontalGrid;
    next.showVerticalGrid = JSON.stringify(vertical);
    next.showHorizontalGrid = JSON.stringify(horizontal);
    next.showGrid = JSON.stringify(vertical && horizontal);
  }
  if (patch.watermarkMode != null) {
    next.showWatermark = JSON.stringify(patch.watermarkMode !== "none");
  } else if (patch.showWatermark != null) {
    next.watermarkMode = patch.showWatermark ? "symbol" : "none";
  }
  if (patch.colorGrid != null) {
    if (patch.colorVerticalGrid == null) next.colorVerticalGrid = patch.colorGrid;
    if (patch.colorHorizontalGrid == null) next.colorHorizontalGrid = patch.colorGrid;
  }
  const userId2 = (_a = useAuthStore.getState().user) == null ? void 0 : _a.id;
  writeTraderPrefs(next, userId2);
  dispatchChartPrefsUpdated();
  return next;
}
function setChartPreferencesPreview(prefs) {
  var _a;
  chartPreferencesPreview = {
    userId: (_a = useAuthStore.getState().user) == null ? void 0 : _a.id,
    prefs: { ...prefs }
  };
  dispatchChartPrefsUpdated();
}
function commitChartPreferencesPreview(prefs) {
  chartPreferencesPreview = null;
  const patch = Object.fromEntries(TEMPLATE_PREF_KEYS.map((key) => [key, prefs[key]]));
  updateChartPreferences(patch);
}
function discardChartPreferencesPreview() {
  if (chartPreferencesPreview === null) return;
  chartPreferencesPreview = null;
  dispatchChartPrefsUpdated();
}
function useChartPreferences() {
  const userId2 = useAuthStore((s) => {
    var _a;
    return (_a = s.user) == null ? void 0 : _a.id;
  });
  const [prefs, setPrefs] = useState(() => getChartPreferencesFromStorage());
  useEffect(() => {
    const refresh = () => setPrefs(getChartPreferencesFromStorage());
    window.addEventListener("storage", refresh);
    window.addEventListener(CHART_PREFS_UPDATED_EVENT, refresh);
    return () => {
      window.removeEventListener("storage", refresh);
      window.removeEventListener(CHART_PREFS_UPDATED_EVENT, refresh);
    };
  }, [userId2]);
  const previewState = chartPreferencesPreview;
  const preview = previewState && previewState.userId === userId2 ? previewState.prefs : null;
  return preview ?? prefs;
}
const STORAGE_KEY = "tradeSoundMuted";
function useTradeSound() {
  const [muted, setMuted] = useState(() => safeStorage.getItem(STORAGE_KEY) === "true");
  const ctxRef = useRef(null);
  const getCtx = useCallback(() => {
    if (!ctxRef.current || ctxRef.current.state === "closed") {
      ctxRef.current = new AudioContext();
    }
    return ctxRef.current;
  }, []);
  const playTradeSound = useCallback(() => {
    if (muted) return;
    try {
      const ctx = getCtx();
      if (ctx.state === "suspended") ctx.resume();
      const now = ctx.currentTime;
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = "sine";
      osc1.frequency.setValueAtTime(880, now);
      osc1.frequency.exponentialRampToValueAtTime(1320, now + 0.06);
      gain1.gain.setValueAtTime(0.18, now);
      gain1.gain.exponentialRampToValueAtTime(1e-3, now + 0.12);
      osc1.connect(gain1).connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.12);
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = "sine";
      osc2.frequency.setValueAtTime(1175, now + 0.08);
      gain2.gain.setValueAtTime(0.14, now + 0.08);
      gain2.gain.exponentialRampToValueAtTime(1e-3, now + 0.25);
      osc2.connect(gain2).connect(ctx.destination);
      osc2.start(now + 0.08);
      osc2.stop(now + 0.25);
    } catch {
    }
  }, [muted, getCtx]);
  const toggleMute = useCallback(() => {
    setMuted((prev) => {
      const next = !prev;
      safeStorage.setItem(STORAGE_KEY, String(next));
      return next;
    });
  }, []);
  return { muted, toggleMute, playTradeSound };
}
function sliceBufferToCursor(buf, cursorMs) {
  var _a;
  const cutoff = cursorMs ?? ((_a = buf[0]) == null ? void 0 : _a.t) ?? 0;
  const out = [];
  for (const b of buf) {
    if (b.t > cutoff) break;
    out.push({ time: b.t, open: b.o, high: b.h, low: b.l, close: b.c, volume: b.v });
  }
  return out;
}
function emptySessionReason(data, sessionDate) {
  var _a;
  return ((_a = data.meta) == null ? void 0 : _a.primarySymbol) ? `No 1m candle history stored for ${data.meta.primarySymbol} on ${sessionDate}` : `No trading activity found on ${sessionDate}`;
}
function useReplayChartData(accountId) {
  var _a;
  const isReplaying = useTradingStore((s) => s.isReplaying);
  const replaySessionDate = useTradingStore((s) => s.replaySessionDate);
  const replayCursorTimestamp = useTradingStore((s) => s.replayCursorTimestamp);
  const setSelectedSymbol = useTradingStore((s) => s.setSelectedSymbol);
  const selectedSymbol = useTradingStore((s) => s.selectedSymbol);
  const { data } = useReplaySession(
    isReplaying ? accountId : null,
    replaySessionDate,
    selectedSymbol
  );
  const replaySymbol = isReplaying ? ((_a = data == null ? void 0 : data.meta) == null ? void 0 : _a.primarySymbol) ?? null : null;
  useEffect(() => {
    if (replaySymbol) setSelectedSymbol(replaySymbol);
  }, [replaySymbol, setSelectedSymbol]);
  useEffect(() => {
    if (!isReplaying || !data || !replaySessionDate || !accountId) return;
    if (data.tickBuffer.length > 0) return;
    toast.warning("Replay unavailable", emptySessionReason(data, replaySessionDate));
    api.replayStop(accountId, replaySessionDate).catch(() => null);
    useTradingStore.getState().onReplayStateChanged("stopped");
  }, [isReplaying, data, replaySessionDate, accountId]);
  const replayCandles = useMemo(() => {
    if (!isReplaying || !data || data.tickBuffer.length === 0) return null;
    return sliceBufferToCursor(data.tickBuffer, replayCursorTimestamp);
  }, [isReplaying, data, replayCursorTimestamp]);
  return {
    replayCandles,
    replayTradeEvents: isReplaying ? data == null ? void 0 : data.tradeEvents : void 0
  };
}
const MAX_TICKS_PER_FRAME = 10;
const STORE_SYNC_MS = 250;
const SERVER_SYNC_MS = 2e3;
function advanceTickIndex(buf, idxRef, cursorMs) {
  var _a;
  let chunk = 0;
  while (idxRef.current < buf.length && (((_a = buf[idxRef.current]) == null ? void 0 : _a.t) ?? Infinity) <= cursorMs && chunk < MAX_TICKS_PER_FRAME) {
    idxRef.current++;
    chunk++;
  }
}
function syncCursorToStore(now, lastSyncRef, cursorMs) {
  if (now - lastSyncRef.current < STORE_SYNC_MS) return;
  useTradingStore.setState({ replayCursorTimestamp: cursorMs });
  lastSyncRef.current = now;
}
function syncCursorToServer(now, lastSyncRef, accountId, sessionDate, cursorMs) {
  if (now - lastSyncRef.current < SERVER_SYNC_MS || !sessionDate) return;
  lastSyncRef.current = now;
  api.replayPatchSession(accountId, { sessionDate, cursorTimestamp: cursorMs }).catch(() => null);
}
function finishReplay(accountId, sessionDate, endMs) {
  useTradingStore.setState({ replayCursorTimestamp: endMs });
  if (sessionDate) {
    api.replayStop(accountId, sessionDate).catch(() => null);
  }
  useTradingStore.getState().onReplayStateChanged("stopped");
}
function useReplayPlayback(accountId) {
  const isReplaying = useTradingStore((s) => s.isReplaying);
  const replayPaused = useTradingStore((s) => s.replayPaused);
  const replaySpeed = useTradingStore((s) => s.replaySpeed);
  const replayCursorTimestamp = useTradingStore((s) => s.replayCursorTimestamp);
  const replaySessionDate = useTradingStore((s) => s.replaySessionDate);
  const selectedSymbol = useTradingStore((s) => s.selectedSymbol);
  const { data: sessionData } = useReplaySession(
    isReplaying ? accountId : null,
    replaySessionDate,
    selectedSymbol
  );
  const speedRef = useRef(replaySpeed);
  const sessionDateRef = useRef(replaySessionDate);
  const tickBufferRef = useRef([]);
  const nextTickIdxRef = useRef(0);
  const localCursorMsRef = useRef(null);
  const lastFrameTimeRef = useRef(null);
  const lastStoreSyncRef = useRef(0);
  const lastServerSyncRef = useRef(0);
  const rafIdRef = useRef(null);
  const isActiveRef = useRef(false);
  useEffect(() => {
    speedRef.current = replaySpeed;
  }, [replaySpeed]);
  useEffect(() => {
    sessionDateRef.current = replaySessionDate;
  }, [replaySessionDate]);
  useEffect(() => {
    if (isReplaying) {
      localCursorMsRef.current = null;
      nextTickIdxRef.current = 0;
    }
  }, [isReplaying]);
  useEffect(() => {
    if (sessionData == null ? void 0 : sessionData.tickBuffer) {
      tickBufferRef.current = sessionData.tickBuffer;
    }
  }, [sessionData]);
  useEffect(() => {
    var _a;
    if (replayCursorTimestamp == null) return;
    const local = localCursorMsRef.current;
    if (local == null || Math.abs(replayCursorTimestamp - local) > 1e3) {
      localCursorMsRef.current = replayCursorTimestamp;
      const buf = tickBufferRef.current;
      let idx = 0;
      while (idx < buf.length && (((_a = buf[idx]) == null ? void 0 : _a.t) ?? Infinity) <= replayCursorTimestamp) idx++;
      nextTickIdxRef.current = idx;
    }
  }, [replayCursorTimestamp]);
  useEffect(() => {
    if (!isReplaying || replayPaused) {
      isActiveRef.current = false;
      if (rafIdRef.current !== null) {
        cancelAnimationFrame(rafIdRef.current);
        rafIdRef.current = null;
      }
      lastFrameTimeRef.current = null;
      return;
    }
    isActiveRef.current = true;
    lastFrameTimeRef.current = null;
    const step = (now) => {
      if (lastFrameTimeRef.current === null) {
        lastFrameTimeRef.current = now;
        return true;
      }
      const realDeltaMs = Math.min(now - lastFrameTimeRef.current, 100);
      lastFrameTimeRef.current = now;
      const replayDeltaMs = realDeltaMs * speedRef.current;
      const buf = tickBufferRef.current;
      if (buf.length === 0) return true;
      const endMs = buf[buf.length - 1].t;
      const prevCursorMs = localCursorMsRef.current ?? buf[0].t;
      const newCursorMs = Math.min(prevCursorMs + replayDeltaMs, endMs);
      localCursorMsRef.current = newCursorMs;
      advanceTickIndex(buf, nextTickIdxRef, newCursorMs);
      syncCursorToStore(now, lastStoreSyncRef, newCursorMs);
      syncCursorToServer(now, lastServerSyncRef, accountId, sessionDateRef.current, newCursorMs);
      if (newCursorMs >= endMs) {
        isActiveRef.current = false;
        finishReplay(accountId, sessionDateRef.current, endMs);
        return false;
      }
      return true;
    };
    const frame = (now) => {
      if (!isActiveRef.current) return;
      if (step(now)) rafIdRef.current = requestAnimationFrame(frame);
    };
    rafIdRef.current = requestAnimationFrame(frame);
    return () => {
      isActiveRef.current = false;
      if (rafIdRef.current !== null) {
        cancelAnimationFrame(rafIdRef.current);
        rafIdRef.current = null;
      }
    };
  }, [isReplaying, replayPaused, accountId]);
  useEffect(() => {
    return () => {
      isActiveRef.current = false;
      if (rafIdRef.current !== null) cancelAnimationFrame(rafIdRef.current);
    };
  }, []);
}
function getPipDigits(symbolInfo, symbolName) {
  const symbolDecimals = _symbolNameDecimals(symbolName);
  if (symbolInfo == null ? void 0 : symbolInfo.tickSize) {
    const s = String(symbolInfo.tickSize);
    const tickDecimals = s.includes(".") ? s.split(".")[1].replace(/0+$/, "").length || s.split(".")[1].length : 0;
    return Math.max(tickDecimals, symbolDecimals, 2);
  }
  return symbolDecimals;
}
function _symbolNameDecimals(symbolName) {
  if (!symbolName) return 5;
  const n = symbolName.toUpperCase();
  if (n.includes("JPY") || n.includes("XAU") || n.includes("GOLD")) return 3;
  if (n.includes("BTC") || n.includes("ETH")) return 2;
  if (n.includes("US30") || n.includes("SPX") || n.includes("NAS") || n.includes("DAX")) return 2;
  return 5;
}
function getMinMove(pipDigits) {
  return Number((1 / Math.pow(10, pipDigits)).toFixed(pipDigits + 1));
}
function toUnixSeconds(ts) {
  if (typeof ts === "number") return ts > 1e12 ? Math.floor(ts / 1e3) : ts;
  return Math.floor(new Date(ts).getTime() / 1e3);
}
function toUnixMs(ts) {
  return ts > 1e12 ? ts : ts * 1e3;
}
function toIndicatorCandles(candles) {
  return candles.map((c) => ({
    time: c.time,
    open: c.open,
    high: c.high,
    low: c.low,
    close: c.close,
    volume: 0
  }));
}
function formatCountdown$1(totalSec) {
  if (totalSec <= 0) return "0:00";
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor(totalSec % 3600 / 60);
  const s = Math.floor(totalSec % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}
function extractCurrencies(symbol) {
  const upper = symbol.toUpperCase().replace(/[^A-Z]/g, "");
  const found = [];
  for (const c of KNOWN_CURRENCIES) {
    if (upper.includes(c)) found.push(c);
  }
  if (found.length === 0 && upper.length >= 6) {
    found.push(upper.slice(0, 3), upper.slice(3, 6));
  }
  return [...new Set(found)];
}
function getCandleBucketTime(timestampMs, tf) {
  const SEC = 1e3;
  const intervals = {
    "1m": 60 * SEC,
    "5m": 5 * 60 * SEC,
    "15m": 15 * 60 * SEC,
    "30m": 30 * 60 * SEC,
    "1h": 60 * 60 * SEC,
    "4h": 4 * 60 * 60 * SEC,
    "1d": 24 * 60 * 60 * SEC,
    "1w": 7 * 24 * 60 * 60 * SEC
  };
  const ms = intervals[tf];
  return Math.floor(Math.floor(timestampMs / ms) * ms / 1e3);
}
function readStoredTimeframe(symbol) {
  const saved = safeStorage.getItem(`tf_${symbol}`);
  return saved && TIMEFRAMES.includes(saved) ? saved : "15m";
}
function getErrorMessage$1(err) {
  if (err && typeof err === "object" && "message" in err) {
    const message = err.message;
    if (typeof message === "string" && message.length > 0) return message;
  }
  return "Request failed";
}
function deepLimitFor(timeframe) {
  switch (timeframe) {
    case "1m":
      return 3e3;
    case "5m":
      return 5e3;
    case "15m":
      return 12e3;
    case "30m":
      return 8e3;
    case "1h":
      return 8e3;
    case "4h":
      return 4e3;
    case "1d":
      return 2e3;
    case "1w":
      return 520;
    default:
      return 5e3;
  }
}
function TerminalProvider({ children }) {
  const queryClient = useQueryClient();
  const {
    selectedSymbol,
    setSelectedSymbol,
    ticks,
    updateTick,
    activeAccountId,
    replayVersion,
    isReplaying
  } = useTradingStore();
  const [timeframeBySymbol, setTimeframeBySymbol] = useState(
    {}
  );
  const timeframe = timeframeBySymbol[selectedSymbol] ?? readStoredTimeframe(selectedSymbol);
  const setTimeframe = useCallback(
    (tf) => {
      setTimeframeBySymbol((prev) => ({ ...prev, [selectedSymbol]: tf }));
      safeStorage.setItem(`tf_${selectedSymbol}`, tf);
    },
    [selectedSymbol]
  );
  const chartPrefs = useChartPreferences();
  const [activeIndicators, setActiveIndicators] = useState([]);
  const toggleIndicator = useCallback((type) => {
    setActiveIndicators(
      (prev) => prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
    );
  }, []);
  const clearIndicators = useCallback(() => setActiveIndicators([]), []);
  const [activePlugins, setActivePlugins] = useState(
    () => getChartPreferencesFromStorage().activePlugins
  );
  const togglePlugin = useCallback((id) => {
    setActivePlugins((prev) => {
      const next = prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id];
      updateChartPreferences({ activePlugins: next });
      return next;
    });
  }, []);
  const setPlugins = useCallback((ids) => {
    setActivePlugins(ids);
    updateChartPreferences({ activePlugins: ids });
  }, []);
  const cycleMagnetMode = useCallback(() => {
    const order = ["none", "weak", "strong"];
    const next = order[(order.indexOf(chartPrefs.magnetMode) + 1) % order.length] ?? "none";
    updateChartPreferences({ magnetMode: next });
  }, [chartPrefs.magnetMode]);
  const [drawingTool, setDrawingTool] = useState("none");
  const {
    drawings,
    addDrawing,
    updateDrawing,
    removeDrawing,
    clearDrawings,
    undo: undoDrawing,
    redo: redoDrawing
  } = useChartDrawings(selectedSymbol, timeframe);
  const [oneClick, setOneClick] = useState(
    () => safeStorage.getItem("oneClickTrading") === "true"
  );
  const toggleOneClick = useCallback(() => {
    setOneClick((prev) => {
      const next = !prev;
      safeStorage.setItem("oneClickTrading", String(next));
      return next;
    });
  }, []);
  const { muted: soundMuted, toggleMute: toggleSoundMute, playTradeSound } = useTradeSound();
  const onOrderSuccess = useCallback(() => {
    playTradeSound();
  }, [playTradeSound]);
  const [modifyingPosition, setModifyingPosition] = useState(null);
  const [modifyingOrder, setModifyingOrder] = useState(null);
  const [confirmOrder, setConfirmOrder] = useState(null);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const { data: symbols = [] } = useSymbols();
  const isFeedConnected = useIsFeedConnected();
  useEffect(() => {
    let cancelled = false;
    void api.getTick(selectedSymbol).then((snapshot) => {
      if (cancelled || !snapshot) return;
      updateTick(
        selectedSymbol,
        Number(snapshot.bid),
        Number(snapshot.ask),
        typeof snapshot.timestamp === "number" ? snapshot.timestamp : Date.now()
      );
    }).catch(() => {
    });
    return () => {
      cancelled = true;
    };
  }, [selectedSymbol, updateTick]);
  const invalidateTrading = useCallback(() => {
    if (!activeAccountId) return;
    queryClient.invalidateQueries({ queryKey: ["orders", activeAccountId] });
    queryClient.invalidateQueries({ queryKey: ["positions", activeAccountId] });
  }, [activeAccountId, queryClient]);
  const submitOrderDirect = useCallback(
    async (input) => {
      try {
        const order = await api.placeOrder(input);
        invalidateTrading();
        return order;
      } catch (err) {
        toast.error("Order Failed", getErrorMessage$1(err));
        throw err;
      }
    },
    [invalidateTrading]
  );
  const modifyPositionLevels = useCallback(
    async (positionId, mods) => {
      if (!isFeedConnected) {
        toast.warning(
          "No Data Feed",
          "Cannot modify positions while disconnected from the data feed"
        );
        invalidateTrading();
        return;
      }
      try {
        await api.modifyPosition(positionId, mods);
        const field = mods.takeProfit !== void 0 ? "TP" : "SL";
        const price = mods.takeProfit !== void 0 ? mods.takeProfit : mods.stopLoss;
        toast.success(`${field} Updated`, `${field} set to ${price}`);
        invalidateTrading();
      } catch (err) {
        toast.error("Modify Failed", getErrorMessage$1(err));
        invalidateTrading();
      }
    },
    [invalidateTrading, isFeedConnected]
  );
  const quickOrder = useCallback(
    (side, type, price) => {
      if (!activeAccountId) {
        toast.warning("No Account", "Select an account before placing orders");
        return;
      }
      const input = {
        accountId: activeAccountId,
        symbol: selectedSymbol,
        side,
        type,
        quantity: 1,
        ...type === "LIMIT" ? { price } : { stopPrice: price }
      };
      setConfirmOrder({ ...input, _submit: () => submitOrderDirect(input) });
    },
    [activeAccountId, selectedSymbol, submitOrderDirect]
  );
  const chartKey = `${selectedSymbol}:${timeframe}`;
  const firstPaintCandleLimit = useMemo(
    () => typeof window !== "undefined" && window.innerWidth < 768 ? 500 : 400,
    []
  );
  const [deepenedFor, setDeepenedFor] = useState(null);
  const candleLimit = deepenedFor === chartKey ? deepLimitFor(timeframe) : firstPaintCandleLimit;
  useEffect(() => {
    const timer = window.setTimeout(() => setDeepenedFor(chartKey), 400);
    return () => window.clearTimeout(timer);
  }, [chartKey]);
  const { data: candles = [] } = useCandles(selectedSymbol, timeframe, candleLimit, replayVersion);
  const { replayCandles, replayTradeEvents } = useReplayChartData(activeAccountId);
  useReplayPlayback(activeAccountId ?? "");
  const { data: positions = [] } = usePositions(activeAccountId);
  const { data: orders = [] } = useOrders(activeAccountId);
  const positionPnl = useMemo(
    () => positions.reduce((sum, position) => sum + (position.unrealizedPnl || 0), 0),
    [positions]
  );
  const chartPositions = chartPrefs.overlayPositionsOnChart ? positions : [];
  const chartOrders = chartPrefs.overlayPositionsOnChart ? orders : [];
  const { data: journalData, isLoading: journalLoading } = useJournalEntries(activeAccountId);
  const createJournalMutation = useCreateJournalEntry();
  const updateJournalMutation = useUpdateJournalEntry();
  const deleteJournalMutation = useDeleteJournalEntry();
  const createJournal = useCallback(
    (data) => createJournalMutation.mutate(data, {
      onSuccess: () => toast.success("Journal", "Entry saved"),
      onError: (err) => toast.error("Journal", getErrorMessage$1(err))
    }),
    [createJournalMutation]
  );
  const updateJournal = useCallback(
    (id, data) => updateJournalMutation.mutate(
      { id, accountId: activeAccountId ?? "", ...data },
      {
        onSuccess: () => toast.success("Journal", "Entry updated"),
        onError: (err) => toast.error("Journal", getErrorMessage$1(err))
      }
    ),
    [activeAccountId, updateJournalMutation]
  );
  const deleteJournal = useCallback(
    (id) => deleteJournalMutation.mutate(
      { id, accountId: activeAccountId ?? "" },
      {
        onSuccess: () => toast.success("Journal", "Entry deleted"),
        onError: (err) => toast.error("Journal", getErrorMessage$1(err))
      }
    ),
    [activeAccountId, deleteJournalMutation]
  );
  const closePositionMutation = useClosePosition();
  const closeAllMutation = useCloseAllPositions();
  const cancelOrderMutation = useCancelOrder();
  const requireTradingReady = useCallback(() => {
    if (!activeAccountId) {
      toast.warning("No Account", "Select an account first");
      return null;
    }
    if (!isFeedConnected) {
      toast.warning("No Data Feed", "Cannot trade while disconnected from the data feed");
      return null;
    }
    return activeAccountId;
  }, [activeAccountId, isFeedConnected]);
  const closePosition = useCallback(
    (positionId, quantity) => {
      const accountId = requireTradingReady();
      if (!accountId || closePositionMutation.isPending) return;
      closePositionMutation.mutate(
        { positionId, accountId, ...quantity != null ? { quantity } : {} },
        {
          onSuccess: () => toast.success(
            quantity != null ? "Partial Close" : "Position Closed",
            quantity != null ? `Closed ${quantity} lot(s)` : "Position has been closed"
          ),
          onError: (err) => toast.error("Close Failed", getErrorMessage$1(err))
        }
      );
    },
    [closePositionMutation, requireTradingReady]
  );
  const closeAllPositions = useCallback(() => {
    const accountId = requireTradingReady();
    if (!accountId || closeAllMutation.isPending) return;
    closeAllMutation.mutate(accountId, {
      onSuccess: () => toast.success("Positions Closed", "All positions have been closed"),
      onError: (err) => toast.error("Close All Failed", getErrorMessage$1(err))
    });
  }, [closeAllMutation, requireTradingReady]);
  const cancelOrder = useCallback(
    (orderId) => {
      const accountId = requireTradingReady();
      if (!accountId || cancelOrderMutation.isPending) return;
      cancelOrderMutation.mutate(
        { orderId, accountId },
        {
          onSuccess: () => toast.info("Order Cancelled", "Pending order has been cancelled"),
          onError: (err) => toast.error("Cancel Failed", getErrorMessage$1(err))
        }
      );
    },
    [cancelOrderMutation, requireTradingReady]
  );
  const account = useTradingStore((s) => s.accounts.find((a) => a.id === activeAccountId));
  const liveCandleUpdates = useTradingStore((s) => s.liveCandleUpdates);
  const liveCandle = liveCandleUpdates[chartKey];
  const tick = ticks[selectedSymbol];
  const symbolInfo = symbols.find((s) => s.name === selectedSymbol);
  const pipDigits = useMemo(
    () => getPipDigits(symbolInfo, selectedSymbol),
    [symbolInfo, selectedSymbol]
  );
  const isDark = typeof document === "undefined" ? true : !document.documentElement.classList.contains("light");
  const value = {
    selectedSymbol,
    setSelectedSymbol,
    symbols,
    symbolInfo,
    pipDigits,
    tick,
    ticks,
    isDark,
    timeframe,
    setTimeframe,
    candles,
    liveCandle,
    replayCandles,
    replayTradeEvents,
    isReplaying,
    chartPrefs,
    activeIndicators,
    toggleIndicator,
    clearIndicators,
    activePlugins,
    togglePlugin,
    setPlugins,
    cycleMagnetMode,
    drawingTool,
    setDrawingTool,
    drawings,
    addDrawing,
    updateDrawing,
    removeDrawing,
    clearDrawings,
    undoDrawing,
    redoDrawing,
    activeAccountId,
    account,
    positions,
    orders,
    positionPnl,
    chartPositions,
    chartOrders,
    isFeedConnected,
    oneClick,
    toggleOneClick,
    soundMuted,
    toggleSoundMute,
    onOrderSuccess,
    requestOrderConfirmation: setConfirmOrder,
    submitOrderDirect,
    quickOrder,
    modifyPositionLevels,
    editPosition: setModifyingPosition,
    editOrder: setModifyingOrder,
    closePosition,
    closeAllPositions,
    cancelOrder,
    journalEntries: (journalData == null ? void 0 : journalData.entries) ?? [],
    journalLoading,
    createJournal,
    updateJournal,
    deleteJournal
  };
  return /* @__PURE__ */ jsxs(TerminalContext.Provider, { value, children: [
    children,
    /* @__PURE__ */ jsx(
      PositionModifyDialog,
      {
        position: modifyingPosition,
        onClose: () => setModifyingPosition(null),
        onSaved: () => setModifyingPosition(null),
        tick,
        isFeedConnected
      },
      (modifyingPosition == null ? void 0 : modifyingPosition.id) ?? "no-position"
    ),
    /* @__PURE__ */ jsx(
      OrderModifyDialog,
      {
        order: modifyingOrder,
        onClose: () => setModifyingOrder(null),
        onSaved: () => setModifyingOrder(null),
        tick
      },
      (modifyingOrder == null ? void 0 : modifyingOrder.id) ?? "no-order"
    ),
    /* @__PURE__ */ jsx(
      OrderConfirmDialog,
      {
        isOpen: !!confirmOrder,
        order: confirmOrder,
        onConfirm: () => {
          if (!(confirmOrder == null ? void 0 : confirmOrder._submit)) return;
          setConfirmLoading(true);
          confirmOrder._submit().then(() => onOrderSuccess()).catch(() => {
          }).finally(() => {
            setConfirmLoading(false);
            setConfirmOrder(null);
          });
        },
        onCancel: () => setConfirmOrder(null),
        loading: confirmLoading,
        tick,
        symbolInfo
      }
    )
  ] });
}
const LOT_PRESETS = [0.01, 0.05, 0.1, 0.25, 0.5, 1];
const TABS$1 = ["order", "positions", "alerts"];
function MobileTradingPanel({
  symbol,
  bid = 0,
  ask = 0,
  spread: spreadProp,
  accountBalance = 0,
  onPlaceOrder,
  positions,
  onClosePosition,
  onCloseAllPositions,
  closingPositionId = null,
  closingAll = false
}) {
  const { formatQty } = useInstrumentLabels();
  const spread = spreadProp ?? ask - bid;
  const [activeTab, setActiveTab] = useState("order");
  const [orderType, setOrderType] = useState("MARKET");
  const [quantity, setQuantity] = useState(0.1);
  const [limitPrice, setLimitPrice] = useState("");
  const [stopLoss, setStopLoss] = useState("");
  const [takeProfit, setTakeProfit] = useState("");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const touchStartX = useRef(0);
  const handleTouchStart = useCallback((e) => {
    touchStartX.current = e.touches[0].clientX;
  }, []);
  const handleTouchEnd = useCallback(
    (e) => {
      const dx = e.changedTouches[0].clientX - touchStartX.current;
      if (Math.abs(dx) > 60) {
        const currentIdx = TABS$1.indexOf(activeTab);
        if (dx > 0 && currentIdx > 0) {
          setActiveTab(TABS$1[currentIdx - 1]);
        } else if (dx < 0 && currentIdx < TABS$1.length - 1) {
          setActiveTab(TABS$1[currentIdx + 1]);
        }
      }
    },
    [activeTab]
  );
  const handleOrder = (side) => {
    onPlaceOrder({
      side,
      quantity,
      type: orderType,
      symbol,
      price: orderType !== "MARKET" && limitPrice ? Number(limitPrice) : void 0,
      stopLoss: stopLoss ? Number(stopLoss) : void 0,
      takeProfit: takeProfit ? Number(takeProfit) : void 0
    });
  };
  const totalPnl = positions.reduce((sum, p) => sum + (p.pnl ?? p.unrealizedPnl ?? 0), 0);
  const openPositionCount = positions.filter((p) => (p.symbol ?? p.symbolName) === symbol).length;
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "md:hidden flex flex-col bg-slate-900 border-t border-slate-700 safe-area-bottom",
      onTouchStart: handleTouchStart,
      onTouchEnd: handleTouchEnd,
      children: [
        /* @__PURE__ */ jsx("div", { className: "flex border-b border-slate-700", children: [
          { key: "order", label: "Order" },
          { key: "positions", label: `Positions (${positions.length})` },
          { key: "alerts", label: "Alerts" }
        ].map((tab) => /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => setActiveTab(tab.key),
            className: cn(
              "flex-1 py-3 text-xs font-semibold uppercase tracking-wider transition",
              activeTab === tab.key ? "text-violet-400 border-b-2 border-violet-500" : "text-slate-500"
            ),
            children: tab.label
          },
          tab.key
        )) }),
        activeTab === "order" && /* @__PURE__ */ jsxs("div", { className: "p-3 space-y-3", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsx("span", { className: "text-sm font-bold text-white", children: symbol }),
            /* @__PURE__ */ jsxs("span", { className: "text-xs text-slate-500", children: [
              "Spread: ",
              /* @__PURE__ */ jsxs("span", { className: "text-amber-400", children: [
                spread.toFixed(1),
                " pts"
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex gap-1.5", children: ["MARKET", "LIMIT", "STOP"].map((t) => /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => setOrderType(t),
              className: cn(
                "flex-1 py-2 rounded-lg text-xs font-medium transition",
                orderType === t ? "bg-violet-600 text-white" : "bg-slate-800 text-slate-400"
              ),
              children: t
            },
            t
          )) }),
          orderType !== "MARKET" && /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("label", { className: "text-xs text-slate-400 mb-1 block", children: orderType === "LIMIT" ? "Limit Price" : "Stop Price" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                step: "any",
                value: limitPrice,
                onChange: (e) => setLimitPrice(e.target.value),
                placeholder: bid.toFixed(5),
                className: "w-full px-3 py-2.5 bg-slate-800 border border-slate-600 rounded-lg text-white text-sm font-mono text-center focus:ring-2 focus:ring-violet-500"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsxs("label", { className: "text-xs text-slate-400 mb-1.5 block", children: [
              "Lot Size: ",
              /* @__PURE__ */ jsx("span", { className: "text-white font-mono", children: quantity })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "grid grid-cols-3 min-[400px]:grid-cols-6 gap-1.5", children: LOT_PRESETS.map((lot) => /* @__PURE__ */ jsx(
              "button",
              {
                onClick: () => setQuantity(lot),
                className: cn(
                  "py-2.5 rounded-lg text-xs font-mono font-medium transition active:scale-95",
                  quantity === lot ? "bg-violet-600 text-white ring-1 ring-violet-400" : "bg-slate-800 text-slate-300"
                ),
                children: lot
              },
              lot
            )) }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                step: "0.01",
                min: "0.01",
                value: quantity,
                onChange: (e) => setQuantity(Number(e.target.value) || 0.01),
                className: "w-full mt-2 px-3 py-2 bg-slate-800 border border-slate-600 rounded-lg text-white text-sm font-mono text-center focus:ring-2 focus:ring-violet-500"
              }
            )
          ] }),
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => setShowAdvanced(!showAdvanced),
              className: "w-full text-xs text-slate-500 hover:text-slate-300 py-1 transition",
              children: showAdvanced ? "▾ Hide SL/TP" : "▸ Set Stop Loss / Take Profit"
            }
          ),
          showAdvanced && /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-2", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "text-xs text-red-400 mb-1 block", children: "Stop Loss" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "number",
                  step: "any",
                  value: stopLoss,
                  onChange: (e) => setStopLoss(e.target.value),
                  placeholder: "Optional",
                  className: "w-full px-2 py-2 bg-slate-800 border border-red-500/30 rounded-lg text-white text-xs font-mono text-center focus:ring-2 focus:ring-red-500"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("label", { className: "text-xs text-emerald-400 mb-1 block", children: "Take Profit" }),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "number",
                  step: "any",
                  value: takeProfit,
                  onChange: (e) => setTakeProfit(e.target.value),
                  placeholder: "Optional",
                  className: "w-full px-2 py-2 bg-slate-800 border border-emerald-500/30 rounded-lg text-white text-xs font-mono text-center focus:ring-2 focus:ring-emerald-500"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-2", children: [
            /* @__PURE__ */ jsxs(
              "button",
              {
                onClick: () => handleOrder("SELL"),
                className: "py-4 rounded-xl bg-red-600 hover:bg-red-500 active:bg-red-700 active:scale-[0.98] text-white font-bold transition-all",
                children: [
                  /* @__PURE__ */ jsx("div", { className: "text-lg", children: "SELL" }),
                  /* @__PURE__ */ jsx("div", { className: "text-xs font-mono opacity-80", children: bid.toFixed(5) })
                ]
              }
            ),
            /* @__PURE__ */ jsxs(
              "button",
              {
                onClick: () => handleOrder("BUY"),
                className: "py-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 active:scale-[0.98] text-white font-bold transition-all",
                children: [
                  /* @__PURE__ */ jsx("div", { className: "text-lg", children: "BUY" }),
                  /* @__PURE__ */ jsx("div", { className: "text-xs font-mono opacity-80", children: ask.toFixed(5) })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between text-xs text-slate-500 pt-1", children: [
            /* @__PURE__ */ jsxs("span", { children: [
              "Balance: $",
              accountBalance.toLocaleString(void 0, { maximumFractionDigits: 2 })
            ] }),
            /* @__PURE__ */ jsxs("span", { children: [
              "Open: ",
              openPositionCount,
              " pos"
            ] })
          ] })
        ] }),
        activeTab === "positions" && /* @__PURE__ */ jsx("div", { className: "p-3 space-y-2 max-h-[50vh] overflow-y-auto", children: positions.length === 0 ? /* @__PURE__ */ jsx("div", { className: "text-center py-8 text-slate-500 text-sm", children: "No open positions" }) : /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between bg-slate-800/60 rounded-lg p-2.5", children: [
            /* @__PURE__ */ jsxs("span", { className: "text-xs text-slate-400", children: [
              "Total P&L (",
              positions.length,
              " positions)"
            ] }),
            /* @__PURE__ */ jsxs(
              "span",
              {
                className: cn(
                  "font-mono font-bold text-sm",
                  totalPnl >= 0 ? "text-emerald-400" : "text-red-400"
                ),
                children: [
                  totalPnl >= 0 ? "+" : "",
                  "$",
                  totalPnl.toFixed(2)
                ]
              }
            )
          ] }),
          positions.map((pos) => {
            var _a;
            const posSymbol = pos.symbol ?? pos.symbolName ?? "";
            const posSide = pos.side === "LONG" ? "BUY" : pos.side === "SHORT" ? "SELL" : pos.side;
            const posPnl = pos.pnl ?? pos.unrealizedPnl ?? 0;
            return /* @__PURE__ */ jsxs(
              "div",
              {
                className: "bg-slate-800/40 border border-slate-700 rounded-xl p-3",
                children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-1", children: [
                    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsx(
                        "span",
                        {
                          className: cn(
                            "px-1.5 py-0.5 rounded text-xs font-bold",
                            posSide === "BUY" ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"
                          ),
                          children: posSide
                        }
                      ),
                      /* @__PURE__ */ jsx("span", { className: "text-sm font-medium text-white", children: posSymbol }),
                      /* @__PURE__ */ jsx("span", { className: "text-xs text-slate-500", children: formatQty(pos.quantity ?? 0) })
                    ] }),
                    /* @__PURE__ */ jsxs(
                      "span",
                      {
                        className: cn(
                          "font-mono text-sm font-bold",
                          posPnl >= 0 ? "text-emerald-400" : "text-red-400"
                        ),
                        children: [
                          posPnl >= 0 ? "+" : "",
                          "$",
                          posPnl.toFixed(2)
                        ]
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxs("span", { className: "text-xs text-slate-500 font-mono", children: [
                      "Entry: ",
                      ((_a = pos.entryPrice) == null ? void 0 : _a.toFixed(5)) ?? "—"
                    ] }),
                    onClosePosition && /* @__PURE__ */ jsx(
                      "button",
                      {
                        onClick: () => onClosePosition(pos.id),
                        disabled: closingPositionId === pos.id || closingAll,
                        className: cn(
                          "px-3 py-1.5 rounded-lg text-xs font-medium transition active:scale-95",
                          closingPositionId === pos.id ? "bg-slate-700/50 text-slate-500 cursor-not-allowed" : "bg-slate-700 hover:bg-red-600/40 active:bg-red-600/60 text-slate-300 hover:text-white"
                        ),
                        children: closingPositionId === pos.id ? "Closing…" : "Close"
                      }
                    )
                  ] })
                ]
              },
              pos.id
            );
          }),
          positions.length > 1 && onCloseAllPositions && /* @__PURE__ */ jsx(
            "button",
            {
              onClick: onCloseAllPositions,
              disabled: closingAll,
              className: cn(
                "w-full py-3 rounded-xl text-sm font-semibold transition active:scale-[0.98]",
                closingAll ? "bg-slate-700/30 text-slate-500 cursor-not-allowed" : "bg-red-600/20 hover:bg-red-600/30 active:bg-red-600/40 text-red-400"
              ),
              children: closingAll ? "Closing All…" : "Close All Positions"
            }
          )
        ] }) }),
        activeTab === "alerts" && /* @__PURE__ */ jsx("div", { className: "p-3 space-y-3", children: /* @__PURE__ */ jsxs("div", { className: "text-center py-8", children: [
          /* @__PURE__ */ jsx("p", { className: "text-slate-500 text-sm", children: "Price alerts coming soon" }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-slate-600 mt-1", children: "Set alerts for price levels and get push notifications" })
        ] }) })
      ]
    }
  );
}
function MobileAccountBar({
  balance,
  equity,
  margin,
  pnl
}) {
  return /* @__PURE__ */ jsxs("div", { className: "md:hidden flex items-center gap-2 px-2 py-1 bg-slate-800/80 border-b border-slate-700 overflow-x-auto no-scrollbar", children: [
    /* @__PURE__ */ jsxs("div", { className: "shrink-0", children: [
      /* @__PURE__ */ jsx("div", { className: "text-[9px] text-slate-500 uppercase", children: "Bal" }),
      /* @__PURE__ */ jsxs("div", { className: "text-[11px] font-mono font-bold text-white", children: [
        "$",
        balance.toLocaleString(void 0, { maximumFractionDigits: 0 })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "w-px h-5 bg-slate-700 shrink-0" }),
    /* @__PURE__ */ jsxs("div", { className: "shrink-0", children: [
      /* @__PURE__ */ jsx("div", { className: "text-[9px] text-slate-500 uppercase", children: "Equity" }),
      /* @__PURE__ */ jsxs("div", { className: "text-[11px] font-mono font-bold text-white", children: [
        "$",
        equity.toLocaleString(void 0, { maximumFractionDigits: 0 })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "w-px h-5 bg-slate-700 shrink-0" }),
    /* @__PURE__ */ jsxs("div", { className: "shrink-0", children: [
      /* @__PURE__ */ jsx("div", { className: "text-[9px] text-slate-500 uppercase", children: "Margin" }),
      /* @__PURE__ */ jsxs("div", { className: "text-[11px] font-mono font-bold text-slate-300", children: [
        "$",
        margin.toLocaleString(void 0, { maximumFractionDigits: 0 })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "w-px h-5 bg-slate-700 shrink-0" }),
    /* @__PURE__ */ jsxs("div", { className: "shrink-0", children: [
      /* @__PURE__ */ jsx("div", { className: "text-[9px] text-slate-500 uppercase", children: "P&L" }),
      /* @__PURE__ */ jsxs(
        "div",
        {
          className: cn(
            "text-[11px] font-mono font-bold",
            pnl >= 0 ? "text-emerald-400" : "text-red-400"
          ),
          children: [
            pnl >= 0 ? "+" : "",
            "$",
            pnl.toFixed(2)
          ]
        }
      )
    ] })
  ] });
}
const SAMPLE_HEADLINES = [
  { id: 1, title: "Central bank rate decision ahead", impact: "HIGH", time: "2h ago" },
  { id: 2, title: "Employment data exceeds expectations", impact: "MEDIUM", time: "4h ago" },
  { id: 3, title: "Price approaching a widely-watched level", impact: "LOW", time: "6h ago" },
  { id: 4, title: "Risk appetite improves across majors", impact: "MEDIUM", time: "8h ago" },
  { id: 5, title: "Volatility expected ahead of the next print", impact: "HIGH", time: "12h ago" }
];
const IMPACT_COLORS = {
  HIGH: "bg-red-500/10 text-red-500",
  MEDIUM: "bg-yellow-500/10 text-yellow-500",
  LOW: "bg-green-500/10 text-green-500"
};
function NewsFeed$1({ symbol }) {
  return /* @__PURE__ */ jsxs(Card, { children: [
    /* @__PURE__ */ jsx(CardHeader, { className: "p-3 pb-0", children: /* @__PURE__ */ jsxs(CardTitle, { className: "text-sm flex items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(Globe, { className: "h-4 w-4 text-accent" }),
        " Market News"
      ] }),
      /* @__PURE__ */ jsx("span", { className: "text-[9px] font-medium uppercase tracking-wide px-1.5 py-0.5 rounded bg-muted text-muted-foreground", children: "Sample data" })
    ] }) }),
    /* @__PURE__ */ jsxs(CardContent, { className: "p-3 pt-2 space-y-2", children: [
      /* @__PURE__ */ jsxs("p", { className: "text-[10px] text-muted-foreground", children: [
        "Placeholder items for ",
        symbol,
        " — connect a news provider to make this live."
      ] }),
      SAMPLE_HEADLINES.map((item) => /* @__PURE__ */ jsxs(
        "div",
        {
          className: "flex items-start gap-2 py-1.5 border-b border-border/30 last:border-0",
          children: [
            /* @__PURE__ */ jsxs("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsx("p", { className: "text-xs font-medium leading-tight line-clamp-2", children: item.title }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 mt-1", children: [
                /* @__PURE__ */ jsx("span", { className: "text-[10px] text-muted-foreground", children: "Sample" }),
                /* @__PURE__ */ jsxs("span", { className: "text-[10px] text-muted-foreground flex items-center gap-0.5", children: [
                  /* @__PURE__ */ jsx(Clock, { className: "h-2.5 w-2.5" }),
                  " ",
                  item.time
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsx(
              "span",
              {
                className: cn(
                  "text-[9px] font-medium px-1.5 py-0.5 rounded shrink-0",
                  IMPACT_COLORS[item.impact]
                ),
                children: item.impact
              }
            )
          ]
        },
        item.id
      ))
    ] })
  ] });
}
function safeClear(container) {
  try {
    container.innerHTML = "";
  } catch (err) {
    if (!(err instanceof DOMException)) throw err;
  }
}
const TV_SYMBOL_MAP = {
  EURUSD: "FX:EURUSD",
  GBPUSD: "FX:GBPUSD",
  USDJPY: "FX:USDJPY",
  USDCHF: "FX:USDCHF",
  AUDUSD: "FX:AUDUSD",
  NZDUSD: "FX:NZDUSD",
  USDCAD: "FX:USDCAD",
  EURGBP: "FX:EURGBP",
  EURJPY: "FX:EURJPY",
  GBPJPY: "FX:GBPJPY",
  EURCHF: "FX:EURCHF",
  EURAUD: "FX:EURAUD",
  AUDNZD: "FX:AUDNZD",
  AUDCAD: "FX:AUDCAD",
  AUDCHF: "FX:AUDCHF",
  AUDJPY: "FX:AUDJPY",
  CADJPY: "FX:CADJPY",
  CHFJPY: "FX:CHFJPY",
  NZDJPY: "FX:NZDJPY",
  GBPCHF: "FX:GBPCHF",
  GBPCAD: "FX:GBPCAD",
  GBPAUD: "FX:GBPAUD",
  GBPNZD: "FX:GBPNZD",
  EURNZD: "FX:EURNZD",
  EURCAD: "FX:EURCAD",
  NZDCAD: "FX:NZDCAD",
  CADCHF: "FX:CADCHF",
  NZDCHF: "FX:NZDCHF",
  XAUUSD: "TVC:GOLD",
  XAGUSD: "TVC:SILVER",
  US30: "TVC:DJI",
  SPX500: "FOREXCOM:SPXUSD",
  NAS100: "NASDAQ:NDX",
  DAX40: "XETR:DAX",
  UK100: "TVC:UKX",
  JP225: "TVC:NI225",
  BTCUSD: "COINBASE:BTCUSD",
  ETHUSD: "COINBASE:ETHUSD",
  XTIUSD: "TVC:USOIL",
  XBRUSD: "TVC:UKOIL",
  USOIL: "TVC:USOIL",
  UKOIL: "TVC:UKOIL",
  // CME equity index futures (front-month continuous contracts)
  ES: "CME_MINI:ES1!",
  MES: "CME_MINI:MES1!",
  NQ: "CME_MINI:NQ1!",
  MNQ: "CME_MINI:MNQ1!",
  RTY: "CME_MINI:RTY1!",
  M2K: "CME_MINI:M2K1!",
  YM: "CBOT_MINI:YM1!",
  MYM: "CBOT_MINI:MYM1!",
  // NYMEX / COMEX commodity futures
  CL: "NYMEX:CL1!",
  MCL: "NYMEX:MCL1!",
  GC: "COMEX:GC1!",
  MGC: "COMEX:MGC1!",
  // CBOT treasury futures
  ZB: "CBOT:ZB1!",
  // CME FX futures
  "6E": "CME:6E1!"
};
const TV_TECHNICAL_INTERVAL_MAP = {
  "1m": "1m",
  "5m": "5m",
  "15m": "15m",
  "30m": "30m",
  "1h": "1h",
  "4h": "4h",
  "1d": "1D",
  "1w": "1W"
};
function mapSymbol(symbol) {
  if (TV_SYMBOL_MAP[symbol]) return TV_SYMBOL_MAP[symbol];
  if (/^[A-Z]{6}$/.test(symbol)) return `FX:${symbol}`;
  return symbol;
}
const TICKER_TAPE_DEFAULT_SYMBOLS = [
  { proName: "FX:EURUSD", title: "EUR/USD" },
  { proName: "FX:GBPUSD", title: "GBP/USD" },
  { proName: "FX:USDJPY", title: "USD/JPY" },
  { proName: "TVC:GOLD", title: "Gold" },
  { proName: "COINBASE:BTCUSD", title: "BTC/USD" },
  { proName: "TVC:DJI", title: "Dow 30" },
  { proName: "NASDAQ:NDX", title: "Nasdaq" },
  { proName: "TVC:USOIL", title: "US Oil" }
];
memo(function TradingViewTickerTape2({
  symbols,
  theme,
  className = ""
}) {
  const containerRef = useRef(null);
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    safeClear(container);
    const widgetDiv = document.createElement("div");
    widgetDiv.className = "tradingview-widget-container__widget";
    container.appendChild(widgetDiv);
    const config = {
      symbols: symbols ?? TICKER_TAPE_DEFAULT_SYMBOLS,
      showSymbolLogo: true,
      isTransparent: true,
      displayMode: "adaptive",
      colorTheme: theme,
      locale: "en"
    };
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js";
    script.type = "text/javascript";
    script.async = true;
    script.textContent = JSON.stringify(config);
    container.appendChild(script);
    return () => {
      safeClear(container);
    };
  }, [symbols, theme]);
  return /* @__PURE__ */ jsx("div", { ref: containerRef, className: `tradingview-widget-container ${className}` });
});
const TradingViewTechnicalAnalysis = memo(function TradingViewTechnicalAnalysis2({
  symbol,
  theme,
  interval = "1h",
  width = "100%",
  height = 400,
  className = ""
}) {
  const containerRef = useRef(null);
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    safeClear(container);
    const widgetDiv = document.createElement("div");
    widgetDiv.className = "tradingview-widget-container__widget";
    widgetDiv.style.height = "100%";
    widgetDiv.style.width = "100%";
    container.appendChild(widgetDiv);
    const config = {
      interval: TV_TECHNICAL_INTERVAL_MAP[interval] ?? "1h",
      width: typeof width === "number" ? width : "100%",
      height: typeof height === "number" ? height : "100%",
      isTransparent: true,
      symbol: mapSymbol(symbol),
      showIntervalTabs: true,
      displayMode: "single",
      locale: "en",
      colorTheme: theme
    };
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-technical-analysis.js";
    script.type = "text/javascript";
    script.async = true;
    script.textContent = JSON.stringify(config);
    container.appendChild(script);
    return () => {
      safeClear(container);
    };
  }, [symbol, theme, interval, width, height]);
  return /* @__PURE__ */ jsx(
    "div",
    {
      ref: containerRef,
      className: `tradingview-widget-container ${className}`,
      style: {
        height: typeof height === "number" ? `${height}px` : height,
        width: typeof width === "number" ? `${width}px` : width
      }
    }
  );
});
const TradingViewEconomicCalendar = memo(function TradingViewEconomicCalendar2({
  theme,
  width = "100%",
  height = 400,
  className = ""
}) {
  const containerRef = useRef(null);
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    safeClear(container);
    const widgetDiv = document.createElement("div");
    widgetDiv.className = "tradingview-widget-container__widget";
    widgetDiv.style.height = "100%";
    widgetDiv.style.width = "100%";
    container.appendChild(widgetDiv);
    const config = {
      width: typeof width === "number" ? width : "100%",
      height: typeof height === "number" ? height : "100%",
      colorTheme: theme,
      isTransparent: true,
      locale: "en",
      importanceFilter: "-1,0,1",
      countryFilter: "ar,au,br,ca,cn,fr,de,in,id,it,jp,kr,mx,ru,sa,za,tr,gb,us,eu"
    };
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-events.js";
    script.type = "text/javascript";
    script.async = true;
    script.textContent = JSON.stringify(config);
    container.appendChild(script);
    return () => {
      safeClear(container);
    };
  }, [theme, width, height]);
  return /* @__PURE__ */ jsx(
    "div",
    {
      ref: containerRef,
      className: `tradingview-widget-container ${className}`,
      style: {
        height: typeof height === "number" ? `${height}px` : height,
        width: typeof width === "number" ? `${width}px` : width
      }
    }
  );
});
memo(function TradingViewMiniChart2({
  symbol,
  theme,
  width = "100%",
  height = 220,
  className = ""
}) {
  const containerRef = useRef(null);
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    safeClear(container);
    const widgetDiv = document.createElement("div");
    widgetDiv.className = "tradingview-widget-container__widget";
    widgetDiv.style.height = "100%";
    widgetDiv.style.width = "100%";
    container.appendChild(widgetDiv);
    const config = {
      symbol: mapSymbol(symbol),
      width: typeof width === "number" ? width : "100%",
      height: typeof height === "number" ? height : "100%",
      locale: "en",
      dateRange: "1D",
      colorTheme: theme,
      isTransparent: true,
      autosize: typeof width === "string" && typeof height === "string",
      largeChartUrl: ""
    };
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-mini-symbol-overview.js";
    script.type = "text/javascript";
    script.async = true;
    script.textContent = JSON.stringify(config);
    container.appendChild(script);
    return () => {
      safeClear(container);
    };
  }, [symbol, theme, width, height]);
  return /* @__PURE__ */ jsx(
    "div",
    {
      ref: containerRef,
      className: `tradingview-widget-container ${className}`,
      style: {
        height: typeof height === "number" ? `${height}px` : height,
        width: typeof width === "number" ? `${width}px` : width
      }
    }
  );
});
function PositionsTable({
  positions,
  onClose,
  onModify,
  onPartialClose,
  onSelectSymbol
}) {
  const [partialCloseId, setPartialCloseId] = useState(null);
  const [partialQty, setPartialQty] = useState("");
  if (positions.length === 0) {
    return /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center h-full text-muted-foreground text-xs", children: "No open positions" });
  }
  const handlePartialSubmit = (positionId, maxQty) => {
    const qty = parseFloat(partialQty);
    if (!Number.isFinite(qty) || qty <= 0) {
      toast.warning("Invalid Quantity", "Enter a positive quantity to close");
      return;
    }
    if (qty >= maxQty) {
      toast.warning(
        "Quantity Too Large",
        `Enter less than ${maxQty} — use Close to exit the whole position`
      );
      return;
    }
    onPartialClose == null ? void 0 : onPartialClose(positionId, qty);
    setPartialCloseId(null);
    setPartialQty("");
  };
  return /* @__PURE__ */ jsxs("table", { className: "w-full text-[11px]", children: [
    /* @__PURE__ */ jsx("thead", { className: "sticky top-0 bg-card z-10", children: /* @__PURE__ */ jsxs("tr", { children: [
      /* @__PURE__ */ jsx("th", { children: "Symbol" }),
      /* @__PURE__ */ jsx("th", { children: "Side" }),
      /* @__PURE__ */ jsx("th", { children: "Qty" }),
      /* @__PURE__ */ jsx("th", { children: "Entry" }),
      /* @__PURE__ */ jsx("th", { children: "Current" }),
      /* @__PURE__ */ jsx("th", { children: "P&L" }),
      /* @__PURE__ */ jsx("th", { children: "SL" }),
      /* @__PURE__ */ jsx("th", { children: "TP" }),
      /* @__PURE__ */ jsx("th", { children: "Time" }),
      /* @__PURE__ */ jsx("th", {})
    ] }) }),
    /* @__PURE__ */ jsx("tbody", { children: positions.map((p) => /* @__PURE__ */ jsxs(
      "tr",
      {
        className: cn("hover:bg-secondary/30", onSelectSymbol ? "cursor-pointer" : void 0),
        onClick: () => onSelectSymbol == null ? void 0 : onSelectSymbol(p.symbolName),
        onKeyDown: (e) => {
          if (!onSelectSymbol) return;
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            onSelectSymbol(p.symbolName);
          }
        },
        tabIndex: onSelectSymbol ? 0 : void 0,
        children: [
          /* @__PURE__ */ jsx("td", { className: "font-semibold", children: p.symbolName }),
          /* @__PURE__ */ jsx("td", { className: p.side === "LONG" ? "text-buy" : "text-sell", children: p.side }),
          /* @__PURE__ */ jsx("td", { className: "font-mono", children: p.quantity }),
          /* @__PURE__ */ jsx("td", { className: "font-mono", children: formatNumber(p.entryPrice, 5) }),
          /* @__PURE__ */ jsx("td", { className: "font-mono", children: p.currentPrice ? formatNumber(p.currentPrice, 5) : "--" }),
          /* @__PURE__ */ jsxs("td", { className: cn("font-mono font-semibold", pnlClass(p.unrealizedPnl)), children: [
            p.unrealizedPnl >= 0 ? "+" : "",
            formatCurrency(p.unrealizedPnl)
          ] }),
          /* @__PURE__ */ jsx("td", { className: "font-mono text-sell", children: p.stopLoss ? formatNumber(p.stopLoss, 5) : "--" }),
          /* @__PURE__ */ jsx("td", { className: "font-mono text-buy", children: p.takeProfit ? formatNumber(p.takeProfit, 5) : "--" }),
          /* @__PURE__ */ jsx("td", { className: "text-muted-foreground", children: formatDate(p.openedAt) }),
          /* @__PURE__ */ jsx("td", { children: partialCloseId === p.id ? /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "number",
                value: partialQty,
                onChange: (e) => setPartialQty(e.target.value),
                onClick: (e) => e.stopPropagation(),
                placeholder: `Max ${p.quantity}`,
                min: 0.01,
                max: p.quantity - 0.01,
                step: "any",
                className: "w-16 h-5 text-[10px] rounded border border-border bg-background px-1 font-mono",
                autoFocus: true,
                onKeyDown: (e) => {
                  if (e.key === "Enter") handlePartialSubmit(p.id, p.quantity);
                  if (e.key === "Escape") {
                    setPartialCloseId(null);
                    setPartialQty("");
                  }
                }
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: (e) => {
                  e.stopPropagation();
                  handlePartialSubmit(p.id, p.quantity);
                },
                className: "px-1 py-0.5 text-[9px] rounded bg-warning/20 text-warning hover:bg-warning/30",
                children: "Go"
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: (e) => {
                  e.stopPropagation();
                  setPartialCloseId(null);
                  setPartialQty("");
                },
                className: "px-1 py-0.5 text-[9px] rounded bg-secondary text-muted-foreground hover:bg-secondary/80",
                children: /* @__PURE__ */ jsx(X, { className: "h-2.5 w-2.5" })
              }
            )
          ] }) : /* @__PURE__ */ jsxs("div", { className: "flex gap-1", children: [
            onModify && /* @__PURE__ */ jsx(
              "button",
              {
                onClick: (e) => {
                  e.stopPropagation();
                  onModify(p);
                },
                className: "px-1.5 py-0.5 text-[10px] rounded bg-accent/20 text-accent hover:bg-accent/30",
                children: "Modify"
              }
            ),
            onPartialClose && p.quantity > 1 && /* @__PURE__ */ jsxs(
              "button",
              {
                onClick: (e) => {
                  e.stopPropagation();
                  setPartialCloseId(p.id);
                  setPartialQty("");
                },
                className: "px-1.5 py-0.5 text-[10px] rounded bg-warning/20 text-warning hover:bg-warning/30 flex items-center gap-0.5",
                title: "Partial Close",
                children: [
                  /* @__PURE__ */ jsx(Scissors, { className: "h-2.5 w-2.5" }),
                  " Partial"
                ]
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: (e) => {
                  e.stopPropagation();
                  onClose(p.id);
                },
                className: "px-1.5 py-0.5 text-[10px] rounded bg-destructive/20 text-destructive hover:bg-destructive/30",
                children: "Close"
              }
            )
          ] }) })
        ]
      },
      p.id
    )) })
  ] });
}
function OrdersTable({
  orders,
  onCancel,
  onModify,
  onSelectSymbol
}) {
  if (orders.length === 0) {
    return /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center h-full text-muted-foreground text-xs", children: "No pending orders" });
  }
  return /* @__PURE__ */ jsxs("table", { className: "w-full text-[11px]", children: [
    /* @__PURE__ */ jsx("thead", { className: "sticky top-0 bg-card z-10", children: /* @__PURE__ */ jsxs("tr", { children: [
      /* @__PURE__ */ jsx("th", { children: "Symbol" }),
      /* @__PURE__ */ jsx("th", { children: "Side" }),
      /* @__PURE__ */ jsx("th", { children: "Type" }),
      /* @__PURE__ */ jsx("th", { children: "Qty" }),
      /* @__PURE__ */ jsx("th", { children: "Price" }),
      /* @__PURE__ */ jsx("th", { children: "SL" }),
      /* @__PURE__ */ jsx("th", { children: "TP" }),
      /* @__PURE__ */ jsx("th", { children: "Status" }),
      /* @__PURE__ */ jsx("th", { children: "Time" }),
      /* @__PURE__ */ jsx("th", {})
    ] }) }),
    /* @__PURE__ */ jsx("tbody", { children: orders.map((o) => /* @__PURE__ */ jsxs(
      "tr",
      {
        className: onSelectSymbol ? "hover:bg-secondary/30 cursor-pointer" : "hover:bg-secondary/30",
        onClick: () => onSelectSymbol == null ? void 0 : onSelectSymbol(o.symbolName),
        onKeyDown: (e) => {
          if (!onSelectSymbol) return;
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            onSelectSymbol(o.symbolName);
          }
        },
        tabIndex: onSelectSymbol ? 0 : void 0,
        children: [
          /* @__PURE__ */ jsx("td", { className: "font-semibold", children: o.symbolName }),
          /* @__PURE__ */ jsx("td", { className: o.side === "BUY" ? "text-buy" : "text-sell", children: o.side }),
          /* @__PURE__ */ jsx("td", { children: o.type }),
          /* @__PURE__ */ jsx("td", { className: "font-mono", children: o.quantity }),
          /* @__PURE__ */ jsx("td", { className: "font-mono", children: o.price ? formatNumber(o.price, 5) : o.stopPrice ? formatNumber(o.stopPrice, 5) : "MKT" }),
          /* @__PURE__ */ jsx("td", { className: "font-mono text-sell", children: o.stopLoss ? formatNumber(o.stopLoss, 5) : "--" }),
          /* @__PURE__ */ jsx("td", { className: "font-mono text-buy", children: o.takeProfit ? formatNumber(o.takeProfit, 5) : "--" }),
          /* @__PURE__ */ jsx("td", { children: o.status }),
          /* @__PURE__ */ jsx("td", { className: "text-muted-foreground", children: formatDate(o.createdAt) }),
          /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsxs("div", { className: "flex gap-1", children: [
            onModify && /* @__PURE__ */ jsx(
              "button",
              {
                onClick: (e) => {
                  e.stopPropagation();
                  onModify(o);
                },
                className: "px-1.5 py-0.5 text-[10px] rounded bg-accent/20 text-accent hover:bg-accent/30",
                children: "Modify"
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: (e) => {
                  e.stopPropagation();
                  onCancel(o.id);
                },
                className: "px-1.5 py-0.5 text-[10px] rounded bg-warning/20 text-warning hover:bg-warning/30",
                children: "Cancel"
              }
            )
          ] }) })
        ]
      },
      o.id
    )) })
  ] });
}
function computeLivePnl(p, tick) {
  if (!tick) return p.unrealizedPnl;
  const livePrice = p.side === "LONG" ? tick.bid : tick.ask;
  const snapPrice = p.currentPrice ?? p.entryPrice;
  const snapDelta = snapPrice - p.entryPrice;
  if (Math.abs(snapDelta) < 1e-12) {
    const contractSize = p.contractSize ?? 1;
    const direction = p.side === "LONG" ? 1 : -1;
    return (livePrice - p.entryPrice) * p.quantity * contractSize * direction;
  }
  const perPriceUnit = p.unrealizedPnl / snapDelta;
  return perPriceUnit * (livePrice - p.entryPrice);
}
function computeLivePrice(p, tick) {
  if (!tick) return p.currentPrice ?? p.entryPrice;
  return p.side === "LONG" ? tick.bid : tick.ask;
}
function getErrorMessage(error) {
  var _a;
  const actionError = error;
  return ((_a = actionError.error) == null ? void 0 : _a.message) || actionError.message || "Request failed";
}
function BottomPanel({
  tab,
  onTabChange,
  positions,
  orders,
  accountId,
  onModifyPosition,
  onModifyOrder,
  onSelectPositionSymbol,
  onSelectOrderSymbol,
  journalEntries,
  journalLoading,
  onCreateJournal,
  onUpdateJournal,
  onDeleteJournal,
  height = 220,
  isFeedConnected = true
}) {
  const isDemo = useAuthStore((s) => s.isDemo);
  const cancelOrder = useCancelOrder();
  const closePosition = useClosePosition();
  const closeAllPositions = useCloseAllPositions();
  const accounts = useTradingStore((s) => s.accounts);
  const activeAccount = accounts.find((account) => account.id === accountId);
  const handleCancel = (orderId) => {
    if (!accountId || isDemo) {
      if (isDemo) toast.warning("Demo Mode", "Trading actions are disabled in demo mode");
      return;
    }
    if (!isFeedConnected) {
      toast.warning("No Data Feed", "Cannot cancel orders while disconnected");
      return;
    }
    if (cancelOrder.isPending) return;
    cancelOrder.mutate(
      { orderId, accountId },
      {
        onSuccess: () => toast.info("Order Cancelled", "Pending order has been cancelled"),
        onError: (err) => toast.error("Cancel Failed", getErrorMessage(err))
      }
    );
  };
  const handleClosePosition = (positionId) => {
    if (!accountId || isDemo) {
      if (isDemo) toast.warning("Demo Mode", "Trading actions are disabled in demo mode");
      return;
    }
    if (!isFeedConnected) {
      toast.warning("No Data Feed", "Cannot close positions while disconnected");
      return;
    }
    if (closePosition.isPending) return;
    closePosition.mutate(
      { positionId, accountId },
      {
        onSuccess: () => toast.success("Position Closed", "Position has been closed"),
        onError: (err) => toast.error("Close Failed", getErrorMessage(err))
      }
    );
  };
  const handlePartialClose = (positionId, quantity) => {
    if (!accountId || isDemo) {
      if (isDemo) toast.warning("Demo Mode", "Trading actions are disabled in demo mode");
      return;
    }
    if (!isFeedConnected) {
      toast.warning("No Data Feed", "Cannot close positions while disconnected");
      return;
    }
    if (closePosition.isPending) return;
    closePosition.mutate(
      { positionId, accountId, quantity },
      {
        onSuccess: () => toast.success("Partial Close", `Closed ${quantity} lot(s) of the position`),
        onError: (err) => toast.error("Partial Close Failed", getErrorMessage(err))
      }
    );
  };
  const handleCloseAll = () => {
    if (!accountId || isDemo) {
      if (isDemo) toast.warning("Demo Mode", "Trading actions are disabled in demo mode");
      return;
    }
    if (!isFeedConnected) {
      toast.warning("No Data Feed", "Cannot close positions while disconnected");
      return;
    }
    closeAllPositions.mutate(accountId, {
      onSuccess: () => toast.success("All Closed", "All positions have been closed"),
      onError: (err) => toast.error("Close All Failed", getErrorMessage(err))
    });
  };
  const ticks = useTradingStore((s) => s.ticks);
  const openPositions = positions.filter((position) => position.quantity > 0).map((p) => {
    const tick = ticks[p.symbolName];
    if (!tick) return p;
    return {
      ...p,
      currentPrice: computeLivePrice(p, tick),
      unrealizedPnl: computeLivePnl(p, tick)
    };
  });
  const pendingOrders = orders.filter(
    (order) => order.status === "PENDING" || order.status === "NEW"
  );
  const totalPnl = openPositions.reduce((sum, position) => sum + (position.unrealizedPnl || 0), 0);
  const tabs = [
    { key: "positions", label: "Positions", icon: TrendingUp, count: openPositions.length },
    { key: "orders", label: "Orders", icon: Clock, count: pendingOrders.length },
    { key: "history", label: "Trade History", icon: History },
    { key: "journal", label: "Journal", icon: BookOpen, count: journalEntries.length },
    { key: "calendar", label: "Calendar", icon: Globe },
    { key: "news", label: "News", icon: Newspaper }
  ];
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "border-t border-border flex flex-col shrink-0 bg-card max-h-[150px] md:max-h-none",
      style: { height },
      children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-0.5 px-2 py-1 border-b border-border bg-secondary text-xs overflow-x-auto no-scrollbar", children: [
          tabs.map((t) => /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: () => onTabChange(t.key),
              className: cn(
                "flex items-center gap-1 px-2.5 py-1 rounded shrink-0 whitespace-nowrap",
                tab === t.key ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              ),
              children: [
                /* @__PURE__ */ jsx(t.icon, { className: "h-3 w-3" }),
                /* @__PURE__ */ jsx("span", { className: "hidden md:inline", children: t.label }),
                t.count !== void 0 && t.count > 0 && /* @__PURE__ */ jsx("span", { className: "bg-primary text-primary-foreground rounded-full px-1.5 text-[9px]", children: t.count })
              ]
            },
            t.key
          )),
          tab === "positions" && openPositions.length > 0 && /* @__PURE__ */ jsxs("div", { className: "ml-auto flex items-center gap-2", children: [
            /* @__PURE__ */ jsxs("span", { className: cn("font-mono text-xs font-semibold", pnlClass(totalPnl)), children: [
              "P&L: ",
              totalPnl >= 0 ? "+" : "",
              formatCurrency(totalPnl)
            ] }),
            /* @__PURE__ */ jsx(
              Button,
              {
                variant: "destructive",
                size: "sm",
                onClick: handleCloseAll,
                className: "text-[10px] h-5",
                disabled: closeAllPositions.isPending || isDemo || !isFeedConnected,
                children: "Close All"
              }
            )
          ] }),
          activeAccount && (tab === "positions" || tab === "orders" || tab === "history") && !(tab === "positions" && openPositions.length > 0) && /* @__PURE__ */ jsx("span", { className: "ml-auto text-[10px] text-muted-foreground font-mono px-2", children: activeAccount.label || (accountId == null ? void 0 : accountId.slice(0, 8)) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex-1 overflow-auto", children: [
          tab === "positions" && /* @__PURE__ */ jsx(
            PositionsTable,
            {
              positions: openPositions,
              onClose: handleClosePosition,
              onModify: onModifyPosition,
              onPartialClose: handlePartialClose,
              onSelectSymbol: onSelectPositionSymbol
            }
          ),
          tab === "orders" && /* @__PURE__ */ jsx(
            OrdersTable,
            {
              orders: pendingOrders,
              onCancel: handleCancel,
              onModify: onModifyOrder,
              onSelectSymbol: onSelectOrderSymbol
            }
          ),
          tab === "history" && /* @__PURE__ */ jsx(TradeHistoryTable, { accountId }),
          tab === "journal" && /* @__PURE__ */ jsx(
            TradeJournalPanel,
            {
              entries: journalEntries,
              isLoading: journalLoading,
              accountId,
              onCreateEntry: onCreateJournal,
              onUpdateEntry: onUpdateJournal,
              onDeleteEntry: onDeleteJournal
            }
          ),
          tab === "calendar" && /* @__PURE__ */ jsx(EconomicCalendar, {}),
          tab === "news" && /* @__PURE__ */ jsx(NewsFeed, {})
        ] })
      ]
    }
  );
}
function TradeHistoryTable({ accountId }) {
  const [page, setPage] = useState(1);
  const { data: closedData, isLoading } = useClosedPositions(accountId, page);
  const trades = (closedData == null ? void 0 : closedData.data) || [];
  const totalPages = (closedData == null ? void 0 : closedData.totalPages) || 1;
  const accounts = useTradingStore((s) => s.accounts);
  const activeAccount = accounts.find((account) => account.id === accountId);
  const prevAccRef = useRef(accountId);
  useEffect(() => {
    if (prevAccRef.current !== accountId) {
      setPage(1);
      prevAccRef.current = accountId;
    }
  }, [accountId]);
  if (!accountId)
    return /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center h-full text-muted-foreground text-xs", children: "Select an account" });
  if (isLoading)
    return /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center h-full text-muted-foreground text-xs", children: "Loading..." });
  if (trades.length === 0)
    return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-center h-full text-muted-foreground text-xs", children: [
      "No trade history yet",
      activeAccount ? ` for ${activeAccount.label || (accountId == null ? void 0 : accountId.slice(0, 8))}` : ""
    ] });
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col h-full", children: [
    /* @__PURE__ */ jsxs("table", { className: "w-full text-[11px]", children: [
      /* @__PURE__ */ jsx("thead", { className: "sticky top-0 bg-card z-10", children: /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx("th", { children: "Closed" }),
        /* @__PURE__ */ jsx("th", { children: "Symbol" }),
        /* @__PURE__ */ jsx("th", { children: "Side" }),
        /* @__PURE__ */ jsx("th", { children: "Volume" }),
        /* @__PURE__ */ jsx("th", { children: "Entry" }),
        /* @__PURE__ */ jsx("th", { children: "Exit" }),
        /* @__PURE__ */ jsx("th", { children: "Commission" }),
        /* @__PURE__ */ jsx("th", { children: "Gross P&L" }),
        /* @__PURE__ */ jsx("th", { children: "Net P&L" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { children: trades.map((t) => {
        const comm = t.commission ?? 0;
        const gross = t.realizedPnl ?? 0;
        const net = gross - comm;
        return /* @__PURE__ */ jsxs("tr", { className: "hover:bg-secondary/30", children: [
          /* @__PURE__ */ jsx("td", { className: "text-muted-foreground font-mono", children: formatDate(t.closedAt || t.openedAt) }),
          /* @__PURE__ */ jsx("td", { className: "font-semibold", children: t.symbolName }),
          /* @__PURE__ */ jsx("td", { className: t.side === "LONG" ? "text-buy" : "text-sell", children: t.side }),
          /* @__PURE__ */ jsx("td", { className: "font-mono", children: t.quantity }),
          /* @__PURE__ */ jsx("td", { className: "font-mono", children: t.entryPrice ? formatNumber(t.entryPrice, 5) : "--" }),
          /* @__PURE__ */ jsx("td", { className: "font-mono", children: t.exitPrice ? formatNumber(t.exitPrice, 5) : "--" }),
          /* @__PURE__ */ jsx("td", { className: "font-mono text-muted-foreground", children: comm > 0 ? `-${comm.toFixed(2)}` : "0.00" }),
          /* @__PURE__ */ jsx(
            "td",
            {
              className: cn(
                "font-mono",
                gross >= 0 ? "text-success/70" : "text-destructive/70"
              ),
              children: `${gross >= 0 ? "+" : ""}${gross.toFixed(2)}`
            }
          ),
          /* @__PURE__ */ jsx("td", { className: cn("font-mono font-semibold", pnlClass(net)), children: `${net >= 0 ? "+" : ""}${net.toFixed(2)}` })
        ] }, t.id);
      }) })
    ] }),
    totalPages > 1 && /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-center gap-2 py-1 border-t border-border text-[10px]", children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => setPage(Math.max(1, page - 1)),
          disabled: page <= 1,
          className: "px-1.5 py-0.5 rounded bg-secondary hover:bg-secondary/80 disabled:opacity-40",
          children: "Prev"
        }
      ),
      /* @__PURE__ */ jsxs("span", { className: "text-muted-foreground", children: [
        page,
        " / ",
        totalPages
      ] }),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => setPage(Math.min(totalPages, page + 1)),
          disabled: page >= totalPages,
          className: "px-1.5 py-0.5 rounded bg-secondary hover:bg-secondary/80 disabled:opacity-40",
          children: "Next"
        }
      )
    ] })
  ] });
}
function EconomicCalendar() {
  const [useTvCalendar, setUseTvCalendar] = useState(
    () => safeStorage.getItem("tvEconCalendar") !== "false"
  );
  const isDark = !document.documentElement.classList.contains("light");
  const impactColor = {
    low: "bg-muted text-muted-foreground",
    medium: "bg-warning/20 text-warning",
    high: "bg-destructive/20 text-destructive"
  };
  return /* @__PURE__ */ jsxs("div", { className: "h-full flex flex-col", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 px-2 py-1 border-b border-border/40 shrink-0", children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => {
            setUseTvCalendar(false);
            safeStorage.setItem("tvEconCalendar", "false");
          },
          className: cn(
            "px-2 py-0.5 rounded text-[10px] font-medium",
            !useTvCalendar ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary"
          ),
          children: "Sim Data"
        }
      ),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => {
            setUseTvCalendar(true);
            safeStorage.setItem("tvEconCalendar", "true");
          },
          className: cn(
            "px-2 py-0.5 rounded text-[10px] font-medium",
            useTvCalendar ? "bg-[#2962ff] text-white" : "text-muted-foreground hover:bg-secondary"
          ),
          children: "TradingView Live"
        }
      )
    ] }),
    useTvCalendar ? /* @__PURE__ */ jsx("div", { className: "flex-1 min-h-0", children: /* @__PURE__ */ jsx(
      TradingViewEconomicCalendar,
      {
        theme: isDark ? "dark" : "light",
        width: "100%",
        height: "100%"
      }
    ) }) : /* @__PURE__ */ jsxs("table", { className: "w-full text-[11px]", children: [
      /* @__PURE__ */ jsx("thead", { className: "sticky top-0 bg-card z-10", children: /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx("th", { children: "Time" }),
        /* @__PURE__ */ jsx("th", { children: "Currency" }),
        /* @__PURE__ */ jsx("th", { children: "Impact" }),
        /* @__PURE__ */ jsx("th", { children: "Event" }),
        /* @__PURE__ */ jsx("th", { children: "Forecast" }),
        /* @__PURE__ */ jsx("th", { children: "Previous" }),
        /* @__PURE__ */ jsx("th", { children: "Actual" })
      ] }) }),
      /* @__PURE__ */ jsxs("tbody", { children: [
        /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsxs("td", { colSpan: 7, className: "px-3 py-1.5 bg-secondary/40 text-[10px] text-muted-foreground", children: [
          /* @__PURE__ */ jsx("span", { className: "font-medium uppercase tracking-wide", children: "Sample data" }),
          " — switch the TradingView calendar back on for live events."
        ] }) }),
        MOCK_EVENTS.map((ev, i) => /* @__PURE__ */ jsxs("tr", { className: "hover:bg-secondary/30", children: [
          /* @__PURE__ */ jsx("td", { className: "text-muted-foreground", children: ev.time }),
          /* @__PURE__ */ jsx("td", { className: "font-semibold", children: ev.currency }),
          /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx(
            "span",
            {
              className: cn(
                "px-1.5 py-0.5 rounded text-[9px] font-medium",
                impactColor[ev.impact]
              ),
              children: ev.impact.toUpperCase()
            }
          ) }),
          /* @__PURE__ */ jsx("td", { children: ev.event }),
          /* @__PURE__ */ jsx("td", { className: "font-mono", children: ev.forecast || "--" }),
          /* @__PURE__ */ jsx("td", { className: "font-mono text-muted-foreground", children: ev.previous || "--" }),
          /* @__PURE__ */ jsx("td", { className: "font-mono font-semibold", children: ev.actual || "--" })
        ] }, i))
      ] })
    ] })
  ] });
}
function NewsFeed() {
  const impactStyle = {
    bullish: "text-buy",
    bearish: "text-sell",
    neutral: "text-muted-foreground"
  };
  return /* @__PURE__ */ jsxs("div", { className: "divide-y divide-border/30", children: [
    /* @__PURE__ */ jsxs("div", { className: "px-3 py-1.5 bg-secondary/40 text-[10px] text-muted-foreground flex items-center gap-1.5", children: [
      /* @__PURE__ */ jsx("span", { className: "font-medium uppercase tracking-wide", children: "Sample data" }),
      /* @__PURE__ */ jsx("span", { children: "— OpenCharts ships no news feed; connect a provider to make this live." })
    ] }),
    MOCK_NEWS.map((item, i) => /* @__PURE__ */ jsxs("div", { className: "px-3 py-2 hover:bg-secondary/30 cursor-pointer", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-[10px] text-muted-foreground mb-0.5", children: [
        /* @__PURE__ */ jsx("span", { children: item.time }),
        /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "|" }),
        /* @__PURE__ */ jsx("span", { children: item.source }),
        /* @__PURE__ */ jsx("span", { className: cn("font-semibold", impactStyle[item.impact]), children: item.impact.toUpperCase() })
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-xs leading-snug", children: item.title })
    ] }, i))
  ] });
}
function observeChartSize(target, resize) {
  let frame = null;
  let latest = null;
  let disposed = false;
  const observer = new ResizeObserver((entries) => {
    const entry = entries.find((item) => item.target === target);
    if (!entry || disposed) return;
    latest = { width: entry.contentRect.width, height: entry.contentRect.height };
    if (frame !== null) return;
    frame = requestAnimationFrame(() => {
      frame = null;
      if (!disposed && latest) resize(latest.width, latest.height);
    });
  });
  observer.observe(target);
  return () => {
    disposed = true;
    observer.disconnect();
    if (frame !== null) cancelAnimationFrame(frame);
  };
}
function ensureDefined(value) {
  if (value === void 0) {
    throw new Error("Value is undefined");
  }
  return value;
}
class PluginBase {
  constructor() {
    __publicField(this, "_chart");
    __publicField(this, "_series");
    __publicField(this, "_requestUpdate");
    // This method is a class property to maintain the
    // lexical 'this' scope (due to the use of the arrow function)
    // and to ensure its reference stays the same, so we can unsubscribe later.
    __publicField(this, "_fireDataUpdated", (scope) => {
      if (this.dataUpdated) {
        this.dataUpdated(scope);
      }
    });
  }
  requestUpdate() {
    if (this._requestUpdate) this._requestUpdate();
  }
  attached({ chart, series, requestUpdate }) {
    this._chart = chart;
    this._series = series;
    this._series.subscribeDataChanged(this._fireDataUpdated);
    this._requestUpdate = requestUpdate;
    this.requestUpdate();
  }
  detached() {
    var _a;
    (_a = this._series) == null ? void 0 : _a.unsubscribeDataChanged(this._fireDataUpdated);
    this._chart = void 0;
    this._series = void 0;
    this._requestUpdate = void 0;
  }
  get chart() {
    return ensureDefined(this._chart);
  }
  get series() {
    return ensureDefined(this._series);
  }
}
function cloneReadonly(obj) {
  return JSON.parse(JSON.stringify(obj));
}
class ClosestTimeIndexFinder {
  constructor(sortedNumbers) {
    __publicField(this, "numbers");
    __publicField(this, "cache");
    this.numbers = sortedNumbers;
    this.cache = /* @__PURE__ */ new Map();
  }
  findClosestIndex(target, direction) {
    const cacheKey = `${target}:${direction}`;
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey);
    }
    const closestIndex = this._performSearch(target, direction);
    this.cache.set(cacheKey, closestIndex);
    return closestIndex;
  }
  _performSearch(target, direction) {
    let low = 0;
    let high = this.numbers.length - 1;
    if (target <= this.numbers[0].time) return 0;
    if (target >= this.numbers[high].time) return high;
    while (low <= high) {
      const mid = Math.floor((low + high) / 2);
      const num = this.numbers[mid].time;
      if (num === target) {
        return mid;
      } else if (num > target) {
        high = mid - 1;
      } else {
        low = mid + 1;
      }
    }
    return direction === "left" ? high : low;
  }
}
class UpperLowerInRange {
  constructor(arr, chunkSize = 10) {
    __publicField(this, "_arr");
    __publicField(this, "_chunkSize");
    __publicField(this, "_cache");
    this._arr = arr;
    this._chunkSize = chunkSize;
    this._cache = /* @__PURE__ */ new Map();
  }
  getMinMax(startIndex, endIndex) {
    const cacheKey = `${startIndex}:${endIndex}`;
    if (this._cache.has(cacheKey)) {
      return this._cache.get(cacheKey);
    }
    const result = {
      lower: Infinity,
      upper: -Infinity
    };
    const startChunkIndex = Math.floor(startIndex / this._chunkSize);
    const endChunkIndex = Math.floor(endIndex / this._chunkSize);
    for (let chunkIndex = startChunkIndex; chunkIndex <= endChunkIndex; chunkIndex++) {
      const chunkStart = chunkIndex * this._chunkSize;
      const chunkEnd = Math.min((chunkIndex + 1) * this._chunkSize - 1, this._arr.length - 1);
      const chunkCacheKey = `${chunkStart}:${chunkEnd}`;
      if (this._cache.has(chunkCacheKey)) {
        const item = this._cache.get(chunkCacheKey);
        this._check(item, result);
      } else {
        const chunkResult = {
          lower: Infinity,
          upper: -Infinity
        };
        for (let i = chunkStart; i <= chunkEnd; i++) {
          this._check(this._arr[i], chunkResult);
        }
        this._cache.set(chunkCacheKey, chunkResult);
        this._check(chunkResult, result);
      }
    }
    this._cache.set(cacheKey, result);
    return result;
  }
  _check(item, state) {
    if (item.lower < state.lower) {
      state.lower = item.lower;
    }
    if (item.upper > state.upper) {
      state.upper = item.upper;
    }
  }
}
class BandsIndicatorPaneRenderer {
  constructor(data) {
    __publicField(this, "_viewData");
    this._viewData = data;
  }
  draw() {
  }
  drawBackground(target) {
    const points = this._viewData.data;
    target.useBitmapCoordinateSpace((scope) => {
      const ctx = scope.context;
      ctx.scale(scope.horizontalPixelRatio, scope.verticalPixelRatio);
      ctx.strokeStyle = this._viewData.options.lineColor;
      ctx.lineWidth = this._viewData.options.lineWidth;
      ctx.beginPath();
      const region = new Path2D();
      const lines = new Path2D();
      region.moveTo(points[0].x, points[0].upper);
      lines.moveTo(points[0].x, points[0].upper);
      for (const point of points) {
        region.lineTo(point.x, point.upper);
        lines.lineTo(point.x, point.upper);
      }
      const end = points.length - 1;
      region.lineTo(points[end].x, points[end].lower);
      lines.moveTo(points[end].x, points[end].lower);
      for (let i = points.length - 2; i >= 0; i--) {
        region.lineTo(points[i].x, points[i].lower);
        lines.lineTo(points[i].x, points[i].lower);
      }
      region.lineTo(points[0].x, points[0].upper);
      region.closePath();
      ctx.stroke(lines);
      ctx.fillStyle = this._viewData.options.fillColor;
      ctx.fill(region);
    });
  }
}
class BandsIndicatorPaneView {
  constructor(source) {
    __publicField(this, "_source");
    __publicField(this, "_data");
    this._source = source;
    this._data = {
      data: [],
      options: this._source._options
    };
  }
  update() {
    const series = this._source.series;
    const timeScale = this._source.chart.timeScale();
    this._data.data = this._source._bandsData.map((d) => {
      return {
        x: timeScale.timeToCoordinate(d.time) ?? -100,
        upper: series.priceToCoordinate(d.upper) ?? -100,
        lower: series.priceToCoordinate(d.lower) ?? -100
      };
    });
  }
  renderer() {
    return new BandsIndicatorPaneRenderer(this._data);
  }
}
function extractPrice(dataPoint) {
  if (dataPoint.close !== void 0) return dataPoint.close;
  if (dataPoint.value !== void 0) return dataPoint.value;
  return void 0;
}
const defaults$1 = {
  lineColor: "rgb(25, 200, 100)",
  fillColor: "rgba(25, 200, 100, 0.25)",
  lineWidth: 1
};
class BandsIndicator extends PluginBase {
  constructor(options = {}) {
    super();
    __publicField(this, "_paneViews");
    __publicField(this, "_seriesData", []);
    __publicField(this, "_bandsData", []);
    __publicField(this, "_options");
    __publicField(this, "_timeIndices");
    __publicField(this, "_upperLower");
    __publicField(this, "_minValue", Number.POSITIVE_INFINITY);
    __publicField(this, "_maxValue", Number.NEGATIVE_INFINITY);
    this._options = { ...defaults$1, ...options };
    this._paneViews = [new BandsIndicatorPaneView(this)];
    this._timeIndices = new ClosestTimeIndexFinder([]);
    this._upperLower = new UpperLowerInRange([]);
  }
  updateAllViews() {
    this._paneViews.forEach((pw) => pw.update());
  }
  paneViews() {
    return this._paneViews;
  }
  attached(p) {
    super.attached(p);
    this.dataUpdated("full");
  }
  dataUpdated(scope) {
    this._seriesData = cloneReadonly(this.series.data());
    this.calculateBands();
    if (scope === "full") {
      this._timeIndices = new ClosestTimeIndexFinder(this._seriesData);
    }
  }
  calculateBands() {
    const bandData = new Array(this._seriesData.length);
    let index = 0;
    this._minValue = Number.POSITIVE_INFINITY;
    this._maxValue = Number.NEGATIVE_INFINITY;
    this._seriesData.forEach((d) => {
      const price = extractPrice(d);
      if (price === void 0) return;
      const upper = price * 1.1;
      const lower = price * 0.9;
      if (upper > this._maxValue) this._maxValue = upper;
      if (lower < this._minValue) this._minValue = lower;
      bandData[index] = {
        upper,
        lower,
        time: d.time
      };
      index += 1;
    });
    bandData.length = index;
    this._bandsData = bandData;
    this._upperLower = new UpperLowerInRange(this._bandsData, 4);
  }
  autoscaleInfo(startTimePoint, endTimePoint) {
    const ts = this.chart.timeScale();
    const startTime = ts.coordinateToTime(ts.logicalToCoordinate(startTimePoint) ?? 0) ?? 0;
    const endTime = ts.coordinateToTime(ts.logicalToCoordinate(endTimePoint) ?? 5e9) ?? 5e9;
    const startIndex = this._timeIndices.findClosestIndex(startTime, "left");
    const endIndex = this._timeIndices.findClosestIndex(endTime, "right");
    const range = this._upperLower.getMinMax(startIndex, endIndex);
    return {
      priceRange: {
        minValue: range.lower,
        maxValue: range.upper
      }
    };
  }
}
class Delegate {
  constructor() {
    __publicField(this, "_listeners", []);
  }
  subscribe(callback, linkedObject, singleshot) {
    const listener = {
      callback,
      linkedObject,
      singleshot: singleshot === true
    };
    this._listeners.push(listener);
  }
  unsubscribe(callback) {
    const index = this._listeners.findIndex(
      (listener) => callback === listener.callback
    );
    if (index > -1) {
      this._listeners.splice(index, 1);
    }
  }
  unsubscribeAll(linkedObject) {
    this._listeners = this._listeners.filter(
      (listener) => listener.linkedObject !== linkedObject
    );
  }
  fire(param1) {
    const listenersSnapshot = [...this._listeners];
    this._listeners = this._listeners.filter((listener) => !listener.singleshot);
    listenersSnapshot.forEach((listener) => listener.callback(param1));
  }
  hasListeners() {
    return this._listeners.length > 0;
  }
  destroy() {
    this._listeners = [];
  }
}
function convertTime(t) {
  if (isUTCTimestamp(t)) return t * 1e3;
  if (isBusinessDay(t)) return new Date(t.year, t.month, t.day).valueOf();
  const parts = t.split("-").map(Number);
  return new Date(parts[0], parts[1], parts[2]).valueOf();
}
function formattedDateAndTime(timestamp) {
  if (!timestamp) return ["", ""];
  const dateObj = new Date(timestamp);
  const year = dateObj.getFullYear();
  const month = dateObj.toLocaleString("default", { month: "short" });
  const date = dateObj.getDate().toString().padStart(2, "0");
  const formattedDate = `${date} ${month} ${year}`;
  const hours = dateObj.getHours().toString().padStart(2, "0");
  const minutes = dateObj.getMinutes().toString().padStart(2, "0");
  const formattedTime = `${hours}:${minutes}`;
  return [formattedDate, formattedTime];
}
function centreOffset(lineBitmapWidth) {
  return Math.floor(lineBitmapWidth * 0.5);
}
function positionsLine(positionMedia, pixelRatio, desiredWidthMedia = 1, widthIsBitmap) {
  const scaledPosition = Math.round(pixelRatio * positionMedia);
  const lineBitmapWidth = Math.round(desiredWidthMedia * pixelRatio);
  const offset = centreOffset(lineBitmapWidth);
  const position = scaledPosition - offset;
  return { position, length: lineBitmapWidth };
}
let TooltipCrosshairLinePaneRenderer$1 = class TooltipCrosshairLinePaneRenderer {
  constructor(data) {
    __publicField(this, "_data");
    this._data = data;
  }
  draw(target) {
    if (!this._data.length) return;
    target.useBitmapCoordinateSpace((scope) => {
      const ctx = scope.context;
      this._data.forEach((data) => {
        const crosshairPos = positionsLine(data.x, scope.horizontalPixelRatio, 1);
        ctx.fillStyle = data.color;
        ctx.fillRect(
          crosshairPos.position,
          data.topMargin * scope.verticalPixelRatio,
          crosshairPos.length,
          scope.bitmapSize.height
        );
        if (data.priceY) {
          ctx.beginPath();
          ctx.ellipse(
            data.x * scope.horizontalPixelRatio,
            data.priceY * scope.verticalPixelRatio,
            6 * scope.horizontalPixelRatio,
            6 * scope.verticalPixelRatio,
            0,
            0,
            Math.PI * 2
          );
          ctx.fillStyle = data.markerBorderColor;
          ctx.fill();
          ctx.beginPath();
          ctx.ellipse(
            data.x * scope.horizontalPixelRatio,
            data.priceY * scope.verticalPixelRatio,
            4 * scope.horizontalPixelRatio,
            4 * scope.verticalPixelRatio,
            0,
            0,
            Math.PI * 2
          );
          ctx.fillStyle = data.markerColor;
          ctx.fill();
        }
      });
    });
  }
};
let MultiTouchCrosshairPaneView$1 = class MultiTouchCrosshairPaneView {
  constructor(data) {
    __publicField(this, "_data");
    this._data = data;
  }
  update(data) {
    this._data = data;
  }
  renderer() {
    return new TooltipCrosshairLinePaneRenderer$1(this._data);
  }
  zOrder() {
    return "top";
  }
};
const styles = {
  background: "#ffffff",
  fontFamily: "-apple-system, BlinkMacSystemFont, 'Trebuchet MS', Roboto, Ubuntu, sans-serif",
  borderRadius: 5,
  shadowColor: "rgba(0, 0, 0, 0.2)",
  shadowBlur: 4,
  shadowOffsetX: 0,
  shadowOffsetY: 2,
  itemBlockPadding: 5,
  itemInlinePadding: 10,
  tooltipLineFontWeights: [590, 400, 400],
  tooltipLineFontSizes: [14, 12, 12],
  tooltipLineLineHeights: [18, 16, 16],
  tooltipLineColors: ["#131722", "#787B86", "#787B86"],
  deltaFontWeights: [590, 400],
  deltaFontSizes: [14, 12],
  deltaLineHeights: [18, 16]
};
function determineSectionWidth(ctx, lines, fontSizes, fontWeights) {
  let maxTextWidth = 0;
  ctx.save();
  lines.forEach((line, index) => {
    ctx.font = `${fontWeights[index]} ${fontSizes[index]}px ${styles.fontFamily}`;
    const measurement = ctx.measureText(line);
    if (measurement.width > maxTextWidth) maxTextWidth = measurement.width;
  });
  ctx.restore();
  return maxTextWidth + styles.itemInlinePadding * 2;
}
function styleAt(values, index, fallback) {
  return values[index] ?? values[values.length - 1] ?? fallback;
}
function determineSectionHeight(lines, lineHeights) {
  let height = styles.itemBlockPadding * 1.5;
  lines.forEach((_line, index) => {
    height += styleAt(lineHeights, index, 0);
  });
  return height;
}
function calculateVerticalDrawingPositions(data) {
  var _a, _b;
  const mainY = data.topSpacing;
  const leftTooltipHeight = data.tooltips.length < 1 ? 0 : determineSectionHeight(((_a = data.tooltips[0]) == null ? void 0 : _a.lineContent) ?? [], styles.tooltipLineLineHeights);
  const rightTooltipHeight = data.tooltips.length < 2 ? 0 : determineSectionHeight(((_b = data.tooltips[1]) == null ? void 0 : _b.lineContent) ?? [], styles.tooltipLineLineHeights);
  const deltaHeight = determineSectionHeight(
    [data.deltaTopLine, data.deltaBottomLine].filter(Boolean),
    styles.deltaLineHeights
  );
  const mainHeight = Math.max(leftTooltipHeight, rightTooltipHeight, deltaHeight);
  const leftTooltipTextY = Math.round(
    styles.itemBlockPadding + (mainHeight - leftTooltipHeight) / 2
  );
  const rightTooltipTextY = Math.round(
    styles.itemBlockPadding + (mainHeight - rightTooltipHeight) / 2
  );
  const deltaTextY = Math.round(styles.itemBlockPadding + (mainHeight - deltaHeight) / 2);
  return {
    mainY,
    mainHeight,
    leftTooltipTextY,
    rightTooltipTextY,
    deltaTextY
  };
}
function calculateInitialTooltipPosition(data, index, ctx, mediaSize) {
  const tooltip = data.tooltips[index];
  const lines = (tooltip == null ? void 0 : tooltip.lineContent) ?? [];
  const tooltipWidth = determineSectionWidth(
    ctx,
    lines,
    styles.tooltipLineFontSizes,
    styles.tooltipLineFontWeights
  );
  const halfWidth = tooltipWidth / 2;
  const idealX = Math.min(
    Math.max(0, ((tooltip == null ? void 0 : tooltip.x) ?? 0) - halfWidth),
    mediaSize.width - tooltipWidth
  );
  const leftSpace = idealX;
  const rightSpace = mediaSize.width - tooltipWidth - leftSpace;
  return {
    x: idealX,
    leftSpace,
    rightSpace,
    width: tooltipWidth
  };
}
function calculateDrawingHorizontalPositions(data, ctx, mediaSize) {
  const leftPosition = calculateInitialTooltipPosition(data, 0, ctx, mediaSize);
  if (data.tooltips.length < 2) {
    return {
      mainX: Math.round(leftPosition.x),
      mainWidth: Math.round(leftPosition.width),
      leftTooltipCentreX: Math.round(leftPosition.x + leftPosition.width / 2),
      rightTooltipCentreX: 0,
      deltaCentreX: 0,
      deltaWidth: 0
    };
  }
  const rightPosition = calculateInitialTooltipPosition(data, 1, ctx, mediaSize);
  const minDeltaWidth = data.tooltips.length < 2 ? 0 : determineSectionWidth(
    ctx,
    [data.deltaTopLine, data.deltaBottomLine].filter(Boolean),
    styles.deltaFontSizes,
    styles.deltaFontWeights
  );
  const overlapWidth = minDeltaWidth + leftPosition.x + leftPosition.width - rightPosition.x;
  if (overlapWidth > 0) {
    const halfOverlap = overlapWidth / 2;
    if (leftPosition.leftSpace >= halfOverlap && rightPosition.rightSpace >= halfOverlap) {
      leftPosition.x -= halfOverlap;
      rightPosition.x += halfOverlap;
    } else {
      const leftSmaller = leftPosition.leftSpace < rightPosition.rightSpace;
      if (leftSmaller) {
        const remainingOverlap = overlapWidth - leftPosition.leftSpace;
        leftPosition.x -= leftPosition.leftSpace;
        rightPosition.x += remainingOverlap;
      } else {
        const remainingOverlap = overlapWidth - rightPosition.rightSpace;
        leftPosition.x = Math.max(0, leftPosition.x - remainingOverlap);
        rightPosition.x += rightPosition.rightSpace;
      }
    }
  }
  const deltaWidth = Math.round(rightPosition.x - leftPosition.x - leftPosition.width);
  const deltaCentreX = Math.round(rightPosition.x - deltaWidth / 2);
  return {
    mainX: Math.round(leftPosition.x),
    mainWidth: Math.round(leftPosition.width + deltaWidth + rightPosition.width),
    leftTooltipCentreX: Math.round(leftPosition.x + leftPosition.width / 2),
    rightTooltipCentreX: Math.round(rightPosition.x + rightPosition.width / 2),
    deltaCentreX,
    deltaWidth
  };
}
function calculateDrawingPositions(data, ctx, mediaSize) {
  return {
    ...calculateVerticalDrawingPositions(data),
    ...calculateDrawingHorizontalPositions(data, ctx, mediaSize)
  };
}
class DeltaTooltipPaneRenderer {
  constructor(data) {
    __publicField(this, "_data");
    this._data = data;
  }
  draw(target) {
    if (this._data.tooltips.length < 1) return;
    target.useMediaCoordinateSpace((scope) => {
      const ctx = scope.context;
      const drawingPositions = calculateDrawingPositions(this._data, ctx, scope.mediaSize);
      this._drawMainTooltip(ctx, drawingPositions);
      this._drawDeltaArea(ctx, drawingPositions);
      this._drawTooltipsText(ctx, drawingPositions);
      this._drawDeltaText(ctx, drawingPositions);
    });
  }
  _drawMainTooltip(ctx, positions) {
    ctx.save();
    ctx.fillStyle = styles.background;
    ctx.shadowBlur = styles.shadowBlur;
    ctx.shadowOffsetX = styles.shadowOffsetX;
    ctx.shadowOffsetY = styles.shadowOffsetY;
    ctx.shadowColor = styles.shadowColor;
    ctx.beginPath();
    ctx.roundRect(
      positions.mainX,
      positions.mainY,
      positions.mainWidth,
      positions.mainHeight,
      styles.borderRadius
    );
    ctx.fill();
    ctx.restore();
  }
  _drawDeltaArea(ctx, positions) {
    ctx.save();
    ctx.fillStyle = this._data.deltaBackgroundColor;
    ctx.beginPath();
    const halfWidth = Math.round(positions.deltaWidth / 2);
    ctx.fillRect(
      positions.deltaCentreX - halfWidth,
      positions.mainY,
      positions.deltaWidth,
      positions.mainHeight
    );
    ctx.restore();
  }
  _drawTooltipsText(ctx, positions) {
    ctx.save();
    this._data.tooltips.forEach((tooltip, tooltipIndex) => {
      const x = tooltipIndex === 0 ? positions.leftTooltipCentreX : positions.rightTooltipCentreX;
      let y = positions.mainY + (tooltipIndex === 0 ? positions.leftTooltipTextY : positions.rightTooltipTextY);
      tooltip.lineContent.forEach((line, lineIndex) => {
        ctx.font = `${styleAt(styles.tooltipLineFontWeights, lineIndex, 400)} ${styleAt(styles.tooltipLineFontSizes, lineIndex, 12)}px ${styles.fontFamily}`;
        ctx.fillStyle = styleAt(styles.tooltipLineColors, lineIndex, "#000000");
        ctx.textAlign = "center";
        ctx.textBaseline = "top";
        ctx.fillText(line, x, y);
        y += styleAt(styles.tooltipLineLineHeights, lineIndex, 0);
      });
    });
    ctx.restore();
  }
  _drawDeltaText(ctx, positions) {
    ctx.save();
    const x = positions.deltaCentreX;
    let y = positions.mainY + positions.deltaTextY;
    const lines = [this._data.deltaTopLine, this._data.deltaBottomLine];
    lines.forEach((line, lineIndex) => {
      ctx.font = `${styleAt(styles.deltaFontWeights, lineIndex, 400)} ${styleAt(styles.deltaFontSizes, lineIndex, 12)}px ${styles.fontFamily}`;
      ctx.fillStyle = this._data.deltaTextColor;
      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      ctx.fillText(line, x, y);
      y += styleAt(styles.deltaLineHeights, lineIndex, 0);
    });
    ctx.restore();
  }
}
class DeltaTooltipPaneView {
  constructor(data) {
    __publicField(this, "_data");
    this._data = {
      ...defaultOptions$5,
      ...data
    };
  }
  update(data) {
    this._data = {
      ...this._data,
      ...data
    };
  }
  renderer() {
    return new DeltaTooltipPaneRenderer(this._data);
  }
  zOrder() {
    return "top";
  }
}
const defaultOptions$5 = {
  deltaTopLine: "",
  deltaBottomLine: "",
  deltaBackgroundColor: "#ffffff",
  deltaTextColor: "#",
  topSpacing: 20,
  tooltips: []
};
function determineChartX(chartElement, chart, mouseX) {
  const chartBox = chartElement.getBoundingClientRect();
  const x = mouseX - chartBox.left - chart.priceScale("left").width();
  if (x < 0 || x > chart.timeScale().width()) return null;
  return x;
}
function determinePaneXLogical(chart, x) {
  if (x === null) return null;
  return chart.timeScale().coordinateToLogical(x);
}
function determineYPosition(chartElement, clientY) {
  const chartContainerBox = chartElement.getBoundingClientRect();
  return clientY - chartContainerBox.y;
}
class MultiTouchChartEvents {
  constructor(chart, options) {
    __publicField(this, "_chartElement");
    __publicField(this, "_chart");
    __publicField(this, "_options");
    __publicField(this, "_mouseState", {
      drawing: false,
      startLogical: null,
      startCoordinate: null,
      startX: null
    });
    __publicField(this, "_touchLeave", new Delegate());
    __publicField(this, "_touchInteraction", new Delegate());
    __publicField(this, "_unSubscribers", []);
    this._options = options;
    this._chart = chart;
    this._chartElement = chart.chartElement();
    this._addMouseEventListener(this._chartElement, "mouseleave", this._mouseLeave);
    this._addMouseEventListener(this._chartElement, "mousemove", this._mouseMove);
    this._addMouseEventListener(this._chartElement, "mousedown", this._mouseDown);
    this._addMouseEventListener(this._chartElement, "mouseup", this._mouseUp);
    this._addTouchEventListener(this._chartElement, "touchstart", this._touchOther);
    this._addTouchEventListener(this._chartElement, "touchmove", this._touchMove);
    this._addTouchEventListener(this._chartElement, "touchcancel", this._touchFinish);
    this._addTouchEventListener(this._chartElement, "touchend", this._touchFinish);
  }
  destroy() {
    this._touchLeave.destroy();
    this._touchInteraction.destroy();
    this._unSubscribers.forEach((unSub) => {
      unSub();
    });
    this._unSubscribers = [];
  }
  leave() {
    return this._touchLeave;
  }
  move() {
    return this._touchInteraction;
  }
  _addMouseEventListener(target, eventType, handler) {
    const boundMouseMoveHandler = handler.bind(this);
    target.addEventListener(eventType, boundMouseMoveHandler);
    const unSubscriber = () => {
      target.removeEventListener(eventType, boundMouseMoveHandler);
    };
    this._unSubscribers.push(unSubscriber);
  }
  _addTouchEventListener(target, eventType, handler) {
    const boundMouseMoveHandler = handler.bind(this);
    target.addEventListener(eventType, boundMouseMoveHandler);
    const unSubscriber = () => {
      target.removeEventListener(eventType, boundMouseMoveHandler);
    };
    this._unSubscribers.push(unSubscriber);
  }
  _mouseLeave() {
    this._mouseState.drawing = false;
    this._touchLeave.fire();
  }
  _mouseMove(event) {
    const chartX = determineChartX(this._chartElement, this._chart, event.clientX);
    const logical = determinePaneXLogical(this._chart, chartX);
    const coordinate = determineYPosition(this._chartElement, event.clientY);
    const points = [];
    if (this._options.simulateMultiTouchUsingMouseDrag && this._mouseState.drawing && this._mouseState.startLogical !== null && this._mouseState.startCoordinate !== null && this._mouseState.startX !== null) {
      points.push({
        x: this._mouseState.startX,
        index: this._mouseState.startLogical,
        y: this._mouseState.startCoordinate
      });
    }
    if (logical !== null && coordinate !== null && chartX !== null) {
      points.push({
        x: chartX,
        index: logical,
        y: coordinate
      });
    }
    const interaction = {
      points
    };
    this._touchInteraction.fire(interaction);
  }
  _mouseDown(event) {
    this._mouseState.startX = determineChartX(this._chartElement, this._chart, event.clientX);
    this._mouseState.startLogical = determinePaneXLogical(this._chart, this._mouseState.startX);
    this._mouseState.startCoordinate = determineYPosition(this._chartElement, event.clientY);
    this._mouseState.drawing = this._mouseState.startLogical !== null && this._mouseState.startCoordinate !== null;
  }
  _mouseUp() {
    this._mouseState.drawing = false;
  }
  _touchMove(event) {
    event.preventDefault();
    const points = [];
    for (let i = 0; i < event.targetTouches.length; i++) {
      const touch = event.targetTouches.item(i);
      if (touch !== null) {
        const chartX = determineChartX(this._chartElement, this._chart, touch.clientX);
        const logical = determinePaneXLogical(this._chart, chartX);
        const y = determineYPosition(this._chartElement, touch.clientY);
        if (chartX !== null && y !== null && logical !== null) {
          points.push({
            x: chartX,
            index: logical,
            y
          });
        }
      }
    }
    const interaction = {
      points
    };
    this._touchInteraction.fire(interaction);
  }
  _touchFinish(event) {
    event.preventDefault();
    if (event.targetTouches.length < 1) {
      this._touchLeave.fire();
      return;
    }
  }
  _touchOther(event) {
    event.preventDefault();
  }
}
const defaultOptions$4 = {
  lineColor: "rgba(0, 0, 0, 0.2)",
  priceExtractor: (data) => {
    if (data.value !== void 0) {
      return [data.value, data.value.toFixed(2)];
    }
    if (data.close !== void 0) {
      return [data.close, data.close.toFixed(2)];
    }
    return [0, ""];
  },
  showTime: false,
  topOffset: 20
};
class DeltaTooltipPrimitive {
  constructor(options) {
    __publicField(this, "_options");
    __publicField(this, "_crosshairPaneView");
    __publicField(this, "_deltaTooltipPaneView");
    __publicField(this, "_paneViews");
    __publicField(this, "_crosshairData", []);
    __publicField(this, "_tooltipData");
    __publicField(this, "_attachedParams");
    __publicField(this, "_touchChartEvents", null);
    __publicField(this, "_activeRange", new Delegate());
    this._options = {
      ...defaultOptions$4,
      ...options
    };
    this._tooltipData = {
      topSpacing: this._options.topOffset
    };
    this._crosshairPaneView = new MultiTouchCrosshairPaneView$1(this._crosshairData);
    this._deltaTooltipPaneView = new DeltaTooltipPaneView(this._tooltipData);
    this._paneViews = [this._crosshairPaneView, this._deltaTooltipPaneView];
  }
  attached(param) {
    this._attachedParams = param;
    this._setCrosshairMode();
    this._touchChartEvents = new MultiTouchChartEvents(param.chart, {
      simulateMultiTouchUsingMouseDrag: true
    });
    this._touchChartEvents.leave().subscribe(() => {
      this._activeRange.fire(null);
      this._hideCrosshair();
    }, this);
    this._touchChartEvents.move().subscribe((interactions) => {
      this._showTooltip(interactions);
    }, this);
  }
  detached() {
    if (this._touchChartEvents) {
      this._touchChartEvents.leave().unsubscribeAll(this);
      this._touchChartEvents.move().unsubscribeAll(this);
      this._touchChartEvents.destroy();
    }
    this._activeRange.destroy();
  }
  paneViews() {
    return this._paneViews;
  }
  updateAllViews() {
    this._crosshairPaneView.update(this._crosshairData);
    this._deltaTooltipPaneView.update(this._tooltipData);
  }
  setData(crosshairData, tooltipData) {
    var _a;
    this._crosshairData = crosshairData;
    this._tooltipData = tooltipData;
    this.updateAllViews();
    (_a = this._attachedParams) == null ? void 0 : _a.requestUpdate();
  }
  currentColor() {
    return this._options.lineColor;
  }
  chart() {
    var _a;
    return (_a = this._attachedParams) == null ? void 0 : _a.chart;
  }
  series() {
    var _a;
    return (_a = this._attachedParams) == null ? void 0 : _a.series;
  }
  applyOptions(options) {
    this._options = {
      ...this._options,
      ...options
    };
    this._tooltipData.topSpacing = this._options.topOffset;
  }
  activeRange() {
    return this._activeRange;
  }
  _setCrosshairMode() {
    const chart = this.chart();
    if (!chart) {
      throw new Error("Unable to change crosshair mode because the chart instance is undefined");
    }
    chart.applyOptions({
      crosshair: {
        mode: CrosshairMode.Magnet,
        vertLine: {
          visible: false,
          labelVisible: false
        },
        horzLine: {
          visible: false,
          labelVisible: false
        }
      }
    });
    const series = this.series();
    if (series) {
      series.applyOptions({ crosshairMarkerVisible: false });
    }
  }
  _hideTooltip() {
    this.setData([], {
      tooltips: []
    });
  }
  _hideCrosshair() {
    this._hideTooltip();
  }
  _chartBackgroundColor() {
    const chart = this.chart();
    if (!chart) {
      return "#FFFFFF";
    }
    const backgroundOptions = chart.options().layout.background;
    if (backgroundOptions.type === ColorType.Solid) {
      return backgroundOptions.color;
    }
    return backgroundOptions.topColor;
  }
  _seriesLineColor() {
    const series = this.series();
    if (!series) {
      return "#888";
    }
    const seriesOptions = series.options();
    return seriesOptions.color || seriesOptions.lineColor || "#888";
  }
  _showTooltip(interactions) {
    const series = this.series();
    if (interactions.points.length < 1 || !series) {
      this._hideCrosshair();
      return;
    }
    const topMargin = this._tooltipData.topSpacing ?? 20;
    const markerBorderColor = this._chartBackgroundColor();
    const markerColor = this._seriesLineColor();
    const tooltips = [];
    const crosshairData = [];
    const priceValues = [];
    const firstPointIndex = interactions.points[0].index;
    for (let i = 0; i < Math.min(2, interactions.points.length); i++) {
      const point = interactions.points[i];
      const data = series.dataByIndex(point.index);
      if (data) {
        const [priceValue, priceString] = this._options.priceExtractor(data);
        priceValues.push([priceValue, point.index]);
        const priceY = series.priceToCoordinate(priceValue) ?? -1e3;
        const [date, time] = formattedDateAndTime(data.time ? convertTime(data.time) : void 0);
        const state = {
          x: point.x,
          lineContent: [priceString, date]
        };
        if (this._options.showTime) {
          state.lineContent.push(time);
        }
        if (point.index >= firstPointIndex) {
          tooltips.push(state);
        } else {
          tooltips.unshift(state);
        }
        crosshairData.push({
          x: point.x,
          priceY,
          visible: true,
          color: this.currentColor(),
          topMargin,
          markerColor,
          markerBorderColor
        });
      }
    }
    const deltaContent = {
      tooltips
    };
    if (priceValues.length > 1) {
      const correctOrder = priceValues[1][1] > priceValues[0][1];
      const firstPrice = correctOrder ? priceValues[0][0] : priceValues[1][0];
      const secondPrice = correctOrder ? priceValues[1][0] : priceValues[0][0];
      const priceChange = secondPrice - firstPrice;
      const pctChange = 100 * priceChange / firstPrice;
      const positive2 = priceChange >= 0;
      deltaContent.deltaTopLine = (positive2 ? "+" : "") + priceChange.toFixed(2);
      deltaContent.deltaBottomLine = (positive2 ? "+" : "") + pctChange.toFixed(2) + "%";
      deltaContent.deltaBackgroundColor = positive2 ? "rgb(4,153,129, 0.2)" : "rgb(239,83,80, 0.2)";
      deltaContent.deltaTextColor = positive2 ? "rgb(4,153,129)" : "rgb(239,83,80)";
      this._activeRange.fire({
        from: priceValues[correctOrder ? 0 : 1][1] + 1,
        to: priceValues[correctOrder ? 1 : 0][1] + 1,
        positive: positive2
      });
    } else {
      deltaContent.deltaTopLine = "";
      deltaContent.deltaBottomLine = "";
      this._activeRange.fire(null);
    }
    this.setData(crosshairData, deltaContent);
  }
}
const REFIRE_COOLDOWN_SEC = 30;
function linePriceAt(d, timeSec) {
  if (!d.alertEnabled) return null;
  if (d.type === "horizontal") return d.price;
  if (d.type === "trendline") {
    if (d.time == null || d.time2 == null || d.price2 == null) return null;
    const dt = d.time2 - d.time;
    if (dt === 0) return null;
    const slope = (d.price2 - d.price) / dt;
    return d.price + slope * (timeSec - d.time);
  }
  return null;
}
function detectCrossings(drawings, prevMid, mid, nowSec, firedAt) {
  const out = [];
  for (const d of drawings) {
    const lp = linePriceAt(d, nowSec);
    if (lp == null) continue;
    if (prevMid < lp === mid < lp) continue;
    if (nowSec - (firedAt.get(d.id) ?? 0) < REFIRE_COOLDOWN_SEC) continue;
    firedAt.set(d.id, nowSec);
    out.push(d);
  }
  return out;
}
function playAlertBeep() {
  if (typeof AudioContext === "undefined") return;
  try {
    const ac = new AudioContext();
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.frequency.value = 880;
    gain.gain.value = 0.05;
    osc.connect(gain);
    gain.connect(ac.destination);
    osc.start();
    osc.stop(ac.currentTime + 0.15);
    osc.onended = () => ac.close();
  } catch {
  }
}
const HANDLE_RADIUS = 5;
const LINE_WIDTH = 2;
const FIB_BAND_ALPHA = 0.08;
const RECT_FILL_ALPHA = 0.14;
function hexToRgba(hex, alpha2) {
  const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!m) return hex;
  return `rgba(${parseInt(m[1], 16)}, ${parseInt(m[2], 16)}, ${parseInt(m[3], 16)}, ${alpha2})`;
}
function alpha(value, fallback) {
  return typeof value === "number" && Number.isFinite(value) ? Math.min(1, Math.max(0, value)) : fallback;
}
function drawingPresentation(d) {
  return {
    strokeColor: hexToRgba(d.color, alpha(d.opacity, 1)),
    fillColor: hexToRgba(d.fillColor ?? d.color, alpha(d.fillOpacity, RECT_FILL_ALPHA)),
    textAlign: d.textAlign ?? "center",
    textPlacement: d.textPlacement ?? "inside",
    positiveColor: d.positiveColor ?? POS_GREEN,
    negativeColor: d.negativeColor ?? POS_RED,
    labelColor: d.labelColor ?? "#ffffff",
    stopColor: d.stopColor ?? POS_RED,
    targetColor: d.targetColor ?? POS_GREEN,
    stopFillOpacity: alpha(d.stopFillOpacity, 0.2),
    targetFillOpacity: alpha(d.targetFillOpacity, 0.2)
  };
}
function positionLinePresentation(d) {
  return {
    color: drawingPresentation(d).strokeColor,
    width: d.width ?? 1.5,
    dash: dashFor(d.lineStyle)
  };
}
function shouldRenderPositionReadout(d, state) {
  return Boolean(d.alwaysShowStats) || state === "selected" || state === "hovered" || state === "preview";
}
function toBitmap(scope, x, y) {
  return {
    x: Math.round(x * scope.horizontalPixelRatio),
    y: Math.round(y * scope.verticalPixelRatio)
  };
}
function showHandles(e) {
  return e.state === "hovered" || e.state === "selected";
}
function dashFor(style) {
  if (style === "dashed") return [6, 6];
  if (style === "dotted") return [2, 3];
  return void 0;
}
function applyDash(scope, dash) {
  if (!dash) return;
  scope.context.setLineDash(dash.map((v) => v * scope.horizontalPixelRatio));
}
function strokeLine(scope, a, b, color, widthMedia, dash) {
  const ctx = scope.context;
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = widthMedia * scope.verticalPixelRatio;
  applyDash(scope, dash);
  ctx.beginPath();
  ctx.moveTo(a.x, a.y);
  ctx.lineTo(b.x, b.y);
  ctx.stroke();
  ctx.restore();
}
function drawHandle(scope, p, color) {
  const ctx = scope.context;
  ctx.save();
  ctx.beginPath();
  ctx.arc(p.x, p.y, HANDLE_RADIUS * scope.horizontalPixelRatio, 0, Math.PI * 2);
  ctx.fillStyle = "#ffffff";
  ctx.fill();
  ctx.lineWidth = 1.5 * scope.horizontalPixelRatio;
  ctx.strokeStyle = color;
  ctx.stroke();
  ctx.restore();
}
function renderEntry(scope, e, info) {
  var _a;
  switch (e.d.type) {
    case "trendline":
      renderTrendline(scope, e);
      break;
    case "horizontal":
      renderHorizontal(scope, e);
      break;
    case "rectangle":
      renderRectangle(scope, e);
      break;
    case "fibonacci":
      renderFibonacci(scope, e);
      break;
    case "position":
      renderPosition(scope, e, info);
      break;
    case "vertical":
      renderVertical(scope, e);
      break;
    case "channel":
      renderChannel(scope, e);
      break;
    case "ellipse":
      renderEllipse(scope, e);
      break;
    case "arrow":
      renderArrow(scope, e);
      break;
    case "triangle":
      renderTriangle(scope, e);
      break;
    case "text":
      renderText(scope, e);
      break;
    case "anchored-text":
      renderText(scope, e);
      break;
    case "note":
      renderNote(scope, e);
      break;
    case "brush":
    case "highlighter":
    case "path":
    case "polyline":
      renderPath(scope, e);
      break;
    case "curve":
      renderCurve(scope, e);
      break;
    case "price-range":
    case "date-range":
    case "date-price-range":
      renderRange(scope, e);
      break;
    case "fibextension":
      renderFibonacci(scope, e);
      break;
  }
  if (supportsAttachedText(e.d) && ((_a = e.d.text) == null ? void 0 : _a.trim())) renderAttachedText(scope, e);
}
function supportsAttachedText(d) {
  return d.type === "trendline" || d.type === "horizontal" || d.type === "vertical" || d.type === "arrow" || d.type === "channel" || d.type === "rectangle" || d.type === "ellipse" || d.type === "triangle" || d.type === "brush" || d.type === "highlighter" || d.type === "path" || d.type === "polyline" || d.type === "curve";
}
function renderAttachedText(scope, e) {
  var _a;
  const points = ((_a = e.points) == null ? void 0 : _a.map((point) => toBitmap(scope, point.x, point.y))) ?? [];
  const anchors = [
    ...e.x1 !== null && e.y1 !== null ? [toBitmap(scope, e.x1, e.y1)] : [],
    ...e.x2 !== null && e.y2 !== null ? [toBitmap(scope, e.x2, e.y2)] : [],
    ...points
  ];
  if (anchors.length === 0) return;
  const left = Math.min(...anchors.map((point) => point.x));
  const right = Math.max(...anchors.map((point) => point.x));
  const top = Math.min(...anchors.map((point) => point.y));
  const bottom = Math.max(...anchors.map((point) => point.y));
  const size = (e.d.fontSize ?? 14) * scope.verticalPixelRatio;
  const pad = 4 * scope.horizontalPixelRatio;
  const presentation = drawingPresentation(e.d);
  let x = presentation.textAlign === "left" ? left + pad : presentation.textAlign === "right" ? right - pad : (left + right) / 2;
  let y = (top + bottom - size) / 2;
  if (presentation.textPlacement === "above") y = top - size - 8 * scope.verticalPixelRatio;
  else if (presentation.textPlacement === "below") y = bottom + 8 * scope.verticalPixelRatio;
  else if (presentation.textPlacement === "outside") {
    x = right + 8 * scope.horizontalPixelRatio;
    y = (top + bottom - size) / 2;
  }
  renderTextAt(scope, e, { x, y });
}
function renderPath(scope, e) {
  if (!e.points || e.points.length < 2) return;
  const points = e.points.map((point) => toBitmap(scope, point.x, point.y));
  const ctx = scope.context;
  ctx.save();
  ctx.strokeStyle = drawingPresentation(e.d).strokeColor;
  ctx.lineWidth = (e.d.width ?? (e.d.type === "highlighter" ? 12 : 2)) * scope.verticalPixelRatio;
  ctx.globalAlpha = e.d.type === "highlighter" ? 0.35 : 1;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  applyDash(scope, dashFor(e.d.lineStyle));
  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  if (e.d.smooth && points.length > 2) {
    for (let index = 1; index < points.length - 1; index += 1) {
      const point = points[index];
      const next = points[index + 1];
      ctx.quadraticCurveTo(point.x, point.y, (point.x + next.x) / 2, (point.y + next.y) / 2);
    }
    ctx.lineTo(points.at(-1).x, points.at(-1).y);
  } else {
    for (const point of points.slice(1)) ctx.lineTo(point.x, point.y);
  }
  if (e.d.closed) ctx.closePath();
  ctx.stroke();
  ctx.restore();
  if (showHandles(e)) for (const point of points) drawHandle(scope, point, e.d.color);
}
function renderCurve(scope, e) {
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null || !e.control) return;
  const start2 = toBitmap(scope, e.x1, e.y1);
  const control = toBitmap(scope, e.control.x, e.control.y);
  const end = toBitmap(scope, e.x2, e.y2);
  const ctx = scope.context;
  ctx.save();
  ctx.strokeStyle = drawingPresentation(e.d).strokeColor;
  ctx.lineWidth = (e.d.width ?? LINE_WIDTH) * scope.verticalPixelRatio;
  applyDash(scope, dashFor(e.d.lineStyle));
  ctx.beginPath();
  ctx.moveTo(start2.x, start2.y);
  ctx.quadraticCurveTo(control.x, control.y, end.x, end.y);
  ctx.stroke();
  ctx.restore();
  if (showHandles(e)) {
    strokeLine(scope, start2, control, hexToRgba(e.d.color, 0.45), 1, [3, 3]);
    strokeLine(scope, control, end, hexToRgba(e.d.color, 0.45), 1, [3, 3]);
    drawHandle(scope, start2, e.d.color);
    drawHandle(scope, control, e.d.color);
    drawHandle(scope, end, e.d.color);
  }
}
function renderRange(scope, e) {
  var _a;
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null) return;
  const a = toBitmap(scope, e.x1, e.y1);
  const b = toBitmap(scope, e.x2, e.y2);
  const left = Math.min(a.x, b.x);
  const top = e.d.type === "date-range" ? 0 : Math.min(a.y, b.y);
  const width = Math.abs(b.x - a.x);
  const height = e.d.type === "date-range" ? scope.bitmapSize.height : Math.abs(b.y - a.y);
  const positive2 = e.d.price2 == null || e.d.price2 >= e.d.price;
  const presentation = drawingPresentation(e.d);
  const color = e.d.type === "date-range" ? presentation.strokeColor : positive2 ? presentation.positiveColor : presentation.negativeColor;
  const ctx = scope.context;
  ctx.save();
  ctx.fillStyle = e.d.fillColor ? presentation.fillColor : hexToRgba(color, alpha(e.d.fillOpacity, 0.12));
  ctx.fillRect(left, top, width, height);
  ctx.strokeStyle = presentation.strokeColor;
  ctx.lineWidth = (e.d.width ?? 1) * scope.verticalPixelRatio;
  applyDash(scope, dashFor(e.d.lineStyle));
  ctx.strokeRect(left, top, width, height);
  ctx.restore();
  if (showHandles(e)) {
    if (e.d.type === "date-range") {
      const middle = Math.round(scope.bitmapSize.height / 2);
      drawHandle(scope, { x: a.x, y: middle }, e.d.color);
      drawHandle(scope, { x: b.x, y: middle }, e.d.color);
    } else {
      drawRectHandles(scope, a, b, e.d.color);
    }
  }
  if ((_a = e.stats) == null ? void 0 : _a.length) drawLabelBox(scope, Math.max(a.x, b.x) + 8, top, e.stats, color);
}
function renderNote(scope, e) {
  if (e.x1 === null || e.y1 === null) return;
  const at = toBitmap(scope, e.x1, e.y1);
  const ctx = scope.context;
  const size = 16 * scope.horizontalPixelRatio;
  const left = at.x - size / 2;
  const top = at.y - size / 2;
  ctx.save();
  ctx.fillStyle = e.d.color;
  ctx.beginPath();
  ctx.roundRect(left, top, size, size, 3 * scope.horizontalPixelRatio);
  ctx.fill();
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = scope.horizontalPixelRatio;
  ctx.beginPath();
  ctx.moveTo(left + size * 0.3, top + size * 0.35);
  ctx.lineTo(left + size * 0.7, top + size * 0.35);
  ctx.moveTo(left + size * 0.3, top + size * 0.55);
  ctx.lineTo(left + size * 0.62, top + size * 0.55);
  ctx.stroke();
  ctx.restore();
  if (showHandles(e)) {
    drawHandle(scope, at, e.d.color);
    if (e.d.text) drawLabelBox(scope, at.x + size, at.y, e.d.text.split("\n"), e.d.color);
  }
}
function renderVertical(scope, e) {
  if (e.x1 === null) return;
  const x = Math.round(e.x1 * scope.horizontalPixelRatio);
  strokeLine(
    scope,
    { x, y: 0 },
    { x, y: scope.bitmapSize.height },
    drawingPresentation(e.d).strokeColor,
    e.d.width ?? 1.5,
    dashFor(e.d.lineStyle)
  );
  if (showHandles(e)) {
    drawHandle(scope, { x, y: Math.round(scope.bitmapSize.height / 2) }, e.d.color);
  }
}
function renderChannel(scope, e) {
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null) return;
  if (e.y3 == null) return;
  const dy = e.y3 - e.y1;
  const a1 = toBitmap(scope, e.x1, e.y1);
  const b1 = toBitmap(scope, e.x2, e.y2);
  const a2 = toBitmap(scope, e.x1, e.y3);
  const b2 = toBitmap(scope, e.x2, e.y2 + dy);
  const ctx = scope.context;
  ctx.save();
  const presentation = drawingPresentation(e.d);
  ctx.fillStyle = e.d.fillColor ? presentation.fillColor : hexToRgba(e.d.color, alpha(e.d.fillOpacity, 0.1));
  ctx.beginPath();
  ctx.moveTo(a1.x, a1.y);
  ctx.lineTo(b1.x, b1.y);
  ctx.lineTo(b2.x, b2.y);
  ctx.lineTo(a2.x, a2.y);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
  const dash = dashFor(e.d.lineStyle);
  strokeLine(scope, a1, b1, presentation.strokeColor, e.d.width ?? LINE_WIDTH, dash);
  strokeLine(scope, a2, b2, e.d.secondaryColor ? hexToRgba(e.d.secondaryColor, alpha(e.d.opacity, 1)) : presentation.strokeColor, e.d.secondaryWidth ?? e.d.width ?? LINE_WIDTH, dashFor(e.d.secondaryLineStyle ?? e.d.lineStyle));
  if (showHandles(e)) {
    drawHandle(scope, a1, e.d.color);
    drawHandle(scope, b1, e.d.color);
    drawHandle(scope, a2, e.d.color);
  }
}
function renderEllipse(scope, e) {
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null) return;
  const a = toBitmap(scope, e.x1, e.y1);
  const b = toBitmap(scope, e.x2, e.y2);
  const ctx = scope.context;
  const cx = (a.x + b.x) / 2;
  const cy = (a.y + b.y) / 2;
  ctx.save();
  ctx.beginPath();
  ctx.ellipse(cx, cy, Math.abs(b.x - a.x) / 2, Math.abs(b.y - a.y) / 2, 0, 0, Math.PI * 2);
  const presentation = drawingPresentation(e.d);
  ctx.fillStyle = presentation.fillColor;
  ctx.fill();
  ctx.strokeStyle = presentation.strokeColor;
  ctx.lineWidth = (e.d.width ?? 1.5) * scope.verticalPixelRatio;
  applyDash(scope, dashFor(e.d.lineStyle));
  ctx.stroke();
  ctx.restore();
  if (showHandles(e)) drawRectHandles(scope, a, b, e.d.color);
}
function renderArrow(scope, e) {
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null) return;
  const a = toBitmap(scope, e.x1, e.y1);
  const b = toBitmap(scope, e.x2, e.y2);
  const stroke = drawingPresentation(e.d).strokeColor;
  strokeLine(scope, a, b, stroke, e.d.width ?? LINE_WIDTH, dashFor(e.d.lineStyle));
  drawArrowhead(scope, a, b, stroke);
  if (showHandles(e)) {
    drawHandle(scope, a, e.d.color);
    drawHandle(scope, b, e.d.color);
  }
}
function drawArrowhead(scope, from, to, color) {
  const ctx = scope.context;
  const ang = Math.atan2(to.y - from.y, to.x - from.x);
  const len = 12 * scope.horizontalPixelRatio;
  const spread = Math.PI / 7;
  ctx.save();
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(to.x, to.y);
  ctx.lineTo(to.x - len * Math.cos(ang - spread), to.y - len * Math.sin(ang - spread));
  ctx.lineTo(to.x - len * Math.cos(ang + spread), to.y - len * Math.sin(ang + spread));
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}
function renderTriangle(scope, e) {
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null) return;
  const a = toBitmap(scope, e.x1, e.y1);
  const b = toBitmap(scope, e.x2, e.y2);
  const ctx = scope.context;
  ctx.save();
  ctx.beginPath();
  ctx.moveTo((a.x + b.x) / 2, a.y);
  ctx.lineTo(b.x, b.y);
  ctx.lineTo(a.x, b.y);
  ctx.closePath();
  const presentation = drawingPresentation(e.d);
  ctx.fillStyle = presentation.fillColor;
  ctx.fill();
  ctx.strokeStyle = presentation.strokeColor;
  ctx.lineWidth = (e.d.width ?? 1.5) * scope.verticalPixelRatio;
  applyDash(scope, dashFor(e.d.lineStyle));
  ctx.stroke();
  ctx.restore();
  if (showHandles(e)) {
    drawHandle(scope, a, e.d.color);
    drawHandle(scope, b, e.d.color);
  }
}
function textFont(d, sizePx) {
  const style = d.italic ? "italic " : "";
  const weight = d.bold ? "bold " : "";
  return `${style}${weight}${Math.round(sizePx)}px ${TRADINGVIEW_FONT_FAMILY$1}`;
}
const TRADINGVIEW_FONT_FAMILY$1 = `-apple-system, BlinkMacSystemFont, "Trebuchet MS", Roboto, Ubuntu, sans-serif`;
function renderText(scope, e) {
  if (e.x1 === null || e.y1 === null) return;
  renderTextAt(scope, e, toBitmap(scope, e.x1, e.y1));
}
function renderTextAt(scope, e, at) {
  const ctx = scope.context;
  const hpr = scope.horizontalPixelRatio;
  const size = (e.d.fontSize ?? 14) * scope.verticalPixelRatio;
  const lines = (e.d.text ?? "Text").split("\n");
  const lineH = size * 1.3;
  const pad = 4 * hpr;
  ctx.save();
  ctx.font = textFont(e.d, size);
  ctx.textBaseline = "top";
  const presentation = drawingPresentation(e.d);
  ctx.textAlign = presentation.textAlign;
  const textW = Math.max(...lines.map((l) => ctx.measureText(l).width));
  const boxW = textW + pad * 2;
  const boxH = lines.length * lineH + pad * 2;
  const bx = presentation.textAlign === "center" ? at.x - textW / 2 - pad : presentation.textAlign === "right" ? at.x - textW - pad : at.x - pad;
  const by = at.y - pad;
  if (e.d.textBg) {
    ctx.fillStyle = e.d.textBgColor ?? "#1e222d";
    ctx.fillRect(bx, by, boxW, boxH);
  }
  if (e.d.textBorder) {
    ctx.strokeStyle = e.d.textBorderColor ?? e.d.color;
    ctx.lineWidth = hpr;
    ctx.strokeRect(bx, by, boxW, boxH);
  }
  ctx.fillStyle = presentation.strokeColor;
  lines.forEach((l, i) => ctx.fillText(l, at.x, at.y + i * lineH));
  if (showHandles(e)) {
    ctx.strokeStyle = e.d.color;
    ctx.lineWidth = hpr;
    ctx.setLineDash([3 * hpr, 3 * hpr]);
    ctx.strokeRect(bx, by, boxW, boxH);
  }
  ctx.restore();
}
const POS_GREEN = "#089981";
const POS_RED = "#f23645";
function renderPosition(scope, e, info) {
  const { x1, x2, y1, yStop, yTarget } = e;
  if (x1 === null || x2 === null || y1 === null || yStop == null || yTarget == null) return;
  const xa = Math.min(x1, x2);
  const xb = Math.max(x1, x2);
  const presentation = drawingPresentation(e.d);
  posZone(scope, xa, xb, y1, yTarget, presentation.targetColor, presentation.targetFillOpacity);
  posZone(scope, xa, xb, y1, yStop, presentation.stopColor, presentation.stopFillOpacity);
  const line = positionLinePresentation(e.d);
  strokeLine(scope, toBitmap(scope, xa, y1), toBitmap(scope, xb, y1), line.color, line.width, line.dash);
  if (showHandles(e)) renderPositionHandles(scope, e, xa, xb, y1);
  const lines = shouldRenderPositionReadout(e.d, e.state) ? positionReadout(e.d, info) : [];
  if (lines.length > 0) {
    const at = toBitmap(scope, xb + 8, y1);
    drawLabelBox(scope, at.x, at.y, lines, e.d.color, presentation.labelColor, e.d.fontSize);
  }
}
function posZone(scope, xa, xb, yFrom, yTo, color, fillOpacity) {
  const ctx = scope.context;
  const a = toBitmap(scope, xa, Math.min(yFrom, yTo));
  const b = toBitmap(scope, xb, Math.max(yFrom, yTo));
  ctx.save();
  ctx.fillStyle = hexToRgba(color, fillOpacity);
  ctx.fillRect(a.x, a.y, b.x - a.x, b.y - a.y);
  ctx.strokeStyle = hexToRgba(color, 0.6);
  ctx.lineWidth = scope.verticalPixelRatio;
  ctx.strokeRect(a.x, a.y, b.x - a.x, b.y - a.y);
  ctx.restore();
}
function renderPositionHandles(scope, e, xa, xb, y1) {
  const xm = (xa + xb) / 2;
  drawHandle(scope, toBitmap(scope, xm, y1), e.d.color);
  if (e.yTarget != null) drawHandle(scope, toBitmap(scope, xm, e.yTarget), e.d.color);
  if (e.yStop != null) drawHandle(scope, toBitmap(scope, xm, e.yStop), e.d.color);
  drawHandle(scope, toBitmap(scope, xb, y1), e.d.color);
}
function positionReadout(d, info) {
  if (d.stopPrice == null || d.targetPrice == null) return [];
  const reward = Math.abs(d.targetPrice - d.price);
  const risk = Math.abs(d.price - d.stopPrice);
  const rr = risk > 0 ? reward / risk : 0;
  const side = d.side === "short" ? "Short" : "Long";
  const heading = `${side}  RR ${rr.toFixed(2)}`;
  if (d.compactStats && d.statsMode === "risk-reward") return [`${side} · RR ${rr.toFixed(2)}`];
  if (d.statsMode === "risk-reward") return [heading];
  const priceLines = [
    `T ${info.priceFormat(d.targetPrice)}  ${signPct(d.targetPrice, d.price)}`,
    `S ${info.priceFormat(d.stopPrice)}  ${signPct(d.stopPrice, d.price)}`
  ];
  const account = typeof d.accountSize === "number" && Number.isFinite(d.accountSize) && d.accountSize > 0 ? d.accountSize : info.accountEquity;
  const amountLines = [];
  if (account > 0 && risk > 0) {
    const riskValue = d.riskValue ?? d.riskPct ?? 1;
    const riskAmt = d.riskUnit === "currency" ? riskValue : account * riskValue / 100;
    const qty = riskAmt / (risk * (d.lotSize ?? 1));
    const targetAmt = reward * qty * (d.lotSize ?? 1);
    const stopAmt = risk * qty * (d.lotSize ?? 1);
    amountLines.push(
      `Target $${targetAmt.toFixed(0)}`,
      `Stop $${stopAmt.toFixed(0)}`,
      `Risk $${riskAmt.toFixed(0)} · Qty ${qty >= 100 ? qty.toFixed(0) : qty.toFixed(2)}`
    );
  }
  if (d.statsMode === "amounts") return [heading, ...amountLines];
  if (d.statsMode === "all") return [heading, ...priceLines, ...amountLines];
  return [heading, ...priceLines, ...amountLines.length ? [amountLines.at(-1)] : []];
}
function signPct(v, entry) {
  if (entry === 0) return "0%";
  const p = (v - entry) / entry * 100;
  return `${p >= 0 ? "+" : ""}${p.toFixed(2)}%`;
}
function drawLabelBox(scope, x, y, lines, borderColor, textColor = "#e0e3ea", fontSize = 10) {
  const ctx = scope.context;
  const hpr = scope.horizontalPixelRatio;
  const vpr = scope.verticalPixelRatio;
  ctx.save();
  ctx.font = `${Math.round(fontSize * vpr)}px ${TRADINGVIEW_FONT_FAMILY$1}`;
  const lineH = (fontSize + 3) * vpr;
  const pad = 6 * hpr;
  const width = Math.max(...lines.map((l) => ctx.measureText(l).width)) + pad * 2;
  const height = lines.length * lineH + pad;
  const bx = Math.min(x, scope.bitmapSize.width - width);
  const by = Math.min(Math.max(y, 0), scope.bitmapSize.height - height);
  ctx.fillStyle = "rgba(20, 24, 35, 0.92)";
  ctx.beginPath();
  ctx.roundRect(bx, by, width, height, 4 * hpr);
  ctx.fill();
  ctx.strokeStyle = borderColor;
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = textColor;
  ctx.textBaseline = "top";
  lines.forEach((l, i) => ctx.fillText(l, bx + pad, by + pad / 2 + i * lineH));
  ctx.restore();
}
function renderTrendline(scope, e) {
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null) return;
  const a = toBitmap(scope, e.x1, e.y1);
  const b = toBitmap(scope, e.x2, e.y2);
  const seg = e.seg ?? { x1: e.x1, y1: e.y1, x2: e.x2, y2: e.y2 };
  const sa = toBitmap(scope, seg.x1, seg.y1);
  const sb = toBitmap(scope, seg.x2, seg.y2);
  const stroke = drawingPresentation(e.d).strokeColor;
  strokeLine(scope, sa, sb, stroke, e.d.width ?? LINE_WIDTH, dashFor(e.d.lineStyle));
  if (e.d.arrowEnd) drawArrowhead(scope, sa, sb, stroke);
  if (e.d.arrowStart) drawArrowhead(scope, sb, sa, stroke);
  if (showHandles(e)) {
    drawHandle(scope, a, e.d.color);
    drawHandle(scope, b, e.d.color);
    drawMidpointHandle(scope, a, b, e.d.color);
  }
  if (e.d.alertEnabled) {
    const right = a.x >= b.x ? a : b;
    drawAlertBadge(scope, right.x, right.y);
  }
  if (e.stats && e.stats.length > 0) drawStatsBox(scope, b, e.stats, e.d, a);
}
function drawMidpointHandle(scope, a, b, color) {
  const ctx = scope.context;
  const half = 3 * scope.horizontalPixelRatio;
  const mx = (a.x + b.x) / 2;
  const my = (a.y + b.y) / 2;
  ctx.save();
  ctx.fillStyle = "#ffffff";
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.5 * scope.horizontalPixelRatio;
  ctx.beginPath();
  ctx.rect(mx - half, my - half, half * 2, half * 2);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}
function drawStatsBox(scope, at, stats, d, from) {
  const ctx = scope.context;
  const hpr = scope.horizontalPixelRatio;
  const vpr = scope.verticalPixelRatio;
  const angleDeg = Math.round(Math.atan2(from.y - at.y, at.x - from.x) * 180 / Math.PI);
  const lines = [...stats, `${angleDeg}°`];
  ctx.save();
  ctx.font = `${Math.round(10 * vpr)}px ${TRADINGVIEW_FONT_FAMILY$1}`;
  const lineH = 13 * vpr;
  const pad = 6 * hpr;
  const width = Math.max(...lines.map((l) => ctx.measureText(l).width)) + pad * 2;
  const height = lines.length * lineH + pad;
  const x = Math.min(at.x + 10 * hpr, scope.bitmapSize.width - width);
  const y = Math.min(at.y + 10 * vpr, scope.bitmapSize.height - height);
  ctx.fillStyle = "rgba(20, 24, 35, 0.92)";
  ctx.beginPath();
  ctx.roundRect(x, y, width, height, 4 * hpr);
  ctx.fill();
  ctx.strokeStyle = d.color;
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = "#e0e3ea";
  ctx.textBaseline = "top";
  lines.forEach((line, i) => {
    ctx.fillText(line, x + pad, y + pad / 2 + i * lineH);
  });
  ctx.restore();
}
function renderHorizontal(scope, e) {
  if (e.y1 === null) return;
  const y = Math.round(e.y1 * scope.verticalPixelRatio);
  strokeLine(
    scope,
    { x: 0, y },
    { x: scope.bitmapSize.width, y },
    drawingPresentation(e.d).strokeColor,
    e.d.width ?? 1.5,
    dashFor(e.d.lineStyle)
  );
  if (showHandles(e))
    drawHandle(scope, { x: Math.round(scope.bitmapSize.width / 2), y }, e.d.color);
  if (e.d.alertEnabled) {
    drawAlertBadge(scope, scope.bitmapSize.width - 14 * scope.horizontalPixelRatio, y);
  }
}
function drawAlertBadge(scope, x, y) {
  const ctx = scope.context;
  const r = 4 * scope.horizontalPixelRatio;
  ctx.save();
  ctx.fillStyle = "#f0b90b";
  ctx.strokeStyle = "#1b1f2a";
  ctx.lineWidth = scope.horizontalPixelRatio;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}
function renderRectangle(scope, e) {
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null) return;
  const a = toBitmap(scope, e.x1, e.y1);
  const b = toBitmap(scope, e.x2, e.y2);
  const ctx = scope.context;
  ctx.save();
  const presentation = drawingPresentation(e.d);
  ctx.fillStyle = presentation.fillColor;
  ctx.fillRect(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y));
  ctx.strokeStyle = presentation.strokeColor;
  ctx.lineWidth = (e.d.width ?? 1.5) * scope.verticalPixelRatio;
  applyDash(scope, dashFor(e.d.lineStyle));
  ctx.strokeRect(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y));
  ctx.restore();
  if (showHandles(e)) drawRectHandles(scope, a, b, e.d.color);
}
function drawRectHandles(scope, a, b, color) {
  drawHandle(scope, a, color);
  drawHandle(scope, b, color);
  drawHandle(scope, { x: a.x, y: b.y }, color);
  drawHandle(scope, { x: b.x, y: a.y }, color);
}
function renderFibonacci(scope, e) {
  if (e.x1 === null || e.x2 === null || !e.fibLevels || e.fibLevels.length === 0) return;
  const xA = Math.round(Math.min(e.x1, e.x2) * scope.horizontalPixelRatio);
  const xB = Math.round(Math.max(e.x1, e.x2) * scope.horizontalPixelRatio);
  renderFibBands(scope, e.fibLevels, xA, xB);
  for (const lvl of e.fibLevels) renderFibLevel(scope, lvl, xA, xB);
  renderFibConnector(scope, e);
}
function renderFibBands(scope, levels, xA, xB) {
  const ctx = scope.context;
  for (let i = 0; i < levels.length - 1; i++) {
    const top = levels[i];
    const bottom = levels[i + 1];
    if (top.y === null || bottom.y === null) continue;
    const yA = Math.round(top.y * scope.verticalPixelRatio);
    const yB = Math.round(bottom.y * scope.verticalPixelRatio);
    ctx.fillStyle = hexToRgba(bottom.color, FIB_BAND_ALPHA);
    ctx.fillRect(xA, Math.min(yA, yB), xB - xA, Math.abs(yB - yA));
  }
}
function renderFibLevel(scope, lvl, xA, xB) {
  if (lvl.y === null) return;
  const y = Math.round(lvl.y * scope.verticalPixelRatio);
  strokeLine(scope, { x: xA, y }, { x: xB, y }, lvl.color, 1);
  const ctx = scope.context;
  ctx.save();
  ctx.font = `${Math.round(10 * scope.verticalPixelRatio)}px ${TRADINGVIEW_FONT_FAMILY$1}`;
  ctx.textAlign = "right";
  ctx.textBaseline = "middle";
  ctx.fillStyle = lvl.color;
  ctx.fillText(lvl.label, xA - 6 * scope.horizontalPixelRatio, y);
  ctx.restore();
}
function renderFibConnector(scope, e) {
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null) return;
  const a = toBitmap(scope, e.x1, e.y1);
  const b = toBitmap(scope, e.x2, e.y2);
  strokeLine(scope, a, b, e.d.color, 1, [4, 4]);
  if (showHandles(e)) {
    drawHandle(scope, a, e.d.color);
    drawHandle(scope, b, e.d.color);
  }
}
function dist(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}
function distToSegment(p, a, b) {
  const abx = b.x - a.x;
  const aby = b.y - a.y;
  const lenSq = abx * abx + aby * aby;
  if (lenSq === 0) return dist(p, a);
  const t = Math.max(0, Math.min(1, ((p.x - a.x) * abx + (p.y - a.y) * aby) / lenSq));
  return dist(p, { x: a.x + t * abx, y: a.y + t * aby });
}
function snapAngle(anchor, p) {
  const dx = p.x - anchor.x;
  const dy = p.y - anchor.y;
  const r = Math.hypot(dx, dy);
  if (r < 1) return p;
  const step = Math.PI / 4;
  const angle = Math.round(Math.atan2(dy, dx) / step) * step;
  return { x: anchor.x + r * Math.cos(angle), y: anchor.y + r * Math.sin(angle) };
}
function pointInBox(p, x1, y1, x2, y2, tolerance) {
  const minX = Math.min(x1, x2) - tolerance;
  const maxX = Math.max(x1, x2) + tolerance;
  const minY = Math.min(y1, y2) - tolerance;
  const maxY = Math.max(y1, y2) + tolerance;
  return p.x >= minX && p.x <= maxX && p.y >= minY && p.y <= maxY;
}
function simplifyPath(points, tolerance) {
  const unique = points.filter(
    (point, index) => index === 0 || dist(point, points[index - 1]) > 0
  );
  if (unique.length <= 2) return unique;
  const simplify = (start2, end) => {
    let furthestIndex = -1;
    let furthestDistance = tolerance;
    for (let index = start2 + 1; index < end; index += 1) {
      const distance = distToSegment(unique[index], unique[start2], unique[end]);
      if (distance > furthestDistance) {
        furthestDistance = distance;
        furthestIndex = index;
      }
    }
    if (furthestIndex < 0) return [unique[start2], unique[end]];
    return [
      ...simplify(start2, furthestIndex).slice(0, -1),
      ...simplify(furthestIndex, end)
    ];
  };
  return simplify(0, unique.length - 1);
}
function quadraticPoint(start2, control, end, t) {
  const inverse = 1 - t;
  return {
    x: inverse * inverse * start2.x + 2 * inverse * t * control.x + t * t * end.x,
    y: inverse * inverse * start2.y + 2 * inverse * t * control.y + t * t * end.y
  };
}
function distToPolyline(point, line) {
  if (line.length === 0) return Number.POSITIVE_INFINITY;
  if (line.length === 1) return dist(point, line[0]);
  let result = Number.POSITIVE_INFINITY;
  for (let index = 1; index < line.length; index += 1) {
    result = Math.min(result, distToSegment(point, line[index - 1], line[index]));
  }
  return result;
}
function distToQuadratic(point, start2, control, end) {
  const segments = 32;
  let previous = start2;
  let result = Number.POSITIVE_INFINITY;
  for (let index = 1; index <= segments; index += 1) {
    const current2 = quadraticPoint(start2, control, end, index / segments);
    result = Math.min(result, distToSegment(point, previous, current2));
    previous = current2;
  }
  return result;
}
function rangeStats(startTime, endTime, startPrice, endPrice, barTimes) {
  const priceChange = endPrice - startPrice;
  const minTime = Math.min(startTime, endTime);
  const maxTime = Math.max(startTime, endTime);
  const visibleBars = barTimes.filter((time) => time >= minTime && time <= maxTime).length;
  return {
    priceChange,
    percentChange: startPrice === 0 ? 0 : priceChange / startPrice * 100,
    bars: Math.max(0, visibleBars - 1),
    durationSec: maxTime - minTime
  };
}
const FIB_LEVELS = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1];
const FIB_EXT_LEVELS = [0, 0.618, 1, 1.618, 2.618];
const FIB_COLORS = [
  "#e91e63",
  "#ff5722",
  "#ff9800",
  "#ffc107",
  "#4caf50",
  "#2196F3",
  "#9c27b0"
];
function makeResolveCtx(chart, series, intervalSec) {
  return { chart, series, intervalSec, data: series.data() };
}
function lowerBound(data, time) {
  let lo = 0;
  let hi = data.length;
  while (lo < hi) {
    const mid = lo + hi >> 1;
    if (data[mid].time < time) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}
function timeToX(ctx, time) {
  const ts = ctx.chart.timeScale();
  const direct = ts.timeToCoordinate(time);
  if (direct !== null) return direct;
  const logical = timeToLogical(ctx, time);
  if (logical === null) return null;
  return logicalToX(ts, logical);
}
function logicalToX(ts, logical) {
  const lo = Math.floor(logical);
  const xLo = ts.logicalToCoordinate(lo);
  if (xLo === null) return null;
  const frac = logical - lo;
  if (frac === 0) return xLo;
  const xHi = ts.logicalToCoordinate(lo + 1);
  if (xHi === null) return null;
  return xLo + frac * (xHi - xLo);
}
function timeToLogical(ctx, time) {
  const { data, intervalSec } = ctx;
  if (data.length === 0 || intervalSec <= 0) return null;
  const firstTime = data[0].time;
  const lastTime = data[data.length - 1].time;
  if (time <= firstTime) return (time - firstTime) / intervalSec;
  if (time >= lastTime) return data.length - 1 + (time - lastTime) / intervalSec;
  const idx = lowerBound(data, time);
  const t1 = data[idx - 1].time;
  const t2 = data[idx].time;
  return idx - 1 + (time - t1) / Math.max(t2 - t1, 1);
}
function xToTime(ctx, x) {
  const direct = ctx.chart.timeScale().coordinateToTime(x);
  if (direct !== null) return direct;
  const { data, intervalSec } = ctx;
  if (data.length === 0 || intervalSec <= 0) return null;
  const logical = ctx.chart.timeScale().coordinateToLogical(x);
  if (logical === null) return null;
  const lastIdx = data.length - 1;
  const lastTime = data[lastIdx].time;
  const firstTime = data[0].time;
  if (logical > lastIdx) return lastTime + Math.round(logical - lastIdx) * intervalSec;
  if (logical < 0) return firstTime + Math.round(logical) * intervalSec;
  return null;
}
function resolveEntry(d, ctx, state) {
  const entry = {
    d,
    x1: d.time != null ? timeToX(ctx, d.time) : null,
    y1: Number.isFinite(d.price) ? ctx.series.priceToCoordinate(d.price) : null,
    x2: d.time2 != null ? timeToX(ctx, d.time2) : null,
    y2: d.price2 != null ? ctx.series.priceToCoordinate(d.price2) : null,
    state
  };
  if (d.type === "fibonacci" || d.type === "fibextension") {
    entry.fibLevels = resolveFibLevels(d, ctx.series);
  }
  if (d.type === "trendline") {
    entry.seg = trendlineSegment(entry, ctx.chart.timeScale().width());
    if (state === "selected" || state === "preview") entry.stats = trendlineStats(d, ctx);
  }
  if (d.type === "position") {
    entry.yStop = d.stopPrice != null ? ctx.series.priceToCoordinate(d.stopPrice) : null;
    entry.yTarget = d.targetPrice != null ? ctx.series.priceToCoordinate(d.targetPrice) : null;
  }
  if (d.type === "channel") {
    entry.x3 = d.time3 != null ? timeToX(ctx, d.time3) : null;
    entry.y3 = d.price3 != null ? ctx.series.priceToCoordinate(d.price3) : null;
  }
  if (d.points) {
    entry.points = d.points.flatMap((point) => {
      const x = timeToX(ctx, point.time);
      const y = ctx.series.priceToCoordinate(point.price);
      return x === null || y === null ? [] : [{ x, y }];
    });
  }
  if (d.type === "curve") {
    const x = d.controlTime != null ? timeToX(ctx, d.controlTime) : null;
    const y = d.controlPrice != null ? ctx.series.priceToCoordinate(d.controlPrice) : null;
    entry.control = x === null || y === null ? null : { x, y };
  }
  if ((d.type === "price-range" || d.type === "date-range" || d.type === "date-price-range") && d.time != null && d.time2 != null && d.price2 != null) {
    entry.stats = rangeLabels(d, ctx);
  }
  return entry;
}
function rangeLabels(d, ctx) {
  const stats = rangeStats(
    d.time,
    d.time2,
    d.price,
    d.price2,
    ctx.data.map((bar) => bar.time)
  );
  const sign = stats.priceChange >= 0 ? "+" : "−";
  const price = ctx.series.priceFormatter().format(Math.abs(stats.priceChange));
  const duration = stats.durationSec % 86400 === 0 ? `${stats.durationSec / 86400}d` : stats.durationSec % 3600 === 0 ? `${stats.durationSec / 3600}h` : `${Math.round(stats.durationSec / 60)}m`;
  const priceLabel = `${sign}${price} (${stats.percentChange.toFixed(2)}%)`;
  const labels = d.type === "price-range" ? [priceLabel] : d.type === "date-range" ? [`${stats.bars} bars`, duration] : [priceLabel, `${stats.bars} bars`, duration];
  return d.rangeLabelMode === "compact" && labels.length > 1 ? [labels.join(" · ")] : labels;
}
function trendlineStats(d, ctx) {
  if (d.price2 == null || d.time == null || d.time2 == null) return [];
  const dp = d.price2 - d.price;
  const pct = d.price !== 0 ? dp / d.price * 100 : 0;
  const bars = ctx.intervalSec > 0 ? Math.round(Math.abs(d.time2 - d.time) / ctx.intervalSec) : 0;
  const formatted = ctx.series.priceFormatter().format(Math.abs(dp));
  return [`${dp >= 0 ? "+" : "−"}${formatted} (${pct.toFixed(2)}%)`, `${bars} bars`];
}
function trendlineSegment(e, paneWidth) {
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null) return void 0;
  const seg = e.x1 <= e.x2 ? { x1: e.x1, y1: e.y1, x2: e.x2, y2: e.y2 } : { x1: e.x2, y1: e.y2, x2: e.x1, y2: e.y1 };
  return extendSegment(seg, e.d, paneWidth);
}
function extendSegment(seg, d, paneWidth) {
  if (!d.extendLeft && !d.extendRight || seg.x2 - seg.x1 < 0.5) return seg;
  const slope = (seg.y2 - seg.y1) / (seg.x2 - seg.x1);
  const out = { ...seg };
  if (d.extendLeft) {
    out.y1 -= slope * out.x1;
    out.x1 = 0;
  }
  if (d.extendRight && paneWidth > out.x2) {
    out.y2 += slope * (paneWidth - out.x2);
    out.x2 = paneWidth;
  }
  return out;
}
function fibLevelsFor(d) {
  if (d.fibLevels && d.fibLevels.length > 0) return d.fibLevels;
  return d.type === "fibextension" ? FIB_EXT_LEVELS : FIB_LEVELS;
}
function resolveFibLevels(d, series) {
  if (d.price2 == null) return [];
  const formatter = series.priceFormatter();
  const configured = d.fibLevelStyles && d.fibLevelStyles.length > 0 ? d.fibLevelStyles : fibLevelsFor(d).map((value) => ({ value, enabled: true }));
  const resolved = [];
  configured.forEach((style, i) => {
    const level = style.value;
    if (!style.enabled || !Number.isFinite(level)) return;
    const price = d.price2 + (d.price - d.price2) * level;
    resolved.push({
      level,
      price,
      y: series.priceToCoordinate(price),
      color: style.color ?? FIB_COLORS[i] ?? "#2196F3",
      label: `${level} (${formatter.format(price)})`
    });
  });
  return resolved;
}
class DrawingsPaneRenderer {
  constructor(entries, info) {
    __publicField(this, "_entries");
    __publicField(this, "_info");
    this._entries = entries;
    this._info = info;
  }
  draw(target) {
    target.useBitmapCoordinateSpace((scope) => {
      for (const e of this._entries) renderEntry(scope, e, this._info);
    });
  }
}
class DrawingsPaneView {
  constructor(source) {
    __publicField(this, "_source");
    __publicField(this, "_entries", []);
    this._source = source;
  }
  update() {
    this._entries = this._source.resolveEntries();
  }
  renderer() {
    return new DrawingsPaneRenderer(this._entries, this._source.drawInfo());
  }
}
class PriceAxisLabelView {
  constructor(source, price, color) {
    __publicField(this, "_source");
    __publicField(this, "_price");
    __publicField(this, "_color");
    __publicField(this, "_y", null);
    this._source = source;
    this._price = price;
    this._color = color;
  }
  update() {
    this._y = this._source.series.priceToCoordinate(this._price);
  }
  coordinate() {
    return this._y ?? -1;
  }
  visible() {
    return this._y !== null;
  }
  tickVisible() {
    return true;
  }
  text() {
    return this._source.series.priceFormatter().format(this._price);
  }
  textColor() {
    return "#ffffff";
  }
  backColor() {
    return this._color;
  }
}
function appendAxisViews(views, d, selectedIds, source) {
  if (d.type === "horizontal") {
    views.push(new PriceAxisLabelView(source, d.price, d.color));
    return;
  }
  if (!shouldAppendAxisViews(d, selectedIds.has(d.id))) return;
  if (Number.isFinite(d.price)) views.push(new PriceAxisLabelView(source, d.price, d.color));
  if (d.price2 != null) views.push(new PriceAxisLabelView(source, d.price2, d.color));
}
function shouldAppendAxisViews(drawing, selected) {
  return selected && !(drawing.type === "position" && drawing.showPriceLabels === false);
}
function sortDrawingsForRender(drawings) {
  return drawings.map((drawing, index) => ({ drawing, index })).sort((a, b) => (a.drawing.zIndex ?? 0) - (b.drawing.zIndex ?? 0) || a.index - b.index).map(({ drawing }) => drawing);
}
class DrawingsPrimitive extends PluginBase {
  constructor() {
    super(...arguments);
    __publicField(this, "_drawings", []);
    __publicField(this, "_preview", null);
    __publicField(this, "_selectedIds", /* @__PURE__ */ new Set());
    __publicField(this, "_hoveredId", null);
    __publicField(this, "_intervalSec", 60);
    __publicField(this, "_accountEquity", 0);
    __publicField(this, "_paneViews", [new DrawingsPaneView(this)]);
    __publicField(this, "_axisViews", []);
  }
  setDrawings(drawings) {
    this._drawings = sortDrawingsForRender(drawings);
    this._rebuildAxisViews();
    this.requestUpdate();
  }
  setPreview(d) {
    this._preview = d;
    this.requestUpdate();
  }
  setSelected(ids) {
    this._selectedIds = new Set(ids);
    this._rebuildAxisViews();
    this.requestUpdate();
  }
  setHovered(id) {
    if (this._hoveredId === id) return;
    this._hoveredId = id;
    this.requestUpdate();
  }
  setAccountEquity(equity) {
    if (this._accountEquity === equity) return;
    this._accountEquity = equity;
    this.requestUpdate();
  }
  /** Account context the position tool reads for its $-risk / size readout. */
  drawInfo() {
    return {
      accountEquity: this._accountEquity,
      priceFormat: (p) => this.series.priceFormatter().format(p)
    };
  }
  setIntervalSec(intervalSec) {
    if (this._intervalSec === intervalSec) return;
    this._intervalSec = intervalSec;
    this.requestUpdate();
  }
  updateAllViews() {
    for (const v of this._paneViews) v.update();
    for (const v of this._axisViews) v.update();
  }
  paneViews() {
    return this._paneViews;
  }
  priceAxisViews() {
    return this._axisViews;
  }
  resolveEntries() {
    const ctx = makeResolveCtx(this.chart, this.series, this._intervalSec);
    const entries = this._drawings.map((d) => resolveEntry(d, ctx, this._stateFor(d.id)));
    if (this._preview) entries.push(resolveEntry(this._preview, ctx, "preview"));
    return entries;
  }
  _stateFor(id) {
    if (this._selectedIds.has(id)) return "selected";
    if (id === this._hoveredId) return "hovered";
    return "normal";
  }
  _rebuildAxisViews() {
    const views = [];
    for (const d of this._drawings) appendAxisViews(views, d, this._selectedIds, this);
    this._axisViews = views;
  }
}
const HANDLE_TOLERANCE = 8;
const LINE_TOLERANCE = 6;
function hitTest(entries, p, scale = 1) {
  const tol = { handle: HANDLE_TOLERANCE * scale, line: LINE_TOLERANCE * scale };
  for (let i = entries.length - 1; i >= 0; i--) {
    const hit = hitEntry(entries[i], p, tol);
    if (hit) return hit;
  }
  return null;
}
function hitEntry(e, p, tol) {
  switch (e.d.type) {
    case "trendline":
      return hitTrendline(e, p, tol);
    case "horizontal":
      return hitHorizontal(e, p, tol);
    case "rectangle":
      return hitRectangle(e, p, tol);
    case "fibonacci":
      return hitFibonacci(e, p, tol);
    case "position":
      return hitPosition(e, p, tol);
    case "arrow":
      return hitTrendline(e, p, tol);
    case "fibextension":
      return hitFibonacci(e, p, tol);
    case "vertical":
      return hitVertical(e, p, tol);
    case "channel":
      return hitChannel(e, p, tol);
    case "ellipse":
    case "triangle":
      return hitBoxShape(e, p, tol);
    case "text":
    case "anchored-text":
      return hitText(e, p, tol);
    case "note":
      return hitNote(e, p, tol);
    case "brush":
    case "highlighter":
    case "path":
    case "polyline":
      return hitPath(e, p, tol);
    case "curve":
      return hitCurve(e, p, tol);
    case "price-range":
    case "date-price-range":
      return hitRectangle(e, p, tol);
    case "date-range":
      return hitDateRange(e, p, tol);
    default:
      return null;
  }
}
function hitDateRange(e, p, tol) {
  if (e.x1 === null || e.x2 === null) return null;
  if (Math.abs(p.x - e.x1) <= tol.handle) return pointHit(e, "time", null);
  if (Math.abs(p.x - e.x2) <= tol.handle) return pointHit(e, "time2", null);
  return p.x >= Math.min(e.x1, e.x2) - tol.line && p.x <= Math.max(e.x1, e.x2) + tol.line ? bodyHit(e) : null;
}
function hitNote(e, p, tol) {
  if (e.x1 === null || e.y1 === null) return null;
  const size = Math.max(16, e.d.fontSize ?? 14);
  return pointInBox(p, e.x1 - size / 2, e.y1 - size / 2, e.x1 + size / 2, e.y1 + size / 2, tol.line) ? pointHit(e, "time", "price") : null;
}
function hitPath(e, p, tol) {
  const points = e.points ?? [];
  if (e.state === "selected") {
    for (let index = 0; index < points.length; index += 1) {
      if (dist(p, points[index]) <= tol.handle) {
        return { id: e.d.id, region: { kind: "point", pointIndex: index, timeKey: null, priceKey: null } };
      }
    }
  }
  const allowance = e.d.type === "highlighter" ? (e.d.width ?? 12) / 2 : 0;
  return distToPolyline(p, points) <= tol.line + allowance ? bodyHit(e) : null;
}
function hitCurve(e, p, tol) {
  const anchor = anchorHit(e, p, tol);
  if (anchor) return anchor;
  if (e.control && dist(p, e.control) <= tol.handle) {
    return { id: e.d.id, region: { kind: "point", timeKey: "controlTime", priceKey: "controlPrice" } };
  }
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null || !e.control) return null;
  return distToQuadratic(p, { x: e.x1, y: e.y1 }, e.control, { x: e.x2, y: e.y2 }) <= tol.line ? bodyHit(e) : null;
}
function hitVertical(e, p, tol) {
  if (e.x1 === null || Math.abs(p.x - e.x1) > tol.line) return null;
  return { id: e.d.id, region: { kind: "point", timeKey: "time", priceKey: null } };
}
function hitChannel(e, p, tol) {
  const anchor = anchorHit(e, p, tol);
  if (anchor) return anchor;
  if (e.x1 !== null && e.y3 != null && dist(p, { x: e.x1, y: e.y3 }) <= tol.handle) {
    return { id: e.d.id, region: { kind: "point", timeKey: "time3", priceKey: "price3" } };
  }
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null || e.y3 == null) return null;
  const dy = e.y3 - e.y1;
  const onMain = distToSegment(p, { x: e.x1, y: e.y1 }, { x: e.x2, y: e.y2 }) <= tol.line;
  const onOff = distToSegment(p, { x: e.x1, y: e.y3 }, { x: e.x2, y: e.y2 + dy }) <= tol.line;
  return onMain || onOff ? bodyHit(e) : null;
}
function hitBoxShape(e, p, tol) {
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null) return null;
  const corner = rectCornerHit(e, p, tol);
  if (corner) return corner;
  return pointInBox(p, e.x1, e.y1, e.x2, e.y2, tol.line) ? bodyHit(e) : null;
}
function hitText(e, p, tol) {
  if (e.x1 === null || e.y1 === null) return null;
  const size = e.d.fontSize ?? 14;
  const lines = (e.d.text ?? "Text").split("\n");
  const longest = lines.reduce((m, l) => Math.max(m, l.length), 4);
  const w = longest * size * 0.6;
  const h = lines.length * size * 1.3;
  const inside = p.x >= e.x1 - tol.line && p.x <= e.x1 + w + tol.line && p.y >= e.y1 - tol.line && p.y <= e.y1 + h + tol.line;
  return inside ? { id: e.d.id, region: { kind: "point", timeKey: "time", priceKey: "price" } } : null;
}
function pointHit(e, timeKey, priceKey) {
  return { id: e.d.id, region: { kind: "point", timeKey, priceKey } };
}
function hitPosition(e, p, tol) {
  const { x1, x2, y1, yStop, yTarget } = e;
  if (x1 === null || x2 === null || y1 === null) return null;
  const xa = Math.min(x1, x2);
  const xb = Math.max(x1, x2);
  const xm = (xa + xb) / 2;
  if (yTarget != null && dist(p, { x: xm, y: yTarget }) <= tol.handle) {
    return pointHit(e, null, "targetPrice");
  }
  if (yStop != null && dist(p, { x: xm, y: yStop }) <= tol.handle) {
    return pointHit(e, null, "stopPrice");
  }
  if (dist(p, { x: xm, y: y1 }) <= tol.handle) return pointHit(e, null, "price");
  if (dist(p, { x: xb, y: y1 }) <= tol.handle) return pointHit(e, "time2", null);
  const ys = [y1, yStop ?? y1, yTarget ?? y1];
  const top = Math.min(...ys);
  const bot = Math.max(...ys);
  const inside = p.x >= xa - tol.line && p.x <= xb + tol.line && p.y >= top - tol.line && p.y <= bot + tol.line;
  return inside ? bodyHit(e) : null;
}
function bodyHit(e) {
  return { id: e.d.id, region: { kind: "body" } };
}
function anchorHit(e, p, tol) {
  if (e.x1 !== null && e.y1 !== null && dist(p, { x: e.x1, y: e.y1 }) <= tol.handle) {
    return { id: e.d.id, region: { kind: "point", timeKey: "time", priceKey: "price" } };
  }
  if (e.x2 !== null && e.y2 !== null && dist(p, { x: e.x2, y: e.y2 }) <= tol.handle) {
    return { id: e.d.id, region: { kind: "point", timeKey: "time2", priceKey: "price2" } };
  }
  return null;
}
function hitTrendline(e, p, tol) {
  const anchor = anchorHit(e, p, tol);
  if (anchor) return anchor;
  const seg = e.seg ?? (e.x1 !== null && e.y1 !== null && e.x2 !== null && e.y2 !== null ? { x1: e.x1, y1: e.y1, x2: e.x2, y2: e.y2 } : null);
  if (!seg) return null;
  const near = distToSegment(p, { x: seg.x1, y: seg.y1 }, { x: seg.x2, y: seg.y2 }) <= tol.line;
  return near ? bodyHit(e) : null;
}
function hitHorizontal(e, p, tol) {
  if (e.y1 === null || Math.abs(p.y - e.y1) > tol.line) return null;
  return { id: e.d.id, region: { kind: "point", timeKey: null, priceKey: "price" } };
}
function hitRectangle(e, p, tol) {
  if (e.x1 === null || e.y1 === null || e.x2 === null || e.y2 === null) return null;
  const corner = rectCornerHit(e, p, tol);
  if (corner) return corner;
  return pointInBox(p, e.x1, e.y1, e.x2, e.y2, tol.line) ? bodyHit(e) : null;
}
function rectCornerHit(e, p, tol) {
  const corners = [
    { x: e.x1, y: e.y1, timeKey: "time", priceKey: "price" },
    { x: e.x2, y: e.y2, timeKey: "time2", priceKey: "price2" },
    { x: e.x1, y: e.y2, timeKey: "time", priceKey: "price2" },
    { x: e.x2, y: e.y1, timeKey: "time2", priceKey: "price" }
  ];
  for (const c of corners) {
    if (dist(p, c) <= tol.handle) {
      return { id: e.d.id, region: { kind: "point", timeKey: c.timeKey, priceKey: c.priceKey } };
    }
  }
  return null;
}
function hitFibonacci(e, p, tol) {
  const anchor = anchorHit(e, p, tol);
  if (anchor) return anchor;
  if (e.x1 === null || e.x2 === null || !e.fibLevels) return null;
  if (p.x < Math.min(e.x1, e.x2) - tol.line) return null;
  if (p.x > Math.max(e.x1, e.x2) + tol.line) return null;
  const onLevel = e.fibLevels.some((lvl) => lvl.y !== null && Math.abs(p.y - lvl.y) <= tol.line);
  return onLevel ? bodyHit(e) : null;
}
const DRAG_COMMIT_THRESHOLD_PX = 10;
const MAGNET_THRESHOLD_PX = 14;
const SNAP_ANCHOR_PX = 8;
const TOUCH_HIT_SCALE = 2;
const LONG_PRESS_MS = 500;
const LONG_PRESS_CANCEL_PX = 10;
const MAX_FREEHAND_SAMPLES = 1024;
const MAX_STORED_FREEHAND_POINTS = 512;
const TOOL_SHORTCUTS = {
  KeyT: "trendline",
  KeyH: "horizontal",
  KeyF: "fibonacci",
  KeyR: "rectangle",
  KeyM: "measure"
};
function asOhlc(bar) {
  const b = bar;
  const valid = typeof b.open === "number" && typeof b.high === "number" && typeof b.low === "number" && typeof b.close === "number";
  return valid ? b : null;
}
function evtFromTouch(e) {
  return {
    shiftKey: false,
    preventDefault: () => e.preventDefault(),
    stopPropagation: () => e.stopPropagation()
  };
}
function definedOnly(obj) {
  const out = {};
  for (const key of Object.keys(obj)) {
    if (obj[key] !== void 0) out[key] = obj[key];
  }
  return out;
}
function isTextInputTarget(t) {
  if (!(t instanceof HTMLElement)) return false;
  return t.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(t.tagName);
}
class DrawingToolsManager {
  constructor(opts) {
    __publicField(this, "chart");
    __publicField(this, "series");
    __publicField(this, "container");
    __publicField(this, "cb");
    __publicField(this, "primitive");
    // Mutable: the chart instance persists across timeframe changes (TradingView
    // behavior), so these are updated in place via updateTimeframe rather than
    // recreating the manager.
    __publicField(this, "intervalSec");
    __publicField(this, "timeframe");
    __publicField(this, "tool", "none");
    __publicField(this, "drawings", []);
    __publicField(this, "placing", null);
    __publicField(this, "freehand", null);
    __publicField(this, "drag", null);
    __publicField(this, "selectedIds", []);
    __publicField(this, "hoveredId", null);
    __publicField(this, "keyboardEnabled", true);
    __publicField(this, "magnetMode", "none");
    __publicField(this, "lastPointer", null);
    __publicField(this, "previewing", false);
    __publicField(this, "stayInMode", false);
    __publicField(this, "longPress", null);
    // The measure tool is a throwaway gesture: its result lingers as a preview
    // (never committed/persisted) until the next pointer-down or Escape.
    __publicField(this, "measureResult", null);
    // Copy/paste clipboard (deep copies of the drawings copied with Ctrl/Cmd+C).
    __publicField(this, "clipboard", []);
    // Per-type style defaults new drawings inherit (set via the settings dialog).
    __publicField(this, "styleDefaults", {});
    // ── Mouse handlers ─────────────────────────────────────────────────
    __publicField(this, "handleMouseDown", (e) => {
      if (e.button !== 0) return;
      const pos = this.eventPos(e);
      if (!pos) return;
      this.clearMeasure();
      if (this.tool !== "none") {
        this.placementStart(pos, e);
        return;
      }
      this.selectionStart(pos, e, false);
    });
    __publicField(this, "handleMouseMove", (e) => {
      const pos = this.eventPos(e);
      this.lastPointer = pos ? { pos, shiftKey: e.shiftKey } : null;
      this.refreshSnapPreview();
      if (this.drag) {
        if (pos) this.dragMove(pos, e.shiftKey);
        return;
      }
      if (!pos) {
        this.hoverHit(null);
        return;
      }
      if (this.placing || this.freehand) {
        this.placingMove(pos, e.shiftKey);
        return;
      }
      if (this.tool === "none") this.hoverHit(hitTest(this.resolveAll(), pos));
    });
    __publicField(this, "handleMouseUp", (e) => {
      if (this.drag) this.endDrag();
      else if (this.freehand) this.finishFreehand();
      else if (this.tool === "polyline" || this.tool === "curve") ;
      else if (this.placing) this.maybeCommitPlacement(this.eventPos(e), e.shiftKey);
      const pos = this.eventPos(e);
      this.lastPointer = pos ? { pos, shiftKey: e.shiftKey } : null;
      this.refreshSnapPreview();
    });
    __publicField(this, "handleDblClick", (e) => {
      var _a, _b;
      if (this.tool === "polyline" && this.placing) {
        e.preventDefault();
        e.stopPropagation();
        this.finishPolyline();
        return;
      }
      if (this.tool !== "none") return;
      const pos = this.eventPos(e);
      if (!pos) return;
      const hit = hitTest(this.resolveAll(), pos);
      if (!hit) return;
      e.preventDefault();
      e.stopPropagation();
      this.select([hit.id]);
      (_b = (_a = this.cb).onRequestSettings) == null ? void 0 : _b.call(_a, hit.id);
    });
    __publicField(this, "handleContextMenu", (e) => {
      var _a, _b;
      const pos = this.eventPos(e);
      if (!pos) return;
      const hit = hitTest(this.resolveAll(), pos);
      if (!hit) return;
      e.preventDefault();
      e.stopPropagation();
      if (!this.selectedIds.includes(hit.id)) this.select([hit.id]);
      (_b = (_a = this.cb).onContextMenu) == null ? void 0 : _b.call(_a, hit.id, e.clientX, e.clientY);
    });
    // ── Touch handlers ─────────────────────────────────────────────────
    __publicField(this, "handleTouchStart", (e) => {
      if (e.touches.length !== 1) return;
      const t = e.touches[0];
      const pos = this.posFromClient(t.clientX, t.clientY);
      if (!pos) return;
      if (this.tool !== "none") {
        this.placementStart(pos, evtFromTouch(e));
        return;
      }
      const hit = this.selectionStart(pos, evtFromTouch(e), true);
      if (hit) this.startLongPress(hit.id, pos);
    });
    __publicField(this, "handleTouchMove", (e) => {
      if (e.touches.length !== 1) return;
      const t = e.touches[0];
      const pos = this.posFromClient(t.clientX, t.clientY);
      this.cancelLongPressIfMoved(pos);
      if (this.drag) {
        e.preventDefault();
        if (pos) this.dragMove(pos, false);
        return;
      }
      if ((this.placing || this.freehand) && pos) this.placingMove(pos, false);
    });
    __publicField(this, "handleTouchEnd", (e) => {
      this.clearLongPress();
      if (this.drag) {
        this.endDrag();
        return;
      }
      if (this.freehand) {
        this.finishFreehand();
        return;
      }
      if (this.tool === "polyline" || this.tool === "curve") return;
      if (!this.placing) return;
      const t = e.changedTouches[0];
      this.maybeCommitPlacement(t ? this.posFromClient(t.clientX, t.clientY) : null, false);
    });
    // ── Keyboard ───────────────────────────────────────────────────────
    __publicField(this, "handleKeyDown", (e) => {
      if (!this.keyboardEnabled) return;
      if (isTextInputTarget(e.target)) return;
      if (this.handleHistoryShortcut(e) || this.handleToolShortcut(e)) return;
      if (this.handleClipboardShortcut(e) || this.handleArrowNudge(e)) return;
      if (e.key === "Escape") {
        this.handleEscape();
        return;
      }
      if (e.key === "Enter" && this.tool === "polyline" && this.placing) {
        e.preventDefault();
        this.finishPolyline();
        return;
      }
      if ((e.key === "Delete" || e.key === "Backspace") && this.selectedIds.length > 0 && !this.drag) {
        e.preventDefault();
        this.removeSelected();
      }
    });
    // Preview the exact resolver used by placement/anchor dragging, not LC's
    // close-only magnet mode. It also reacts to Cmd release without mouse motion.
    __publicField(this, "refreshSnapPreview", () => {
      const pointer = this.lastPointer;
      if (!pointer || !this.keyboardEnabled) return;
      if (this.magnetMode === "none" && !this.previewing) return;
      const anchor = this.drag ? this.dragAnchorPx(this.drag) : this.placementAnchorPx();
      const point = this.magnetMode === "none" ? this.toPoint(pointer.pos) : this.pointFor(pointer.pos, pointer.shiftKey, anchor);
      if (!point) return;
      this.chart.setCrosshairPosition(point.price, point.time, this.series);
      this.previewing = this.magnetMode !== "none";
      if (this.placing) this.placingMove(pointer.pos, pointer.shiftKey);
    });
    __publicField(this, "forgetPointer", () => {
      this.lastPointer = null;
      this.previewing = false;
    });
    __publicField(this, "handleBlur", () => {
      if (this.previewing) this.chart.clearCrosshairPosition();
      this.cancelPlacement();
      this.clearMeasure();
      this.forgetPointer();
    });
    this.chart = opts.chart;
    this.series = opts.series;
    this.container = opts.container;
    this.cb = opts.callbacks;
    this.intervalSec = opts.intervalSec;
    this.timeframe = opts.timeframe;
    this.primitive = new DrawingsPrimitive();
    this.primitive.setIntervalSec(opts.intervalSec);
    this.primitive.setAccountEquity(opts.accountEquity ?? 0);
    this.series.attachPrimitive(this.primitive);
    this.container.addEventListener("mousedown", this.handleMouseDown, true);
    this.container.addEventListener("mouseleave", this.forgetPointer);
    window.addEventListener("blur", this.handleBlur);
    this.series.subscribeDataChanged(this.refreshSnapPreview);
    this.container.addEventListener("dblclick", this.handleDblClick);
    this.container.addEventListener("contextmenu", this.handleContextMenu);
    this.container.addEventListener("touchstart", this.handleTouchStart, {
      capture: true,
      passive: false
    });
    window.addEventListener("mousemove", this.handleMouseMove);
    window.addEventListener("mouseup", this.handleMouseUp);
    window.addEventListener("touchmove", this.handleTouchMove, { passive: false });
    window.addEventListener("touchend", this.handleTouchEnd);
    window.addEventListener("touchcancel", this.handleTouchEnd);
    window.addEventListener("keydown", this.handleKeyDown);
  }
  setKeyboardEnabled(enabled) {
    this.keyboardEnabled = enabled;
    if (!enabled) this.forgetPointer();
  }
  destroy() {
    this.clearLongPress();
    this.cancelPlacement();
    this.clearMeasure();
    this.container.removeEventListener("mousedown", this.handleMouseDown, true);
    this.container.removeEventListener("mouseleave", this.forgetPointer);
    window.removeEventListener("blur", this.handleBlur);
    this.series.unsubscribeDataChanged(this.refreshSnapPreview);
    this.container.removeEventListener("dblclick", this.handleDblClick);
    this.container.removeEventListener("contextmenu", this.handleContextMenu);
    this.container.removeEventListener("touchstart", this.handleTouchStart, true);
    window.removeEventListener("mousemove", this.handleMouseMove);
    window.removeEventListener("mouseup", this.handleMouseUp);
    window.removeEventListener("touchmove", this.handleTouchMove);
    window.removeEventListener("touchend", this.handleTouchEnd);
    window.removeEventListener("touchcancel", this.handleTouchEnd);
    window.removeEventListener("keydown", this.handleKeyDown);
    try {
      this.series.detachPrimitive(this.primitive);
    } catch {
    }
    this.container.style.cursor = "";
  }
  setTool(tool) {
    if (this.tool === tool) return;
    this.tool = tool;
    this.cancelPlacement();
    this.applyCursor(null);
  }
  setMagnetMode(mode) {
    this.magnetMode = mode;
    this.refreshSnapPreview();
  }
  setStyleDefaults(defaults2) {
    this.styleDefaults = defaults2;
  }
  setStayInDrawingMode(enabled) {
    this.stayInMode = enabled;
  }
  setAccountEquity(equity) {
    this.primitive.setAccountEquity(equity);
  }
  /**
   * Re-point the manager at a new timeframe without recreating it. The chart
   * and drawing primitive stay alive (so drawings never blink out on a TF
   * switch); only the interval used for whitespace extrapolation and the
   * createdTf stamped on new drawings change.
   */
  updateTimeframe(timeframe, intervalSec) {
    this.timeframe = timeframe;
    this.intervalSec = intervalSec;
    this.primitive.setIntervalSec(intervalSec);
  }
  /** External selection (e.g. object tree row click). Unknown ids are dropped. */
  setSelection(ids) {
    this.select(ids.filter((id) => this.drawings.some((d) => d.id === id)));
  }
  setDrawings(drawings) {
    if (this.drag) return;
    this.drawings = drawings.map((d) => {
      var _a;
      return { ...d, points: (_a = d.points) == null ? void 0 : _a.map((point) => ({ ...point })) };
    });
    const pruned = this.selectedIds.filter((id) => this.drawings.some((d) => d.id === id));
    if (pruned.length !== this.selectedIds.length) this.select(pruned);
    this.primitive.setDrawings(this.drawings);
  }
  // ── Coordinate helpers ─────────────────────────────────────────────
  ctx() {
    return makeResolveCtx(this.chart, this.series, this.intervalSec);
  }
  /** Pointer position relative to the chart pane, or null when outside it. */
  posFromClient(clientX, clientY) {
    const rect = this.container.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    const timeScale = this.chart.timeScale();
    const paneWidth = timeScale.width() || Math.max(0, rect.width - this.chart.priceScale("right").width() - this.chart.priceScale("left").width());
    const paneHeight = rect.height - timeScale.height();
    if (paneWidth <= 0 || x < 0 || y < 0 || x > paneWidth || y > paneHeight) return null;
    return { x, y };
  }
  eventPos(e) {
    return this.posFromClient(e.clientX, e.clientY);
  }
  toPoint(p) {
    const time = xToTime(this.ctx(), p.x);
    const price = this.series.coordinateToPrice(p.y);
    if (time === null || price === null) return null;
    return { time, price };
  }
  resolveAll() {
    const ctx = this.ctx();
    return this.drawings.map((d) => resolveEntry(d, ctx, "normal"));
  }
  // Build a drawing, then merge the user's saved style default for its type
  // (the measure gesture keeps its fixed look).
  makeNew(tool, p1, p2) {
    const d = this.buildNew(tool, p1, p2);
    if (tool === "measure") return d;
    const def = this.styleDefaults[d.type];
    return def ? { ...d, ...definedOnly(def) } : d;
  }
  buildNew(tool, p1, p2) {
    if (tool === "long-position" || tool === "short-position") {
      return this.makePosition(tool === "long-position" ? "long" : "short", p1, p2);
    }
    const base = {
      id: crypto.randomUUID(),
      color: tool === "trendline" ? "#2196F3" : "#f0b90b",
      createdTf: this.timeframe
    };
    if (tool === "horizontal") return { ...base, type: "horizontal", price: p1.price };
    if (tool === "vertical") return { ...base, type: "vertical", price: p1.price, time: p1.time };
    const two = { ...base, price: p1.price, time: p1.time, price2: p2.price, time2: p2.time };
    if (tool === "ray") return { ...two, type: "trendline", extendRight: true };
    if (tool === "extended")
      return { ...two, type: "trendline", extendLeft: true, extendRight: true };
    if (tool === "measure")
      return { ...two, type: "trendline", color: "#b2b5be", lineStyle: "dashed" };
    if (tool === "channel") {
      return { ...two, type: "channel", time3: p1.time, price3: 2 * p1.price - p2.price };
    }
    if (tool === "text") return { ...two, type: "text", text: "Text" };
    if (tool === "anchored-text") return { ...two, type: "anchored-text", text: "Text" };
    if (tool === "note") {
      return { ...two, type: "note", text: "Note", textBg: true, textBgColor: "#2a2e39" };
    }
    if (tool === "highlighter") return { ...two, type: "highlighter", width: 12 };
    return { ...two, type: tool };
  }
  // Position tool: entry = first anchor price; the drag's release price becomes
  // the target and the stop is mirrored 1:1 on the opposite side (draggable
  // afterwards). Side only drives labelling/colour — risk math uses absolutes.
  makePosition(side, p1, p2) {
    const entry = p1.price;
    const target = p2.price;
    return {
      id: crypto.randomUUID(),
      type: "position",
      side,
      color: side === "long" ? "#089981" : "#f23645",
      createdTf: this.timeframe,
      price: entry,
      time: Math.min(p1.time, p2.time),
      time2: Math.max(p1.time, p2.time),
      targetPrice: target,
      stopPrice: entry - (target - entry),
      riskPct: 1
    };
  }
  startLongPress(id, pos) {
    this.clearLongPress();
    const timer = window.setTimeout(() => {
      var _a, _b;
      this.longPress = null;
      this.drag = null;
      this.applyCursor(null);
      (_b = (_a = this.cb).onRequestSettings) == null ? void 0 : _b.call(_a, id);
    }, LONG_PRESS_MS);
    this.longPress = { timer, id, startPos: pos };
  }
  cancelLongPressIfMoved(pos) {
    if (!this.longPress) return;
    if (!pos || dist(pos, this.longPress.startPos) > LONG_PRESS_CANCEL_PX) this.clearLongPress();
  }
  clearLongPress() {
    if (!this.longPress) return;
    window.clearTimeout(this.longPress.timer);
    this.longPress = null;
  }
  /** Ctrl/Cmd+Z undo, Ctrl/Cmd+Shift+Z or Ctrl/Cmd+Y redo. */
  handleHistoryShortcut(e) {
    var _a, _b, _c, _d, _e, _f;
    if (!e.ctrlKey && !e.metaKey) return false;
    if (e.code === "KeyZ") {
      e.preventDefault();
      if (e.shiftKey) (_b = (_a = this.cb).onRedo) == null ? void 0 : _b.call(_a);
      else (_d = (_c = this.cb).onUndo) == null ? void 0 : _d.call(_c);
      return true;
    }
    if (e.code === "KeyY") {
      e.preventDefault();
      (_f = (_e = this.cb).onRedo) == null ? void 0 : _f.call(_e);
      return true;
    }
    return false;
  }
  /** Alt+T/H/F/R arms the matching drawing tool. */
  handleToolShortcut(e) {
    var _a, _b;
    if (!e.altKey || e.ctrlKey || e.metaKey) return false;
    const tool = TOOL_SHORTCUTS[e.code];
    if (!tool) return false;
    e.preventDefault();
    (_b = (_a = this.cb).onSelectTool) == null ? void 0 : _b.call(_a, tool);
    return true;
  }
  /** Ctrl/Cmd+C copy, +V paste, +D duplicate the current selection. */
  handleClipboardShortcut(e) {
    if (!e.ctrlKey && !e.metaKey) return false;
    if (e.code === "KeyC") {
      this.copySelected();
      return true;
    }
    if (e.code === "KeyV") {
      e.preventDefault();
      this.pasteClipboard();
      return true;
    }
    if (e.code === "KeyD") {
      e.preventDefault();
      this.copySelected();
      this.pasteClipboard();
      return true;
    }
    return false;
  }
  /** Arrow keys nudge the selection 1px (10px with Shift). */
  handleArrowNudge(e) {
    const deltas = {
      ArrowLeft: [-1, 0],
      ArrowRight: [1, 0],
      ArrowUp: [0, -1],
      ArrowDown: [0, 1]
    };
    const d = deltas[e.key];
    if (!d || this.selectedIds.length === 0) return false;
    e.preventDefault();
    const step = e.shiftKey ? 10 : 1;
    this.nudgeSelected(d[0] * step, d[1] * step);
    return true;
  }
  copySelected() {
    this.clipboard = this.drawings.filter((d) => this.selectedIds.includes(d.id)).map((d) => {
      var _a;
      return { ...d, points: (_a = d.points) == null ? void 0 : _a.map((point) => ({ ...point })) };
    });
  }
  pasteClipboard() {
    if (this.clipboard.length === 0) return;
    const dt = this.intervalSec * 3;
    const created = this.clipboard.map((d) => this.offsetCopy(d, dt));
    this.drawings = [...this.drawings, ...created];
    this.primitive.setDrawings(this.drawings);
    for (const d of created) this.cb.onAdd({ ...d });
    this.select(created.map((c) => c.id));
  }
  offsetCopy(d, dt) {
    var _a;
    return {
      ...d,
      id: crypto.randomUUID(),
      time: d.time != null ? d.time + dt : void 0,
      time2: d.time2 != null ? d.time2 + dt : void 0,
      time3: d.time3 != null ? d.time3 + dt : void 0,
      controlTime: d.controlTime != null ? d.controlTime + dt : void 0,
      points: (_a = d.points) == null ? void 0 : _a.map((point) => ({ ...point, time: point.time + dt }))
    };
  }
  nudgeSelected(dx, dy) {
    const entries = this.resolveAll();
    const updates = [];
    for (const id of this.selectedIds) {
      const origin = this.drawings.find((d) => d.id === id);
      const entry = entries.find((en) => en.d.id === id);
      if (!origin || !entry || origin.locked) continue;
      const u = this.shiftDrawing(origin, entry, dx, dy);
      if (u) updates.push(u);
    }
    if (updates.length === 0) return;
    const byId = new Map(updates.map((u) => [u.id, u]));
    this.drawings = this.drawings.map((d) => byId.get(d.id) ?? d);
    this.primitive.setDrawings(this.drawings);
    for (const u of updates) this.cb.onUpdate({ ...u });
  }
  handleEscape() {
    this.clearMeasure();
    if (this.tool !== "none") {
      this.tool = "none";
      this.cancelPlacement();
      this.applyCursor(null);
      this.cb.onToolFinished();
      return;
    }
    this.select([]);
  }
  // ── Placement ──────────────────────────────────────────────────────
  placementStart(pos, e) {
    var _a;
    const pt = this.pointFor(pos, e.shiftKey, this.placementAnchorPx());
    if (!pt) return;
    e.preventDefault();
    e.stopPropagation();
    if (this.tool === "brush" || this.tool === "highlighter" || this.tool === "path") {
      this.freehand = { samples: [{ data: pt, pixel: pos }] };
      this.primitive.setPreview(this.makeFreehand(this.tool, this.freehand.samples));
      return;
    }
    if (this.tool === "horizontal" || this.tool === "vertical" || this.tool === "text" || this.tool === "anchored-text" || this.tool === "note") {
      this.commitDrawing(this.makeNew(this.tool, pt, pt));
      return;
    }
    if (this.tool === "polyline") {
      if (!this.placing) {
        this.placing = { p1: pt, startX: pos.x, startY: pos.y, points: [pt] };
      } else {
        this.placing.points = [...this.placing.points ?? [this.placing.p1], pt];
      }
      this.previewPolyline(pt);
      return;
    }
    if (this.tool === "curve") {
      if (!this.placing) {
        this.placing = { p1: pt, startX: pos.x, startY: pos.y, points: [pt] };
        this.primitive.setPreview(this.makeCurve(pt, pt, pt));
      } else if ((((_a = this.placing.points) == null ? void 0 : _a.length) ?? 1) === 1) {
        this.placing.points = [this.placing.p1, pt];
        this.primitive.setPreview(this.makeCurve(this.placing.p1, pt, pt));
      } else {
        this.commitDrawing(this.makeCurve(this.placing.p1, this.placing.points[1], pt));
      }
      return;
    }
    if (this.placing) {
      this.commitPlacement(this.placing.p1, pt);
      return;
    }
    this.placing = { p1: pt, startX: pos.x, startY: pos.y };
    this.primitive.setPreview(this.makeNew(this.tool, pt, pt));
  }
  // Branches the measure tool (a throwaway readout) away from the persist path.
  commitPlacement(p1, p2) {
    if (this.tool === "measure") {
      this.finishMeasure(p1, p2);
      return;
    }
    this.commitDrawing(this.makeNew(this.tool, p1, p2));
  }
  finishMeasure(p1, p2) {
    this.placing = null;
    this.measureResult = {
      id: "measure",
      type: "trendline",
      color: "#b2b5be",
      lineStyle: "dashed",
      price: p1.price,
      time: p1.time,
      price2: p2.price,
      time2: p2.time
    };
    this.primitive.setPreview(this.measureResult);
    this.tool = "none";
    this.applyCursor(null);
    this.cb.onToolFinished();
  }
  clearMeasure() {
    if (!this.measureResult) return;
    this.measureResult = null;
    this.primitive.setPreview(null);
  }
  placingMove(pos, shiftKey) {
    if (this.freehand) {
      const pt2 = this.toPoint(pos);
      if (!pt2) return;
      const previous = this.freehand.samples.at(-1);
      if (!previous || dist(previous.pixel, pos) >= 2) {
        this.freehand.samples.push({ data: pt2, pixel: pos });
        if (this.freehand.samples.length > MAX_FREEHAND_SAMPLES) {
          this.freehand.samples = this.compactFreehandSamples(
            this.freehand.samples,
            Math.floor(MAX_FREEHAND_SAMPLES / 2)
          );
        }
        this.primitive.setPreview(this.makeFreehand(this.tool, this.freehand.samples));
      }
      return;
    }
    const pt = this.pointFor(pos, shiftKey, this.placementAnchorPx());
    if (!pt) return;
    if (!this.placing) return;
    if (this.tool === "polyline") {
      this.previewPolyline(pt);
      return;
    }
    if (this.tool === "curve") {
      const points = this.placing.points ?? [this.placing.p1];
      const control = points[1] ?? pt;
      this.primitive.setPreview(this.makeCurve(this.placing.p1, control, pt));
      return;
    }
    this.primitive.setPreview(this.makeNew(this.tool, this.placing.p1, pt));
  }
  makeFreehand(tool, samples) {
    const first = samples[0].data;
    const last = samples.at(-1).data;
    const base = this.makeNew(tool, first, last);
    const points = tool === "path" ? this.compactFreehandSamples(samples, MAX_STORED_FREEHAND_POINTS).map((sample) => sample.data) : samples.map((sample) => sample.data);
    return { ...base, points };
  }
  compactFreehandSamples(samples, limit) {
    if (samples.length <= 2) return samples.map((sample) => ({ ...sample, data: { ...sample.data }, pixel: { ...sample.pixel } }));
    const tolerance = this.tool === "path" ? 1.5 : 0.75;
    const retainedPixels = new Set(simplifyPath(samples.map((sample) => sample.pixel), tolerance));
    let retained = samples.filter((sample) => retainedPixels.has(sample.pixel));
    if (retained.length <= limit) return retained;
    const bounded = [];
    for (let index = 0; index < limit; index += 1) {
      bounded.push(retained[Math.round(index * (retained.length - 1) / (limit - 1))]);
    }
    return bounded;
  }
  finishFreehand() {
    const freehand = this.freehand;
    if (!freehand) return;
    this.freehand = null;
    if (freehand.samples.length < 2) {
      this.primitive.setPreview(null);
      return;
    }
    const last = freehand.samples.at(-1);
    const snappedLast = this.pointFor(last.pixel, false, null);
    if (snappedLast) last.data = snappedLast;
    const compact = this.compactFreehandSamples(freehand.samples, MAX_STORED_FREEHAND_POINTS);
    this.commitDrawing(this.makeFreehand(this.tool, compact));
  }
  previewPolyline(cursor) {
    if (!this.placing) return;
    const points = [...this.placing.points ?? [this.placing.p1], cursor];
    const d = this.makeNew("polyline", points[0], points.at(-1));
    this.primitive.setPreview({ ...d, points });
  }
  finishPolyline() {
    if (!this.placing) return;
    const points = (this.placing.points ?? [this.placing.p1]).filter(
      (point, index, all) => index === 0 || point.time !== all[index - 1].time || point.price !== all[index - 1].price
    );
    if (points.length < 2) {
      this.cancelPlacement();
      return;
    }
    const d = this.makeNew("polyline", points[0], points.at(-1));
    this.commitDrawing({ ...d, points });
  }
  makeCurve(start2, control, end) {
    const d = this.makeNew("curve", start2, end);
    return { ...d, controlTime: control.time, controlPrice: control.price };
  }
  maybeCommitPlacement(pos, shiftKey) {
    const placing = this.placing;
    if (!pos || dist(pos, { x: placing.startX, y: placing.startY }) < DRAG_COMMIT_THRESHOLD_PX) {
      return;
    }
    const pt = this.pointFor(pos, shiftKey, this.placementAnchorPx());
    if (pt) this.commitPlacement(placing.p1, pt);
  }
  commitDrawing(d) {
    this.placing = null;
    this.primitive.setPreview(null);
    this.drawings = [...this.drawings, d];
    this.primitive.setDrawings(this.drawings);
    this.cb.onAdd({ ...d });
    this.select([d.id]);
    if (this.stayInMode && this.tool !== "none") return;
    this.tool = "none";
    this.applyCursor(null);
    this.cb.onToolFinished();
  }
  cancelPlacement() {
    this.placing = null;
    this.freehand = null;
    this.primitive.setPreview(null);
  }
  // ── Selection & dragging ───────────────────────────────────────────
  selectionStart(pos, e, isTouch) {
    const entries = this.resolveAll();
    const hit = hitTest(entries, pos, isTouch ? TOUCH_HIT_SCALE : 1);
    if (!hit) {
      if (!e.shiftKey) this.select([]);
      return null;
    }
    e.preventDefault();
    e.stopPropagation();
    if (e.shiftKey) {
      this.toggleSelection(hit.id);
      return hit;
    }
    if (!this.selectedIds.includes(hit.id)) this.select([hit.id]);
    this.beginDrag(hit, pos, entries, isTouch);
    return hit;
  }
  toggleSelection(id) {
    const next = this.selectedIds.includes(id) ? this.selectedIds.filter((x) => x !== id) : [...this.selectedIds, id];
    this.select(next);
  }
  beginDrag(hit, pos, entries, isTouch) {
    const origin = this.drawings.find((d) => d.id === hit.id);
    const originEntry = entries.find((en) => en.d.id === hit.id);
    if (!origin || !originEntry || origin.locked) return;
    const group = hit.region.kind === "body" ? this.groupFor(hit.id, entries) : [];
    this.drag = {
      hit,
      startX: pos.x,
      startY: pos.y,
      origin: { ...origin },
      originEntry,
      group,
      moved: false,
      isTouch
    };
    this.applyCursor("grabbing");
  }
  /** Other selected, unlocked drawings that ride along on a body drag. */
  groupFor(primaryId, entries) {
    if (this.selectedIds.length < 2 || !this.selectedIds.includes(primaryId)) return [];
    const out = [];
    for (const id of this.selectedIds) {
      if (id === primaryId) continue;
      const origin = this.drawings.find((d) => d.id === id);
      const entry = entries.find((en) => en.d.id === id);
      if (origin && entry && !origin.locked) out.push({ origin: { ...origin }, entry });
    }
    return out;
  }
  dragMove(pos, shiftKey) {
    const drag = this.drag;
    const updates = this.computeDragUpdates(drag, pos, shiftKey);
    if (updates.length === 0) return;
    drag.moved = true;
    const byId = new Map(updates.map((u) => [u.id, u]));
    this.drawings = this.drawings.map((d) => byId.get(d.id) ?? d);
    this.primitive.setDrawings(this.drawings);
  }
  computeDragUpdates(drag, pos, shiftKey) {
    if (drag.hit.region.kind !== "body") {
      const u = this.dragPoint(drag, pos, shiftKey);
      return u ? [u] : [];
    }
    const dx = pos.x - drag.startX;
    const dy = pos.y - drag.startY;
    const updates = [];
    const primary = this.shiftDrawing(drag.origin, drag.originEntry, dx, dy);
    if (!primary) return [];
    updates.push(primary);
    for (const g of drag.group) {
      const u = this.shiftDrawing(g.origin, g.entry, dx, dy);
      if (u) updates.push(u);
    }
    return updates;
  }
  dragPoint(drag, pos, shiftKey) {
    var _a;
    if (drag.hit.region.kind !== "point") return null;
    const pt = this.pointFor(pos, shiftKey, this.dragAnchorPx(drag));
    if (!pt) return null;
    const updated = { ...drag.origin };
    const { timeKey, priceKey, pointIndex } = drag.hit.region;
    if (pointIndex != null && ((_a = updated.points) == null ? void 0 : _a[pointIndex])) {
      updated.points = updated.points.map((point, index) => index === pointIndex ? pt : { ...point });
      if (pointIndex === 0) {
        updated.time = pt.time;
        updated.price = pt.price;
      }
      if (pointIndex === updated.points.length - 1) {
        updated.time2 = pt.time;
        updated.price2 = pt.price;
      }
    }
    if (timeKey) updated[timeKey] = pt.time;
    if (priceKey) updated[priceKey] = pt.price;
    return updated;
  }
  /** Move a whole drawing by a pixel delta (body / group drag). */
  shiftDrawing(origin, entry, dx, dy) {
    var _a, _b;
    if (origin.type === "horizontal") {
      if (entry.y1 === null) return null;
      const price = this.series.coordinateToPrice(entry.y1 + dy);
      return price === null ? null : { ...origin, price };
    }
    if (origin.type === "vertical") {
      const p = this.shiftPoint(entry.x1, entry.y1, dx, 0);
      return p ? { ...origin, time: p.time } : null;
    }
    if (origin.type === "position") return this.shiftPosition(origin, entry, dx, dy);
    if (origin.type === "channel") return this.shiftChannel(origin, entry, dx, dy);
    if (origin.points && entry.points) {
      const movedAnchor = this.shiftPoint(((_a = entry.points[0]) == null ? void 0 : _a.x) ?? null, ((_b = entry.points[0]) == null ? void 0 : _b.y) ?? null, dx, dy);
      const sourceAnchor = origin.points[0];
      if (!movedAnchor || !sourceAnchor) return null;
      const timeDelta = movedAnchor.time - sourceAnchor.time;
      const priceDelta = movedAnchor.price - sourceAnchor.price;
      const shifted = origin.points.map((point) => ({
        time: point.time + timeDelta,
        price: point.price + priceDelta
      }));
      const first = shifted[0];
      const last = shifted.at(-1);
      return {
        ...origin,
        time: first.time,
        price: first.price,
        time2: last.time,
        price2: last.price,
        points: shifted
      };
    }
    if (origin.type === "curve" && entry.x1 !== null && entry.y1 !== null) {
      const movedAnchor = this.shiftPoint(entry.x1, entry.y1, dx, dy);
      if (!movedAnchor || origin.time == null || origin.time2 == null || origin.price2 == null) return null;
      const timeDelta = movedAnchor.time - origin.time;
      const priceDelta = movedAnchor.price - origin.price;
      return {
        ...origin,
        time: movedAnchor.time,
        price: movedAnchor.price,
        time2: origin.time2 + timeDelta,
        price2: origin.price2 + priceDelta,
        controlTime: origin.controlTime != null ? origin.controlTime + timeDelta : void 0,
        controlPrice: origin.controlPrice != null ? origin.controlPrice + priceDelta : void 0
      };
    }
    const p1 = this.shiftPoint(entry.x1, entry.y1, dx, dy);
    const p2 = this.shiftPoint(entry.x2, entry.y2, dx, dy);
    if (!p1 || !p2) return null;
    const updated = { ...origin, time: p1.time, price: p1.price, time2: p2.time, price2: p2.price };
    return updated;
  }
  // Body-drag a parallel channel: move all three anchors together.
  shiftChannel(origin, entry, dx, dy) {
    const p1 = this.shiftPoint(entry.x1, entry.y1, dx, dy);
    const p2 = this.shiftPoint(entry.x2, entry.y2, dx, dy);
    const p3 = this.shiftPoint(entry.x1, entry.y3 ?? entry.y1, dx, dy);
    if (!p1 || !p2 || !p3) return null;
    return {
      ...origin,
      time: p1.time,
      price: p1.price,
      time2: p2.time,
      price2: p2.price,
      time3: p3.time,
      price3: p3.price
    };
  }
  // Body-drag a position: shift the box in time and every price row together.
  shiftPosition(origin, entry, dx, dy) {
    const p = this.shiftPoint(entry.x1, entry.y1, dx, dy);
    if (!p) return null;
    const dPrice = p.price - origin.price;
    const dTime = p.time - (origin.time ?? p.time);
    return {
      ...origin,
      time: (origin.time ?? 0) + dTime,
      time2: (origin.time2 ?? 0) + dTime,
      price: p.price,
      stopPrice: origin.stopPrice != null ? origin.stopPrice + dPrice : void 0,
      targetPrice: origin.targetPrice != null ? origin.targetPrice + dPrice : void 0
    };
  }
  shiftPoint(x, y, dx, dy) {
    if (x === null || y === null) return null;
    return this.toPoint({ x: x + dx, y: y + dy });
  }
  endDrag() {
    const drag = this.drag;
    this.drag = null;
    this.applyCursor(null);
    if (!drag.moved) return;
    const ids = [drag.hit.id, ...drag.group.map((g) => g.origin.id)];
    for (const id of ids) {
      const d = this.drawings.find((x) => x.id === id);
      if (d) this.cb.onUpdate({ ...d });
    }
  }
  // ── Snapping (Shift = 45° angle, magnet = OHLC price) ──────────────
  /**
   * Resolve a cursor position to a data point, applying Shift angle-snap
   * (trendlines, when an opposite anchor exists) or magnet OHLC snapping.
   */
  pointFor(pos, shiftKey, angleAnchor) {
    const snapped = this.snapToNearbyAnchor(pos);
    if (snapped) return snapped;
    if (shiftKey && angleAnchor) return this.toPoint(snapAngle(angleAnchor, pos));
    const pt = this.toPoint(pos);
    if (!pt || this.magnetMode === "none") return pt;
    return this.magnetSnap(pt, pos.y);
  }
  // Snap an anchor to a nearby *other* drawing's anchor (object snapping). The
  // currently-selected drawings are skipped so dragging never snaps to itself.
  snapToNearbyAnchor(pos) {
    for (const e of this.resolveAll()) {
      if (this.selectedIds.includes(e.d.id)) continue;
      for (const c of this.anchorPoints(e)) {
        if (dist(pos, { x: c.x, y: c.y }) <= SNAP_ANCHOR_PX)
          return { time: c.time, price: c.price };
      }
    }
    return null;
  }
  anchorPoints(e) {
    const d = e.d;
    const out = [];
    if (e.x1 != null && e.y1 != null && d.time != null) {
      out.push({ x: e.x1, y: e.y1, time: d.time, price: d.price });
    }
    if (e.x2 != null && e.y2 != null && d.time2 != null && d.price2 != null) {
      out.push({ x: e.x2, y: e.y2, time: d.time2, price: d.price2 });
    }
    if (e.x3 != null && e.y3 != null && d.time3 != null && d.price3 != null) {
      out.push({ x: e.x3, y: e.y3, time: d.time3, price: d.price3 });
    }
    if (e.control && d.controlTime != null && d.controlPrice != null) {
      out.push({ ...e.control, time: d.controlTime, price: d.controlPrice });
    }
    if (e.points && d.points) {
      for (let index = 0; index < Math.min(e.points.length, d.points.length); index += 1) {
        out.push({ ...e.points[index], ...d.points[index] });
      }
    }
    return out;
  }
  /** Pixel position of the first anchor while placing a trendline. */
  placementAnchorPx() {
    if (!this.placing || this.tool !== "trendline") return null;
    const x = timeToX(this.ctx(), this.placing.p1.time);
    const y = this.series.priceToCoordinate(this.placing.p1.price);
    return x !== null && y !== null ? { x, y } : null;
  }
  /** Pixel position of the anchor opposite the one being dragged. */
  dragAnchorPx(drag) {
    if (drag.origin.type !== "trendline" || drag.hit.region.kind !== "point") return null;
    const en = drag.originEntry;
    const movingP1 = drag.hit.region.timeKey === "time";
    const x = movingP1 ? en.x2 : en.x1;
    const y = movingP1 ? en.y2 : en.y1;
    return x !== null && y !== null ? { x, y } : null;
  }
  magnetSnap(pt, cursorY) {
    const candle = this.candleAt(pt.time);
    if (!candle) return pt;
    let bestPrice = pt.price;
    let bestDist = this.magnetMode === "strong" ? Number.POSITIVE_INFINITY : MAGNET_THRESHOLD_PX;
    for (const price of [candle.open, candle.high, candle.low, candle.close]) {
      const y = this.series.priceToCoordinate(price);
      if (y === null) continue;
      const d = Math.abs(y - cursorY);
      if (d < bestDist) {
        bestDist = d;
        bestPrice = price;
      }
    }
    return { time: pt.time, price: bestPrice };
  }
  /** Binary search the series data for the bar at the given unix time. */
  candleAt(time) {
    const data = this.series.data();
    let lo = 0;
    let hi = data.length - 1;
    while (lo <= hi) {
      const mid = lo + hi >> 1;
      const t = data[mid].time;
      if (t === time) return asOhlc(data[mid]);
      if (t < time) lo = mid + 1;
      else hi = mid - 1;
    }
    return null;
  }
  // ── State helpers ──────────────────────────────────────────────────
  removeSelected() {
    const ids = this.selectedIds;
    this.select([]);
    this.drawings = this.drawings.filter((d) => !ids.includes(d.id));
    this.primitive.setDrawings(this.drawings);
    for (const id of ids) this.cb.onRemove(id);
  }
  select(ids) {
    var _a, _b;
    const same = ids.length === this.selectedIds.length && ids.every((id, i) => id === this.selectedIds[i]);
    if (same) return;
    this.selectedIds = ids;
    this.primitive.setSelected(ids);
    (_b = (_a = this.cb).onSelectionChange) == null ? void 0 : _b.call(_a, [...ids]);
  }
  hoverHit(hit) {
    const id = (hit == null ? void 0 : hit.id) ?? null;
    if (id !== this.hoveredId) {
      this.hoveredId = id;
      this.primitive.setHovered(id);
    }
    this.applyCursor(hit ? "pointer" : null);
  }
  applyCursor(interactionCursor) {
    if (interactionCursor) {
      this.container.style.cursor = interactionCursor;
      return;
    }
    this.container.style.cursor = this.tool !== "none" ? "crosshair" : "";
  }
}
class CrosshairHighlightPaneRenderer {
  constructor(data) {
    __publicField(this, "_data");
    this._data = data;
  }
  draw(target) {
    if (!this._data.visible) return;
    target.useBitmapCoordinateSpace((scope) => {
      const ctx = scope.context;
      const crosshairPos = positionsLine(
        this._data.x,
        scope.horizontalPixelRatio,
        Math.max(1, this._data.barSpacing)
      );
      ctx.fillStyle = this._data.color;
      ctx.fillRect(crosshairPos.position, 0, crosshairPos.length, scope.bitmapSize.height);
    });
  }
}
class CrosshairHighlightPaneView {
  constructor(data) {
    __publicField(this, "_data");
    this._data = data;
  }
  update(data) {
    this._data = data;
  }
  renderer() {
    return new CrosshairHighlightPaneRenderer(this._data);
  }
  zOrder() {
    return "bottom";
  }
}
const defaultOptions$3 = {
  color: "rgba(0, 0, 0, 0.2)"
};
class CrosshairHighlightPrimitive {
  constructor(options) {
    __publicField(this, "_options");
    __publicField(this, "_paneViews");
    __publicField(this, "_data", {
      x: 0,
      visible: false,
      color: "rgba(0, 0, 0, 0.2)",
      barSpacing: 6
    });
    __publicField(this, "_attachedParams");
    __publicField(this, "_moveHandler", (param) => this._onMouseMove(param));
    this._options = {
      ...defaultOptions$3,
      ...options
    };
    this._paneViews = [new CrosshairHighlightPaneView(this._data)];
  }
  attached(param) {
    this._attachedParams = param;
    this._setCrosshairMode();
    param.chart.subscribeCrosshairMove(this._moveHandler);
  }
  detached() {
    const chart = this.chart();
    if (chart) {
      chart.unsubscribeCrosshairMove(this._moveHandler);
    }
  }
  paneViews() {
    return this._paneViews;
  }
  updateAllViews() {
    this._paneViews.forEach((pw) => pw.update(this._data));
  }
  setData(data) {
    var _a;
    this._data = data;
    this.updateAllViews();
    (_a = this._attachedParams) == null ? void 0 : _a.requestUpdate();
  }
  currentColor() {
    return this._options.color;
  }
  chart() {
    var _a;
    return (_a = this._attachedParams) == null ? void 0 : _a.chart;
  }
  // We need to disable magnet mode for this to work nicely
  _setCrosshairMode() {
    const chart = this.chart();
    if (!chart) {
      throw new Error("Unable to change crosshair mode because the chart instance is undefined");
    }
    chart.applyOptions({
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          visible: false
        }
      }
    });
  }
  _barSpacing() {
    const chart = this.chart();
    if (!chart) return 6;
    const ts = chart.timeScale();
    const visibleLogicalRange = ts.getVisibleLogicalRange();
    if (!visibleLogicalRange) return 6;
    return ts.width() / (visibleLogicalRange.to - visibleLogicalRange.from);
  }
  _onMouseMove(param) {
    const chart = this.chart();
    const logical = param.logical;
    if (!logical || !chart) {
      this.setData({
        x: 0,
        visible: false,
        color: this.currentColor(),
        barSpacing: this._barSpacing()
      });
      return;
    }
    const coordinate = chart.timeScale().logicalToCoordinate(logical);
    this.setData({
      x: coordinate ?? 0,
      visible: coordinate !== null,
      color: this.currentColor(),
      barSpacing: this._barSpacing()
    });
  }
}
const defaultOptions$2 = {
  color: "rgba(130, 150, 190, 0.5)",
  width: 1,
  dash: [5, 5],
  sessionStart: "utc-midnight"
};
const RTH_OPEN_MINUTES = 9 * 60 + 30;
class SessionBreaksPaneRenderer {
  constructor(xs, options) {
    __publicField(this, "_xs");
    __publicField(this, "_options");
    this._xs = xs;
    this._options = options;
  }
  draw(target) {
    target.useBitmapCoordinateSpace((scope) => {
      const ctx = scope.context;
      ctx.save();
      ctx.strokeStyle = this._options.color;
      ctx.lineWidth = Math.max(1, this._options.width * scope.horizontalPixelRatio);
      ctx.setLineDash(this._options.dash.map((v) => v * scope.verticalPixelRatio));
      for (const x of this._xs) {
        const xb = Math.round(x * scope.horizontalPixelRatio);
        ctx.beginPath();
        ctx.moveTo(xb, 0);
        ctx.lineTo(xb, scope.bitmapSize.height);
        ctx.stroke();
      }
      ctx.restore();
    });
  }
}
class SessionBreaksPaneView {
  constructor(source) {
    __publicField(this, "_source");
    __publicField(this, "_xs", []);
    this._source = source;
  }
  update() {
    const timeScale = this._source.chart.timeScale();
    const xs = [];
    for (const time of this._source.breakTimes()) {
      const x = timeScale.timeToCoordinate(time);
      if (x !== null) xs.push(x);
    }
    this._xs = xs;
  }
  renderer() {
    return new SessionBreaksPaneRenderer(this._xs, this._source.options());
  }
  zOrder() {
    return "bottom";
  }
}
class SessionBreaks extends PluginBase {
  constructor(options = {}) {
    super();
    __publicField(this, "_options");
    __publicField(this, "_paneViews");
    __publicField(this, "_breakTimes", []);
    __publicField(this, "_nyFormatter", null);
    // Incremental state so live tick updates don't rescan the whole series.
    __publicField(this, "_lastBarTime", 0);
    __publicField(this, "_lastSessionKey", null);
    this._options = { ...defaultOptions$2, ...options };
    this._paneViews = [new SessionBreaksPaneView(this)];
  }
  options() {
    return this._options;
  }
  breakTimes() {
    return this._breakTimes;
  }
  attached(param) {
    super.attached(param);
    this._recomputeAll();
  }
  dataUpdated(scope) {
    if (scope === "update") this._appendLatest();
    else this._recomputeAll();
    this.requestUpdate();
  }
  updateAllViews() {
    for (const view of this._paneViews) view.update();
  }
  paneViews() {
    return this._paneViews;
  }
  // ── Session detection ──────────────────────────────────────────────
  _recomputeAll() {
    const data = this.series.data();
    const breaks = [];
    let prevKey = null;
    let lastTime = 0;
    for (const bar of data) {
      const t = bar.time;
      const key = this._sessionKey(t);
      if (prevKey !== null && key !== prevKey) breaks.push(t);
      prevKey = key;
      lastTime = t;
    }
    this._breakTimes = breaks;
    this._lastSessionKey = prevKey;
    this._lastBarTime = lastTime;
  }
  /** O(1) handling of live bar updates — only the newest bar can add a break. */
  _appendLatest() {
    const data = this.series.data();
    const last = data[data.length - 1];
    if (!last) return;
    const t = last.time;
    if (t === this._lastBarTime) return;
    if (t < this._lastBarTime) {
      this._recomputeAll();
      return;
    }
    const key = this._sessionKey(t);
    if (this._lastSessionKey !== null && key !== this._lastSessionKey) this._breakTimes.push(t);
    this._lastSessionKey = key;
    this._lastBarTime = t;
  }
  /** Bars with the same key belong to the same trading session. */
  _sessionKey(timeSec) {
    if (this._options.sessionStart === "utc-midnight") return Math.floor(timeSec / 86400);
    return this._nySessionKey(timeSec);
  }
  // Key = the NY calendar day the session opened on; bars before 09:30 local
  // (pre-market / overnight) count toward the previous session.
  _nySessionKey(timeSec) {
    const p = this._nyParts(timeSec);
    let dayMs = Date.UTC(p.year, p.month - 1, p.day);
    if (p.minutesOfDay < RTH_OPEN_MINUTES) dayMs -= 864e5;
    return dayMs / 864e5;
  }
  _nyParts(timeSec) {
    if (!this._nyFormatter) {
      this._nyFormatter = new Intl.DateTimeFormat("en-US", {
        timeZone: "America/New_York",
        year: "numeric",
        month: "numeric",
        day: "numeric",
        hour: "numeric",
        minute: "numeric",
        hourCycle: "h23"
      });
    }
    const fields = {};
    for (const part of this._nyFormatter.formatToParts(new Date(timeSec * 1e3))) {
      if (part.type !== "literal") fields[part.type] = Number(part.value);
    }
    return {
      year: fields.year ?? 1970,
      month: fields.month ?? 1,
      day: fields.day ?? 1,
      minutesOfDay: (fields.hour ?? 0) * 60 + (fields.minute ?? 0)
    };
  }
}
class SessionHighlightingPaneRenderer {
  constructor(data) {
    __publicField(this, "_viewData");
    this._viewData = data;
  }
  draw(target) {
    const points = this._viewData.data;
    target.useBitmapCoordinateSpace((scope) => {
      const ctx = scope.context;
      const yTop = 0;
      const height = scope.bitmapSize.height;
      const halfWidth = scope.horizontalPixelRatio * this._viewData.barWidth / 2;
      const cutOff = -1 * (halfWidth + 1);
      const maxX = scope.bitmapSize.width;
      points.forEach((point) => {
        const xScaled = point.x * scope.horizontalPixelRatio;
        if (xScaled < cutOff) return;
        ctx.fillStyle = point.color || "rgba(0, 0, 0, 0)";
        const x1 = Math.max(0, Math.round(xScaled - halfWidth));
        const x2 = Math.min(maxX, Math.round(xScaled + halfWidth));
        ctx.fillRect(x1, yTop, x2 - x1, height);
      });
    });
  }
}
class SessionHighlightingPaneView {
  constructor(source) {
    __publicField(this, "_source");
    __publicField(this, "_data");
    this._source = source;
    this._data = {
      data: [],
      barWidth: 6,
      options: this._source._options
    };
  }
  update() {
    const timeScale = this._source.chart.timeScale();
    this._data.data = this._source._backgroundColors.map((d) => {
      return {
        x: timeScale.timeToCoordinate(d.time) ?? -100,
        color: d.color
      };
    });
    if (this._data.data.length > 1) {
      this._data.barWidth = this._data.data[1].x - this._data.data[0].x;
    } else {
      this._data.barWidth = 6;
    }
  }
  renderer() {
    return new SessionHighlightingPaneRenderer(this._data);
  }
  zOrder() {
    return "bottom";
  }
}
const defaults = {};
class SessionHighlighting extends PluginBase {
  constructor(highlighter, options = {}) {
    super();
    __publicField(this, "_paneViews");
    __publicField(this, "_seriesData", []);
    __publicField(this, "_backgroundColors", []);
    __publicField(this, "_options");
    __publicField(this, "_highlighter");
    this._highlighter = highlighter;
    this._options = { ...defaults, ...options };
    this._paneViews = [new SessionHighlightingPaneView(this)];
  }
  updateAllViews() {
    this._paneViews.forEach((pw) => pw.update());
  }
  paneViews() {
    return this._paneViews;
  }
  attached(p) {
    super.attached(p);
    this.dataUpdated("full");
  }
  dataUpdated(_scope) {
    this._backgroundColors = this.series.data().map((dataPoint) => {
      return {
        time: dataPoint.time,
        color: this._highlighter(dataPoint.time)
      };
    });
    this.requestUpdate();
  }
}
const defaultOptions$1 = {
  title: "",
  followMode: "tracking",
  horizontalDeadzoneWidth: 45,
  verticalDeadzoneHeight: 100,
  verticalSpacing: 20,
  topOffset: 20
};
class TooltipElement {
  constructor(chart, options) {
    __publicField(this, "_chart");
    __publicField(this, "_element");
    __publicField(this, "_titleElement");
    __publicField(this, "_priceElement");
    __publicField(this, "_dateElement");
    __publicField(this, "_timeElement");
    __publicField(this, "_options");
    __publicField(this, "_lastTooltipWidth", null);
    this._options = {
      ...defaultOptions$1,
      ...options
    };
    this._chart = chart;
    const element = document.createElement("div");
    applyStyle(element, {
      display: "flex",
      "flex-direction": "column",
      "align-items": "center",
      position: "absolute",
      transform: "translate(calc(0px - 50%), 0px)",
      opacity: "0",
      left: "0%",
      top: "0",
      "z-index": "100",
      "background-color": "white",
      "border-radius": "4px",
      padding: "5px 10px",
      "font-family": "-apple-system, BlinkMacSystemFont, 'Trebuchet MS', Roboto, Ubuntu, sans-serif",
      "font-size": "12px",
      "font-weight": "400",
      "box-shadow": "0px 2px 4px rgba(0, 0, 0, 0.2)",
      "line-height": "16px",
      "pointer-events": "none",
      color: "#131722"
    });
    const titleElement = document.createElement("div");
    applyStyle(titleElement, {
      "font-size": "16px",
      "line-height": "24px",
      "font-weight": "590"
    });
    setElementText(titleElement, this._options.title);
    element.appendChild(titleElement);
    const priceElement = document.createElement("div");
    applyStyle(priceElement, {
      "font-size": "14px",
      "line-height": "18px",
      "font-weight": "590"
    });
    setElementText(priceElement, "");
    element.appendChild(priceElement);
    const dateElement = document.createElement("div");
    applyStyle(dateElement, {
      color: "#787B86"
    });
    setElementText(dateElement, "");
    element.appendChild(dateElement);
    const timeElement = document.createElement("div");
    applyStyle(timeElement, {
      color: "#787B86"
    });
    setElementText(timeElement, "");
    element.appendChild(timeElement);
    this._element = element;
    this._titleElement = titleElement;
    this._priceElement = priceElement;
    this._dateElement = dateElement;
    this._timeElement = timeElement;
    const chartElement = this._chart.chartElement();
    chartElement.appendChild(this._element);
    const chartElementParent = chartElement.parentElement;
    if (!chartElementParent) {
      console.error("Chart Element is not attached to the page.");
      return;
    }
    const position = getComputedStyle(chartElementParent).position;
    if (position !== "relative" && position !== "absolute") {
      console.error("Chart Element position is expected be `relative` or `absolute`.");
    }
  }
  destroy() {
    if (this._chart && this._element) this._chart.chartElement().removeChild(this._element);
  }
  applyOptions(options) {
    this._options = {
      ...this._options,
      ...options
    };
  }
  options() {
    return this._options;
  }
  updateTooltipContent(tooltipContentData) {
    if (!this._element) return;
    const tooltipMeasurement = this._element.getBoundingClientRect();
    this._lastTooltipWidth = tooltipMeasurement.width;
    if (tooltipContentData.title !== void 0 && this._titleElement) {
      setElementText(this._titleElement, tooltipContentData.title);
    }
    setElementText(this._priceElement, tooltipContentData.price);
    setElementText(this._dateElement, tooltipContentData.date);
    setElementText(this._timeElement, tooltipContentData.time);
  }
  updatePosition(positionData) {
    if (!this._chart || !this._element) return;
    this._element.style.opacity = positionData.visible ? "1" : "0";
    if (!positionData.visible) {
      return;
    }
    const x = this._calculateXPosition(positionData, this._chart);
    const y = this._calculateYPosition(positionData);
    this._element.style.transform = `translate(${x}, ${y})`;
  }
  _calculateXPosition(positionData, chart) {
    const x = positionData.paneX + chart.priceScale("left").width();
    const deadzoneWidth = this._lastTooltipWidth ? Math.ceil(this._lastTooltipWidth / 2) : this._options.horizontalDeadzoneWidth;
    const xAdjusted = Math.min(
      Math.max(deadzoneWidth, x),
      chart.timeScale().width() - deadzoneWidth
    );
    return `calc(${xAdjusted}px - 50%)`;
  }
  _calculateYPosition(positionData) {
    if (this._options.followMode === "top") {
      return `${this._options.topOffset}px`;
    }
    const y = positionData.paneY;
    const flip = y <= this._options.verticalSpacing + this._options.verticalDeadzoneHeight;
    const yPx = y + (flip ? 1 : -1) * this._options.verticalSpacing;
    const yPct = flip ? "" : " - 100%";
    return `calc(${yPx}px${yPct})`;
  }
}
function setElementText(element, text) {
  if (!element || text === element.innerText) return;
  element.innerText = text;
  element.style.display = text ? "block" : "none";
}
function applyStyle(element, styles2) {
  for (const [key, value] of Object.entries(styles2)) {
    element.style.setProperty(key, value);
  }
}
class TooltipCrosshairLinePaneRenderer2 {
  constructor(data) {
    __publicField(this, "_data");
    this._data = data;
  }
  draw(target) {
    if (!this._data.visible) return;
    target.useBitmapCoordinateSpace((scope) => {
      const ctx = scope.context;
      const crosshairPos = positionsLine(this._data.x, scope.horizontalPixelRatio, 1);
      ctx.fillStyle = this._data.color;
      ctx.fillRect(
        crosshairPos.position,
        this._data.topMargin * scope.verticalPixelRatio,
        crosshairPos.length,
        scope.bitmapSize.height
      );
    });
  }
}
class MultiTouchCrosshairPaneView2 {
  constructor(data) {
    __publicField(this, "_data");
    this._data = data;
  }
  update(data) {
    this._data = data;
  }
  renderer() {
    return new TooltipCrosshairLinePaneRenderer2(this._data);
  }
  zOrder() {
    return "bottom";
  }
}
const defaultOptions = {
  lineColor: "rgba(0, 0, 0, 0.2)",
  priceExtractor: (data) => {
    if (data.value !== void 0) {
      return data.value.toFixed(2);
    }
    if (data.close !== void 0) {
      return data.close.toFixed(2);
    }
    return "";
  }
};
class TooltipPrimitive {
  constructor(options) {
    __publicField(this, "_options");
    __publicField(this, "_tooltip");
    __publicField(this, "_paneViews");
    __publicField(this, "_data", {
      x: 0,
      visible: false,
      color: "rgba(0, 0, 0, 0.2)",
      topMargin: 0
    });
    __publicField(this, "_attachedParams");
    __publicField(this, "_moveHandler", (param) => this._onMouseMove(param));
    this._options = {
      ...defaultOptions,
      ...options
    };
    this._paneViews = [new MultiTouchCrosshairPaneView2(this._data)];
  }
  attached(param) {
    this._attachedParams = param;
    this._setCrosshairMode();
    param.chart.subscribeCrosshairMove(this._moveHandler);
    this._createTooltipElement();
  }
  detached() {
    var _a;
    const chart = this.chart();
    if (chart) {
      chart.unsubscribeCrosshairMove(this._moveHandler);
    }
    (_a = this._tooltip) == null ? void 0 : _a.destroy();
    this._tooltip = void 0;
  }
  paneViews() {
    return this._paneViews;
  }
  updateAllViews() {
    this._paneViews.forEach((pw) => pw.update(this._data));
  }
  setData(data) {
    var _a;
    this._data = data;
    this.updateAllViews();
    (_a = this._attachedParams) == null ? void 0 : _a.requestUpdate();
  }
  currentColor() {
    return this._options.lineColor;
  }
  chart() {
    var _a;
    return (_a = this._attachedParams) == null ? void 0 : _a.chart;
  }
  series() {
    var _a;
    return (_a = this._attachedParams) == null ? void 0 : _a.series;
  }
  applyOptions(options) {
    this._options = {
      ...this._options,
      ...options
    };
    if (this._tooltip) {
      this._tooltip.applyOptions({ ...this._options.tooltip });
    }
  }
  _setCrosshairMode() {
    const chart = this.chart();
    if (!chart) {
      throw new Error("Unable to change crosshair mode because the chart instance is undefined");
    }
    chart.applyOptions({
      crosshair: {
        mode: CrosshairMode.Magnet,
        vertLine: {
          visible: false,
          labelVisible: false
        },
        horzLine: {
          visible: false,
          labelVisible: false
        }
      }
    });
  }
  _hideTooltip() {
    if (!this._tooltip) return;
    this._tooltip.updateTooltipContent({
      title: "",
      price: "",
      date: "",
      time: ""
    });
    this._tooltip.updatePosition({
      paneX: 0,
      paneY: 0,
      visible: false
    });
  }
  _hideCrosshair() {
    this._hideTooltip();
    this.setData({
      x: 0,
      visible: false,
      color: this.currentColor(),
      topMargin: 0
    });
  }
  _onMouseMove(param) {
    var _a, _b;
    const chart = this.chart();
    const series = this.series();
    const logical = param.logical;
    if (!logical || !chart || !series) {
      this._hideCrosshair();
      return;
    }
    const data = param.seriesData.get(series);
    if (!data) {
      this._hideCrosshair();
      return;
    }
    const price = this._options.priceExtractor(data);
    const coordinate = chart.timeScale().logicalToCoordinate(logical);
    const [date, time] = formattedDateAndTime(param.time ? convertTime(param.time) : void 0);
    if (this._tooltip) {
      const tooltipOptions = this._tooltip.options();
      const topMargin = tooltipOptions.followMode === "top" ? tooltipOptions.topOffset + 10 : 0;
      this.setData({
        x: coordinate ?? 0,
        visible: coordinate !== null,
        color: this.currentColor(),
        topMargin
      });
      this._tooltip.updateTooltipContent({
        price,
        date,
        time
      });
      this._tooltip.updatePosition({
        paneX: ((_a = param.point) == null ? void 0 : _a.x) ?? 0,
        paneY: ((_b = param.point) == null ? void 0 : _b.y) ?? 0,
        visible: true
      });
    }
  }
  _createTooltipElement() {
    const chart = this.chart();
    if (!chart) throw new Error("Unable to create Tooltip element. Chart not attached");
    this._tooltip = new TooltipElement(chart, {
      ...this._options.tooltip
    });
  }
}
const DEFAULT_TIMEZONE = "Etc/UTC";
function validTimezone(input) {
  try {
    new Intl.DateTimeFormat("en", { timeZone: input });
    return input;
  } catch {
    return DEFAULT_TIMEZONE;
  }
}
function dateForChartTime(time) {
  if (typeof time === "number") {
    const date = new Date(time * 1e3);
    return Number.isNaN(date.getTime()) ? null : date;
  }
  if (typeof time === "string") {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(time);
    if (!match) return null;
    return new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
  }
  return new Date(Date.UTC(time.year, time.month - 1, time.day));
}
function dateParts(date, timezone, locale, showWeekday) {
  return Object.fromEntries(
    new Intl.DateTimeFormat(locale, {
      timeZone: timezone,
      year: "numeric",
      month: "short",
      day: "2-digit",
      ...showWeekday ? { weekday: "short" } : {}
    }).formatToParts(date).map(({ type, value }) => [type, value])
  );
}
function formatChartTimeLabel(time, timezone, timeFormat, dateFormat, locale, tickMarkType, showDayOfWeek = false) {
  const date = dateForChartTime(time);
  if (!date) return "";
  const resolvedTimezone = validTimezone(timezone);
  if (tickMarkType === TickMarkType.Year) {
    return new Intl.DateTimeFormat(locale, { timeZone: resolvedTimezone, year: "numeric" }).format(date);
  }
  if (tickMarkType === TickMarkType.Month) {
    return new Intl.DateTimeFormat(locale, { timeZone: resolvedTimezone, month: "short" }).format(date);
  }
  if (tickMarkType === TickMarkType.Time || tickMarkType === TickMarkType.TimeWithSeconds) {
    const use12HourClock = timeFormat === "12-hour";
    return new Intl.DateTimeFormat(locale, {
      timeZone: resolvedTimezone,
      hour: "numeric",
      minute: "2-digit",
      ...tickMarkType === TickMarkType.TimeWithSeconds ? { second: "2-digit" } : {},
      hourCycle: use12HourClock ? "h12" : "h23"
    }).format(date);
  }
  const prefix = showDayOfWeek && tickMarkType === TickMarkType.DayOfMonth;
  if (dateFormat === "locale") {
    return new Intl.DateTimeFormat(locale, {
      timeZone: resolvedTimezone,
      year: "numeric",
      month: "short",
      day: "2-digit",
      ...prefix ? { weekday: "short" } : {}
    }).format(date);
  }
  const parts = dateParts(date, resolvedTimezone, locale, prefix);
  const formattedDate = dateFormat === "yyyy-MM-dd" ? `${parts.year}-${parts.month}-${parts.day}` : dateFormat === "dd MMM yyyy" ? `${parts.day} ${parts.month} ${parts.year}` : `${parts.month} ${parts.day}, ${parts.year}`;
  return prefix ? `${parts.weekday}, ${formattedDate}` : formattedDate;
}
function mapPriceScaleMode(mode) {
  switch (mode) {
    case "logarithmic":
      return PriceScaleMode.Logarithmic;
    case "percentage":
      return PriceScaleMode.Percentage;
    case "indexedTo100":
      return PriceScaleMode.IndexedTo100;
    default:
      return PriceScaleMode.Normal;
  }
}
function mapCrosshairLineStyle(style) {
  switch (style) {
    case "solid":
      return LineStyle.Solid;
    case "dotted":
      return LineStyle.Dotted;
    case "dashed":
      return LineStyle.Dashed;
    default:
      return LineStyle.LargeDashed;
  }
}
function boundedMargin(value) {
  return Number.isFinite(value) ? Math.min(0.45, Math.max(0, value)) : 0.2;
}
function buildChartSettingsOptions(prefs, colors, timeframe) {
  const timezone = validTimezone(prefs.displayTimezone);
  const lineStyle = mapCrosshairLineStyle(prefs.crosshairLineStyle);
  const rightOffset = prefs.timeScaleRightOffset === "default" ? timeframe === "1m" ? CHART_SETTINGS_DEFAULTS.oneMinuteRightOffset : CHART_SETTINGS_DEFAULTS.rightOffset : prefs.timeScaleRightOffset;
  const secondsVisible = prefs.timeScaleSecondsVisible === "auto" ? timeframe === "1m" : prefs.timeScaleSecondsVisible;
  const tickMarkFormatter = (time, tickMarkType, locale) => formatChartTimeLabel(
    time,
    timezone,
    prefs.timeScaleTimeFormat,
    prefs.timeScaleDateFormat,
    locale,
    tickMarkType,
    prefs.timeScaleShowDayOfWeek
  );
  const chartBackground = prefs.chartBackgroundMode === "transparent" ? "rgba(0, 0, 0, 0)" : prefs.colorBackground || colors.background;
  const sideVisible = prefs.showPriceScale;
  const selectedMode = mapPriceScaleMode(prefs.priceScaleMode);
  const scaleMargins = {
    top: boundedMargin(prefs.priceScaleTopMargin),
    bottom: boundedMargin(prefs.priceScaleBottomMargin)
  };
  return {
    layout: {
      background: { type: ColorType.Solid, color: chartBackground },
      textColor: prefs.colorScaleText || colors.text,
      fontSize: prefs.scaleTextSize
    },
    grid: {
      vertLines: {
        visible: prefs.showVerticalGrid,
        color: prefs.colorVerticalGrid || colors.grid
      },
      horzLines: {
        visible: prefs.showHorizontalGrid,
        color: prefs.colorHorizontalGrid || colors.grid
      }
    },
    leftPriceScale: {
      visible: sideVisible && prefs.priceScaleSide === "left",
      mode: selectedMode,
      invertScale: prefs.priceScaleInverted && prefs.priceScaleSide === "left",
      alignLabels: prefs.noOverlappingLabels,
      borderVisible: prefs.showScaleBorder,
      borderColor: prefs.colorGrid || colors.grid,
      textColor: prefs.colorScaleText || colors.text,
      scaleMargins
    },
    rightPriceScale: {
      visible: sideVisible && prefs.priceScaleSide === "right",
      mode: selectedMode,
      invertScale: prefs.priceScaleInverted && prefs.priceScaleSide === "right",
      alignLabels: prefs.noOverlappingLabels,
      borderVisible: prefs.showScaleBorder,
      borderColor: prefs.colorGrid || colors.grid,
      textColor: prefs.colorScaleText || colors.text,
      scaleMargins
    },
    timeScale: {
      visible: prefs.showTimeScale,
      rightOffset,
      secondsVisible,
      tickMarkFormatter
    },
    localization: {
      timeFormatter: (time) => formatChartTimeLabel(
        time,
        timezone,
        prefs.timeScaleTimeFormat,
        prefs.timeScaleDateFormat,
        typeof navigator === "undefined" ? "en-US" : navigator.language || "en-US",
        TickMarkType.Time
      )
    },
    crosshair: {
      vertLine: { color: prefs.colorCrosshair || colors.crosshair, labelBackgroundColor: prefs.colorCrosshair || colors.crosshair, style: lineStyle },
      horzLine: { color: prefs.colorCrosshair || colors.crosshair, labelBackgroundColor: prefs.colorCrosshair || colors.crosshair, style: lineStyle }
    },
    watermark: {
      visible: prefs.watermarkMode !== "none",
      text: "",
      color: colors.watermark
    },
    handleScroll: prefs.enableChartScroll,
    handleScale: prefs.enableChartScale
  };
}
function buildCandlestickSettingsOptions(prefs, colors, pipDigits, minMove) {
  const precision = prefs.pricePrecision === "default" ? pipDigits : prefs.pricePrecision;
  const computedMinMove = prefs.pricePrecision === "default" ? minMove : 10 ** -precision;
  return {
    upColor: prefs.candleBullBodyColor || colors.up,
    downColor: prefs.candleBearBodyColor || colors.down,
    borderUpColor: prefs.candleBullBorderColor || colors.up,
    borderDownColor: prefs.candleBearBorderColor || colors.down,
    wickUpColor: prefs.candleBullWickColor || colors.up,
    wickDownColor: prefs.candleBearWickColor || colors.down,
    wickVisible: prefs.showWicks,
    borderVisible: prefs.showCandleBorders,
    priceLineVisible: prefs.showPriceLine,
    lastValueVisible: prefs.showLastValue,
    priceScaleId: prefs.priceScaleSide,
    priceFormat: { type: "price", precision, minMove: computedMinMove }
  };
}
const TEXT_TABS = ["text", "style", "coordinates", "visibility"];
const STANDARD_TABS = ["style", "text", "coordinates", "visibility"];
const COMPACT_TABS = ["style", "coordinates", "visibility"];
const POSITION_TABS = ["inputs", "style", "visibility"];
const TEXT_TYPES = /* @__PURE__ */ new Set(["text", "anchored-text", "note"]);
const COMPACT_TYPES = /* @__PURE__ */ new Set([
  "fibonacci",
  "fibextension",
  "price-range",
  "date-range",
  "date-price-range",
  "position"
]);
function finite(value, fallback) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}
function positive(value, fallback) {
  return typeof value === "number" && Number.isFinite(value) && value > 0 ? value : fallback;
}
function unitInterval(value, fallback) {
  const next = finite(value, fallback);
  return Math.min(1, Math.max(0, next));
}
function settingsTabsFor(type) {
  if (type === "position") return [...POSITION_TABS];
  if (TEXT_TYPES.has(type)) return [...TEXT_TABS];
  if (COMPACT_TYPES.has(type)) return [...COMPACT_TABS];
  return [...STANDARD_TABS];
}
function visibilityUnitFor(timeframe) {
  if (/t$/i.test(timeframe)) return "ticks";
  if (/r$/i.test(timeframe)) return "ranges";
  if (/s$/i.test(timeframe)) return "seconds";
  if (/m$/.test(timeframe)) return "minutes";
  if (/h$/i.test(timeframe)) return "hours";
  if (/d$/i.test(timeframe)) return "days";
  if (/w$/i.test(timeframe)) return "weeks";
  if (/M$/.test(timeframe)) return "months";
  return "minutes";
}
function isDrawingVisibleOnTimeframe(drawing, timeframe) {
  if (drawing.visibility === "tf" && drawing.createdTf !== timeframe) return false;
  const rules = drawing.visibilityRules;
  return rules ? rules[visibilityUnitFor(timeframe)] !== false : true;
}
function normalizeDrawingSettings(drawing) {
  const riskValue = positive(drawing.riskValue, positive(drawing.riskPct, 1));
  return {
    ...drawing,
    opacity: unitInterval(drawing.opacity, 1),
    fillColor: drawing.fillColor ?? drawing.color,
    fillOpacity: unitInterval(drawing.fillOpacity, 0.14),
    textAlign: drawing.textAlign ?? "center",
    textPlacement: drawing.textPlacement ?? "inside",
    visibility: drawing.visibility === "tf" ? "tf" : "all",
    visibilityRules: drawing.visibilityRules ?? {
      ticks: true,
      seconds: true,
      minutes: true,
      hours: true,
      days: true,
      weeks: true,
      months: true,
      ranges: true
    },
    positiveColor: drawing.positiveColor ?? "#089981",
    negativeColor: drawing.negativeColor ?? "#f23645",
    labelColor: drawing.labelColor ?? "#ffffff",
    rangeLabelMode: drawing.rangeLabelMode ?? "full",
    accountSize: positive(drawing.accountSize, 1e3),
    lotSize: positive(drawing.lotSize, 1),
    leverage: positive(drawing.leverage, 1),
    riskValue,
    riskUnit: drawing.riskUnit === "currency" ? "currency" : "percent",
    quantityPrecision: drawing.quantityPrecision ?? "default",
    tickSize: positive(drawing.tickSize, 0.1),
    stopColor: drawing.stopColor ?? "#f23645",
    targetColor: drawing.targetColor ?? "#089981",
    stopFillOpacity: unitInterval(drawing.stopFillOpacity, 0.2),
    targetFillOpacity: unitInterval(drawing.targetFillOpacity, 0.2),
    showPriceLabels: drawing.showPriceLabels ?? true,
    statsMode: drawing.statsMode ?? "price-offsets",
    compactStats: drawing.compactStats ?? false,
    alwaysShowStats: drawing.alwaysShowStats ?? false
  };
}
function validatePositive(errors, field, value, message) {
  if (!Number.isFinite(value) || value <= 0) errors[field] = message;
}
function validateDrawingSettings(draft) {
  var _a, _b;
  const errors = {};
  if (!Number.isFinite(draft.price)) errors.price = "Price must be a finite value";
  for (const field of ["time", "price2", "time2", "price3", "time3", "controlPrice", "controlTime"]) {
    const value = draft[field];
    if (value !== void 0 && !Number.isFinite(value)) {
      errors[field] = `${field.toLowerCase().includes("time") ? "Bar" : "Price"} must be a finite value`;
    }
  }
  if ((_a = draft.points) == null ? void 0 : _a.some((point) => !Number.isFinite(point.time) || !Number.isFinite(point.price))) {
    errors.points = "First and last points must use finite price and bar values";
  }
  if ((_b = draft.fibLevelStyles) == null ? void 0 : _b.some((level) => !Number.isFinite(level.value))) {
    errors.fibLevelStyles = "Fibonacci level values must be finite";
  }
  if (draft.type !== "position") return errors;
  validatePositive(errors, "accountSize", draft.accountSize, "Account size must be greater than 0");
  validatePositive(errors, "lotSize", draft.lotSize, "Lot size must be greater than 0");
  validatePositive(
    errors,
    "leverage",
    draft.leverage,
    "Leverage must be a finite value greater than 0"
  );
  validatePositive(errors, "riskValue", draft.riskValue, "Risk must be greater than 0");
  const stop2 = draft.stopPrice;
  const target = draft.targetPrice;
  if (typeof stop2 !== "number" || !Number.isFinite(stop2)) errors.stopPrice = "Stop price is required";
  if (typeof target !== "number" || !Number.isFinite(target)) {
    errors.targetPrice = "Target price is required";
  }
  if (!Number.isFinite(draft.price) || draft.price <= 0) errors.price = "Entry price must be greater than 0";
  if (Number.isFinite(draft.price) && typeof stop2 === "number" && Number.isFinite(stop2)) {
    if (draft.side === "short" && stop2 <= draft.price) {
      errors.stopPrice = "Stop must be above entry for a short position";
    } else if (draft.side !== "short" && stop2 >= draft.price) {
      errors.stopPrice = "Stop must be below entry for a long position";
    }
  }
  if (Number.isFinite(draft.price) && typeof target === "number" && Number.isFinite(target)) {
    if (draft.side === "short" && target >= draft.price) {
      errors.targetPrice = "Target must be below entry for a short position";
    } else if (draft.side !== "short" && target <= draft.price) {
      errors.targetPrice = "Target must be above entry for a long position";
    }
  }
  return errors;
}
function positionMetrics(draft) {
  if (draft.type !== "position" || Object.keys(validateDrawingSettings(draft)).length > 0) return null;
  const stop2 = draft.stopPrice;
  const target = draft.targetPrice;
  const short = draft.side === "short";
  const stopDistance = short ? stop2 - draft.price : draft.price - stop2;
  const targetDistance = short ? draft.price - target : target - draft.price;
  const riskAmount = draft.riskUnit === "currency" ? draft.riskValue : draft.accountSize * draft.riskValue / 100;
  const quantity = riskAmount / (stopDistance * draft.lotSize);
  const notional = quantity * draft.lotSize * draft.price;
  return {
    riskAmount,
    quantity,
    notional,
    margin: notional / draft.leverage,
    targetAmount: quantity * draft.lotSize * targetDistance,
    targetDistance,
    targetPercent: targetDistance / draft.price * 100,
    targetTicks: targetDistance / draft.tickSize,
    stopAmount: riskAmount,
    stopDistance,
    stopPercent: stopDistance / draft.price * 100,
    stopTicks: stopDistance / draft.tickSize,
    riskReward: targetDistance / stopDistance
  };
}
function MenuItem$1({
  icon,
  label,
  onClick,
  danger = false
}) {
  return /* @__PURE__ */ jsxs(
    "button",
    {
      onClick,
      className: cn(
        "flex w-full items-center gap-2.5 px-3 py-1.5 text-left text-xs transition-colors",
        danger ? "text-red-400 hover:bg-red-500/10" : "text-foreground hover:bg-secondary"
      ),
      children: [
        /* @__PURE__ */ jsx("span", { className: "flex h-3.5 w-3.5 items-center justify-center text-muted-foreground", children: icon }),
        /* @__PURE__ */ jsx("span", { className: "flex-1 truncate", children: label })
      ]
    }
  );
}
function Separator() {
  return /* @__PURE__ */ jsx("div", { className: "my-1 border-t border-border" });
}
function buyOrderType(price, ask) {
  return price <= ask ? "LIMIT" : "STOP";
}
function sellOrderType(price, bid) {
  return price >= bid ? "LIMIT" : "STOP";
}
function TradeSection({
  price,
  pipDigits,
  symbol,
  tick,
  onQuickOrder,
  onAddAlert,
  onClose
}) {
  const p = price.toFixed(pipDigits);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    onAddAlert && /* @__PURE__ */ jsx(
      MenuItem$1,
      {
        icon: /* @__PURE__ */ jsx(Bell, { className: "h-3.5 w-3.5" }),
        label: `Add alert on ${symbol} at ${p}`,
        onClick: () => {
          onAddAlert(price);
          onClose();
        }
      }
    ),
    onQuickOrder && tick && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(
        MenuItem$1,
        {
          icon: /* @__PURE__ */ jsx(ArrowUpFromLine, { className: "h-3.5 w-3.5" }),
          label: `Buy 1 ${symbol} @ ${p} ${buyOrderType(price, tick.ask).toLowerCase()}`,
          onClick: () => {
            onQuickOrder("BUY", buyOrderType(price, tick.ask), price);
            onClose();
          }
        }
      ),
      /* @__PURE__ */ jsx(
        MenuItem$1,
        {
          icon: /* @__PURE__ */ jsx(ArrowDownToLine, { className: "h-3.5 w-3.5" }),
          label: `Sell 1 ${symbol} @ ${p} ${sellOrderType(price, tick.bid).toLowerCase()}`,
          onClick: () => {
            onQuickOrder("SELL", sellOrderType(price, tick.bid), price);
            onClose();
          }
        }
      )
    ] })
  ] });
}
function ChartContextMenu(props) {
  const {
    x,
    y,
    price,
    pipDigits,
    drawingsCount,
    indicatorsCount,
    onClose,
    onResetView,
    onCopyPrice,
    onOpenObjectTree,
    onRemoveAllDrawings,
    onClearIndicators,
    onOpenSettings
  } = props;
  const menuRef = useRef(null);
  const [pos, setPos] = useState({ x, y });
  useLayoutEffect(() => {
    const el = menuRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    setPos({
      x: Math.max(8, Math.min(x, window.innerWidth - rect.width - 8)),
      y: Math.max(8, Math.min(y, window.innerHeight - rect.height - 8))
    });
  }, [x, y]);
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  return createPortal(
    /* @__PURE__ */ jsxs("div", { className: "opencharts", "data-chart-context-layer": true, style: { position: "fixed", inset: 0, width: "auto", height: "auto", overflow: "visible", zIndex: 900, pointerEvents: "none", background: "transparent" }, children: [
      /* @__PURE__ */ jsx(
        "div",
        {
          className: "fixed inset-0 z-40",
          style: { pointerEvents: "auto" },
          onClick: onClose,
          onContextMenu: (e) => {
            e.preventDefault();
            onClose();
          }
        }
      ),
      /* @__PURE__ */ jsxs(
        "div",
        {
          ref: menuRef,
          style: { left: pos.x, top: pos.y, pointerEvents: "auto", maxHeight: "calc(100dvh - 16px)", maxWidth: "calc(100vw - 16px)", overflowY: "auto" },
          className: "fixed z-50 min-w-[230px] rounded-lg border border-border bg-card/95 py-1 shadow-2xl backdrop-blur-xl",
          children: [
            /* @__PURE__ */ jsx(
              MenuItem$1,
              {
                icon: /* @__PURE__ */ jsx(RotateCcw, { className: "h-3.5 w-3.5" }),
                label: "Reset chart view",
                onClick: () => {
                  onResetView();
                  onClose();
                }
              }
            ),
            price != null && /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx(Separator, {}),
              /* @__PURE__ */ jsx(
                MenuItem$1,
                {
                  icon: /* @__PURE__ */ jsx(ClipboardCopy, { className: "h-3.5 w-3.5" }),
                  label: `Copy price ${price.toFixed(pipDigits)}`,
                  onClick: () => {
                    onCopyPrice(price);
                    onClose();
                  }
                }
              ),
              /* @__PURE__ */ jsx(Separator, {}),
              /* @__PURE__ */ jsx(TradeSection, { ...props, price })
            ] }),
            /* @__PURE__ */ jsx(Separator, {}),
            /* @__PURE__ */ jsx(
              MenuItem$1,
              {
                icon: /* @__PURE__ */ jsx(ListTree, { className: "h-3.5 w-3.5" }),
                label: "Object tree",
                onClick: () => {
                  onOpenObjectTree();
                  onClose();
                }
              }
            ),
            (drawingsCount > 0 || indicatorsCount > 0) && /* @__PURE__ */ jsx(Separator, {}),
            drawingsCount > 0 && onRemoveAllDrawings && /* @__PURE__ */ jsx(
              MenuItem$1,
              {
                icon: /* @__PURE__ */ jsx(Trash2, { className: "h-3.5 w-3.5" }),
                label: `Remove ${drawingsCount} drawing${drawingsCount === 1 ? "" : "s"}`,
                danger: true,
                onClick: () => {
                  onRemoveAllDrawings();
                  onClose();
                }
              }
            ),
            indicatorsCount > 0 && onClearIndicators && /* @__PURE__ */ jsx(
              MenuItem$1,
              {
                icon: /* @__PURE__ */ jsx(Trash2, { className: "h-3.5 w-3.5" }),
                label: `Remove ${indicatorsCount} indicator${indicatorsCount === 1 ? "" : "s"}`,
                danger: true,
                onClick: () => {
                  onClearIndicators();
                  onClose();
                }
              }
            ),
            /* @__PURE__ */ jsx(Separator, {}),
            /* @__PURE__ */ jsx(
              MenuItem$1,
              {
                icon: /* @__PURE__ */ jsx(Settings, { className: "h-3.5 w-3.5" }),
                label: "Chart Settings…",
                onClick: () => {
                  onOpenSettings();
                  onClose();
                }
              }
            )
          ]
        }
      )
    ] }),
    document.body
  );
}
const ENUM_VALUES = {
  displayTimezone: [],
  priceScaleMode: ["normal", "logarithmic", "percentage", "indexedTo100"],
  priceScaleSide: ["right", "left"],
  timeScaleDateFormat: ["locale", "yyyy-MM-dd", "dd MMM yyyy", "MMM dd, yyyy"],
  timeScaleTimeFormat: ["24-hour", "12-hour"],
  timeScaleSecondsVisible: ["auto"],
  timeScaleRightOffset: ["default"],
  watermarkMode: ["none", "symbol", "symbol-timeframe"],
  crosshairLineStyle: ["solid", "dotted", "dashed", "large-dashed"],
  chartBackgroundMode: ["solid", "transparent"]
};
function isTemplateValue(key, value) {
  const defaults2 = getChartPreferencesFromStorage();
  const expected = defaults2[key];
  if (key === "pricePrecision") {
    return value === "default" || typeof value === "number" && Number.isInteger(value) && value >= 0 && value <= 8;
  }
  if (key === "priceScaleTopMargin" || key === "priceScaleBottomMargin") {
    return typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 0.45;
  }
  if (key === "scaleTextSize") return typeof value === "number" && Number.isFinite(value) && value >= 8 && value <= 20;
  if (key === "timeScaleRightOffset") {
    return value === "default" || typeof value === "number" && Number.isInteger(value) && value >= 0 && value <= 50;
  }
  if (key === "timeScaleSecondsVisible") return value === "auto" || typeof value === "boolean";
  if (key === "displayTimezone") {
    if (typeof value !== "string") return false;
    try {
      new Intl.DateTimeFormat("en", { timeZone: value });
      return true;
    } catch {
      return false;
    }
  }
  if (typeof value !== typeof expected) return false;
  if (key.startsWith("color") || key.startsWith("candle")) {
    return value === "" || typeof value === "string" && /^#(?:[\da-f]{3}|[\da-f]{6}|[\da-f]{8})$/i.test(value);
  }
  if (typeof value === "string") {
    const allowed = ENUM_VALUES[key];
    return allowed ? allowed.includes(value) : true;
  }
  return true;
}
function supportedPreferences(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const input = value;
  const result = {};
  for (const key of TEMPLATE_PREF_KEYS) {
    if (Object.hasOwn(input, key) && isTemplateValue(key, input[key])) {
      Object.assign(result, { [key]: input[key] });
    }
  }
  return result;
}
function parseTemplates(raw) {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.flatMap((entry) => {
      if (!entry || typeof entry !== "object") return [];
      const candidate = entry;
      if (typeof candidate.id !== "string" || typeof candidate.name !== "string" || !candidate.name.trim()) return [];
      return [{
        id: candidate.id,
        name: candidate.name.trim(),
        preferences: supportedPreferences(candidate.preferences)
      }];
    });
  } catch {
    return [];
  }
}
function writeTemplates(templates) {
  updateChartPreferences({
    chartSettingsTemplates: JSON.stringify(templates)
  });
}
function newTemplateId() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  return `chart-settings-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}
function readChartSettingsTemplates() {
  var _a;
  const userId2 = (_a = useAuthStore.getState().user) == null ? void 0 : _a.id;
  return parseTemplates(readTraderPrefs$1(userId2).chartSettingsTemplates);
}
function saveChartSettingsTemplate(name, prefs) {
  const normalizedName = name.trim();
  const current2 = readChartSettingsTemplates();
  if (!normalizedName) return current2;
  const matching = current2.find((template2) => template2.name.toLocaleLowerCase() === normalizedName.toLocaleLowerCase());
  const template = {
    id: (matching == null ? void 0 : matching.id) ?? newTemplateId(),
    name: normalizedName,
    preferences: supportedPreferences(prefs)
  };
  const next = [template, ...current2.filter((entry) => entry.id !== template.id && entry.name.toLocaleLowerCase() !== normalizedName.toLocaleLowerCase())];
  writeTemplates(next);
  return next;
}
function deleteChartSettingsTemplate(id) {
  const current2 = readChartSettingsTemplates();
  const next = current2.filter((template) => template.id !== id);
  if (next.length !== current2.length) writeTemplates(next);
  return next;
}
const BASE_COLORS = [
  "#f23645",
  "#ff9800",
  "#ffeb3b",
  "#4caf50",
  "#089981",
  "#00bcd4",
  "#2962ff",
  "#673ab7",
  "#9c27b0",
  "#e91e63"
];
const GRAYSCALE = [
  "#ffffff",
  "#d9d9d9",
  "#bfbfbf",
  "#a6a6a6",
  "#8c8c8c",
  "#737373",
  "#595959",
  "#404040",
  "#262626",
  "#000000"
];
const RECENT_LIMIT = 8;
let recentColors = [];
function parseColor(input) {
  const match = /^#([\da-f]{3,4}|[\da-f]{6}|[\da-f]{8})$/i.exec(input.trim());
  if (!match) return { hex: "#2962ff", opacity: 1 };
  let value = match[1].toLowerCase();
  if (value.length === 3 || value.length === 4) {
    value = value.split("").map((char) => char + char).join("");
  }
  const alpha2 = value.length === 8 ? parseInt(value.slice(6, 8), 16) / 255 : 1;
  return { hex: "#" + value.slice(0, 6), opacity: alpha2 };
}
function encodeColor(hex, opacity) {
  const alpha2 = Math.round(Math.max(0, Math.min(1, opacity)) * 255);
  return alpha2 === 255 ? hex : hex + alpha2.toString(16).padStart(2, "0");
}
function mixColor(color, target, amount) {
  const source = parseColor(color).hex.slice(1);
  const destination = parseColor(target).hex.slice(1);
  const channels = [0, 2, 4].map((index) => {
    const start2 = parseInt(source.slice(index, index + 2), 16);
    const end = parseInt(destination.slice(index, index + 2), 16);
    return Math.round(start2 + (end - start2) * amount).toString(16).padStart(2, "0");
  });
  return "#" + channels.join("");
}
function paletteRows() {
  return [
    GRAYSCALE,
    BASE_COLORS,
    ...[0.82, 0.64, 0.46, 0.28].map((amount) => BASE_COLORS.map((color) => mixColor(color, "#ffffff", amount))),
    ...[0.28, 0.58].map((amount) => BASE_COLORS.map((color) => mixColor(color, "#000000", amount)))
  ];
}
const COLOR_ROWS = paletteRows();
const PALETTE_COLORS = COLOR_ROWS.flat();
function rememberColor(color) {
  recentColors = [color, ...recentColors.filter((item) => item !== color)].slice(0, RECENT_LIMIT);
}
function clampOpacity(value) {
  return Math.max(0, Math.min(1, value));
}
function TradingViewColorPicker({
  label,
  value,
  onChange,
  name,
  opacity,
  onOpacity,
  className = "",
  popoverFooter
}) {
  const trigger = useRef(null);
  const popover = useRef(null);
  const customInput = useRef(null);
  const id = useId();
  const [open, setOpen] = useState(false);
  const [portalTarget, setPortalTarget] = useState(null);
  const [position, setPosition] = useState({ top: 8, left: 8 });
  const [recent, setRecent] = useState(() => recentColors.slice());
  const [activeColor, setActiveColor] = useState("#2962ff");
  const parsed = parseColor(value);
  const managesOpacity = opacity !== void 0 && onOpacity !== void 0;
  const activeOpacity = clampOpacity(managesOpacity ? opacity : parsed.opacity);
  const [opacityText, setOpacityText] = useState(String(Math.round(activeOpacity * 100)));
  useEffect(() => {
    setOpacityText(String(Math.round(activeOpacity * 100)));
  }, [activeOpacity]);
  const updateColor = (nextColor) => {
    const color = parseColor(nextColor).hex;
    rememberColor(color);
    setRecent(recentColors.slice());
    if (managesOpacity) onChange(color);
    else onChange(encodeColor(color, activeOpacity));
  };
  const updateOpacity = (nextOpacity) => {
    const next = clampOpacity(nextOpacity);
    setOpacityText(String(Math.round(next * 100)));
    if (managesOpacity) onOpacity(next);
    else onChange(encodeColor(parsed.hex, next));
  };
  const openPicker = () => {
    var _a;
    if (open) {
      setOpen(false);
      return;
    }
    setPortalTarget(((_a = trigger.current) == null ? void 0 : _a.closest("dialog")) ?? document.body);
    setRecent(recentColors.slice());
    setActiveColor(PALETTE_COLORS.includes(parsed.hex) ? parsed.hex : "#2962ff");
    setOpen(true);
  };
  useLayoutEffect(() => {
    if (!open) return;
    const place = () => {
      var _a;
      const anchor = (_a = trigger.current) == null ? void 0 : _a.getBoundingClientRect();
      const popup = popover.current;
      if (!anchor || !popup) return;
      const gutter = 8;
      const width = popup.offsetWidth;
      const height = popup.offsetHeight;
      const left = Math.max(gutter, Math.min(anchor.left, window.innerWidth - width - gutter));
      const below = anchor.bottom + 6;
      const top = below + height <= window.innerHeight - gutter ? below : Math.max(gutter, anchor.top - height - 6);
      setPosition({ top, left });
    };
    const frame = requestAnimationFrame(() => {
      var _a, _b;
      place();
      (_b = (_a = popover.current) == null ? void 0 : _a.querySelector('[data-palette-color="' + activeColor + '"]')) == null ? void 0 : _b.focus();
    });
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
    };
  }, [open, portalTarget, activeColor]);
  useEffect(() => {
    if (!open) return;
    const onPointerDown = (event) => {
      var _a, _b;
      const target = event.target;
      if (!(target instanceof Node)) return;
      if (((_a = trigger.current) == null ? void 0 : _a.contains(target)) || ((_b = popover.current) == null ? void 0 : _b.contains(target))) return;
      setOpen(false);
    };
    const onKeyDown = (event) => {
      if (event.key !== "Escape") return;
      event.preventDefault();
      setOpen(false);
      requestAnimationFrame(() => {
        var _a;
        return (_a = trigger.current) == null ? void 0 : _a.focus();
      });
    };
    document.addEventListener("pointerdown", onPointerDown, true);
    document.addEventListener("keydown", onKeyDown, true);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown, true);
      document.removeEventListener("keydown", onKeyDown, true);
    };
  }, [open]);
  const chooseColor = (color) => updateColor(color);
  const rows = COLOR_ROWS;
  const visibleRecent = recent.filter((color) => color !== parsed.hex).slice(0, RECENT_LIMIT - 1);
  const percent = Math.round(activeOpacity * 100);
  const popoverNode = open && portalTarget ? /* @__PURE__ */ jsxs(
    "div",
    {
      ref: popover,
      className: "tv-color-picker",
      role: "dialog",
      "aria-label": label + " color picker",
      style: { top: position.top, left: position.left },
      children: [
        /* @__PURE__ */ jsx("div", { className: "tv-color-picker__palette", role: "grid", "aria-label": "Color palette", children: rows.map((row, rowIndex) => /* @__PURE__ */ jsx("div", { className: "tv-color-picker__row", role: "row", children: row.map((color, columnIndex) => /* @__PURE__ */ jsx("div", { className: "tv-color-picker__gridcell", role: "gridcell", children: /* @__PURE__ */ jsx(
          "button",
          {
            type: "button",
            "data-palette-color": color,
            tabIndex: activeColor === color ? 0 : -1,
            className: "tv-color-picker__swatch" + (parsed.hex === color ? " is-selected" : ""),
            style: { backgroundColor: color },
            title: color.toUpperCase(),
            "aria-label": "Choose color " + color.toUpperCase(),
            "aria-pressed": parsed.hex === color,
            onClick: () => {
              setActiveColor(color);
              chooseColor(color);
            },
            onKeyDown: (event) => {
              const currentIndex = rowIndex * 10 + columnIndex;
              let nextIndex = currentIndex;
              if (event.key === "ArrowRight") nextIndex = Math.min(PALETTE_COLORS.length - 1, currentIndex + 1);
              else if (event.key === "ArrowLeft") nextIndex = Math.max(0, currentIndex - 1);
              else if (event.key === "ArrowDown") nextIndex = Math.min(PALETTE_COLORS.length - 1, currentIndex + 10);
              else if (event.key === "ArrowUp") nextIndex = Math.max(0, currentIndex - 10);
              else if (event.key === "Home") nextIndex = Math.floor(currentIndex / 10) * 10;
              else if (event.key === "End") nextIndex = Math.min(PALETTE_COLORS.length - 1, Math.floor(currentIndex / 10) * 10 + 9);
              else return;
              event.preventDefault();
              const nextColor = PALETTE_COLORS[nextIndex];
              setActiveColor(nextColor);
              requestAnimationFrame(() => {
                var _a, _b;
                return (_b = (_a = popover.current) == null ? void 0 : _a.querySelector('[data-palette-color="' + nextColor + '"]')) == null ? void 0 : _b.focus();
              });
            }
          }
        ) }, color)) }, rowIndex)) }),
        /* @__PURE__ */ jsxs("div", { className: "tv-color-picker__recent", role: "group", "aria-label": "Recent colors", children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              className: "tv-color-picker__recent-swatch tv-color-picker__recent-swatch--current",
              style: { ["--picker-current-color"]: "rgba(" + parseInt(parsed.hex.slice(1, 3), 16) + ", " + parseInt(parsed.hex.slice(3, 5), 16) + ", " + parseInt(parsed.hex.slice(5, 7), 16) + ", " + activeOpacity + ")" },
              title: "Current color " + parsed.hex.toUpperCase(),
              "aria-label": "Current color " + parsed.hex.toUpperCase(),
              onClick: () => chooseColor(parsed.hex)
            }
          ),
          visibleRecent.map((color) => /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              className: "tv-color-picker__recent-swatch",
              style: { backgroundColor: color },
              title: color.toUpperCase(),
              "aria-label": "Choose recent color " + color.toUpperCase(),
              onClick: () => chooseColor(color)
            },
            color
          )),
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              className: "tv-color-picker__custom",
              "aria-label": "Choose custom color",
              title: "Choose custom color",
              onClick: () => {
                var _a;
                return (_a = customInput.current) == null ? void 0 : _a.click();
              },
              children: /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "+" })
            }
          ),
          /* @__PURE__ */ jsx(
            "input",
            {
              ref: customInput,
              className: "tv-color-picker__native-input",
              type: "color",
              "aria-label": "Custom color",
              tabIndex: -1,
              value: parsed.hex,
              onChange: (event) => chooseColor(event.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "tv-color-picker__opacity", children: [
          /* @__PURE__ */ jsx("label", { htmlFor: id + "-opacity", children: "Opacity" }),
          /* @__PURE__ */ jsxs("div", { className: "tv-color-picker__opacity-row", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                id: id + "-opacity",
                type: "range",
                min: "0",
                max: "100",
                step: "1",
                value: percent,
                "aria-label": "Opacity",
                style: { ["--picker-color"]: parsed.hex },
                onChange: (event) => updateOpacity(Number(event.target.value) / 100)
              }
            ),
            /* @__PURE__ */ jsxs("span", { className: "tv-color-picker__percentage", children: [
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  inputMode: "numeric",
                  maxLength: 3,
                  value: opacityText,
                  "aria-label": "Opacity percentage",
                  onChange: (event) => {
                    const nextText = event.target.value.replace(/[^\d]/g, "").slice(0, 3);
                    setOpacityText(nextText);
                    if (nextText !== "") updateOpacity(Number(nextText) / 100);
                  },
                  onBlur: () => {
                    if (opacityText === "") setOpacityText(String(percent));
                    else updateOpacity(Number(opacityText) / 100);
                  },
                  onKeyDown: (event) => {
                    if (event.key === "Enter") {
                      event.preventDefault();
                      event.currentTarget.blur();
                    }
                  }
                }
              ),
              /* @__PURE__ */ jsx("span", { "aria-hidden": "true", children: "%" })
            ] })
          ] })
        ] }),
        popoverFooter ? /* @__PURE__ */ jsx("div", { className: "tv-color-picker__footer", children: popoverFooter }) : null
      ]
    }
  ) : null;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    name ? /* @__PURE__ */ jsx("input", { type: "hidden", name, value }) : null,
    /* @__PURE__ */ jsx("span", { className: "opencharts tv-color-picker-trigger-host", children: /* @__PURE__ */ jsxs(
      "button",
      {
        ref: trigger,
        type: "button",
        className: "tv-color-trigger " + className,
        "aria-label": label,
        "aria-haspopup": "dialog",
        "aria-expanded": open,
        onClick: openPicker,
        onKeyDown: (event) => {
          if (!open && (event.key === "ArrowDown" || event.key === "ArrowUp")) {
            event.preventDefault();
            openPicker();
          }
        },
        children: [
          /* @__PURE__ */ jsx(
            "span",
            {
              className: "tv-color-trigger__swatch",
              style: {
                ["--picker-current-color"]: "rgba(" + parseInt(parsed.hex.slice(1, 3), 16) + ", " + parseInt(parsed.hex.slice(3, 5), 16) + ", " + parseInt(parsed.hex.slice(5, 7), 16) + ", " + activeOpacity + ")"
              }
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "tv-color-trigger__chevron", "aria-hidden": "true", children: "▾" })
        ]
      }
    ) }),
    portalTarget && popoverNode ? createPortal(
      /* @__PURE__ */ jsx("div", { className: "opencharts", children: /* @__PURE__ */ jsx("div", { className: "tv-color-picker-portal", children: popoverNode }) }),
      portalTarget
    ) : null
  ] });
}
function SettingsSection({ children }) {
  return /* @__PURE__ */ jsx("h3", { className: "chart-settings-section-title", children });
}
function SettingsCheckRow({
  label,
  checked,
  onChange,
  hint,
  indent = false
}) {
  const id = useId();
  return /* @__PURE__ */ jsxs("label", { className: `chart-settings-check-row${indent ? " is-indented" : ""}`, htmlFor: id, children: [
    /* @__PURE__ */ jsx("input", { id, type: "checkbox", checked, onChange: (event) => onChange(event.target.checked) }),
    /* @__PURE__ */ jsxs("span", { className: "chart-settings-label-copy", children: [
      /* @__PURE__ */ jsx("span", { children: label }),
      hint ? /* @__PURE__ */ jsx("small", { children: hint }) : null
    ] })
  ] });
}
function SettingsSelectRow({
  label,
  value,
  options,
  onChange
}) {
  const id = useId();
  return /* @__PURE__ */ jsxs("label", { className: "chart-settings-field-row", htmlFor: id, children: [
    /* @__PURE__ */ jsx("span", { children: label }),
    /* @__PURE__ */ jsx("select", { id, value, onChange: (event) => onChange(event.target.value), children: options.map((option) => /* @__PURE__ */ jsx("option", { value: option.value, children: option.label }, option.value)) })
  ] });
}
function SettingsColorRow({
  label,
  value,
  fallback,
  onChange
}) {
  const id = useId();
  return /* @__PURE__ */ jsxs("div", { className: "chart-settings-color-row", children: [
    /* @__PURE__ */ jsx("label", { htmlFor: id, children: label }),
    /* @__PURE__ */ jsxs("span", { className: "chart-settings-color-control", children: [
      /* @__PURE__ */ jsx(TradingViewColorPicker, { label, value: value || fallback, onChange, className: "chart-settings-color-picker" }),
      value ? /* @__PURE__ */ jsx("button", { type: "button", "aria-label": `Use default ${label.toLowerCase()}`, onClick: () => onChange(""), children: "Reset" }) : null
    ] })
  ] });
}
function SettingsColorPair({
  label,
  bullish,
  bearish,
  bullishFallback,
  bearishFallback,
  onBullishChange,
  onBearishChange
}) {
  return /* @__PURE__ */ jsxs("div", { className: "chart-settings-color-pair-row", children: [
    /* @__PURE__ */ jsx("span", { children: label }),
    /* @__PURE__ */ jsxs("div", { className: "chart-settings-color-pair", children: [
      /* @__PURE__ */ jsx(TradingViewColorPicker, { label: "Bullish " + label.toLowerCase() + " color", value: bullish || bullishFallback, onChange: onBullishChange, className: "chart-settings-color-picker" }),
      /* @__PURE__ */ jsx(TradingViewColorPicker, { label: "Bearish " + label.toLowerCase() + " color", value: bearish || bearishFallback, onChange: onBearishChange, className: "chart-settings-color-picker" })
    ] })
  ] });
}
function SettingsNumberRow({
  label,
  value,
  min,
  max,
  step = 1,
  unit,
  onChange
}) {
  const id = useId();
  const [inputValue, setInputValue] = useState(String(value));
  useEffect(() => setInputValue(String(value)), [value]);
  return /* @__PURE__ */ jsxs("label", { className: "chart-settings-field-row", htmlFor: id, children: [
    /* @__PURE__ */ jsx("span", { children: label }),
    /* @__PURE__ */ jsxs("span", { className: "chart-settings-number-control", children: [
      /* @__PURE__ */ jsx("input", { id, type: "number", value: inputValue, min, max, step, onChange: (event) => {
        const raw = event.target.value;
        setInputValue(raw);
        if (raw === "") return;
        const next = Number(raw);
        if (Number.isFinite(next)) onChange(next);
      } }),
      unit ? /* @__PURE__ */ jsx("small", { children: unit }) : null
    ] })
  ] });
}
function CanvasTab({ prefs, onChange }) {
  return /* @__PURE__ */ jsxs("div", { className: "chart-settings-fields", children: [
    /* @__PURE__ */ jsx(SettingsSection, { children: "Chart basic styles" }),
    /* @__PURE__ */ jsx(SettingsSelectRow, { label: "Background", value: prefs.chartBackgroundMode, options: [
      { value: "solid", label: "Solid" },
      { value: "transparent", label: "Transparent" }
    ], onChange: (value) => onChange({ chartBackgroundMode: value }) }),
    /* @__PURE__ */ jsx(SettingsColorRow, { label: "Background color", value: prefs.colorBackground, fallback: CHART_COLORS.dark.background, onChange: (value) => onChange({ colorBackground: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Vertical grid lines", checked: prefs.showVerticalGrid, onChange: (value) => onChange({ showVerticalGrid: value }) }),
    /* @__PURE__ */ jsx(SettingsColorRow, { label: "Vertical grid color", value: prefs.colorVerticalGrid, fallback: prefs.colorGrid || CHART_COLORS.dark.grid, onChange: (value) => onChange({ colorVerticalGrid: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Horizontal grid lines", checked: prefs.showHorizontalGrid, onChange: (value) => onChange({ showHorizontalGrid: value }) }),
    /* @__PURE__ */ jsx(SettingsColorRow, { label: "Horizontal grid color", value: prefs.colorHorizontalGrid, fallback: prefs.colorGrid || CHART_COLORS.dark.grid, onChange: (value) => onChange({ colorHorizontalGrid: value }) }),
    /* @__PURE__ */ jsx(SettingsColorRow, { label: "Crosshair color", value: prefs.colorCrosshair, fallback: CHART_COLORS.dark.crosshair, onChange: (value) => onChange({ colorCrosshair: value }) }),
    /* @__PURE__ */ jsx(SettingsSelectRow, { label: "Crosshair line", value: prefs.crosshairLineStyle, options: [
      { value: "solid", label: "Solid" },
      { value: "dotted", label: "Dotted" },
      { value: "dashed", label: "Dashed" },
      { value: "large-dashed", label: "Large dashed" }
    ], onChange: (value) => onChange({ crosshairLineStyle: value }) }),
    /* @__PURE__ */ jsx(SettingsSelectRow, { label: "Watermark", value: prefs.watermarkMode, options: [
      { value: "none", label: "None" },
      { value: "symbol", label: "Symbol" },
      { value: "symbol-timeframe", label: "Symbol, timeframe" }
    ], onChange: (value) => onChange({ watermarkMode: value }) }),
    /* @__PURE__ */ jsx(SettingsSection, { children: "Scales" }),
    /* @__PURE__ */ jsx(SettingsColorRow, { label: "Scale text", value: prefs.colorScaleText, fallback: CHART_COLORS.dark.text, onChange: (value) => onChange({ colorScaleText: value }) }),
    /* @__PURE__ */ jsx(SettingsSelectRow, { label: "Text size", value: String(prefs.scaleTextSize), options: Array.from({ length: 13 }, (_, index) => index + 8).map((size) => ({ value: String(size), label: String(size) })), onChange: (value) => onChange({ scaleTextSize: Number(value) }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Scale borders", checked: prefs.showScaleBorder, onChange: (value) => onChange({ showScaleBorder: value }) }),
    /* @__PURE__ */ jsx(SettingsSection, { children: "Navigation" }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Scroll chart", checked: prefs.enableChartScroll, onChange: (value) => onChange({ enableChartScroll: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Scale chart", checked: prefs.enableChartScale, onChange: (value) => onChange({ enableChartScale: value }) }),
    /* @__PURE__ */ jsx(SettingsSection, { children: "Panes" }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Volume histogram", checked: prefs.showVolume, onChange: (value) => onChange({ showVolume: value }) }),
    /* @__PURE__ */ jsx(SettingsSection, { children: "Margins" }),
    /* @__PURE__ */ jsx(SettingsNumberRow, { label: "Top", value: prefs.priceScaleTopMargin * 100, min: 0, max: 45, unit: "%", onChange: (value) => onChange({ priceScaleTopMargin: value / 100 }) }),
    /* @__PURE__ */ jsx(SettingsNumberRow, { label: "Bottom", value: prefs.priceScaleBottomMargin * 100, min: 0, max: 45, unit: "%", onChange: (value) => onChange({ priceScaleBottomMargin: value / 100 }) }),
    /* @__PURE__ */ jsx(SettingsSelectRow, { label: "Right margin", value: String(prefs.timeScaleRightOffset), options: [
      { value: "default", label: "Default" },
      ...Array.from({ length: 51 }, (_, value) => ({ value: String(value), label: `${value} bars` }))
    ], onChange: (value) => onChange({ timeScaleRightOffset: value === "default" ? "default" : Number(value) }) })
  ] });
}
function ScalesAndLinesTab({ prefs, onChange }) {
  return /* @__PURE__ */ jsxs("div", { className: "chart-settings-fields", children: [
    /* @__PURE__ */ jsx(SettingsSection, { children: "Price scale" }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Price scale", checked: prefs.showPriceScale, onChange: (value) => onChange({ showPriceScale: value }) }),
    /* @__PURE__ */ jsx(SettingsSelectRow, { label: "Scale mode", value: prefs.priceScaleMode, options: [
      { value: "normal", label: "Normal" },
      { value: "logarithmic", label: "Logarithmic" },
      { value: "percentage", label: "Percentage" },
      { value: "indexedTo100", label: "Indexed to 100" }
    ], onChange: (value) => onChange({ priceScaleMode: value }) }),
    /* @__PURE__ */ jsx(SettingsSelectRow, { label: "Scale placement", value: prefs.priceScaleSide, options: [
      { value: "right", label: "Right" },
      { value: "left", label: "Left" }
    ], onChange: (value) => onChange({ priceScaleSide: value }) }),
    /* @__PURE__ */ jsx(SettingsSection, { children: "Price labels and lines" }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "No overlapping labels", checked: prefs.noOverlappingLabels, onChange: (value) => onChange({ noOverlappingLabels: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Last value label", checked: prefs.showLastValue, onChange: (value) => onChange({ showLastValue: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Price line", checked: prefs.showPriceLine, onChange: (value) => onChange({ showPriceLine: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Countdown to bar close", checked: prefs.showCountdown, onChange: (value) => onChange({ showCountdown: value }) }),
    /* @__PURE__ */ jsx(SettingsSection, { children: "Time scale" }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Time scale", checked: prefs.showTimeScale, onChange: (value) => onChange({ showTimeScale: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Day of week on labels", checked: prefs.timeScaleShowDayOfWeek, onChange: (value) => onChange({ timeScaleShowDayOfWeek: value }) }),
    /* @__PURE__ */ jsx(SettingsSelectRow, { label: "Date format", value: prefs.timeScaleDateFormat, options: [
      { value: "locale", label: "Locale" },
      { value: "yyyy-MM-dd", label: "2026-10-27" },
      { value: "dd MMM yyyy", label: "27 Oct 2026" },
      { value: "MMM dd, yyyy", label: "Oct 27, 2026" }
    ], onChange: (value) => onChange({ timeScaleDateFormat: value }) }),
    /* @__PURE__ */ jsx(SettingsSelectRow, { label: "Time format", value: prefs.timeScaleTimeFormat, options: [
      { value: "24-hour", label: "24-hour" },
      { value: "12-hour", label: "12-hour" }
    ], onChange: (value) => onChange({ timeScaleTimeFormat: value }) }),
    /* @__PURE__ */ jsx(SettingsSelectRow, { label: "Seconds", value: typeof prefs.timeScaleSecondsVisible === "boolean" ? String(prefs.timeScaleSecondsVisible) : "auto", options: [
      { value: "auto", label: "Auto" },
      { value: "true", label: "Always visible" },
      { value: "false", label: "Hidden" }
    ], onChange: (value) => onChange({ timeScaleSecondsVisible: value === "auto" ? "auto" : value === "true" }) })
  ] });
}
function StatusLineTab({ prefs, onChange }) {
  return /* @__PURE__ */ jsxs("div", { className: "chart-settings-fields", children: [
    /* @__PURE__ */ jsx(SettingsSection, { children: "Instrument" }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Symbol", checked: prefs.showStatusLineSymbol, onChange: (value) => onChange({ showStatusLineSymbol: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Market state", checked: prefs.showStatusLineMarketState, onChange: (value) => onChange({ showStatusLineMarketState: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Chart values", checked: prefs.showOhlcLegend, onChange: (value) => onChange({ showOhlcLegend: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Bar change values", checked: prefs.showStatusLineChange, onChange: (value) => onChange({ showStatusLineChange: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Volume", checked: prefs.showStatusLineVolume, onChange: (value) => onChange({ showStatusLineVolume: value }) }),
    /* @__PURE__ */ jsx(SettingsSection, { children: "Indicators" }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Titles", checked: prefs.showStatusLineStudyTitle, onChange: (value) => onChange({ showStatusLineStudyTitle: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Inputs", checked: prefs.showStatusLineStudyInputs, onChange: (value) => onChange({ showStatusLineStudyInputs: value }), indent: true }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Values", checked: prefs.showStatusLineStudyValues, onChange: (value) => onChange({ showStatusLineStudyValues: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Background", checked: prefs.showStatusLineStudyBackground, onChange: (value) => onChange({ showStatusLineStudyBackground: value }) })
  ] });
}
const TIMEZONES = [
  ["Etc/UTC", "UTC"],
  ["Europe/Prague", "Europe/Prague"],
  ["America/New_York", "New York"],
  ["America/Los_Angeles", "Los Angeles"],
  ["Asia/Tokyo", "Tokyo"]
];
function SymbolTab({ prefs, onChange }) {
  const timezones = TIMEZONES.some(([value]) => value === prefs.displayTimezone) ? TIMEZONES : [[prefs.displayTimezone, prefs.displayTimezone], ...TIMEZONES];
  return /* @__PURE__ */ jsxs("div", { className: "chart-settings-fields", children: [
    /* @__PURE__ */ jsx(SettingsSection, { children: "Candles" }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Color bars based on previous close", checked: prefs.colorBarsByPreviousClose, onChange: (value) => onChange({ colorBarsByPreviousClose: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Wicks", checked: prefs.showWicks, onChange: (value) => onChange({ showWicks: value }) }),
    /* @__PURE__ */ jsx(SettingsCheckRow, { label: "Candle borders", checked: prefs.showCandleBorders, onChange: (value) => onChange({ showCandleBorders: value }) }),
    /* @__PURE__ */ jsx(SettingsColorPair, { label: "Body", bullish: prefs.candleBullBodyColor, bearish: prefs.candleBearBodyColor, bullishFallback: CHART_COLORS.dark.up, bearishFallback: CHART_COLORS.dark.down, onBullishChange: (value) => onChange({ candleBullBodyColor: value }), onBearishChange: (value) => onChange({ candleBearBodyColor: value }) }),
    /* @__PURE__ */ jsx(SettingsColorPair, { label: "Borders", bullish: prefs.candleBullBorderColor, bearish: prefs.candleBearBorderColor, bullishFallback: CHART_COLORS.dark.up, bearishFallback: CHART_COLORS.dark.down, onBullishChange: (value) => onChange({ candleBullBorderColor: value }), onBearishChange: (value) => onChange({ candleBearBorderColor: value }) }),
    /* @__PURE__ */ jsx(SettingsColorPair, { label: "Wick", bullish: prefs.candleBullWickColor, bearish: prefs.candleBearWickColor, bullishFallback: CHART_COLORS.dark.up, bearishFallback: CHART_COLORS.dark.down, onBullishChange: (value) => onChange({ candleBullWickColor: value }), onBearishChange: (value) => onChange({ candleBearWickColor: value }) }),
    /* @__PURE__ */ jsx(SettingsSection, { children: "Data modification" }),
    /* @__PURE__ */ jsx(SettingsSelectRow, { label: "Precision", value: String(prefs.pricePrecision), options: [
      { value: "default", label: "Default" },
      ...Array.from({ length: 9 }, (_, value) => ({ value: String(value), label: String(value) }))
    ], onChange: (value) => onChange({ pricePrecision: value === "default" ? "default" : Number(value) }) }),
    /* @__PURE__ */ jsx(SettingsSelectRow, { label: "Timezone", value: prefs.displayTimezone, options: timezones.map(([value, label]) => ({ value, label })), onChange: (value) => onChange({ displayTimezone: value }) })
  ] });
}
const TABS = [
  { id: "symbol", label: "Symbol", icon: CandlestickChart },
  { id: "status-line", label: "Status line", icon: List },
  { id: "scales-and-lines", label: "Scales and lines", icon: Scaling },
  { id: "canvas", label: "Canvas", icon: Paintbrush }
];
const DEFAULTS = getDefaultChartPreferences();
const RESET_BY_TAB = {
  symbol: {
    colorBarsByPreviousClose: false,
    showWicks: true,
    showCandleBorders: true,
    candleBullBodyColor: "",
    candleBearBodyColor: "",
    candleBullBorderColor: "",
    candleBearBorderColor: "",
    candleBullWickColor: "",
    candleBearWickColor: "",
    pricePrecision: "default",
    displayTimezone: DEFAULTS.displayTimezone
  },
  "status-line": {
    showStatusLineSymbol: true,
    showStatusLineMarketState: false,
    showOhlcLegend: true,
    showStatusLineChange: true,
    showStatusLineVolume: true,
    showStatusLineStudyTitle: true,
    showStatusLineStudyInputs: true,
    showStatusLineStudyValues: true,
    showStatusLineStudyBackground: true
  },
  "scales-and-lines": {
    priceScaleMode: "normal",
    priceScaleSide: "right",
    showPriceScale: true,
    showTimeScale: true,
    showPriceLine: true,
    showLastValue: true,
    showCountdown: true,
    timeScaleDateFormat: "locale",
    timeScaleTimeFormat: "24-hour",
    timeScaleSecondsVisible: "auto"
  },
  canvas: {
    chartBackgroundMode: "solid",
    colorBackground: "",
    showVerticalGrid: true,
    showHorizontalGrid: true,
    colorVerticalGrid: "",
    colorHorizontalGrid: "",
    colorCrosshair: "",
    crosshairLineStyle: "large-dashed",
    watermarkMode: "symbol",
    colorScaleText: "",
    scaleTextSize: DEFAULTS.scaleTextSize,
    showScaleBorder: true,
    enableChartScroll: true,
    enableChartScale: true,
    showVolume: true,
    priceScaleTopMargin: DEFAULTS.priceScaleTopMargin,
    priceScaleBottomMargin: DEFAULTS.priceScaleBottomMargin,
    timeScaleRightOffset: "default"
  }
};
function tabId(id) {
  return `chart-settings-tab-${id}`;
}
function panelId(id) {
  return `chart-settings-panel-${id}`;
}
function ChartSettingsDialog(props) {
  const { open, onClose, prefs } = props;
  const dialogRef = useRef(null);
  const firstTabRef = useRef(null);
  const templateButtonRef = useRef(null);
  const openerRef = useRef(null);
  const nativeDialogClosedRef = useRef(true);
  const draftRef = useRef({ ...prefs });
  const [draft, setDraft] = useState({ ...prefs });
  const [tab, setTab] = useState("symbol");
  const [templates, setTemplates] = useState([]);
  const [templateMenuOpen, setTemplateMenuOpen] = useState(false);
  const [templateName, setTemplateName] = useState("");
  const closeNativeDialog = () => {
    const dialog = dialogRef.current;
    if (!dialog || nativeDialogClosedRef.current) return;
    dialog.close();
    nativeDialogClosedRef.current = true;
  };
  useEffect(() => {
    var _a;
    const dialog = dialogRef.current;
    if (!open) {
      discardChartPreferencesPreview();
      closeNativeDialog();
      return;
    }
    const original = { ...prefs };
    openerRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    draftRef.current = original;
    setDraft(original);
    setTab("symbol");
    setTemplateMenuOpen(false);
    setTemplateName("");
    setTemplates(readChartSettingsTemplates());
    if (dialog && !dialog.open) dialog.showModal();
    nativeDialogClosedRef.current = false;
    (_a = firstTabRef.current) == null ? void 0 : _a.focus();
    return () => {
      var _a2;
      discardChartPreferencesPreview();
      if (!nativeDialogClosedRef.current) {
        dialog == null ? void 0 : dialog.close();
        nativeDialogClosedRef.current = true;
      }
      if ((_a2 = openerRef.current) == null ? void 0 : _a2.isConnected) openerRef.current.focus();
    };
  }, [open]);
  const changeDraft = (patch) => {
    const next = { ...draftRef.current, ...patch };
    draftRef.current = next;
    setDraft(next);
    setChartPreferencesPreview(next);
  };
  const close = () => {
    var _a;
    setTemplateMenuOpen(false);
    discardChartPreferencesPreview();
    closeNativeDialog();
    onClose();
    if ((_a = openerRef.current) == null ? void 0 : _a.isConnected) openerRef.current.focus();
  };
  const commit = () => {
    var _a;
    commitChartPreferencesPreview(draftRef.current);
    setTemplateMenuOpen(false);
    closeNativeDialog();
    onClose();
    if ((_a = openerRef.current) == null ? void 0 : _a.isConnected) openerRef.current.focus();
  };
  const handleTabKey = (event, index) => {
    var _a;
    let nextIndex = null;
    if (event.key === "ArrowRight" || event.key === "ArrowDown") nextIndex = (index + 1) % TABS.length;
    if (event.key === "ArrowLeft" || event.key === "ArrowUp") nextIndex = (index - 1 + TABS.length) % TABS.length;
    if (event.key === "Home") nextIndex = 0;
    if (event.key === "End") nextIndex = TABS.length - 1;
    if (nextIndex === null) return;
    event.preventDefault();
    const next = TABS[nextIndex];
    setTab(next.id);
    (_a = document.getElementById(tabId(next.id))) == null ? void 0 : _a.focus();
  };
  const resetCurrentTab = () => changeDraft(RESET_BY_TAB[tab]);
  const applyTemplate = (template) => {
    changeDraft(template.preferences);
    setTemplateMenuOpen(false);
  };
  const saveTemplate = () => {
    const next = saveChartSettingsTemplate(templateName, draftRef.current);
    setTemplates(next);
    if (templateName.trim()) setTemplateName("");
    setTemplateMenuOpen(false);
  };
  const removeTemplate = (template) => {
    setTemplates(deleteChartSettingsTemplate(template.id));
  };
  if (!open) return null;
  const ActiveTab = tab === "symbol" ? SymbolTab : tab === "status-line" ? StatusLineTab : tab === "scales-and-lines" ? ScalesAndLinesTab : CanvasTab;
  return createPortal(
    /* @__PURE__ */ jsx(
      "dialog",
      {
        ref: dialogRef,
        className: "opencharts",
        "data-chart-settings-dialog": true,
        "aria-label": "Chart settings",
        onCancel: (event) => {
          event.preventDefault();
          close();
        },
        onKeyDown: (event) => event.stopPropagation(),
        style: { position: "fixed", inset: 0, margin: 0, padding: 0, border: 0, width: "100vw", height: "100dvh", maxWidth: "none", maxHeight: "none", overflow: "visible", background: "transparent" },
        children: /* @__PURE__ */ jsx("div", { className: "chart-settings-screen chart-settings-dialog", onClick: (event) => {
          if (event.target === event.currentTarget) close();
        }, children: /* @__PURE__ */ jsxs("section", { className: "chart-settings-modal", "aria-labelledby": "chart-settings-title", children: [
          /* @__PURE__ */ jsxs("header", { className: "chart-settings-header", children: [
            /* @__PURE__ */ jsx("h2", { id: "chart-settings-title", children: "Settings" }),
            /* @__PURE__ */ jsx("button", { className: "chart-settings-close chart-settings-icon-button", type: "button", "aria-label": "Close chart settings", onClick: close, children: /* @__PURE__ */ jsx(X, {}) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "chart-settings-body", children: [
            /* @__PURE__ */ jsx("nav", { className: "chart-settings-nav", role: "tablist", "aria-label": "Chart settings sections", "aria-orientation": "vertical", children: TABS.map(({ id, label, icon: Icon }, index) => /* @__PURE__ */ jsxs(
              "button",
              {
                ref: index === 0 ? firstTabRef : void 0,
                id: tabId(id),
                className: "chart-settings-tab",
                type: "button",
                role: "tab",
                "aria-selected": tab === id,
                "aria-controls": panelId(id),
                tabIndex: tab === id ? 0 : -1,
                onClick: () => setTab(id),
                onKeyDown: (event) => handleTabKey(event, index),
                children: [
                  /* @__PURE__ */ jsx(Icon, { "aria-hidden": "true" }),
                  label
                ]
              },
              id
            )) }),
            /* @__PURE__ */ jsx("div", { className: "chart-settings-content", id: panelId(tab), role: "tabpanel", "aria-labelledby": tabId(tab), children: /* @__PURE__ */ jsx(ActiveTab, { prefs: draft, onChange: changeDraft }) })
          ] }),
          /* @__PURE__ */ jsxs("footer", { className: "chart-settings-footer", children: [
            /* @__PURE__ */ jsxs("div", { className: "chart-settings-template-anchor", children: [
              /* @__PURE__ */ jsxs(
                "button",
                {
                  ref: templateButtonRef,
                  className: "chart-settings-template-trigger",
                  type: "button",
                  "aria-haspopup": "menu",
                  "aria-expanded": templateMenuOpen,
                  onClick: () => setTemplateMenuOpen((value) => !value),
                  children: [
                    "Template ",
                    /* @__PURE__ */ jsx(ChevronDown, { "aria-hidden": "true" })
                  ]
                }
              ),
              templateMenuOpen ? /* @__PURE__ */ jsxs("div", { className: "chart-settings-menu", role: "menu", "aria-label": "Chart settings templates", children: [
                /* @__PURE__ */ jsx("div", { className: "chart-settings-menu-title", children: "Templates" }),
                templates.length === 0 ? /* @__PURE__ */ jsx("div", { className: "chart-settings-menu-empty", children: "No templates yet" }) : templates.map((template) => /* @__PURE__ */ jsxs("div", { className: "chart-settings-menu-row", children: [
                  /* @__PURE__ */ jsx("button", { type: "button", role: "menuitem", "aria-label": `Apply ${template.name}`, onClick: () => applyTemplate(template), children: template.name }),
                  /* @__PURE__ */ jsx("button", { className: "chart-settings-delete-template", type: "button", "aria-label": `Delete ${template.name}`, title: `Delete ${template.name}`, onClick: () => removeTemplate(template), children: "×" })
                ] }, template.id)),
                /* @__PURE__ */ jsxs("div", { className: "chart-settings-template-save", children: [
                  /* @__PURE__ */ jsx("input", { "aria-label": "Template name", value: templateName, placeholder: "Template name", onChange: (event) => setTemplateName(event.target.value), onKeyDown: (event) => {
                    if (event.key === "Enter") saveTemplate();
                  } }),
                  /* @__PURE__ */ jsx("button", { type: "button", onClick: saveTemplate, children: "Save template" })
                ] }),
                /* @__PURE__ */ jsx("div", { className: "chart-settings-menu-separator", role: "separator" }),
                /* @__PURE__ */ jsx("button", { type: "button", role: "menuitem", onClick: resetCurrentTab, children: "Reset current tab" })
              ] }) : null
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "chart-settings-footer-actions", children: [
              /* @__PURE__ */ jsx("button", { className: "chart-settings-button", type: "button", onClick: close, children: "Cancel" }),
              /* @__PURE__ */ jsx("button", { className: "chart-settings-button is-primary", type: "button", onClick: commit, children: "OK" })
            ] })
          ] })
        ] }) })
      }
    ),
    document.body
  );
}
function useDragOffset() {
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const dragRef = useRef(
    null
  );
  const onPointerDown = useCallback(
    (e) => {
      if (e.target.closest("button, input, select, textarea, a")) return;
      e.preventDefault();
      dragRef.current = { startX: e.clientX, startY: e.clientY, baseX: offset.x, baseY: offset.y };
      const onMove = (ev) => {
        const drag = dragRef.current;
        if (!drag) return;
        setOffset({
          x: drag.baseX + (ev.clientX - drag.startX),
          y: drag.baseY + (ev.clientY - drag.startY)
        });
      };
      const onUp = () => {
        dragRef.current = null;
        window.removeEventListener("pointermove", onMove);
        window.removeEventListener("pointerup", onUp);
      };
      window.addEventListener("pointermove", onMove);
      window.addEventListener("pointerup", onUp);
    },
    [offset.x, offset.y]
  );
  const reset = useCallback(() => setOffset({ x: 0, y: 0 }), []);
  return {
    style: offset.x !== 0 || offset.y !== 0 ? { transform: `translate(${offset.x}px, ${offset.y}px)` } : {},
    onPointerDown,
    reset
  };
}
const DRAWING_STYLES_EVENT = "drawing-styles-updated";
const DEFAULTS_KEY = "drawingDefaults";
const TEMPLATES_KEY = "drawingTemplates";
function userId() {
  var _a;
  return (_a = useAuthStore.getState().user) == null ? void 0 : _a.id;
}
function parse(raw, fallback) {
  if (raw == null) return fallback;
  try {
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}
function persist(key, value) {
  const id = userId();
  writeTraderPrefs({ ...readTraderPrefs$1(id), [key]: JSON.stringify(value) }, id);
  if (typeof window !== "undefined") window.dispatchEvent(new Event(DRAWING_STYLES_EVENT));
}
function pickStyle(d) {
  return {
    color: d.color,
    width: d.width,
    lineStyle: d.lineStyle,
    opacity: d.opacity,
    secondaryColor: d.secondaryColor,
    secondaryWidth: d.secondaryWidth,
    secondaryLineStyle: d.secondaryLineStyle,
    fillColor: d.fillColor,
    fillOpacity: d.fillOpacity,
    extendLeft: d.extendLeft,
    extendRight: d.extendRight,
    arrowStart: d.arrowStart,
    arrowEnd: d.arrowEnd,
    fontSize: d.fontSize,
    bold: d.bold,
    italic: d.italic,
    textBg: d.textBg,
    textBgColor: d.textBgColor,
    textBorder: d.textBorder,
    textBorderColor: d.textBorderColor,
    textAlign: d.textAlign,
    textPlacement: d.textPlacement,
    positiveColor: d.positiveColor,
    negativeColor: d.negativeColor,
    labelColor: d.labelColor,
    rangeLabelMode: d.rangeLabelMode,
    fibLevelStyles: d.fibLevelStyles,
    stopColor: d.stopColor,
    targetColor: d.targetColor,
    stopFillOpacity: d.stopFillOpacity,
    targetFillOpacity: d.targetFillOpacity,
    showPriceLabels: d.showPriceLabels,
    statsMode: d.statsMode,
    compactStats: d.compactStats,
    alwaysShowStats: d.alwaysShowStats,
    smooth: d.smooth,
    closed: d.closed
  };
}
function getStyleDefaults() {
  return parse(readTraderPrefs$1(userId())[DEFAULTS_KEY], {});
}
function setTypeDefault(type, d) {
  persist(DEFAULTS_KEY, { ...getStyleDefaults(), [type]: pickStyle(d) });
}
function getTemplates() {
  return parse(readTraderPrefs$1(userId())[TEMPLATES_KEY], []);
}
function useDrawingSettingsDraft(drawing, onPreview, onCommit, onClose) {
  const originalRef = useRef({ ...drawing });
  const openerRef = useRef(
    typeof document === "undefined" ? null : document.activeElement
  );
  const finalizedRef = useRef(false);
  const onPreviewRef = useRef(onPreview);
  const onCommitRef = useRef(onCommit);
  const onCloseRef = useRef(onClose);
  const [draft, setDraft] = useState(() => normalizeDrawingSettings(drawing));
  useEffect(() => {
    onPreviewRef.current = onPreview;
    onCommitRef.current = onCommit;
    onCloseRef.current = onClose;
  });
  const restoreFocus = useCallback(() => {
    var _a;
    if ((_a = openerRef.current) == null ? void 0 : _a.isConnected) openerRef.current.focus();
  }, []);
  const cancel = useCallback(() => {
    if (finalizedRef.current) return;
    finalizedRef.current = true;
    onPreviewRef.current(originalRef.current);
    onCloseRef.current();
    restoreFocus();
  }, [restoreFocus]);
  useEffect(
    () => () => {
      if (!finalizedRef.current) onPreviewRef.current(originalRef.current);
      restoreFocus();
    },
    [restoreFocus]
  );
  const update = useCallback((patch) => {
    setDraft((current2) => {
      const next = { ...current2, ...patch };
      onPreviewRef.current(next);
      return next;
    });
  }, []);
  const errors = useMemo(() => validateDrawingSettings(draft), [draft]);
  const canCommit = Object.keys(errors).length === 0;
  const commit = useCallback(() => {
    if (finalizedRef.current || Object.keys(validateDrawingSettings(draft)).length > 0) return;
    finalizedRef.current = true;
    onCommitRef.current(draft);
    onCloseRef.current();
    restoreFocus();
  }, [draft, restoreFocus]);
  return { draft, errors, canCommit, update, cancel, commit };
}
function SettingsField({ label, children, className = "" }) {
  return /* @__PURE__ */ jsxs("div", { className: `drawing-settings-field ${className}`.trim(), children: [
    /* @__PURE__ */ jsx("span", { children: label }),
    /* @__PURE__ */ jsx("div", { className: "drawing-settings-control", children })
  ] });
}
function NumberField({ label, value, onChange, error, step = "any" }) {
  const id = useId();
  const errorId = `${id}-error`;
  return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-field", children: [
    /* @__PURE__ */ jsx("label", { htmlFor: id, children: label }),
    /* @__PURE__ */ jsx(
      "input",
      {
        id,
        className: "drawing-settings-input drawing-settings-value",
        type: "number",
        inputMode: "decimal",
        step,
        value: value != null && Number.isFinite(value) ? value : "",
        "aria-invalid": Boolean(error),
        "aria-describedby": error ? errorId : void 0,
        onChange: (event) => onChange(event.target.value === "" ? Number.NaN : Number(event.target.value))
      }
    ),
    error && /* @__PURE__ */ jsx("p", { id: errorId, className: "drawing-settings-error", role: "alert", children: error })
  ] });
}
function SelectField({ label, value, onChange, children }) {
  const id = useId();
  return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-field", children: [
    /* @__PURE__ */ jsx("label", { htmlFor: id, children: label }),
    /* @__PURE__ */ jsx("select", { id, className: "drawing-settings-select drawing-settings-value", value, onChange: (event) => onChange(event.target.value), children })
  ] });
}
function CheckboxField({ label, checked, onChange, children }) {
  return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-check-row", children: [
    /* @__PURE__ */ jsxs("label", { className: "drawing-settings-check", children: [
      /* @__PURE__ */ jsx("input", { type: "checkbox", checked, onChange: (event) => onChange(event.target.checked) }),
      /* @__PURE__ */ jsx("span", { "aria-hidden": "true", className: "drawing-settings-check-mark" }),
      /* @__PURE__ */ jsx("span", { children: label })
    ] }),
    children && /* @__PURE__ */ jsx("div", { className: "drawing-settings-check-control", children })
  ] });
}
function ColorControl({ label, value, onChange, opacity, onOpacity }) {
  return /* @__PURE__ */ jsx("div", { className: "drawing-settings-color-control", children: /* @__PURE__ */ jsx(TradingViewColorPicker, { label, value, onChange, opacity, onOpacity, className: "drawing-settings-color-picker" }) });
}
function LineControl({ label, color, width, style, opacity, onChange }) {
  return /* @__PURE__ */ jsxs("fieldset", { className: "drawing-settings-line-control", "aria-label": label, children: [
    /* @__PURE__ */ jsx(ColorControl, { label: `${label} color`, value: color, onChange: (next) => onChange({ color: next }), opacity, onOpacity: (next) => onChange({ opacity: next }) }),
    /* @__PURE__ */ jsx("select", { "aria-label": `${label} width`, value: width, onChange: (event) => onChange({ width: Number(event.target.value) }), children: [1, 2, 3, 4].map((item) => /* @__PURE__ */ jsxs("option", { value: item, children: [
      item,
      "px"
    ] }, item)) }),
    /* @__PURE__ */ jsxs("select", { "aria-label": `${label} style`, value: style, onChange: (event) => onChange({ lineStyle: event.target.value }), children: [
      /* @__PURE__ */ jsx("option", { value: "solid", children: "Solid" }),
      /* @__PURE__ */ jsx("option", { value: "dashed", children: "Dashed" }),
      /* @__PURE__ */ jsx("option", { value: "dotted", children: "Dotted" })
    ] }),
    /* @__PURE__ */ jsx("span", { className: `drawing-settings-line-preview drawing-settings-line-preview--${style}`, style: { color }, "aria-hidden": "true" })
  ] });
}
function SectionLabel({ children }) {
  return /* @__PURE__ */ jsx("h3", { className: "drawing-settings-section-label", children });
}
function TabList({ tabs, active, onChange, initialFocusRef }) {
  const refs = useRef(/* @__PURE__ */ new Map());
  const activate = (tab) => {
    var _a;
    onChange(tab);
    (_a = refs.current.get(tab)) == null ? void 0 : _a.focus();
  };
  return /* @__PURE__ */ jsx("div", { className: "drawing-settings-tabs", role: "tablist", "aria-label": "Drawing settings sections", children: tabs.map((tab, index) => /* @__PURE__ */ jsx(
    "button",
    {
      ref: (node) => {
        if (node) {
          refs.current.set(tab, node);
          if (index === 0) initialFocusRef.current = node;
        }
      },
      type: "button",
      role: "tab",
      "aria-selected": active === tab,
      tabIndex: active === tab ? 0 : -1,
      className: "drawing-settings-tab",
      onClick: () => onChange(tab),
      onKeyDown: (event) => {
        const current2 = tabs.indexOf(tab);
        let next = -1;
        if (event.key === "ArrowRight") next = (current2 + 1) % tabs.length;
        if (event.key === "ArrowLeft") next = (current2 - 1 + tabs.length) % tabs.length;
        if (event.key === "Home") next = 0;
        if (event.key === "End") next = tabs.length - 1;
        if (next >= 0) {
          event.preventDefault();
          activate(tabs[next]);
        }
      },
      children: tab.charAt(0).toUpperCase() + tab.slice(1)
    },
    tab
  )) });
}
function Anchor({ index, price, time, priceError, timeError, onPrice, onTime }) {
  return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-anchor-row", children: [
    /* @__PURE__ */ jsx(NumberField, { label: `${index} price`, value: price, error: priceError, onChange: onPrice }),
    /* @__PURE__ */ jsx(NumberField, { label: `${index} bar`, value: time, error: timeError, onChange: onTime })
  ] });
}
function CoordinatesTab({ draft, errors, update }) {
  if (draft.points && draft.points.length > 0) {
    const lastIndex = draft.points.length - 1;
    const first = draft.points[0];
    const last = draft.points[lastIndex];
    const updatePoint = (index, patch) => update({ points: draft.points.map((point, pointIndex) => pointIndex === index ? { ...point, ...patch } : point) });
    return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-stack", children: [
      /* @__PURE__ */ jsxs(SectionLabel, { children: [
        draft.points.length,
        " points"
      ] }),
      /* @__PURE__ */ jsx(Anchor, { index: "First point", price: first.price, time: first.time, priceError: errors.points, timeError: errors.points, onPrice: (price) => updatePoint(0, { price }), onTime: (time) => updatePoint(0, { time }) }),
      lastIndex > 0 && /* @__PURE__ */ jsx(Anchor, { index: "Last point", price: last.price, time: last.time, priceError: errors.points, timeError: errors.points, onPrice: (price) => updatePoint(lastIndex, { price }), onTime: (time) => updatePoint(lastIndex, { time }) })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-stack", children: [
    /* @__PURE__ */ jsx(Anchor, { index: "#1", price: draft.price, time: draft.time, priceError: errors.price, timeError: errors.time, onPrice: (price) => update({ price }), onTime: (time) => update({ time }) }),
    (draft.price2 != null || draft.time2 != null) && /* @__PURE__ */ jsx(Anchor, { index: "#2", price: draft.price2, time: draft.time2, priceError: errors.price2, timeError: errors.time2, onPrice: (price2) => update({ price2 }), onTime: (time2) => update({ time2 }) }),
    (draft.price3 != null || draft.time3 != null) && /* @__PURE__ */ jsx(Anchor, { index: "#3", price: draft.price3, time: draft.time3, priceError: errors.price3, timeError: errors.time3, onPrice: (price3) => update({ price3 }), onTime: (time3) => update({ time3 }) }),
    draft.type === "curve" && /* @__PURE__ */ jsx(Anchor, { index: "Control", price: draft.controlPrice, time: draft.controlTime, priceError: errors.controlPrice, timeError: errors.controlTime, onPrice: (controlPrice) => update({ controlPrice }), onTime: (controlTime) => update({ controlTime }) })
  ] });
}
function PositionInputsTab({ draft, errors, update }) {
  const metrics = positionMetrics(draft);
  return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-stack drawing-settings-position-inputs", children: [
    /* @__PURE__ */ jsx(NumberField, { label: "Account size", value: draft.accountSize, error: errors.accountSize, onChange: (accountSize) => update({ accountSize }) }),
    /* @__PURE__ */ jsx(NumberField, { label: "Lot size", value: draft.lotSize, error: errors.lotSize, onChange: (lotSize) => update({ lotSize }) }),
    /* @__PURE__ */ jsxs("div", { className: "drawing-settings-split-field", children: [
      /* @__PURE__ */ jsx(NumberField, { label: "Risk", value: draft.riskValue, error: errors.riskValue, onChange: (riskValue) => update({ riskValue }) }),
      /* @__PURE__ */ jsxs(SelectField, { label: "Risk unit", value: draft.riskUnit, onChange: (riskUnit) => update({ riskUnit }), children: [
        /* @__PURE__ */ jsx("option", { value: "percent", children: "%" }),
        /* @__PURE__ */ jsx("option", { value: "currency", children: "Currency" })
      ] })
    ] }),
    /* @__PURE__ */ jsx(NumberField, { label: "Entry price", value: draft.price, error: errors.price, onChange: (price) => update({ price }) }),
    /* @__PURE__ */ jsx(NumberField, { label: "Leverage", value: draft.leverage, error: errors.leverage, onChange: (leverage) => update({ leverage }) }),
    /* @__PURE__ */ jsx(SectionLabel, { children: "Profit level" }),
    /* @__PURE__ */ jsx(NumberField, { label: "Target price", value: draft.targetPrice, error: errors.targetPrice, onChange: (targetPrice) => update({ targetPrice }) }),
    /* @__PURE__ */ jsxs("div", { className: "drawing-settings-derived", children: [
      /* @__PURE__ */ jsx("span", { children: "Target ticks" }),
      /* @__PURE__ */ jsx("strong", { children: (metrics == null ? void 0 : metrics.targetTicks.toFixed(0)) ?? "—" })
    ] }),
    /* @__PURE__ */ jsx(SectionLabel, { children: "Stop level" }),
    /* @__PURE__ */ jsx(NumberField, { label: "Stop price", value: draft.stopPrice, error: errors.stopPrice, onChange: (stopPrice) => update({ stopPrice }) }),
    /* @__PURE__ */ jsxs("div", { className: "drawing-settings-derived", children: [
      /* @__PURE__ */ jsx("span", { children: "Stop ticks" }),
      /* @__PURE__ */ jsx("strong", { children: (metrics == null ? void 0 : metrics.stopTicks.toFixed(0)) ?? "—" })
    ] }),
    /* @__PURE__ */ jsxs(SelectField, { label: "QTY precision", value: draft.quantityPrecision, onChange: (quantityPrecision) => update({ quantityPrecision: quantityPrecision === "default" ? "default" : Number(quantityPrecision) }), children: [
      /* @__PURE__ */ jsx("option", { value: "default", children: "Default" }),
      [0, 1, 2, 3, 4, 5, 6].map((item) => /* @__PURE__ */ jsx("option", { value: item, children: item }, item))
    ] }),
    metrics && /* @__PURE__ */ jsxs("div", { className: "drawing-settings-position-summary", role: "status", children: [
      /* @__PURE__ */ jsxs("strong", { children: [
        "Risk/reward ",
        metrics.riskReward.toFixed(2)
      ] }),
      /* @__PURE__ */ jsxs("span", { children: [
        "Risk ",
        metrics.riskAmount.toFixed(2),
        " · Qty ",
        metrics.quantity.toFixed(2),
        " · Margin ",
        metrics.margin.toFixed(2)
      ] })
    ] })
  ] });
}
function drawingPortalRoot() {
  return document.querySelector(".opencharts:not(dialog)") ?? document.body;
}
const SHAPES = /* @__PURE__ */ new Set(["rectangle", "ellipse", "triangle", "channel"]);
const RANGES = /* @__PURE__ */ new Set(["price-range", "date-range", "date-price-range"]);
const TEXTS = /* @__PURE__ */ new Set(["text", "anchored-text", "note"]);
function BaseLine({ draft, update, label = "Lines" }) {
  return /* @__PURE__ */ jsx(SettingsField, { label, children: /* @__PURE__ */ jsx(LineControl, { label, color: draft.color, width: draft.width ?? 2, style: draft.lineStyle ?? "solid", opacity: draft.opacity, onChange: (patch) => update(patch) }) });
}
function Extend({ draft, update }) {
  const value = draft.extendLeft && draft.extendRight ? "both" : draft.extendLeft ? "left" : draft.extendRight ? "right" : "none";
  return /* @__PURE__ */ jsxs(SelectField, { label: "Extend", value, onChange: (next) => update({ extendLeft: next === "left" || next === "both", extendRight: next === "right" || next === "both" }), children: [
    /* @__PURE__ */ jsx("option", { value: "none", children: "Don't extend" }),
    /* @__PURE__ */ jsx("option", { value: "left", children: "Extend left" }),
    /* @__PURE__ */ jsx("option", { value: "right", children: "Extend right" }),
    /* @__PURE__ */ jsx("option", { value: "both", children: "Extend both" })
  ] });
}
function ShapeStyle({ draft, update }) {
  return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-stack", children: [
    draft.type === "rectangle" && /* @__PURE__ */ jsx(Extend, { draft, update }),
    /* @__PURE__ */ jsx(SettingsField, { label: "Border", children: /* @__PURE__ */ jsx(LineControl, { label: "Border", color: draft.color, width: draft.width ?? 2, style: draft.lineStyle ?? "solid", opacity: draft.opacity, onChange: (patch) => update(patch) }) }),
    draft.type === "channel" && /* @__PURE__ */ jsx(CheckboxField, { label: "Middle line", checked: Boolean(draft.secondaryColor), onChange: (checked) => update({ secondaryColor: checked ? draft.color : void 0 }), children: /* @__PURE__ */ jsx(LineControl, { label: "Middle line", color: draft.secondaryColor ?? draft.color, width: draft.secondaryWidth ?? 1, style: draft.secondaryLineStyle ?? "dashed", opacity: draft.opacity, onChange: (patch) => update({ secondaryColor: patch.color ?? draft.secondaryColor ?? draft.color, secondaryWidth: patch.width, secondaryLineStyle: patch.lineStyle }) }) }),
    /* @__PURE__ */ jsx(CheckboxField, { label: "Background", checked: (draft.fillOpacity ?? 0) > 0, onChange: (checked) => update({ fillOpacity: checked ? Math.max(draft.fillOpacity, 0.14) : 0 }), children: /* @__PURE__ */ jsx(ColorControl, { label: "Background color", value: draft.fillColor, onChange: (fillColor) => update({ fillColor }), opacity: draft.fillOpacity, onOpacity: (fillOpacity) => update({ fillOpacity }) }) })
  ] });
}
function PositionStyle({ draft, update }) {
  return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-stack", children: [
    /* @__PURE__ */ jsx(BaseLine, { draft, update }),
    /* @__PURE__ */ jsx(SettingsField, { label: "Stop color", children: /* @__PURE__ */ jsx(ColorControl, { label: "Stop color", value: draft.stopColor, onChange: (stopColor) => update({ stopColor }), opacity: draft.stopFillOpacity, onOpacity: (stopFillOpacity) => update({ stopFillOpacity }) }) }),
    /* @__PURE__ */ jsx(SettingsField, { label: "Target color", children: /* @__PURE__ */ jsx(ColorControl, { label: "Target color", value: draft.targetColor, onChange: (targetColor) => update({ targetColor }), opacity: draft.targetFillOpacity, onOpacity: (targetFillOpacity) => update({ targetFillOpacity }) }) }),
    /* @__PURE__ */ jsxs(SettingsField, { label: "Text", children: [
      /* @__PURE__ */ jsx(ColorControl, { label: "Text color", value: draft.labelColor, onChange: (labelColor) => update({ labelColor }) }),
      /* @__PURE__ */ jsx("select", { className: "drawing-settings-select drawing-settings-select--compact", "aria-label": "Text size", value: draft.fontSize ?? 12, onChange: (event) => update({ fontSize: Number(event.target.value) }), children: [10, 11, 12, 14, 16, 18].map((size) => /* @__PURE__ */ jsx("option", { value: size, children: size }, size)) })
    ] }),
    /* @__PURE__ */ jsx(CheckboxField, { label: "Price labels", checked: draft.showPriceLabels, onChange: (showPriceLabels) => update({ showPriceLabels }) }),
    /* @__PURE__ */ jsx(SectionLabel, { children: "Info" }),
    /* @__PURE__ */ jsxs(SelectField, { label: "Stats", value: draft.statsMode, onChange: (statsMode) => update({ statsMode }), children: [
      /* @__PURE__ */ jsx("option", { value: "price-offsets", children: "TP price offset, TP/SL amounts" }),
      /* @__PURE__ */ jsx("option", { value: "risk-reward", children: "Risk/reward ratio" }),
      /* @__PURE__ */ jsx("option", { value: "amounts", children: "Amounts" }),
      /* @__PURE__ */ jsx("option", { value: "all", children: "All stats" })
    ] }),
    /* @__PURE__ */ jsx(CheckboxField, { label: "Compact stats mode", checked: draft.compactStats, onChange: (compactStats) => update({ compactStats }) }),
    /* @__PURE__ */ jsx(CheckboxField, { label: "Always show stats", checked: draft.alwaysShowStats, onChange: (alwaysShowStats) => update({ alwaysShowStats }) })
  ] });
}
function RangeStyle({ draft, update }) {
  return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-stack", children: [
    /* @__PURE__ */ jsx(BaseLine, { draft, update }),
    /* @__PURE__ */ jsx(SettingsField, { label: "Positive color", children: /* @__PURE__ */ jsx(ColorControl, { label: "Positive color", value: draft.positiveColor, onChange: (positiveColor) => update({ positiveColor }) }) }),
    /* @__PURE__ */ jsx(SettingsField, { label: "Negative color", children: /* @__PURE__ */ jsx(ColorControl, { label: "Negative color", value: draft.negativeColor, onChange: (negativeColor) => update({ negativeColor }) }) }),
    /* @__PURE__ */ jsx(SettingsField, { label: "Background", children: /* @__PURE__ */ jsx(ColorControl, { label: "Background color", value: draft.fillColor, onChange: (fillColor) => update({ fillColor }), opacity: draft.fillOpacity, onOpacity: (fillOpacity) => update({ fillOpacity }) }) }),
    /* @__PURE__ */ jsx(SettingsField, { label: "Label color", children: /* @__PURE__ */ jsx(ColorControl, { label: "Label color", value: draft.labelColor, onChange: (labelColor) => update({ labelColor }) }) }),
    /* @__PURE__ */ jsxs(SelectField, { label: "Label mode", value: draft.rangeLabelMode, onChange: (rangeLabelMode) => update({ rangeLabelMode }), children: [
      /* @__PURE__ */ jsx("option", { value: "full", children: "Full" }),
      /* @__PURE__ */ jsx("option", { value: "compact", children: "Compact" })
    ] })
  ] });
}
function FibonacciStyle({ draft, errors, update }) {
  var _a;
  const defaults2 = draft.type === "fibextension" ? FIB_EXT_LEVELS : FIB_LEVELS;
  const levels = ((_a = draft.fibLevelStyles) == null ? void 0 : _a.length) ? draft.fibLevelStyles : (draft.fibLevels ?? defaults2).map((value, index) => ({
    value,
    enabled: true,
    color: FIB_COLORS[index] ?? draft.color
  }));
  const updateLevel = (index, patch) => {
    update({ fibLevelStyles: levels.map((level, levelIndex) => levelIndex === index ? { ...level, ...patch } : level) });
  };
  return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-stack", children: [
    /* @__PURE__ */ jsx(BaseLine, { draft, update }),
    /* @__PURE__ */ jsxs("fieldset", { className: "drawing-settings-levels", "aria-label": "Levels", children: [
      /* @__PURE__ */ jsx("legend", { children: "Levels" }),
      levels.map((level, index) => /* @__PURE__ */ jsxs("div", { className: "drawing-settings-level-row", children: [
        /* @__PURE__ */ jsxs("label", { className: "drawing-settings-level-toggle", children: [
          /* @__PURE__ */ jsx("input", { "aria-label": `Enable level ${index + 1}`, type: "checkbox", checked: level.enabled, onChange: (event) => updateLevel(index, { enabled: event.target.checked }) }),
          /* @__PURE__ */ jsx("span", { "aria-hidden": "true", className: "drawing-settings-check-mark" })
        ] }),
        /* @__PURE__ */ jsx("input", { className: "drawing-settings-input drawing-settings-level-value", "aria-label": `Level ${index + 1} value`, type: "number", step: "any", value: Number.isFinite(level.value) ? level.value : "", onChange: (event) => updateLevel(index, { value: event.target.value === "" ? Number.NaN : Number(event.target.value) }) }),
        /* @__PURE__ */ jsx(ColorControl, { label: `Level ${index + 1} color`, value: level.color ?? FIB_COLORS[index] ?? draft.color, onChange: (color) => updateLevel(index, { color }) })
      ] }, index)),
      errors.fibLevelStyles && /* @__PURE__ */ jsx("p", { className: "drawing-settings-error", role: "alert", children: errors.fibLevelStyles })
    ] })
  ] });
}
function StyleTab({ draft, errors, update }) {
  if (draft.type === "position") return /* @__PURE__ */ jsx(PositionStyle, { draft, update });
  if (SHAPES.has(draft.type)) return /* @__PURE__ */ jsx(ShapeStyle, { draft, update });
  if (RANGES.has(draft.type)) return /* @__PURE__ */ jsx(RangeStyle, { draft, update });
  if (draft.type === "fibonacci" || draft.type === "fibextension") return /* @__PURE__ */ jsx(FibonacciStyle, { draft, errors, update });
  if (TEXTS.has(draft.type)) return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-stack", children: [
    /* @__PURE__ */ jsx(SettingsField, { label: draft.type === "note" ? "Marker" : "Text color", children: /* @__PURE__ */ jsx(ColorControl, { label: draft.type === "note" ? "Marker color" : "Text color", value: draft.color, onChange: (color) => update({ color }) }) }),
    /* @__PURE__ */ jsx(CheckboxField, { label: "Background", checked: Boolean(draft.textBg), onChange: (textBg) => update({ textBg }) }),
    /* @__PURE__ */ jsx(CheckboxField, { label: "Border", checked: Boolean(draft.textBorder), onChange: (textBorder) => update({ textBorder }) })
  ] });
  return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-stack", children: [
    /* @__PURE__ */ jsx(BaseLine, { draft, update }),
    (draft.type === "trendline" || draft.type === "horizontal") && /* @__PURE__ */ jsx(Extend, { draft, update }),
    " ",
    (draft.type === "trendline" || draft.type === "arrow") && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(CheckboxField, { label: "Start arrow", checked: Boolean(draft.arrowStart), onChange: (arrowStart) => update({ arrowStart }) }),
      /* @__PURE__ */ jsx(CheckboxField, { label: "End arrow", checked: Boolean(draft.arrowEnd), onChange: (arrowEnd) => update({ arrowEnd }) })
    ] })
  ] });
}
function TextTab({ draft, update }) {
  return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-stack", children: [
    /* @__PURE__ */ jsxs("div", { className: "drawing-settings-format-bar", children: [
      /* @__PURE__ */ jsx(ColorControl, { label: "Text color", value: draft.color, onChange: (color) => update({ color }) }),
      /* @__PURE__ */ jsx("select", { className: "drawing-settings-select drawing-settings-select--compact", "aria-label": "Font size", value: draft.fontSize ?? 14, onChange: (event) => update({ fontSize: Number(event.target.value) }), children: [8, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 40, 48].map((size) => /* @__PURE__ */ jsx("option", { value: size, children: size }, size)) }),
      /* @__PURE__ */ jsx("button", { type: "button", className: "drawing-settings-format-button", "aria-label": "Bold", "aria-pressed": Boolean(draft.bold), onClick: () => update({ bold: !draft.bold }), children: /* @__PURE__ */ jsx(Bold, { "aria-hidden": "true", size: 18 }) }),
      /* @__PURE__ */ jsx("button", { type: "button", className: "drawing-settings-format-button", "aria-label": "Italic", "aria-pressed": Boolean(draft.italic), onClick: () => update({ italic: !draft.italic }), children: /* @__PURE__ */ jsx(Italic, { "aria-hidden": "true", size: 18 }) })
    ] }),
    /* @__PURE__ */ jsxs("label", { className: "drawing-settings-textarea-label", children: [
      /* @__PURE__ */ jsx("span", { className: "sr-only", children: "Text" }),
      /* @__PURE__ */ jsx("textarea", { className: "drawing-settings-textarea", "aria-label": "Text", value: draft.text ?? "", placeholder: "Add text", onChange: (event) => update({ text: event.target.value }) })
    ] }),
    /* @__PURE__ */ jsx(SettingsField, { label: "Text alignment", children: /* @__PURE__ */ jsxs("div", { className: "drawing-settings-inline-selects", children: [
      /* @__PURE__ */ jsxs("select", { className: "drawing-settings-select", "aria-label": "Text placement", value: draft.textPlacement, onChange: (event) => update({ textPlacement: event.target.value }), children: [
        /* @__PURE__ */ jsx("option", { value: "inside", children: "Inside" }),
        /* @__PURE__ */ jsx("option", { value: "outside", children: "Outside" }),
        /* @__PURE__ */ jsx("option", { value: "above", children: "Above" }),
        /* @__PURE__ */ jsx("option", { value: "below", children: "Below" })
      ] }),
      /* @__PURE__ */ jsxs("select", { className: "drawing-settings-select", "aria-label": "Text alignment", value: draft.textAlign, onChange: (event) => update({ textAlign: event.target.value }), children: [
        /* @__PURE__ */ jsx("option", { value: "left", children: "Left" }),
        /* @__PURE__ */ jsx("option", { value: "center", children: "Center" }),
        /* @__PURE__ */ jsx("option", { value: "right", children: "Right" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx(CheckboxField, { label: "Background", checked: Boolean(draft.textBg), onChange: (textBg) => update({ textBg }), children: /* @__PURE__ */ jsx(ColorControl, { label: "Text background color", value: draft.textBgColor ?? "#1e222d", onChange: (textBgColor) => update({ textBgColor, textBg: true }) }) }),
    /* @__PURE__ */ jsx(CheckboxField, { label: "Border", checked: Boolean(draft.textBorder), onChange: (textBorder) => update({ textBorder }), children: /* @__PURE__ */ jsx(ColorControl, { label: "Text border color", value: draft.textBorderColor ?? draft.color, onChange: (textBorderColor) => update({ textBorderColor, textBorder: true }) }) })
  ] });
}
const UNITS = [["ticks", "Ticks"], ["seconds", "Seconds"], ["minutes", "Minutes"], ["hours", "Hours"], ["days", "Days"], ["weeks", "Weeks"], ["months", "Months"], ["ranges", "Ranges"]];
function VisibilityTab({ draft, currentTf, update }) {
  return /* @__PURE__ */ jsxs("div", { className: "drawing-settings-stack", children: [
    /* @__PURE__ */ jsxs(SelectField, { label: "Scope", value: draft.visibility, onChange: (visibility) => update(visibility === "tf" ? { visibility: "tf", createdTf: draft.createdTf ?? currentTf } : { visibility: "all" }), children: [
      /* @__PURE__ */ jsx("option", { value: "all", children: "All intervals" }),
      /* @__PURE__ */ jsxs("option", { value: "tf", children: [
        "Only ",
        draft.createdTf ?? currentTf
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "drawing-settings-visibility-list", children: UNITS.map(([unit, label]) => /* @__PURE__ */ jsx(CheckboxField, { label, checked: draft.visibilityRules[unit], onChange: (checked) => update({ visibilityRules: { ...draft.visibilityRules, [unit]: checked } }) }, unit)) })
  ] });
}
function toolName(drawing) {
  if (drawing.type === "position") {
    return drawing.side === "short" ? "Short Position" : "Long Position";
  }
  return drawing.type.split("-").map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join(" ");
}
function tabName(tab) {
  return tab.charAt(0).toUpperCase() + tab.slice(1);
}
function focusable(dialog) {
  return Array.from(
    dialog.querySelectorAll(
      'button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex="0"]'
    )
  ).filter((element) => element.getAttribute("aria-hidden") !== "true");
}
function DrawingSettingsDialog({
  drawing,
  currentTf: _currentTf,
  onPreview,
  onCommit,
  onClose
}) {
  const dialogRef = useRef(null);
  const firstTabRef = useRef(null);
  const frameRef = useRef(null);
  const dragRef = useRef(null);
  const tabs = settingsTabsFor(drawing.type);
  const [activeTab, setActiveTab] = useState(tabs[0]);
  const [renaming, setRenaming] = useState(false);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const { draft, errors, canCommit, update, cancel, commit } = useDrawingSettingsDraft(
    drawing,
    onPreview,
    onCommit,
    onClose
  );
  useEffect(() => {
    var _a;
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (!dialog.open) dialog.showModal();
    (_a = firstTabRef.current) == null ? void 0 : _a.focus();
    return () => {
      if (dialog.open) dialog.close();
    };
  }, []);
  const onKeyDown = (event) => {
    if (event.key !== "Tab") return;
    const items = focusable(event.currentTarget);
    if (items.length === 0) return;
    const first = items[0];
    const last = items[items.length - 1];
    if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    } else if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    }
  };
  const startDrag = (event) => {
    var _a, _b;
    if (event.target.closest("button,input")) return;
    dragRef.current = { pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, originX: offset.x, originY: offset.y };
    (_b = (_a = event.currentTarget).setPointerCapture) == null ? void 0 : _b.call(_a, event.pointerId);
  };
  const moveDrag = (event) => {
    const drag = dragRef.current;
    const frame = frameRef.current;
    if (!drag || drag.pointerId !== event.pointerId || !frame) return;
    const maxX = Math.max(0, (window.innerWidth - frame.offsetWidth) / 2 - 8);
    const maxY = Math.max(0, (window.innerHeight - frame.offsetHeight) / 2 - 8);
    setOffset({
      x: Math.max(-maxX, Math.min(maxX, drag.originX + event.clientX - drag.startX)),
      y: Math.max(-maxY, Math.min(maxY, drag.originY + event.clientY - drag.startY))
    });
  };
  const stopDrag = (event) => {
    var _a;
    if (((_a = dragRef.current) == null ? void 0 : _a.pointerId) === event.pointerId) dragRef.current = null;
  };
  const name = toolName(drawing);
  return createPortal(
    /* @__PURE__ */ jsx(
      "dialog",
      {
        ref: dialogRef,
        className: "opencharts drawing-settings-dialog",
        "aria-label": `${name} settings`,
        "data-drawing-type": drawing.type,
        onCancel: (event) => {
          event.preventDefault();
          cancel();
        },
        onKeyDown,
        children: /* @__PURE__ */ jsxs("section", { ref: frameRef, className: "drawing-settings-frame", "aria-labelledby": "drawing-settings-title", style: { transform: `translate(calc(-50% + ${offset.x}px), calc(-50% + ${offset.y}px))` }, children: [
          /* @__PURE__ */ jsxs("header", { className: "drawing-settings-header", onPointerDown: startDrag, onPointerMove: moveDrag, onPointerUp: stopDrag, onPointerCancel: stopDrag, children: [
            /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
              renaming ? /* @__PURE__ */ jsx("input", { className: "drawing-settings-title-input", "aria-label": "Drawing name", value: draft.name ?? name, autoFocus: true, onChange: (event) => update({ name: event.target.value }), onBlur: () => setRenaming(false), onKeyDown: (event) => {
                if (event.key === "Enter") setRenaming(false);
              } }) : /* @__PURE__ */ jsx("h2", { id: "drawing-settings-title", className: "drawing-settings-title", children: draft.name || name }),
              /* @__PURE__ */ jsx("button", { type: "button", className: "drawing-settings-icon-button", "aria-label": `Rename ${name}`, onClick: () => setRenaming(true), children: /* @__PURE__ */ jsx(Pencil, { "aria-hidden": "true", size: 17, strokeWidth: 1.5 }) })
            ] }),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                className: "drawing-settings-icon-button",
                "aria-label": `Close ${name} settings`,
                onClick: cancel,
                children: /* @__PURE__ */ jsx(X, { "aria-hidden": "true", size: 22, strokeWidth: 1.5 })
              }
            )
          ] }),
          /* @__PURE__ */ jsx(TabList, { tabs, active: activeTab, onChange: setActiveTab, initialFocusRef: firstTabRef }),
          /* @__PURE__ */ jsxs("div", { className: "drawing-settings-body", role: "tabpanel", "aria-label": tabName(activeTab), "data-drawing-tab": activeTab, children: [
            activeTab === "inputs" && /* @__PURE__ */ jsx(PositionInputsTab, { draft, errors, update }),
            activeTab === "style" && /* @__PURE__ */ jsx(StyleTab, { draft, errors, update }),
            activeTab === "text" && /* @__PURE__ */ jsx(TextTab, { draft, update }),
            activeTab === "coordinates" && /* @__PURE__ */ jsx(CoordinatesTab, { draft, errors, update }),
            activeTab === "visibility" && /* @__PURE__ */ jsx(VisibilityTab, { draft, currentTf: _currentTf, update })
          ] }),
          /* @__PURE__ */ jsxs("footer", { className: "drawing-settings-footer", children: [
            /* @__PURE__ */ jsxs("select", { className: "drawing-settings-select max-w-36", "aria-label": "Template", defaultValue: "", onChange: (event) => {
              if (event.target.value === "__default") setTypeDefault(draft.type, draft);
              else {
                const template = getTemplates().find((item) => item.name === event.target.value);
                if (template) update(template.style);
              }
              event.currentTarget.value = "";
            }, children: [
              /* @__PURE__ */ jsx("option", { value: "", children: "Template" }),
              getTemplates().map((template) => /* @__PURE__ */ jsx("option", { value: template.name, children: template.name }, template.name)),
              /* @__PURE__ */ jsx("option", { value: "__default", children: "Set as default" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "drawing-settings-footer-actions", children: [
              /* @__PURE__ */ jsx("button", { type: "button", className: "drawing-settings-button", onClick: cancel, children: "Cancel" }),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  className: "drawing-settings-button drawing-settings-button--primary",
                  disabled: !canCommit,
                  onClick: commit,
                  children: "OK"
                }
              )
            ] })
          ] })
        ] })
      }
    ),
    drawingPortalRoot()
  );
}
const TEXT = /* @__PURE__ */ new Set(["text", "anchored-text", "note"]);
const FREEHAND = /* @__PURE__ */ new Set(["brush", "highlighter", "path", "curve"]);
const RANGE = /* @__PURE__ */ new Set(["price-range", "date-range", "date-price-range"]);
const SHAPE = /* @__PURE__ */ new Set(["rectangle", "ellipse", "triangle", "channel"]);
function toolbarControlsFor(drawing) {
  let contextual;
  if (drawing.type === "position") contextual = ["line", "text", "stop-color", "target-color", "stats"];
  else if (TEXT.has(drawing.type)) contextual = ["text-color", "font-size", "bold", "italic"];
  else if (RANGE.has(drawing.type)) contextual = ["text", "positive-color", "negative-color"];
  else if (FREEHAND.has(drawing.type)) contextual = ["line", "smooth", "close"];
  else if (SHAPE.has(drawing.type)) contextual = ["border", "fill", "text", "visibility", "order"];
  else contextual = ["line", "text", "extend"];
  return [...contextual, "clone", "settings", "lock", "delete", "more"];
}
function clampDrawingToolbar(anchor, bounds, size) {
  const inset = 8;
  const gap = 12;
  const maxWidth = Math.max(0, bounds.width - inset * 2);
  const renderedWidth = Math.min(size.width, maxWidth);
  const minX = bounds.left + inset;
  const maxX = bounds.left + bounds.width - inset - renderedWidth;
  const preferredY = anchor.y - size.height - gap;
  const side = preferredY >= bounds.top + inset ? "above" : "below";
  const rawY = side === "above" ? preferredY : anchor.y + gap;
  const maxY = bounds.top + bounds.height - inset - size.height;
  return {
    x: Math.round(Math.min(Math.max(anchor.x - renderedWidth / 2, minX), Math.max(minX, maxX))),
    y: Math.round(Math.min(Math.max(rawY, bounds.top + inset), Math.max(bounds.top + inset, maxY))),
    side,
    maxWidth
  };
}
const NEXT_LINE = { solid: "dashed", dashed: "dotted", dotted: "solid" };
function ToolButton$1({ label, active, danger, onClick, children }) {
  return /* @__PURE__ */ jsx("button", { type: "button", "aria-label": label, title: label, "aria-pressed": active, className: `drawing-floating-button${active ? " is-active" : ""}${danger ? " is-danger" : ""}`, onClick, children });
}
function ColorTool({ label, value, onChange }) {
  return /* @__PURE__ */ jsx(TradingViewColorPicker, { label, value, onChange, className: "drawing-floating-color" });
}
function DrawingFloatingToolbar({ drawing, anchor, bounds, onUpdate, onClone, onRemove, onOpenSettings }) {
  const controls = useMemo(() => new Set(toolbarControlsFor(drawing)), [drawing]);
  const ref = useRef(null);
  const dragRef = useRef(null);
  const dragCleanupRef = useRef(null);
  const [size, setSize] = useState({ width: 520, height: 48 });
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const patch = (next) => onUpdate({ ...drawing, ...next });
  useLayoutEffect(() => {
    const element = ref.current;
    if (!element) return;
    const measure = () => setSize({ width: element.scrollWidth, height: element.offsetHeight || 48 });
    measure();
    if (typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    return () => observer.disconnect();
  }, [drawing.type]);
  useEffect(() => () => {
    var _a;
    return (_a = dragCleanupRef.current) == null ? void 0 : _a.call(dragCleanupRef);
  }, []);
  const placement = clampDrawingToolbar({ x: anchor.x + offset.x, y: anchor.y + offset.y }, bounds, size);
  const beginDrag = (event) => {
    var _a;
    event.preventDefault();
    (_a = dragCleanupRef.current) == null ? void 0 : _a.call(dragCleanupRef);
    const pointerId = Number.isFinite(event.pointerId) ? event.pointerId : 0;
    const startX = Number.isFinite(event.clientX) ? event.clientX : 0;
    const startY = Number.isFinite(event.clientY) ? event.clientY : 0;
    dragRef.current = { pointerId, x: startX, y: startY, dx: offset.x, dy: offset.y };
    const move = (next) => {
      const drag = dragRef.current;
      const nextPointerId = Number.isFinite(next.pointerId) ? next.pointerId : 0;
      if (!drag || nextPointerId !== drag.pointerId) return;
      const nextX = Number.isFinite(next.clientX) ? next.clientX : drag.x;
      const nextY = Number.isFinite(next.clientY) ? next.clientY : drag.y;
      setOffset({ x: drag.dx + nextX - drag.x, y: drag.dy + nextY - drag.y });
    };
    let finish;
    const cleanup = () => {
      dragRef.current = null;
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", finish);
      window.removeEventListener("pointercancel", finish);
      dragCleanupRef.current = null;
    };
    finish = (next) => {
      var _a2;
      const nextPointerId = Number.isFinite(next.pointerId) ? next.pointerId : 0;
      if (((_a2 = dragRef.current) == null ? void 0 : _a2.pointerId) !== nextPointerId) return;
      cleanup();
    };
    dragCleanupRef.current = cleanup;
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", finish);
    window.addEventListener("pointercancel", finish);
  };
  const toolbar = /* @__PURE__ */ jsxs("div", { ref, role: "toolbar", "aria-label": "Selected drawing", className: "drawing-floating-toolbar drawing-alignment-surface", style: { left: placement.x, top: placement.y, maxWidth: placement.maxWidth }, children: [
    /* @__PURE__ */ jsx("button", { type: "button", "aria-label": "Move drawing toolbar", title: "Move toolbar", className: "drawing-floating-grip", onPointerDown: beginDrag, children: /* @__PURE__ */ jsx(GripVertical, { "aria-hidden": "true" }) }),
    /* @__PURE__ */ jsxs("div", { className: "drawing-floating-scroll", children: [
      (controls.has("line") || controls.has("border")) && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(ColorTool, { label: controls.has("border") ? "Border color" : "Line color", value: drawing.color, onChange: (color) => patch({ color }) }),
        /* @__PURE__ */ jsx(ToolButton$1, { label: "Line style", onClick: () => patch({ lineStyle: NEXT_LINE[drawing.lineStyle ?? "solid"] }), children: /* @__PURE__ */ jsx("span", { className: `drawing-floating-line drawing-floating-line--${drawing.lineStyle ?? "solid"}` }) }),
        /* @__PURE__ */ jsxs("button", { type: "button", "aria-label": "Line width", className: "drawing-floating-width", onClick: () => patch({ width: (drawing.width ?? 2) >= 4 ? 1 : (drawing.width ?? 2) + 1 }), children: [
          /* @__PURE__ */ jsx("span", {}),
          drawing.width ?? 2,
          "px"
        ] })
      ] }),
      controls.has("fill") && /* @__PURE__ */ jsx(ColorTool, { label: "Fill color", value: drawing.fillColor ?? drawing.color, onChange: (fillColor) => patch({ fillColor }) }),
      controls.has("positive-color") && /* @__PURE__ */ jsx(ColorTool, { label: "Positive color", value: drawing.positiveColor ?? "#089981", onChange: (positiveColor) => patch({ positiveColor }) }),
      controls.has("negative-color") && /* @__PURE__ */ jsx(ColorTool, { label: "Negative color", value: drawing.negativeColor ?? "#f23645", onChange: (negativeColor) => patch({ negativeColor }) }),
      controls.has("stop-color") && /* @__PURE__ */ jsx(ColorTool, { label: "Stop color", value: drawing.stopColor ?? "#f23645", onChange: (stopColor) => patch({ stopColor }) }),
      controls.has("target-color") && /* @__PURE__ */ jsx(ColorTool, { label: "Target color", value: drawing.targetColor ?? "#089981", onChange: (targetColor) => patch({ targetColor }) }),
      (controls.has("text") || controls.has("text-color")) && /* @__PURE__ */ jsx(ToolButton$1, { label: "Text style", onClick: onOpenSettings, children: /* @__PURE__ */ jsx(Type, { "aria-hidden": "true" }) }),
      controls.has("font-size") && /* @__PURE__ */ jsx("button", { type: "button", "aria-label": "Font size", className: "drawing-floating-text-value", onClick: () => patch({ fontSize: (drawing.fontSize ?? 14) >= 24 ? 10 : (drawing.fontSize ?? 14) + 2 }), children: drawing.fontSize ?? 14 }),
      controls.has("bold") && /* @__PURE__ */ jsx(ToolButton$1, { label: "Bold", active: drawing.bold, onClick: () => patch({ bold: !drawing.bold }), children: /* @__PURE__ */ jsx(Bold, { "aria-hidden": "true" }) }),
      controls.has("italic") && /* @__PURE__ */ jsx(ToolButton$1, { label: "Italic", active: drawing.italic, onClick: () => patch({ italic: !drawing.italic }), children: /* @__PURE__ */ jsx(Italic, { "aria-hidden": "true" }) }),
      controls.has("extend") && /* @__PURE__ */ jsx(ToolButton$1, { label: "Extend line", active: drawing.extendLeft || drawing.extendRight, onClick: () => patch({ extendLeft: !drawing.extendLeft, extendRight: !drawing.extendRight }), children: /* @__PURE__ */ jsx("span", { className: "drawing-floating-extend", children: "↔" }) }),
      controls.has("smooth") && /* @__PURE__ */ jsx(ToolButton$1, { label: "Smooth path", active: drawing.smooth, onClick: () => patch({ smooth: !drawing.smooth }), children: /* @__PURE__ */ jsx("span", { className: "drawing-floating-glyph", children: "⌁" }) }),
      controls.has("close") && /* @__PURE__ */ jsx(ToolButton$1, { label: "Close path", active: drawing.closed, onClick: () => patch({ closed: !drawing.closed }), children: /* @__PURE__ */ jsx("span", { className: "drawing-floating-glyph", children: "◇" }) }),
      controls.has("stats") && /* @__PURE__ */ jsx(ToolButton$1, { label: "Position stats", active: drawing.alwaysShowStats, onClick: () => patch({ alwaysShowStats: !drawing.alwaysShowStats }), children: /* @__PURE__ */ jsx("span", { className: "drawing-floating-glyph", children: "%" }) }),
      controls.has("visibility") && /* @__PURE__ */ jsx(ToolButton$1, { label: drawing.hidden ? "Show drawing" : "Hide drawing", active: !drawing.hidden, onClick: () => patch({ hidden: !drawing.hidden }), children: drawing.hidden ? /* @__PURE__ */ jsx(EyeOff, { "aria-hidden": "true" }) : /* @__PURE__ */ jsx(Eye, { "aria-hidden": "true" }) }),
      controls.has("order") && /* @__PURE__ */ jsx(ToolButton$1, { label: "Bring drawing forward", onClick: () => patch({ zIndex: (drawing.zIndex ?? 0) + 1 }), children: /* @__PURE__ */ jsx(BringToFront, { "aria-hidden": "true" }) }),
      /* @__PURE__ */ jsx("span", { className: "drawing-floating-separator" }),
      /* @__PURE__ */ jsx(ToolButton$1, { label: "Clone drawing", onClick: onClone, children: /* @__PURE__ */ jsx(Copy, { "aria-hidden": "true" }) }),
      /* @__PURE__ */ jsx(ToolButton$1, { label: "Open drawing settings", onClick: onOpenSettings, children: /* @__PURE__ */ jsx(Settings2, { "aria-hidden": "true" }) }),
      /* @__PURE__ */ jsx(ToolButton$1, { label: drawing.locked ? "Unlock drawing" : "Lock drawing", active: drawing.locked, onClick: () => patch({ locked: !drawing.locked }), children: drawing.locked ? /* @__PURE__ */ jsx(Lock, { "aria-hidden": "true" }) : /* @__PURE__ */ jsx(LockOpen, { "aria-hidden": "true" }) }),
      /* @__PURE__ */ jsx(ToolButton$1, { label: "Delete drawing", danger: true, onClick: onRemove, children: /* @__PURE__ */ jsx(Trash2, { "aria-hidden": "true" }) }),
      /* @__PURE__ */ jsx(ToolButton$1, { label: "More drawing actions", onClick: onOpenSettings, children: /* @__PURE__ */ jsx(Ellipsis, { "aria-hidden": "true" }) })
    ] })
  ] });
  return createPortal(toolbar, drawingPortalRoot());
}
function MenuItem({
  icon: Icon,
  label,
  danger,
  onClick
}) {
  return /* @__PURE__ */ jsxs(
    "button",
    {
      type: "button",
      onClick,
      className: cn(
        "flex w-full items-center gap-2 px-3 py-1.5 text-xs hover:bg-secondary text-left",
        danger ? "text-[#f6465d]" : "text-foreground"
      ),
      children: [
        /* @__PURE__ */ jsx(Icon, { className: "h-3.5 w-3.5" }),
        label
      ]
    }
  );
}
function DrawingContextMenu({
  drawing,
  x,
  y,
  onClose,
  onSettings,
  onDuplicate,
  onReorder,
  onToggleLock,
  onToggleAlert,
  onRemove
}) {
  const canAlert = drawing.type === "horizontal" || drawing.type === "trendline";
  const act = (fn) => () => {
    fn();
    onClose();
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        "aria-label": "Close menu",
        className: "fixed inset-0 z-40 cursor-default",
        onClick: onClose
      }
    ),
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: "fixed z-40 w-44 rounded-md bg-card border border-border shadow-2xl py-1",
        style: { left: x, top: y },
        children: [
          /* @__PURE__ */ jsx(MenuItem, { icon: Settings2, label: "Settings", onClick: act(onSettings) }),
          /* @__PURE__ */ jsx(MenuItem, { icon: Copy, label: "Duplicate", onClick: act(onDuplicate) }),
          /* @__PURE__ */ jsx(
            MenuItem,
            {
              icon: ChevronsUp,
              label: "Bring to front",
              onClick: act(() => onReorder("front"))
            }
          ),
          /* @__PURE__ */ jsx(MenuItem, { icon: ChevronsDown, label: "Send to back", onClick: act(() => onReorder("back")) }),
          /* @__PURE__ */ jsx(
            MenuItem,
            {
              icon: drawing.locked ? LockOpen : Lock,
              label: drawing.locked ? "Unlock" : "Lock",
              onClick: act(onToggleLock)
            }
          ),
          canAlert && /* @__PURE__ */ jsx(
            MenuItem,
            {
              icon: Bell,
              label: drawing.alertEnabled ? "Remove alert" : "Add alert",
              onClick: act(onToggleAlert)
            }
          ),
          /* @__PURE__ */ jsx("div", { className: "my-1 border-t border-border/60" }),
          /* @__PURE__ */ jsx(MenuItem, { icon: Trash2, label: "Delete", danger: true, onClick: act(onRemove) })
        ]
      }
    )
  ] });
}
const DRAWING_TOOL_GROUPS = [
  {
    id: "lines",
    icon: TrendingUp,
    label: "Lines",
    tools: [
      { tool: "trendline", icon: TrendingUp, label: "Trend Line" },
      { tool: "ray", icon: MoveUpRight, label: "Ray" },
      { tool: "extended", icon: Spline, label: "Extended Line" },
      { tool: "horizontal", icon: Minus, label: "Horizontal Line" },
      { tool: "vertical", icon: MoveVertical, label: "Vertical Line" },
      { tool: "channel", icon: Equal, label: "Parallel Channel" },
      { tool: "polyline", icon: Waypoints, label: "Polyline" },
      { tool: "curve", icon: Spline, label: "Curve" }
    ]
  },
  {
    id: "brushes",
    icon: Brush,
    label: "Brushes",
    tools: [
      { tool: "brush", icon: Brush, label: "Brush" },
      { tool: "highlighter", icon: Highlighter, label: "Highlighter" },
      { tool: "path", icon: Route, label: "Path" }
    ]
  },
  {
    id: "fib",
    icon: Layers,
    label: "Fibonacci",
    tools: [
      { tool: "fibonacci", icon: Layers, label: "Fib Retracement" },
      { tool: "fibextension", icon: Layers3, label: "Fib Extension" }
    ]
  },
  {
    id: "shapes",
    icon: Square,
    label: "Shapes",
    tools: [
      { tool: "rectangle", icon: Square, label: "Rectangle" },
      { tool: "ellipse", icon: Circle, label: "Ellipse" },
      { tool: "triangle", icon: Triangle, label: "Triangle" },
      { tool: "arrow", icon: ArrowRight, label: "Arrow" }
    ]
  },
  {
    id: "measure",
    icon: Ruler,
    label: "Measure",
    tools: [
      { tool: "measure", icon: Ruler, label: "Measure" },
      { tool: "price-range", icon: ChartNoAxesColumnIncreasing, label: "Price Range" },
      { tool: "date-range", icon: CalendarRange, label: "Date Range" },
      { tool: "date-price-range", icon: MoveDiagonal2, label: "Date & Price Range" }
    ]
  },
  {
    id: "trade",
    icon: ArrowUpRight,
    label: "Trade",
    tools: [
      { tool: "long-position", icon: ArrowUpRight, label: "Long Position" },
      { tool: "short-position", icon: ArrowDownRight, label: "Short Position" }
    ]
  },
  {
    id: "text",
    icon: Type,
    label: "Text & Notes",
    tools: [
      { tool: "text", icon: Type, label: "Text" },
      { tool: "anchored-text", icon: Type, label: "Anchored Text" },
      { tool: "note", icon: StickyNote, label: "Note" }
    ]
  }
];
function RailButton({
  icon: Icon,
  title,
  active,
  onClick
}) {
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      title,
      "aria-label": title,
      "aria-pressed": active,
      onClick,
      className: cn(
        "p-1.5 rounded hover:bg-secondary",
        active ? "bg-primary/20 text-primary" : "text-muted-foreground"
      ),
      children: /* @__PURE__ */ jsx(Icon, { className: "h-4 w-4" })
    }
  );
}
function RailGroup({
  group,
  activeTool,
  open,
  onToggle,
  onSelect
}) {
  const anchor = useRef(null);
  const [position, setPosition] = useState({ left: 40, top: 50 });
  const activeMeta = group.tools.find((t) => t.tool === activeTool);
  const Icon = (activeMeta == null ? void 0 : activeMeta.icon) ?? group.icon;
  return /* @__PURE__ */ jsxs("div", { className: "relative", ref: anchor, children: [
    /* @__PURE__ */ jsx(RailButton, { icon: Icon, title: group.label, active: Boolean(activeMeta), onClick: () => {
      var _a;
      const r = (_a = anchor.current) == null ? void 0 : _a.getBoundingClientRect();
      if (r) setPosition({ left: Math.max(8, Math.min(r.right + 5, window.innerWidth - 232)), top: Math.max(8, Math.min(r.top, window.innerHeight - group.tools.length * 34 - 20)) });
      onToggle();
    } }),
    open && createPortal(
      /* @__PURE__ */ jsx("div", { className: "opencharts", "data-drawing-rail-menu": true, style: { position: "fixed", left: position.left, top: position.top, right: "auto", bottom: "auto", width: "max-content", height: "auto", maxWidth: "calc(100vw - 16px)", zIndex: 1e3, maxHeight: "calc(100vh - 32px)", overflowY: "auto", background: "#202124", border: "1px solid #404040", borderRadius: 4, minWidth: 180, padding: "4px 0", boxShadow: "0 10px 30px #0008" }, children: group.tools.map((t) => /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          onClick: () => onSelect(t.tool),
          className: cn(
            "w-full flex items-center gap-2.5 px-3 py-1.5 text-sm hover:bg-secondary text-left",
            activeTool === t.tool && "bg-secondary text-primary"
          ),
          children: [
            /* @__PURE__ */ jsx(t.icon, { className: "h-3.5 w-3.5 shrink-0" }),
            t.label
          ]
        },
        t.tool
      )) }),
      document.body
    )
  ] });
}
function DrawingToolRail({
  drawingTool,
  onDrawingTool,
  magnetActive = false,
  onMagnetToggle,
  stayActive = false,
  onStayToggle
}) {
  const [openGroup, setOpenGroup] = useState(null);
  const [hidden, setHidden] = useState(false);
  const ref = useRef(null);
  const drag = useDragOffset();
  useEffect(() => {
    if (!openGroup) return;
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target) && !e.target.closest("[data-drawing-rail-menu]")) setOpenGroup(null);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [openGroup]);
  const select = (t) => {
    onDrawingTool(drawingTool === t ? "none" : t);
    setOpenGroup(null);
  };
  const hide = () => {
    setOpenGroup(null);
    setHidden(true);
  };
  if (hidden) {
    return /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        title: "Show drawing tools",
        onClick: () => setHidden(false),
        style: drag.style,
        className: "absolute left-1 top-1 z-20 rounded-md border border-border bg-card/90 p-1.5 text-muted-foreground backdrop-blur-sm hover:text-primary",
        children: /* @__PURE__ */ jsx(PenTool, { className: "h-4 w-4" })
      }
    );
  }
  return /* @__PURE__ */ jsxs(
    "div",
    {
      ref,
      style: drag.style,
      className: "absolute left-1 top-1 z-20 flex flex-col items-center gap-0.5 rounded-md bg-card/90 border border-border p-0.5 backdrop-blur-sm",
      children: [
        /* @__PURE__ */ jsx(
          "div",
          {
            onPointerDown: drag.onPointerDown,
            title: "Drag to move",
            className: "flex w-full cursor-move justify-center py-0.5 text-muted-foreground/50 hover:text-muted-foreground",
            children: /* @__PURE__ */ jsx(GripVertical, { className: "h-3.5 w-3.5" })
          }
        ),
        /* @__PURE__ */ jsx(
          RailButton,
          {
            icon: MousePointer2,
            title: "Cursor",
            active: drawingTool === "none",
            onClick: () => {
              onDrawingTool("none");
              setOpenGroup(null);
            }
          }
        ),
        DRAWING_TOOL_GROUPS.map((g) => /* @__PURE__ */ jsx(
          RailGroup,
          {
            group: g,
            activeTool: drawingTool,
            open: openGroup === g.id,
            onToggle: () => setOpenGroup((o) => o === g.id ? null : g.id),
            onSelect: select
          },
          g.id
        )),
        /* @__PURE__ */ jsx("div", { className: "my-0.5 w-full border-t border-border/50" }),
        onMagnetToggle && /* @__PURE__ */ jsx(RailButton, { icon: Magnet, title: "Magnet · hold Cmd/Ctrl for temporary snap", active: magnetActive, onClick: onMagnetToggle }),
        onStayToggle && /* @__PURE__ */ jsx(RailButton, { icon: PencilLine, title: "Stay in drawing mode", active: stayActive, onClick: onStayToggle }),
        /* @__PURE__ */ jsx(RailButton, { icon: EyeOff, title: "Hide toolbar", onClick: hide })
      ]
    }
  );
}
function NewsOverlay({
  newsConfig,
  setNewsConfig,
  showNewsConfigDialog,
  setShowNewsConfigDialog,
  newsPopup,
  setNewsPopup,
  isDark,
  containerRef
}) {
  const configDrag = useDragOffset();
  const [paneWidth, setPaneWidth] = useState(0);
  useLayoutEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const measure = () => setPaneWidth(el.clientWidth);
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, [containerRef]);
  const POPUP_WIDTH = 288;
  const popupLeft = newsPopup ? Math.max(8, Math.min(newsPopup.x - 140, Math.max(8, paneWidth - POPUP_WIDTH))) : 0;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    newsPopup && /* @__PURE__ */ jsx(
      "div",
      {
        className: "absolute z-30",
        style: {
          left: popupLeft,
          top: Math.max(newsPopup.y - 200, 8)
        },
        onClick: (e) => e.stopPropagation(),
        children: /* @__PURE__ */ jsxs(
          "div",
          {
            className: cn(
              "w-[calc(100vw-2rem)] sm:w-[280px] rounded-lg shadow-2xl border overflow-hidden",
              isDark ? "bg-[#1e222d] border-[#363a45]" : "bg-white border-gray-200"
            ),
            children: [
              /* @__PURE__ */ jsx(
                "div",
                {
                  className: cn(
                    "h-1",
                    newsPopup.event.impact === "high" ? "bg-red-500" : newsPopup.event.impact === "medium" ? "bg-amber-500" : "bg-gray-400"
                  )
                }
              ),
              /* @__PURE__ */ jsxs("div", { className: "p-3", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mb-2", children: [
                  /* @__PURE__ */ jsx(
                    "h4",
                    {
                      className: cn(
                        "font-bold text-[13px] leading-tight",
                        isDark ? "text-white" : "text-gray-900"
                      ),
                      children: newsPopup.event.event
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    "button",
                    {
                      onClick: () => setNewsPopup(null),
                      className: "text-muted-foreground hover:text-foreground p-0.5",
                      children: /* @__PURE__ */ jsx(X, { className: "h-3.5 w-3.5" })
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("p", { className: "text-[11px] text-muted-foreground mb-3", children: [
                  new Date(newsPopup.event.time).toLocaleDateString("en-US", {
                    day: "numeric",
                    month: "short",
                    year: "2-digit"
                  }),
                  " ",
                  new Date(newsPopup.event.time).toLocaleTimeString("en-US", {
                    hour: "2-digit",
                    minute: "2-digit",
                    hour12: false
                  })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between text-[11px]", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Actual" }),
                    /* @__PURE__ */ jsx(
                      "span",
                      {
                        className: cn("font-bold font-mono", isDark ? "text-white" : "text-gray-900"),
                        children: newsPopup.event.actual || "—"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between text-[11px]", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Forecast" }),
                    /* @__PURE__ */ jsx("span", { className: "font-mono font-medium", children: newsPopup.event.forecast || "—" })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "flex justify-between text-[11px]", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Previous" }),
                    /* @__PURE__ */ jsx("span", { className: "font-mono text-muted-foreground", children: newsPopup.event.previous || "—" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "mt-2.5 pt-2 border-t border-border/40 flex items-center gap-1.5 text-[10px] text-muted-foreground", children: [
                  /* @__PURE__ */ jsx(
                    "span",
                    {
                      className: cn(
                        "inline-flex items-center gap-1 px-1.5 py-0.5 rounded font-semibold text-[9px]",
                        newsPopup.event.impact === "high" ? "bg-red-500/15 text-red-500" : newsPopup.event.impact === "medium" ? "bg-amber-500/15 text-amber-500" : "bg-gray-500/15 text-gray-400"
                      ),
                      children: newsPopup.event.impact.toUpperCase()
                    }
                  ),
                  /* @__PURE__ */ jsx("span", { children: newsPopup.event.currency }),
                  /* @__PURE__ */ jsx("span", { className: "text-muted-foreground/50", children: "|" }),
                  /* @__PURE__ */ jsx("span", { children: newsPopup.event.country })
                ] })
              ] })
            ]
          }
        )
      }
    ),
    /* @__PURE__ */ jsxs(
      "button",
      {
        onClick: (e) => {
          e.stopPropagation();
          setShowNewsConfigDialog((v) => !v);
          setNewsPopup(null);
        },
        className: cn(
          "absolute bottom-2 right-24 z-10 flex items-center gap-1 px-2 py-1 rounded text-[10px] font-medium transition-all",
          newsConfig.enabled ? "bg-red-500/15 text-red-400 border border-red-500/30 hover:bg-red-500/25" : "bg-secondary/60 text-muted-foreground border border-border hover:bg-secondary"
        ),
        title: "News overlay settings",
        children: [
          /* @__PURE__ */ jsx(Newspaper, { className: "h-3 w-3" }),
          "News",
          /* @__PURE__ */ jsx(Settings2, { className: "h-2.5 w-2.5 ml-0.5 opacity-60" })
        ]
      }
    ),
    showNewsConfigDialog && /* @__PURE__ */ jsx(
      "div",
      {
        className: "absolute bottom-10 right-2 sm:right-24 z-30 w-[calc(100vw-1rem)] sm:w-[260px]",
        style: configDrag.style,
        onClick: (e) => e.stopPropagation(),
        children: /* @__PURE__ */ jsxs(
          "div",
          {
            className: cn(
              "rounded-lg shadow-2xl border overflow-hidden",
              isDark ? "bg-[#1e222d] border-[#363a45]" : "bg-white border-gray-200"
            ),
            children: [
              /* @__PURE__ */ jsxs(
                "div",
                {
                  onPointerDown: configDrag.onPointerDown,
                  className: "flex cursor-grab select-none items-center justify-between px-3 py-2 border-b border-border/40 active:cursor-grabbing",
                  children: [
                    /* @__PURE__ */ jsxs(
                      "span",
                      {
                        className: cn(
                          "flex items-center gap-1.5 font-bold text-[12px]",
                          isDark ? "text-white" : "text-gray-900"
                        ),
                        children: [
                          /* @__PURE__ */ jsx(GripVertical, { className: "h-3 w-3 text-muted-foreground/60" }),
                          "News Overlay Settings"
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      "button",
                      {
                        onClick: () => setShowNewsConfigDialog(false),
                        className: "text-muted-foreground hover:text-foreground p-0.5",
                        children: /* @__PURE__ */ jsx(X, { className: "h-3.5 w-3.5" })
                      }
                    )
                  ]
                }
              ),
              /* @__PURE__ */ jsxs("div", { className: "p-3 space-y-3", children: [
                /* @__PURE__ */ jsxs("label", { className: "flex items-center justify-between cursor-pointer", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-[11px] font-medium", children: "Enable News Overlay" }),
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "checkbox",
                      checked: newsConfig.enabled,
                      onChange: (e) => setNewsConfig((c) => ({ ...c, enabled: e.target.checked })),
                      className: "h-3.5 w-3.5 rounded accent-red-500 cursor-pointer"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsx("span", { className: "text-[11px] font-medium", children: "Line Color" }),
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsx(
                      TradingViewColorPicker,
                      {
                        label: "News line color",
                        value: newsConfig.lineColor,
                        onChange: (lineColor) => setNewsConfig((c) => ({ ...c, lineColor }))
                      }
                    ),
                    /* @__PURE__ */ jsx("span", { className: "text-[9px] font-mono text-muted-foreground", children: newsConfig.lineColor })
                  ] })
                ] }),
                /* @__PURE__ */ jsx("div", { className: "border-t border-border/40" }),
                /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
                  /* @__PURE__ */ jsx(
                    "span",
                    {
                      className: cn(
                        "text-[10px] font-semibold uppercase tracking-wider",
                        isDark ? "text-muted-foreground" : "text-gray-500"
                      ),
                      children: "Time Filters"
                    }
                  ),
                  /* @__PURE__ */ jsxs("label", { className: "flex items-center justify-between cursor-pointer", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-[11px]", children: "Show Past Events" }),
                    /* @__PURE__ */ jsx(
                      "input",
                      {
                        type: "checkbox",
                        checked: newsConfig.showPast,
                        onChange: (e) => setNewsConfig((c) => ({ ...c, showPast: e.target.checked })),
                        className: "h-3.5 w-3.5 rounded accent-red-500 cursor-pointer"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("label", { className: "flex items-center justify-between cursor-pointer", children: [
                    /* @__PURE__ */ jsx("span", { className: "text-[11px]", children: "Show Future Events" }),
                    /* @__PURE__ */ jsx(
                      "input",
                      {
                        type: "checkbox",
                        checked: newsConfig.showFuture,
                        onChange: (e) => setNewsConfig((c) => ({ ...c, showFuture: e.target.checked })),
                        className: "h-3.5 w-3.5 rounded accent-red-500 cursor-pointer"
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsx("div", { className: "border-t border-border/40" }),
                /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
                  /* @__PURE__ */ jsx(
                    "span",
                    {
                      className: cn(
                        "text-[10px] font-semibold uppercase tracking-wider",
                        isDark ? "text-muted-foreground" : "text-gray-500"
                      ),
                      children: "Impact Levels"
                    }
                  ),
                  /* @__PURE__ */ jsxs("label", { className: "flex items-center justify-between cursor-pointer", children: [
                    /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1.5 text-[11px]", children: [
                      /* @__PURE__ */ jsx("span", { className: "inline-block w-2 h-2 rounded-full bg-red-500" }),
                      "High Impact"
                    ] }),
                    /* @__PURE__ */ jsx(
                      "input",
                      {
                        type: "checkbox",
                        checked: newsConfig.showHigh,
                        onChange: (e) => setNewsConfig((c) => ({ ...c, showHigh: e.target.checked })),
                        className: "h-3.5 w-3.5 rounded accent-red-500 cursor-pointer"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("label", { className: "flex items-center justify-between cursor-pointer", children: [
                    /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1.5 text-[11px]", children: [
                      /* @__PURE__ */ jsx("span", { className: "inline-block w-2 h-2 rounded-full bg-amber-500" }),
                      "Medium Impact"
                    ] }),
                    /* @__PURE__ */ jsx(
                      "input",
                      {
                        type: "checkbox",
                        checked: newsConfig.showMedium,
                        onChange: (e) => setNewsConfig((c) => ({ ...c, showMedium: e.target.checked })),
                        className: "h-3.5 w-3.5 rounded accent-amber-500 cursor-pointer"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("label", { className: "flex items-center justify-between cursor-pointer", children: [
                    /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1.5 text-[11px]", children: [
                      /* @__PURE__ */ jsx("span", { className: "inline-block w-2 h-2 rounded-full bg-gray-400" }),
                      "Low Impact"
                    ] }),
                    /* @__PURE__ */ jsx(
                      "input",
                      {
                        type: "checkbox",
                        checked: newsConfig.showLow,
                        onChange: (e) => setNewsConfig((c) => ({ ...c, showLow: e.target.checked })),
                        className: "h-3.5 w-3.5 rounded accent-gray-500 cursor-pointer"
                      }
                    )
                  ] })
                ] })
              ] })
            ]
          }
        )
      }
    )
  ] });
}
const TYPE_META = {
  trendline: { icon: TrendingUp, label: "Trendline" },
  horizontal: { icon: Minus, label: "Horizontal" },
  fibonacci: { icon: Layers, label: "Fibonacci" },
  rectangle: { icon: Square, label: "Rectangle" },
  position: { icon: TrendingUp, label: "Position" }
};
function RowIconButton({
  title,
  onClick,
  children
}) {
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      title,
      onClick: (e) => {
        e.stopPropagation();
        onClick();
      },
      className: "p-1 rounded hover:bg-secondary text-muted-foreground hover:text-foreground",
      children
    }
  );
}
function ObjectTreeRow({
  d,
  selected,
  pipDigits,
  currentTf,
  onSelect,
  onUpdate,
  onRemove,
  onReorder
}) {
  const meta = TYPE_META[d.type] ?? { icon: Minus, label: d.type };
  const Icon = meta.icon;
  const tfOnly = d.visibility === "tf" && d.createdTf !== currentTf;
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: cn(
        "group flex items-center gap-1.5 px-2 py-1 rounded text-xs",
        selected ? "bg-primary/15" : "hover:bg-secondary",
        (d.hidden || tfOnly) && "opacity-50"
      ),
      children: [
        /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            onClick: () => onSelect(d),
            className: "flex flex-1 min-w-0 items-center gap-1.5 text-left",
            children: [
              /* @__PURE__ */ jsx("span", { className: "h-2 w-2 rounded-full shrink-0", style: { backgroundColor: d.color } }),
              /* @__PURE__ */ jsx(Icon, { className: "h-3 w-3 shrink-0 text-muted-foreground" }),
              /* @__PURE__ */ jsxs("span", { className: "flex-1 truncate", children: [
                meta.label,
                " ",
                d.price.toFixed(pipDigits),
                tfOnly && /* @__PURE__ */ jsxs("span", { className: "ml-1 text-[9px] text-muted-foreground", children: [
                  "(",
                  d.createdTf,
                  ")"
                ] })
              ] })
            ]
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "hidden group-hover:flex items-center", children: [
          /* @__PURE__ */ jsx(RowIconButton, { title: "Bring to front", onClick: () => onReorder(d, "front"), children: /* @__PURE__ */ jsx(ArrowUpToLine, { className: "h-3 w-3" }) }),
          /* @__PURE__ */ jsx(RowIconButton, { title: "Send to back", onClick: () => onReorder(d, "back"), children: /* @__PURE__ */ jsx(ArrowDownToLine, { className: "h-3 w-3" }) })
        ] }),
        /* @__PURE__ */ jsx(
          RowIconButton,
          {
            title: d.hidden ? "Show" : "Hide",
            onClick: () => onUpdate({ ...d, hidden: !d.hidden }),
            children: d.hidden ? /* @__PURE__ */ jsx(EyeOff, { className: "h-3 w-3" }) : /* @__PURE__ */ jsx(Eye, { className: "h-3 w-3" })
          }
        ),
        /* @__PURE__ */ jsx(
          RowIconButton,
          {
            title: d.locked ? "Unlock" : "Lock",
            onClick: () => onUpdate({ ...d, locked: !d.locked }),
            children: d.locked ? /* @__PURE__ */ jsx(Lock, { className: "h-3 w-3" }) : /* @__PURE__ */ jsx(LockOpen, { className: "h-3 w-3" })
          }
        ),
        /* @__PURE__ */ jsx(RowIconButton, { title: "Delete", onClick: () => onRemove(d.id), children: /* @__PURE__ */ jsx(Trash2, { className: "h-3 w-3" }) })
      ]
    }
  );
}
function ObjectTreePanel({
  drawings,
  selectedIds,
  pipDigits,
  currentTf,
  onSelect,
  onUpdate,
  onRemove,
  onReorder,
  onClose
}) {
  return /* @__PURE__ */ jsxs("div", { className: "absolute top-2 right-2 bottom-10 z-20 w-60 flex flex-col rounded-lg bg-card border border-border shadow-xl", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-2.5 py-1.5 border-b border-border", children: [
      /* @__PURE__ */ jsxs("span", { className: "text-xs font-semibold", children: [
        "Objects (",
        drawings.length,
        ")"
      ] }),
      /* @__PURE__ */ jsx(
        "button",
        {
          type: "button",
          onClick: onClose,
          className: "p-1 rounded hover:bg-secondary text-muted-foreground",
          children: /* @__PURE__ */ jsx(X, { className: "h-3.5 w-3.5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex-1 overflow-y-auto p-1 space-y-0.5", children: drawings.length === 0 ? /* @__PURE__ */ jsx("div", { className: "px-2 py-6 text-center text-xs text-muted-foreground", children: "No drawings yet" }) : [...drawings].reverse().map((d) => /* @__PURE__ */ jsx(
      ObjectTreeRow,
      {
        d,
        selected: selectedIds.includes(d.id),
        pipDigits,
        currentTf,
        onSelect,
        onUpdate,
        onRemove,
        onReorder
      },
      d.id
    )) })
  ] });
}
function netExposure(positions, symbol) {
  let net = 0;
  for (const p of positions) {
    if (p.symbolName !== symbol) continue;
    net += p.side === "LONG" ? p.quantity : -p.quantity;
  }
  return net;
}
function dailyLossFloor(m, sb) {
  if (m.ddDailyMax == null) return void 0;
  const dailyStart = (m.equity ?? sb) - (m.dailyPnl ?? 0);
  return dailyStart - sb * (m.ddDailyMax / 100);
}
function maxDrawdownFloor(m, sb) {
  const total = m.ddTotalMax != null ? sb * (1 - m.ddTotalMax / 100) : void 0;
  const trailing = m.ddTrailingMax != null ? m.trailingDrawdownFloor ?? void 0 : void 0;
  if (total == null) return trailing;
  if (trailing == null) return total;
  return Math.max(total, trailing);
}
function computeEquityLevels(m) {
  const sb = m == null ? void 0 : m.startingBalance;
  if (!m || !sb || sb <= 0) return {};
  const target = m.profitTargetPercent != null && m.profitTargetPercent > 0 ? sb * (1 + m.profitTargetPercent / 100) : void 0;
  return {
    dailyLoss: dailyLossFloor(m, sb),
    maxDrawdown: maxDrawdownFloor(m, sb),
    profitTarget: target
  };
}
function projectToPrice(targetEquity, ctx) {
  return ctx.mid + (targetEquity - ctx.equityNow) / (ctx.netQty * ctx.contractSize);
}
function formatUsd(v) {
  return `$${Math.abs(v).toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
}
function buildLevel(key, label, color, targetEquity, ctx) {
  if (targetEquity == null) return null;
  const price = projectToPrice(targetEquity, ctx);
  if (!Number.isFinite(price) || price <= 0) return null;
  return { key, price, color, title: `${label} · ${formatUsd(targetEquity - ctx.equityNow)}` };
}
const LEVEL_COLORS = {
  dailyLoss: "#f59e0b",
  maxDrawdown: "#f6465d",
  profitTarget: "#0ecb81"
};
function buildLevels(eq, flags, ctx) {
  const out = [];
  const candidates = [
    flags.dailyLoss ? buildLevel("daily-loss", "Daily Loss Limit", LEVEL_COLORS.dailyLoss, eq.dailyLoss, ctx) : null,
    flags.maxDrawdown ? buildLevel("max-drawdown", "Max Drawdown", LEVEL_COLORS.maxDrawdown, eq.maxDrawdown, ctx) : null,
    flags.profitTarget ? buildLevel(
      "profit-target",
      "Profit Target",
      LEVEL_COLORS.profitTarget,
      eq.profitTarget,
      ctx
    ) : null
  ];
  for (const c of candidates) {
    if (c) out.push(c);
  }
  return out;
}
function syncLines(series, map, levels) {
  const wanted = new Set(levels.map((l) => l.key));
  for (const [key, line] of map) {
    if (wanted.has(key)) continue;
    try {
      series.removePriceLine(line);
    } catch {
    }
    map.delete(key);
  }
  for (const level of levels) {
    const existing = map.get(level.key);
    if (existing) {
      existing.applyOptions({ price: level.price, title: level.title });
      continue;
    }
    map.set(
      level.key,
      series.createPriceLine({
        price: level.price,
        color: level.color,
        lineWidth: 1,
        lineStyle: LineStyle.Dashed,
        axisLabelVisible: true,
        title: level.title
      })
    );
  }
}
function useChallengeLevels(opts) {
  const {
    accountId,
    selectedSymbol,
    positions,
    tick,
    contractSize,
    accountEquity,
    candleSeriesRef,
    flags,
    chartEpoch
  } = opts;
  const { data: metrics } = useAccountMetrics(flags.enabled ? accountId ?? null : null);
  const levels = useMemo(() => {
    if (!flags.enabled || !tick) return [];
    const netQty = netExposure(positions, selectedSymbol);
    if (netQty === 0) return [];
    const eq = computeEquityLevels(metrics);
    const ctx = {
      mid: (tick.bid + tick.ask) / 2,
      equityNow: accountEquity > 0 ? accountEquity : (metrics == null ? void 0 : metrics.equity) ?? 0,
      netQty,
      contractSize
    };
    if (ctx.equityNow <= 0) return [];
    return buildLevels(eq, flags, ctx);
  }, [flags, tick, positions, selectedSymbol, metrics, accountEquity, contractSize]);
  const linesRef = useRef(/* @__PURE__ */ new Map());
  useEffect(() => {
    linesRef.current = /* @__PURE__ */ new Map();
  }, [chartEpoch]);
  useEffect(() => {
    const series = candleSeriesRef.current;
    if (!series) return;
    syncLines(series, linesRef.current, levels);
  }, [levels, chartEpoch, candleSeriesRef]);
}
function validPeriod(period, min = 1) {
  if (period == null || !Number.isFinite(period)) return null;
  const floored = Math.floor(period);
  return floored >= min ? floored : null;
}
function sma(candles, period) {
  const result = [];
  const p = validPeriod(period);
  if (p === null || candles.length < p) return result;
  period = p;
  let sum = 0;
  for (let i = 0; i < period; i++) sum += candles[i].close;
  result.push({ time: candles[period - 1].time, value: sum / period });
  for (let i = period; i < candles.length; i++) {
    sum += candles[i].close - candles[i - period].close;
    result.push({ time: candles[i].time, value: sum / period });
  }
  return result;
}
function ema(candles, period) {
  const result = [];
  const p = validPeriod(period);
  if (p === null || candles.length < p) return result;
  period = p;
  const k = 2 / (period + 1);
  let sum = 0;
  for (let i = 0; i < period; i++) sum += candles[i].close;
  let prev = sum / period;
  result.push({ time: candles[period - 1].time, value: prev });
  for (let i = period; i < candles.length; i++) {
    prev = candles[i].close * k + prev * (1 - k);
    result.push({ time: candles[i].time, value: prev });
  }
  return result;
}
function rsiFrom(avgGain, avgLoss) {
  if (avgLoss === 0) return avgGain === 0 ? 50 : 100;
  return 100 - 100 / (1 + avgGain / avgLoss);
}
function rsi(candles, period = 14) {
  const result = [];
  const p = validPeriod(period);
  if (p === null || candles.length < p + 1) return result;
  period = p;
  let avgGain = 0;
  let avgLoss = 0;
  for (let i = 1; i <= period; i++) {
    const change = candles[i].close - candles[i - 1].close;
    if (change > 0) avgGain += change;
    else avgLoss += Math.abs(change);
  }
  avgGain /= period;
  avgLoss /= period;
  result.push({ time: candles[period].time, value: rsiFrom(avgGain, avgLoss) });
  for (let i = period + 1; i < candles.length; i++) {
    const change = candles[i].close - candles[i - 1].close;
    const gain = change > 0 ? change : 0;
    const loss = change < 0 ? Math.abs(change) : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
    result.push({ time: candles[i].time, value: rsiFrom(avgGain, avgLoss) });
  }
  return result;
}
function macd(candles, fastPeriod = 12, slowPeriod = 26, signalPeriod = 9) {
  const fast = validPeriod(fastPeriod);
  const slow = validPeriod(slowPeriod);
  const signalLen = validPeriod(signalPeriod);
  if (fast === null || slow === null || signalLen === null) {
    return { macd: [], signal: [], histogram: [] };
  }
  signalPeriod = signalLen;
  const fastEma = ema(candles, fast);
  const slowEma = ema(candles, slow);
  const slowTimes = new Map(slowEma.map((p) => [p.time, p.value]));
  const macdLine = [];
  for (const fp of fastEma) {
    const sv = slowTimes.get(fp.time);
    if (sv !== void 0) {
      macdLine.push({ time: fp.time, value: fp.value - sv });
    }
  }
  const signalLine = [];
  if (macdLine.length >= signalPeriod) {
    const k = 2 / (signalPeriod + 1);
    let sum = 0;
    for (let i = 0; i < signalPeriod; i++) sum += macdLine[i].value;
    let prev = sum / signalPeriod;
    signalLine.push({ time: macdLine[signalPeriod - 1].time, value: prev });
    for (let i = signalPeriod; i < macdLine.length; i++) {
      prev = macdLine[i].value * k + prev * (1 - k);
      signalLine.push({ time: macdLine[i].time, value: prev });
    }
  }
  const signalTimes = new Map(signalLine.map((p) => [p.time, p.value]));
  const histogram = [];
  for (const mp of macdLine) {
    const sv = signalTimes.get(mp.time);
    if (sv !== void 0) {
      histogram.push({ time: mp.time, value: mp.value - sv });
    }
  }
  return { macd: macdLine, signal: signalLine, histogram };
}
function bollingerBands(candles, period = 20, stdDevMultiplier = 2) {
  const upper = [];
  const middle = [];
  const lower = [];
  const p = validPeriod(period);
  if (p === null || candles.length < p) return { upper, middle, lower };
  period = p;
  for (let i = period - 1; i < candles.length; i++) {
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) sum += candles[j].close;
    const avg = sum / period;
    let variance = 0;
    for (let j = i - period + 1; j <= i; j++) {
      variance += (candles[j].close - avg) ** 2;
    }
    const stdDev = Math.sqrt(variance / period);
    const t = candles[i].time;
    middle.push({ time: t, value: avg });
    upper.push({ time: t, value: avg + stdDevMultiplier * stdDev });
    lower.push({ time: t, value: avg - stdDevMultiplier * stdDev });
  }
  return { upper, middle, lower };
}
function atr(candles, period = 14) {
  const result = [];
  const p = validPeriod(period);
  if (p === null || candles.length < p + 1) return result;
  period = p;
  const trs = [];
  for (let i = 1; i < candles.length; i++) {
    const tr = Math.max(
      candles[i].high - candles[i].low,
      Math.abs(candles[i].high - candles[i - 1].close),
      Math.abs(candles[i].low - candles[i - 1].close)
    );
    trs.push(tr);
  }
  let sum = 0;
  for (let i = 0; i < period; i++) sum += trs[i];
  let prev = sum / period;
  result.push({ time: candles[period].time, value: prev });
  for (let i = period; i < trs.length; i++) {
    prev = (prev * (period - 1) + trs[i]) / period;
    result.push({ time: candles[i + 1].time, value: prev });
  }
  return result;
}
function stochastic(candles, kPeriod = 14, dPeriod = 3) {
  const kLine = [];
  const kLen = validPeriod(kPeriod);
  const dLen = validPeriod(dPeriod);
  if (kLen === null || dLen === null || candles.length < kLen) return { k: [], d: [] };
  kPeriod = kLen;
  dPeriod = dLen;
  for (let i = kPeriod - 1; i < candles.length; i++) {
    let highest = -Infinity;
    let lowest = Infinity;
    for (let j = i - kPeriod + 1; j <= i; j++) {
      if (candles[j].high > highest) highest = candles[j].high;
      if (candles[j].low < lowest) lowest = candles[j].low;
    }
    const range = highest - lowest;
    const kVal = range === 0 ? 50 : (candles[i].close - lowest) / range * 100;
    kLine.push({ time: candles[i].time, value: kVal });
  }
  const dLine = [];
  if (kLine.length >= dPeriod) {
    let sum = 0;
    for (let i = 0; i < dPeriod; i++) sum += kLine[i].value;
    dLine.push({ time: kLine[dPeriod - 1].time, value: sum / dPeriod });
    for (let i = dPeriod; i < kLine.length; i++) {
      sum += kLine[i].value - kLine[i - dPeriod].value;
      dLine.push({ time: kLine[i].time, value: sum / dPeriod });
    }
  }
  return { k: kLine, d: dLine };
}
function vwap(candles) {
  const result = [];
  let cumVolPrice = 0;
  let cumVol = 0;
  for (const c of candles) {
    const typicalPrice = (c.high + c.low + c.close) / 3;
    const vol = Number.isFinite(c.volume) && (c.volume ?? 0) > 0 ? c.volume : 0;
    cumVolPrice += typicalPrice * vol;
    cumVol += vol;
    result.push({ time: c.time, value: cumVol > 0 ? cumVolPrice / cumVol : typicalPrice });
  }
  return result;
}
const INDICATOR_REGISTRY = [
  {
    type: "SMA",
    label: "Simple Moving Average",
    pane: "overlay",
    defaultParams: { period: 20 },
    color: "#f0b90b"
  },
  {
    type: "EMA",
    label: "Exponential Moving Average",
    pane: "overlay",
    defaultParams: { period: 20 },
    color: "#e377c2"
  },
  {
    type: "RSI",
    label: "Relative Strength Index",
    pane: "below",
    defaultParams: { period: 14 },
    color: "#8884d8"
  },
  {
    type: "MACD",
    label: "MACD",
    pane: "below",
    defaultParams: { fast: 12, slow: 26, signal: 9 },
    color: "#2196f3"
  },
  {
    type: "BOLL",
    label: "Bollinger Bands",
    pane: "overlay",
    defaultParams: { period: 20, stdDev: 2 },
    color: "#26a69a"
  },
  {
    type: "ATR",
    label: "Average True Range",
    pane: "below",
    defaultParams: { period: 14 },
    color: "#ff7043"
  },
  {
    type: "STOCH",
    label: "Stochastic Oscillator",
    pane: "below",
    defaultParams: { kPeriod: 14, dPeriod: 3 },
    color: "#ab47bc"
  },
  {
    type: "VWAP",
    label: "Volume Weighted Avg Price",
    pane: "overlay",
    defaultParams: {},
    color: "#42a5f5"
  }
];
function useIndicators(chartRef, candleSeriesRef, chartData, activeIndicators, isDark) {
  const indicatorSeriesRef = useRef(
    /* @__PURE__ */ new Map()
  );
  const colors = isDark ? CHART_COLORS.dark : CHART_COLORS.light;
  useEffect(() => {
    if (!chartRef.current || !candleSeriesRef.current || chartData.length === 0) return;
    const chart = chartRef.current;
    const indCandles = toIndicatorCandles(chartData);
    for (const [_key, series] of indicatorSeriesRef.current) {
      try {
        chart.removeSeries(series);
      } catch {
      }
    }
    indicatorSeriesRef.current.clear();
    for (const type of activeIndicators) {
      const config = INDICATOR_REGISTRY.find((r) => r.type === type);
      if (!config) continue;
      switch (type) {
        case "SMA": {
          const data = sma(indCandles, config.defaultParams.period);
          const s = chart.addLineSeries({
            color: config.color,
            lineWidth: 1,
            priceScaleId: "right"
          });
          s.setData(data.map((p) => ({ time: p.time, value: p.value })));
          indicatorSeriesRef.current.set("SMA", s);
          break;
        }
        case "EMA": {
          const data = ema(indCandles, config.defaultParams.period);
          const s = chart.addLineSeries({
            color: config.color,
            lineWidth: 1,
            priceScaleId: "right"
          });
          s.setData(data.map((p) => ({ time: p.time, value: p.value })));
          indicatorSeriesRef.current.set("EMA", s);
          break;
        }
        case "RSI": {
          const data = rsi(indCandles, config.defaultParams.period);
          const s = chart.addLineSeries({ color: config.color, lineWidth: 1, priceScaleId: "rsi" });
          s.setData(data.map((p) => ({ time: p.time, value: p.value })));
          indicatorSeriesRef.current.set("RSI", s);
          const refHigh = chart.addLineSeries({
            color: "#555",
            lineWidth: 1,
            lineStyle: LineStyle.Dashed,
            priceScaleId: "rsi"
          });
          refHigh.setData(data.map((p) => ({ time: p.time, value: 70 })));
          indicatorSeriesRef.current.set("RSI-70", refHigh);
          const refLow = chart.addLineSeries({
            color: "#555",
            lineWidth: 1,
            lineStyle: LineStyle.Dashed,
            priceScaleId: "rsi"
          });
          refLow.setData(data.map((p) => ({ time: p.time, value: 30 })));
          indicatorSeriesRef.current.set("RSI-30", refLow);
          break;
        }
        case "MACD": {
          const data = macd(
            indCandles,
            config.defaultParams.fast,
            config.defaultParams.slow,
            config.defaultParams.signal
          );
          const mLine = chart.addLineSeries({
            color: "#2196f3",
            lineWidth: 1,
            priceScaleId: "macd"
          });
          mLine.setData(data.macd.map((p) => ({ time: p.time, value: p.value })));
          indicatorSeriesRef.current.set("MACD-line", mLine);
          const sLine = chart.addLineSeries({
            color: "#ff9800",
            lineWidth: 1,
            priceScaleId: "macd"
          });
          sLine.setData(data.signal.map((p) => ({ time: p.time, value: p.value })));
          indicatorSeriesRef.current.set("MACD-signal", sLine);
          const histo = chart.addHistogramSeries({ priceScaleId: "macd" });
          histo.setData(
            data.histogram.map((p) => ({
              time: p.time,
              value: p.value,
              color: p.value >= 0 ? colors.up + "99" : colors.down + "99"
            }))
          );
          indicatorSeriesRef.current.set("MACD-hist", histo);
          break;
        }
        case "BOLL": {
          const data = bollingerBands(
            indCandles,
            config.defaultParams.period,
            config.defaultParams.stdDev
          );
          const upper = chart.addLineSeries({
            color: config.color + "80",
            lineWidth: 1,
            priceScaleId: "right"
          });
          upper.setData(data.upper.map((p) => ({ time: p.time, value: p.value })));
          indicatorSeriesRef.current.set("BOLL-upper", upper);
          const mid = chart.addLineSeries({
            color: config.color,
            lineWidth: 1,
            priceScaleId: "right"
          });
          mid.setData(data.middle.map((p) => ({ time: p.time, value: p.value })));
          indicatorSeriesRef.current.set("BOLL-mid", mid);
          const lower = chart.addLineSeries({
            color: config.color + "80",
            lineWidth: 1,
            priceScaleId: "right"
          });
          lower.setData(data.lower.map((p) => ({ time: p.time, value: p.value })));
          indicatorSeriesRef.current.set("BOLL-lower", lower);
          break;
        }
        case "ATR": {
          const data = atr(indCandles, config.defaultParams.period);
          const s = chart.addLineSeries({ color: config.color, lineWidth: 1, priceScaleId: "atr" });
          s.setData(data.map((p) => ({ time: p.time, value: p.value })));
          indicatorSeriesRef.current.set("ATR", s);
          break;
        }
        case "STOCH": {
          const data = stochastic(
            indCandles,
            config.defaultParams.kPeriod,
            config.defaultParams.dPeriod
          );
          const kLine = chart.addLineSeries({
            color: "#ab47bc",
            lineWidth: 1,
            priceScaleId: "stoch"
          });
          kLine.setData(data.k.map((p) => ({ time: p.time, value: p.value })));
          indicatorSeriesRef.current.set("STOCH-K", kLine);
          const dLine = chart.addLineSeries({
            color: "#ff7043",
            lineWidth: 1,
            priceScaleId: "stoch"
          });
          dLine.setData(data.d.map((p) => ({ time: p.time, value: p.value })));
          indicatorSeriesRef.current.set("STOCH-D", dLine);
          break;
        }
        case "VWAP": {
          const data = vwap(indCandles);
          const s = chart.addLineSeries({
            color: config.color,
            lineWidth: 2,
            lineStyle: LineStyle.Dashed,
            priceScaleId: "right"
          });
          s.setData(data.map((p) => ({ time: p.time, value: p.value })));
          indicatorSeriesRef.current.set("VWAP", s);
          break;
        }
      }
    }
  }, [activeIndicators, chartData, isDark]);
}
function useNewsOverlay(containerRef, chartRef, selectedSymbol, isDark, chartData) {
  const [newsConfig, setNewsConfig] = useState(() => {
    const saved = safeStorage.getItem("newsOverlayConfig");
    if (saved)
      try {
        return JSON.parse(saved);
      } catch {
      }
    return {
      enabled: true,
      lineColor: "#ef4444",
      showPast: true,
      showFuture: true,
      showHigh: true,
      showMedium: false,
      showLow: false
    };
  });
  const [showNewsConfigDialog, setShowNewsConfigDialog] = useState(false);
  const [newsPopup, setNewsPopup] = useState(null);
  const newsMarkersRef = useRef([]);
  useEffect(() => {
    safeStorage.setItem("newsOverlayConfig", JSON.stringify(newsConfig));
  }, [newsConfig]);
  const [nowMs, setNowMs] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 6e4);
    return () => clearInterval(id);
  }, []);
  const symbolCurrencies = useMemo(() => extractCurrencies(selectedSymbol), [selectedSymbol]);
  const { data: rawCalendarData } = useEconomicCalendar(symbolCurrencies);
  const calendarEvents = useMemo(() => {
    if (!newsConfig.enabled) return [];
    const now = nowMs;
    return (rawCalendarData || []).filter((e) => {
      if (e.impact === "high" && !newsConfig.showHigh) return false;
      if (e.impact === "medium" && !newsConfig.showMedium) return false;
      if (e.impact === "low" && !newsConfig.showLow) return false;
      const eventTime = new Date(e.time).getTime();
      if (eventTime < now && !newsConfig.showPast) return false;
      if (eventTime > now && !newsConfig.showFuture) return false;
      return true;
    });
  }, [rawCalendarData, newsConfig, nowMs]);
  useEffect(() => {
    const container = containerRef.current;
    const chart = chartRef.current;
    if (!container || !chart || !newsConfig.enabled || calendarEvents.length === 0) {
      newsMarkersRef.current.forEach((el) => el.remove());
      newsMarkersRef.current = [];
      return;
    }
    newsMarkersRef.current.forEach((el) => el.remove());
    newsMarkersRef.current = [];
    const timeScale = chart.timeScale();
    const lineColor = newsConfig.lineColor || "#ef4444";
    const hexToRgba2 = (hex, alpha2) => {
      const r = parseInt(hex.slice(1, 3), 16);
      const g = parseInt(hex.slice(3, 5), 16);
      const b = parseInt(hex.slice(5, 7), 16);
      return `rgba(${r},${g},${b},${alpha2})`;
    };
    const impactColor = (impact) => {
      if (impact === "high") return lineColor;
      if (impact === "medium") return "#f59e0b";
      return "#6b7280";
    };
    const renderMarkers = () => {
      newsMarkersRef.current.forEach((el) => el.remove());
      newsMarkersRef.current = [];
      const containerRect = container.getBoundingClientRect();
      for (const ev of calendarEvents) {
        const eventTimeSec = Math.floor(new Date(ev.time).getTime() / 1e3);
        const x = timeScale.timeToCoordinate(
          eventTimeSec
        );
        if (x === null || x < 0 || x > containerRect.width) continue;
        const color = impactColor(ev.impact);
        const line = document.createElement("div");
        line.style.position = "absolute";
        line.style.left = `${x}px`;
        line.style.top = "0";
        line.style.bottom = "28px";
        line.style.width = "1px";
        line.style.backgroundImage = `repeating-linear-gradient(to bottom, ${hexToRgba2(color, 0.5)} 0px, ${hexToRgba2(color, 0.5)} 4px, transparent 4px, transparent 8px)`;
        line.style.pointerEvents = "none";
        line.style.zIndex = "5";
        container.appendChild(line);
        newsMarkersRef.current.push(line);
        const flag = document.createElement("div");
        flag.style.position = "absolute";
        flag.style.left = `${x - 10}px`;
        flag.style.bottom = "30px";
        flag.style.width = "20px";
        flag.style.height = "20px";
        flag.style.borderRadius = "50%";
        flag.style.display = "flex";
        flag.style.alignItems = "center";
        flag.style.justifyContent = "center";
        flag.style.fontSize = "11px";
        flag.style.fontWeight = "700";
        flag.style.cursor = "pointer";
        flag.style.zIndex = "6";
        flag.style.transition = "transform 0.15s ease, box-shadow 0.15s ease";
        flag.style.border = "2px solid";
        flag.style.backgroundColor = hexToRgba2(color, 0.2);
        flag.style.borderColor = hexToRgba2(color, 0.7);
        flag.style.color = color;
        flag.textContent = ev.currency.slice(0, 2);
        flag.title = `${ev.event} (${ev.currency})`;
        flag.addEventListener("mouseenter", () => {
          flag.style.transform = "scale(1.2)";
          flag.style.boxShadow = `0 0 8px ${hexToRgba2(color, 0.4)}`;
        });
        flag.addEventListener("mouseleave", () => {
          flag.style.transform = "scale(1)";
          flag.style.boxShadow = "none";
        });
        flag.addEventListener("click", (e) => {
          e.stopPropagation();
          const rect = flag.getBoundingClientRect();
          const containerPos = container.getBoundingClientRect();
          setNewsPopup({
            event: ev,
            x: rect.left - containerPos.left + rect.width / 2,
            y: rect.top - containerPos.top - 8
          });
        });
        container.appendChild(flag);
        newsMarkersRef.current.push(flag);
      }
    };
    renderMarkers();
    const onVisibleRangeChange = () => renderMarkers();
    timeScale.subscribeVisibleLogicalRangeChange(onVisibleRangeChange);
    const resizeObserver = new ResizeObserver(() => renderMarkers());
    resizeObserver.observe(container);
    return () => {
      timeScale.unsubscribeVisibleLogicalRangeChange(onVisibleRangeChange);
      resizeObserver.disconnect();
      newsMarkersRef.current.forEach((el) => el.remove());
      newsMarkersRef.current = [];
    };
  }, [calendarEvents, newsConfig, isDark, chartData]);
  useEffect(() => {
    if (!newsPopup) return;
    const handleClick = () => setNewsPopup(null);
    window.addEventListener("click", handleClick);
    return () => window.removeEventListener("click", handleClick);
  }, [newsPopup]);
  return {
    newsConfig,
    setNewsConfig,
    showNewsConfigDialog,
    setShowNewsConfigDialog,
    newsPopup,
    setNewsPopup
  };
}
function useSlTpDrag(containerRef, chartRef, candleSeriesRef, slTpLinesRef, drawingTool, onModifyPosition, pipDigits, symbolInfo, chartEpoch) {
  const dragRef = useRef(null);
  const [dragPrice, setDragPrice] = useState(null);
  const onModifyPositionRef = useRef(onModifyPosition);
  const pipDigitsRef = useRef(pipDigits);
  const symbolInfoRef = useRef(symbolInfo);
  useEffect(() => {
    onModifyPositionRef.current = onModifyPosition;
    pipDigitsRef.current = pipDigits;
    symbolInfoRef.current = symbolInfo;
  }, [onModifyPosition, pipDigits, symbolInfo]);
  useEffect(() => {
    const container = containerRef.current;
    const chart = chartRef.current;
    const series = candleSeriesRef.current;
    if (!container || !chart || !series) return;
    const SNAP_PX = 8;
    const yToPrice = (clientY) => {
      const rect = container.getBoundingClientRect();
      const y = clientY - rect.top;
      const price = series.coordinateToPrice(y);
      return typeof price === "number" && isFinite(price) ? price : null;
    };
    const findNearestLine = (clientY) => {
      const rect = container.getBoundingClientRect();
      const mouseY = clientY - rect.top;
      let closest = null;
      for (const [key, entry] of slTpLinesRef.current) {
        const lineY = series.priceToCoordinate(entry.price);
        if (lineY === null || lineY === void 0) continue;
        const dist2 = Math.abs(mouseY - lineY);
        if (dist2 <= SNAP_PX && (!closest || dist2 < closest.dist)) {
          closest = { key, entry, dist: dist2 };
        }
      }
      return closest;
    };
    const handleMouseDown = (e) => {
      if (e.button !== 0 || drawingTool !== "none") return;
      const nearest = findNearestLine(e.clientY);
      if (!nearest) return;
      e.preventDefault();
      e.stopPropagation();
      dragRef.current = {
        active: true,
        positionId: nearest.entry.positionId,
        field: nearest.entry.field,
        priceLine: nearest.entry.line,
        startPrice: nearest.entry.price,
        entryPrice: nearest.entry.entryPrice,
        quantity: nearest.entry.quantity,
        side: nearest.entry.side
      };
      chart.applyOptions({
        handleScroll: {
          mouseWheel: true,
          pressedMouseMove: false,
          horzTouchDrag: false,
          vertTouchDrag: false
        }
      });
      container.style.cursor = "grabbing";
    };
    const handleMouseMove = (e) => {
      var _a;
      const drag = dragRef.current;
      if (drag == null ? void 0 : drag.active) {
        const price = yToPrice(e.clientY);
        if (price !== null) {
          const rounded = parseFloat(price.toFixed(pipDigitsRef.current));
          drag.priceLine.applyOptions({ price: rounded });
          const cSize = ((_a = symbolInfoRef.current) == null ? void 0 : _a.contractSize) || 1e5;
          const dir = drag.side === "LONG" ? 1 : -1;
          const pnlUsd = parseFloat(
            ((rounded - drag.entryPrice) * dir * drag.quantity * cSize).toFixed(2)
          );
          const label = drag.field === "takeProfit" ? "TP" : "SL";
          const sign = pnlUsd >= 0 ? "+" : "";
          drag.priceLine.applyOptions({
            title: `${label}  ${sign}$${pnlUsd.toFixed(2)}`
          });
          const rect = container.getBoundingClientRect();
          setDragPrice({
            price: rounded,
            y: e.clientY - rect.top,
            field: drag.field === "takeProfit" ? "TP" : "SL",
            pnlUsd
          });
        }
        return;
      }
      const nearest = findNearestLine(e.clientY);
      if (nearest && drawingTool === "none") {
        container.style.cursor = "grab";
      } else if (!(drag == null ? void 0 : drag.active) && drawingTool === "none") {
        container.style.cursor = "default";
      }
    };
    const handleMouseUp = (e) => {
      const drag = dragRef.current;
      if (!(drag == null ? void 0 : drag.active)) return;
      const newPrice = yToPrice(e.clientY);
      dragRef.current = null;
      setDragPrice(null);
      chart.applyOptions({
        handleScroll: {
          mouseWheel: true,
          pressedMouseMove: true,
          horzTouchDrag: true,
          vertTouchDrag: true
        }
      });
      container.style.cursor = "default";
      if (newPrice === null) return;
      const rounded = parseFloat(newPrice.toFixed(pipDigitsRef.current));
      if (Math.abs(rounded - drag.startPrice) < Math.pow(10, -pipDigitsRef.current)) return;
      if (onModifyPositionRef.current) {
        onModifyPositionRef.current(drag.positionId, {
          [drag.field]: rounded
        });
      }
    };
    container.addEventListener("mousedown", handleMouseDown, true);
    container.addEventListener("mousemove", handleMouseMove);
    container.addEventListener("mouseup", handleMouseUp);
    window.addEventListener("mouseup", handleMouseUp);
    return () => {
      container.removeEventListener("mousedown", handleMouseDown, true);
      container.removeEventListener("mousemove", handleMouseMove);
      container.removeEventListener("mouseup", handleMouseUp);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [drawingTool, chartEpoch]);
  return dragPrice;
}
const TRADINGVIEW_FONT_FAMILY = `-apple-system, BlinkMacSystemFont, "Trebuchet MS", Roboto, Ubuntu, sans-serif`;
function requestGapRefetch(refAtRef, qc, symbol, timeframe) {
  const now = Date.now();
  if (now - refAtRef.current <= 3e3) return;
  refAtRef.current = now;
  qc.invalidateQueries({ queryKey: queryKeys.market.candles(symbol, timeframe) });
}
const LOAD_MORE_THRESHOLD = 20;
const LOAD_MORE_WINDOW = 500;
const MAX_EMPTY_WINDOWS = 4;
function getSeriesOldestMs(series) {
  const data = series.data();
  return data.length === 0 ? 0 : data[0].time * 1e3;
}
function isLoadMoreEligible(state, series, range) {
  if (state.loading || state.noMoreData) return false;
  const barsInfo = series.barsInLogicalRange(range);
  if (((barsInfo == null ? void 0 : barsInfo.barsBefore) ?? Number.POSITIVE_INFINITY) > LOAD_MORE_THRESHOLD) return false;
  if (state.fetchFromMs > 0) return true;
  const oldestMs = getSeriesOldestMs(series);
  if (oldestMs === 0) return false;
  return state.lastFetchedBeforeMs === 0 || oldestMs < state.lastFetchedBeforeMs;
}
function fetchOlderRange(symbol, timeframe, toMs, state, onLoaded) {
  const windowMs = LOAD_MORE_WINDOW * (TF_INTERVAL_MS[timeframe] ?? 6e4);
  api.getCandles(symbol, timeframe, void 0, { fromMs: toMs - windowMs, toMs }).then((bars) => {
    if (bars.length === 0) {
      state.emptyWindows += 1;
      const nextToMs = toMs - windowMs;
      if (nextToMs > 0 && state.emptyWindows < MAX_EMPTY_WINDOWS) {
        state.fetchFromMs = nextToMs;
      } else {
        state.noMoreData = true;
      }
    } else {
      state.emptyWindows = 0;
      onLoaded(bars);
    }
  }).catch(() => {
    state.lastFetchedBeforeMs = 0;
  }).finally(() => {
    state.loading = false;
  });
}
function makeHistoryLoader(symbol, timeframeRef, seriesRef, stateRef, onLoaded) {
  return (range) => {
    const series = seriesRef.current;
    if (!range || !series) return;
    const state = stateRef.current;
    if (!isLoadMoreEligible(state, series, range)) return;
    const toMs = state.fetchFromMs > 0 ? state.fetchFromMs : getSeriesOldestMs(series);
    if (toMs === 0) return;
    state.loading = true;
    state.lastFetchedBeforeMs = toMs;
    state.fetchFromMs = 0;
    fetchOlderRange(symbol, timeframeRef.current, toMs, state, onLoaded);
  };
}
function getForexSessionColor(utcHour) {
  if (utcHour >= 22 || utcHour < 8) return "rgba(255,200,50,0.04)";
  if (utcHour >= 8 && utcHour < 16) return "rgba(50,200,255,0.04)";
  if (utcHour >= 13) return "rgba(255,80,80,0.04)";
  return "transparent";
}
const forexSessionHighlighter = (date) => getForexSessionColor(new Date(date * 1e3).getUTCHours());
const EQUITY_CATEGORY = /stock|equit|share|etf|index|indices/i;
function buildSessionBreaks(ctx) {
  const intervalMs = TF_INTERVAL_MS[ctx.timeframe] ?? 6e4;
  if (intervalMs >= 864e5) return null;
  return new SessionBreaks({
    color: ctx.isDark ? "rgba(130, 150, 190, 0.5)" : "rgba(90, 110, 150, 0.45)",
    sessionStart: EQUITY_CATEGORY.test(ctx.symbolCategory ?? "") ? "ny-0930" : "utc-midnight"
  });
}
const PLUGIN_FACTORIES = {
  crosshair: ({ isDark }) => new CrosshairHighlightPrimitive({
    color: isDark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.05)"
  }),
  session: () => new SessionHighlighting(forexSessionHighlighter),
  "session-breaks": buildSessionBreaks,
  bands: () => new BandsIndicator(),
  tooltip: () => new TooltipPrimitive({}),
  "delta-tooltip": () => new DeltaTooltipPrimitive({})
};
function buildPlugin(id, ctx) {
  var _a;
  return ((_a = PLUGIN_FACTORIES[id]) == null ? void 0 : _a.call(PLUGIN_FACTORIES, ctx)) ?? null;
}
function chartOptionsForPanel(prefs, colors, timeframe, selectedSymbol) {
  var _a, _b, _c, _d;
  const settings = buildChartSettingsOptions(prefs, colors, timeframe);
  return {
    ...settings,
    layout: {
      ...settings.layout,
      fontFamily: TRADINGVIEW_FONT_FAMILY
    },
    grid: {
      vertLines: { style: LineStyle.Dotted, ...(_a = settings.grid) == null ? void 0 : _a.vertLines },
      horzLines: { style: LineStyle.Dotted, ...(_b = settings.grid) == null ? void 0 : _b.horzLines }
    },
    crosshair: {
      mode: CrosshairMode.Normal,
      ...settings.crosshair,
      vertLine: {
        width: 1,
        labelBackgroundColor: "#363a45",
        labelVisible: true,
        ...(_c = settings.crosshair) == null ? void 0 : _c.vertLine
      },
      horzLine: {
        width: 1,
        labelBackgroundColor: "#363a45",
        labelVisible: true,
        ...(_d = settings.crosshair) == null ? void 0 : _d.horzLine
      }
    },
    leftPriceScale: {
      minimumWidth: 80,
      autoScale: true,
      alignLabels: true,
      entireTextOnly: false,
      ticksVisible: true,
      ...settings.leftPriceScale
    },
    rightPriceScale: {
      minimumWidth: 80,
      autoScale: true,
      alignLabels: true,
      entireTextOnly: false,
      ticksVisible: true,
      ...settings.rightPriceScale
    },
    timeScale: {
      borderColor: colors.grid,
      timeVisible: true,
      minBarSpacing: 0.5,
      fixLeftEdge: false,
      fixRightEdge: false,
      borderVisible: true,
      ...settings.timeScale
    },
    watermark: {
      fontSize: 56,
      color: colors.watermark,
      horzAlign: "center",
      vertAlign: "center",
      ...settings.watermark,
      text: prefs.watermarkMode === "symbol-timeframe" ? `${selectedSymbol} · ${timeframe}` : selectedSymbol
    },
    handleScroll: prefs.enableChartScroll ? {
      mouseWheel: true,
      pressedMouseMove: true,
      horzTouchDrag: true,
      vertTouchDrag: true
    } : false,
    handleScale: prefs.enableChartScale ? {
      mouseWheel: true,
      pinch: true,
      axisPressedMouseMove: { time: true, price: true },
      axisDoubleClickReset: { time: true, price: true }
    } : false
  };
}
function candleToLegend(c, volume) {
  const change = c.open ? (c.close - c.open) / c.open * 100 : 0;
  return { o: c.open, h: c.high, l: c.low, c: c.close, v: volume, change, color: c.color };
}
function withPreviousCloseColors(bar, previousClose, ctx) {
  const bullish = ctx.colorBarsByPreviousClose ? bar.close >= (previousClose ?? bar.open) : bar.close >= bar.open;
  return {
    ...bar,
    color: bullish ? ctx.candleColors.bullBody : ctx.candleColors.bearBody,
    borderColor: bullish ? ctx.candleColors.bullBorder : ctx.candleColors.bearBorder,
    wickColor: bullish ? ctx.candleColors.bullWick : ctx.candleColors.bearWick
  };
}
function intervalSecOf(tf) {
  return (TF_INTERVAL_MS[tf] ?? 6e4) / 1e3;
}
function paintServerVolume(live, barTime, ctx) {
  if (!ctx.volume || live.volume == null) return;
  ctx.legendVol.current = live.volume;
  try {
    ctx.volume.update({
      time: barTime,
      value: live.volume,
      color: live.close >= live.open ? ctx.colors.volumeUp : ctx.colors.volumeDown
    });
  } catch {
  }
}
function applyServerCandle(live, ctx) {
  const ts = toUnixSeconds(live.timestamp);
  if (Number.isNaN(ts) || ts <= 0 || !ctx.lastCandle.current) return;
  const previous = ctx.lastCandle.current;
  if (ts - previous.time > intervalSecOf(ctx.timeframe) * 1.5) {
    requestGapRefetch(ctx.gapAt, ctx.qc, ctx.symbol, ctx.timeframe);
  }
  if (ts > previous.time) ctx.previousClose.current = previous.close;
  const comparisonClose = ts === previous.time ? ctx.previousClose.current : previous.close;
  const bar = withPreviousCloseColors({
    time: ts,
    open: live.open,
    high: live.high,
    low: live.low,
    close: live.close
  }, comparisonClose, ctx);
  ctx.lastCandle.current = bar;
  ctx.liveCandleTs.current = toUnixMs(live.timestamp);
  try {
    ctx.series.update(bar);
  } catch {
  }
  paintServerVolume(live, ts, ctx);
  ctx.setLegend(candleToLegend(bar, live.volume || 0));
}
function buildTickBar(prev, isContinuation, bucketTime, mid, ctx) {
  if (isContinuation) {
    return {
      time: bucketTime,
      open: prev.open,
      high: Math.max(prev.high, mid),
      low: Math.min(prev.low, mid),
      close: mid
    };
  }
  if (bucketTime <= prev.time) return null;
  if (bucketTime - prev.time > intervalSecOf(ctx.timeframe) * 1.5) {
    requestGapRefetch(ctx.gapAt, ctx.qc, ctx.symbol, ctx.timeframe);
  }
  const seedOpen = prev.close;
  return {
    time: bucketTime,
    open: seedOpen,
    high: Math.max(seedOpen, mid),
    low: Math.min(seedOpen, mid),
    close: mid
  };
}
function paintTickVolume(bar, isContinuation, bucketTime, ctx) {
  if (!ctx.volume) return;
  if (!isContinuation) ctx.legendVol.current = 0;
  try {
    ctx.volume.update({
      time: bucketTime,
      value: ctx.legendVol.current,
      color: bar.close >= bar.open ? ctx.colors.volumeUp : ctx.colors.volumeDown
    });
  } catch {
  }
}
function applyTick(tick, ctx) {
  if (!tick.timestamp) return;
  const tickMs = toUnixMs(tick.timestamp);
  if (ctx.liveCandleTs.current && tickMs <= ctx.liveCandleTs.current) return;
  const prev = ctx.lastCandle.current;
  if (!prev) return;
  const mid = (tick.bid + tick.ask) / 2;
  const bucketTime = getCandleBucketTime(tickMs, ctx.timeframe);
  const isContinuation = prev.time === bucketTime;
  const rawBar = buildTickBar(prev, isContinuation, bucketTime, mid, ctx);
  if (!rawBar) return;
  if (!isContinuation) ctx.previousClose.current = prev.close;
  const bar = withPreviousCloseColors(rawBar, ctx.previousClose.current, ctx);
  ctx.lastCandle.current = bar;
  try {
    ctx.series.update(bar);
  } catch {
  }
  paintTickVolume(bar, isContinuation, bucketTime, ctx);
  ctx.setLegend((prevLegend) => ({
    ...candleToLegend(bar, 0),
    v: isContinuation ? (prevLegend == null ? void 0 : prevLegend.v) ?? 0 : 0
  }));
}
function removePriceLineSafe(ref, series) {
  if (!ref.current) return;
  try {
    series.removePriceLine(ref.current);
  } catch {
  }
  ref.current = null;
}
function upsertPriceLine(ref, series, enabled, opts) {
  if (!enabled) {
    removePriceLineSafe(ref, series);
    return;
  }
  if (ref.current) {
    try {
      ref.current.applyOptions(opts);
      return;
    } catch {
      ref.current = null;
    }
  }
  ref.current = series.createPriceLine(opts);
}
function applyBidAskLines(tick, prefs, ctx) {
  const series = ctx.series;
  if (!tick) {
    removePriceLineSafe(ctx.bidLine, series);
    removePriceLineSafe(ctx.askLine, series);
    removePriceLineSafe(ctx.midLine, series);
    return;
  }
  upsertPriceLine(ctx.bidLine, series, prefs.showBidLine, {
    price: tick.bid,
    color: ctx.colors.bidLine,
    lineWidth: 2,
    lineStyle: LineStyle.Dashed,
    axisLabelVisible: true,
    title: "Bid",
    axisLabelColor: ctx.colors.bidLabelBg,
    axisLabelTextColor: "#ffffff"
  });
  upsertPriceLine(ctx.askLine, series, prefs.showAskLine, {
    price: tick.ask,
    color: ctx.colors.askLine,
    lineWidth: 2,
    lineStyle: LineStyle.Dashed,
    axisLabelVisible: true,
    title: "Ask",
    axisLabelColor: ctx.colors.askLabelBg,
    axisLabelTextColor: "#ffffff"
  });
  upsertPriceLine(ctx.midLine, series, !prefs.showBidLine && !prefs.showAskLine, {
    price: (tick.bid + tick.ask) / 2,
    color: "#7aa2ff99",
    lineWidth: 1,
    lineStyle: LineStyle.Dashed,
    axisLabelVisible: true,
    title: "",
    axisLabelColor: "#3b5ab5",
    axisLabelTextColor: "#ffffff"
  });
}
function detachPlugins(series, list) {
  for (const p of list) {
    try {
      series.detachPrimitive(p);
    } catch {
    }
  }
}
function attachPlugins(series, ids, ctx, list) {
  for (const id of ids) {
    const p = buildPlugin(id, ctx);
    if (p) {
      try {
        series.attachPrimitive(p);
        list.push(p);
      } catch {
      }
    }
  }
}
function liveBarFrom(live) {
  const ts = toUnixSeconds(live.timestamp);
  if (Number.isNaN(ts) || ts <= 0) return null;
  return { time: ts, open: live.open, high: live.high, low: live.low, close: live.close };
}
function legendFromSeries(chartData, volumeData) {
  var _a;
  const last = chartData[chartData.length - 1];
  if (!last) return null;
  const vol = volumeData.length > 0 ? ((_a = volumeData[volumeData.length - 1]) == null ? void 0 : _a.value) ?? 0 : 0;
  return candleToLegend(last, vol);
}
function scrollOrFit(chart, barCount) {
  const ts = chart == null ? void 0 : chart.timeScale();
  if (!ts) return;
  if (barCount > 150) ts.scrollToPosition(8, false);
  else ts.fitContent();
}
function reapplyLive(live, ctx) {
  if (!live) return;
  const rawBar = liveBarFrom(live);
  if (!rawBar) return;
  const current2 = ctx.lastCandle.current;
  if (current2 && rawBar.time > current2.time) {
    ctx.previousClose.current = current2.close;
  }
  const bar = withPreviousCloseColors(rawBar, ctx.previousClose.current, ctx);
  try {
    ctx.series.update(bar);
  } catch {
  }
  ctx.lastCandle.current = bar;
  ctx.setLegend(candleToLegend(bar, live.volume || 0));
}
function replayBufferedLive(buffered, chartData, ctx) {
  var _a, _b, _c;
  if (!buffered) return;
  const liveTs = toUnixSeconds(buffered.timestamp);
  const lastHistBarSec = ((_a = chartData[chartData.length - 1]) == null ? void 0 : _a.time) ?? 0;
  if (Number.isNaN(liveTs) || liveTs <= 0 || liveTs < lastHistBarSec) return;
  const liveBar = liveBarFrom(buffered);
  if (!liveBar) return;
  const isSameBar = liveTs === lastHistBarSec;
  const previousClose = isSameBar ? ((_b = chartData[chartData.length - 2]) == null ? void 0 : _b.close) ?? null : ((_c = chartData[chartData.length - 1]) == null ? void 0 : _c.close) ?? null;
  ctx.previousClose.current = previousClose;
  const styledBar = withPreviousCloseColors(liveBar, previousClose, ctx);
  try {
    ctx.series.update(styledBar);
    ctx.lastCandle.current = styledBar;
    ctx.liveCandleTs.current = toUnixMs(buffered.timestamp);
    ctx.setLegend(candleToLegend(styledBar, buffered.volume || 0));
  } catch {
  }
}
function scheduleStaleRefetch(chartData, ctx) {
  var _a;
  const lastBarSec = ((_a = chartData[chartData.length - 1]) == null ? void 0 : _a.time) ?? 0;
  const nowSec = Math.floor(Date.now() / 1e3);
  if (lastBarSec <= 0 || nowSec - lastBarSec <= intervalSecOf(ctx.timeframe) * 2) return void 0;
  const now = Date.now();
  if (now - ctx.gapAt.current <= 3e3) return void 0;
  ctx.gapAt.current = now;
  const { symbol, timeframe, qc } = ctx;
  const timer = window.setTimeout(() => {
    qc.invalidateQueries({ queryKey: queryKeys.market.candles(symbol, timeframe) });
  }, 1500);
  return () => window.clearTimeout(timer);
}
function clearPriceLines(series, list) {
  for (const pl of list) {
    try {
      series.removePriceLine(pl);
    } catch {
    }
  }
}
function addSlTpLine(series, pos, field, price, pnl, out, map, colors) {
  const isTp = field === "takeProfit";
  const line = series.createPriceLine({
    price,
    color: isTp ? colors.tpLine : colors.slLine,
    lineWidth: 2,
    lineStyle: LineStyle.Dashed,
    axisLabelVisible: true,
    title: `${isTp ? "TP" : "SL"}  ${pnl >= 0 ? "+" : ""}$${pnl.toFixed(2)}`
  });
  out.push(line);
  map.set(`${pos.id}:${isTp ? "tp" : "sl"}`, {
    line,
    price,
    positionId: pos.id,
    field,
    side: pos.side,
    entryPrice: pos.entryPrice,
    quantity: pos.quantity
  });
}
function addPositionOverlay(series, pos, opts, out, map) {
  if (pos.symbolName !== opts.symbol || !Number.isFinite(pos.entryPrice)) return;
  out.push(
    series.createPriceLine({
      price: pos.entryPrice,
      color: pos.side === "LONG" ? opts.colors.up : opts.colors.down,
      lineWidth: 1,
      lineStyle: LineStyle.Dotted,
      axisLabelVisible: true,
      title: `${pos.side === "LONG" ? "buy" : "sell"} ${pos.quantity.toFixed(2)}`
    })
  );
  const direction = pos.side === "LONG" ? 1 : -1;
  const pnlAt = (target) => parseFloat(
    ((target - pos.entryPrice) * direction * pos.quantity * opts.contractSize).toFixed(2)
  );
  if (typeof pos.takeProfit === "number" && Number.isFinite(pos.takeProfit)) {
    addSlTpLine(
      series,
      pos,
      "takeProfit",
      pos.takeProfit,
      pnlAt(pos.takeProfit),
      out,
      map,
      opts.colors
    );
  }
  if (typeof pos.stopLoss === "number" && Number.isFinite(pos.stopLoss)) {
    addSlTpLine(series, pos, "stopLoss", pos.stopLoss, pnlAt(pos.stopLoss), out, map, opts.colors);
  }
}
function addOrderOverlay(series, ord, symbol, orderColor, out) {
  if (ord.symbolName !== symbol || ord.status !== "PENDING" || !Number.isFinite(ord.price)) {
    return;
  }
  out.push(
    series.createPriceLine({
      price: ord.price,
      color: orderColor,
      lineWidth: 1,
      lineStyle: LineStyle.Dashed,
      axisLabelVisible: true,
      title: `[P] ${ord.side} ${ord.type} ${ord.quantity}`
    })
  );
}
function restoreLegendOnLeave(restored, lastCandle, legendVol, setLegend) {
  if (!restored.current && lastCandle.current) {
    setLegend(candleToLegend(lastCandle.current, legendVol.current));
  }
  restored.current = true;
}
function entryMarker(ev, time) {
  const isBuy = ev.side === "BUY";
  return {
    time,
    position: isBuy ? "belowBar" : "aboveBar",
    color: isBuy ? "#2196F3" : "#FF9800",
    shape: isBuy ? "arrowUp" : "arrowDown",
    text: isBuy ? "B" : "S"
  };
}
function exitMarker(ev, time) {
  const profit = ev.pnl != null && ev.pnl >= 0;
  const text = ev.pnl != null ? `${ev.pnl >= 0 ? "+" : ""}$${Math.abs(ev.pnl).toFixed(0)}` : "Exit";
  return {
    time,
    position: profit ? "aboveBar" : "belowBar",
    color: profit ? "#0ecb81" : "#f6465d",
    shape: "circle",
    text
  };
}
function buildReplayMarker(ev, timeframe) {
  const evMs = new Date(ev.timestamp).getTime();
  if (Number.isNaN(evMs)) return null;
  const time = getCandleBucketTime(evMs, timeframe);
  if (ev.type === "entry") return entryMarker(ev, time);
  if (ev.type === "exit") return exitMarker(ev, time);
  return {
    time,
    position: "aboveBar",
    color: "#FF1744",
    shape: "square",
    text: ev.ruleCode ?? "Rule"
  };
}
function OhlcvCell({
  label,
  value,
  digits,
  color,
  bold
}) {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("span", { className: "text-muted-foreground/70", children: label }),
    /* @__PURE__ */ jsx(
      "span",
      {
        className: bold ? "font-semibold" : "font-medium",
        style: { color },
        children: value.toFixed(digits)
      }
    )
  ] });
}
function OhlcvLegendRow({
  legend,
  pipDigits,
  showChange,
  showVolume
}) {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(OhlcvCell, { label: "O", value: legend.o, digits: pipDigits, color: legend.color }),
    /* @__PURE__ */ jsx(OhlcvCell, { label: "H", value: legend.h, digits: pipDigits, color: legend.color }),
    /* @__PURE__ */ jsx(OhlcvCell, { label: "L", value: legend.l, digits: pipDigits, color: legend.color }),
    /* @__PURE__ */ jsx(OhlcvCell, { label: "C", value: legend.c, digits: pipDigits, color: legend.color, bold: true }),
    showChange && /* @__PURE__ */ jsxs(
      "span",
      {
        className: "font-semibold",
        style: { color: legend.color },
        children: [
          legend.change >= 0 ? "+" : "",
          legend.change.toFixed(2),
          "%"
        ]
      }
    ),
    showVolume && legend.v > 0 && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("span", { className: "text-muted-foreground/70", children: "V" }),
      /* @__PURE__ */ jsx("span", { className: "text-foreground/60", children: legend.v.toLocaleString() })
    ] })
  ] });
}
function BidAskRow({ tick, pipDigits }) {
  const spread = ((tick.ask - tick.bid) * 10 ** pipDigits).toFixed(1);
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-[10px]", children: [
    /* @__PURE__ */ jsx("span", { className: "text-muted-foreground/50", children: "Bid" }),
    /* @__PURE__ */ jsx("span", { className: "text-[#0ecb81]/80", children: tick.bid.toFixed(pipDigits) }),
    /* @__PURE__ */ jsx("span", { className: "text-muted-foreground/50", children: "Ask" }),
    /* @__PURE__ */ jsx("span", { className: "text-[#f6465d]/80", children: tick.ask.toFixed(pipDigits) }),
    /* @__PURE__ */ jsx("span", { className: "text-muted-foreground/50", children: "Spread" }),
    /* @__PURE__ */ jsx("span", { className: "text-foreground/50", children: spread })
  ] });
}
function ChartLegendHeader({
  selectedSymbol,
  timeframe,
  legend,
  countdown,
  tick,
  pipDigits,
  showOhlcLegend,
  showCountdown,
  showSymbol,
  showMode,
  showChange,
  showVolume,
  isReplaying
}) {
  return /* @__PURE__ */ jsxs("div", { className: "absolute top-2 left-3 z-10 pointer-events-none select-none", style: { left: 48 }, children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-[11px] leading-none mb-1", children: [
      showSymbol && /* @__PURE__ */ jsx("span", { className: "text-foreground font-bold text-[13px] tracking-tight", children: selectedSymbol }),
      /* @__PURE__ */ jsx("span", { className: "text-muted-foreground font-medium", children: timeframe }),
      showMode && /* @__PURE__ */ jsx("span", { className: "text-muted-foreground/70 font-medium", children: isReplaying ? "REPLAY" : "LIVE" }),
      legend && showOhlcLegend && /* @__PURE__ */ jsx(
        OhlcvLegendRow,
        {
          legend,
          pipDigits,
          showChange,
          showVolume
        }
      ),
      countdown && showCountdown && /* @__PURE__ */ jsxs("span", { className: "text-muted-foreground/60 flex items-center gap-0.5", children: [
        /* @__PURE__ */ jsx(Clock, { className: "h-2.5 w-2.5 opacity-50" }),
        countdown
      ] })
    ] }),
    tick && /* @__PURE__ */ jsx(BidAskRow, { tick, pipDigits })
  ] });
}
function DrawingOverlays({
  drawing,
  toolbarAnchor,
  toolbarBounds,
  showSettings,
  currentTf,
  onPreview,
  onUpdate,
  onClone,
  onRemove,
  onOpenSettings,
  onCloseSettings
}) {
  if (!drawing) return null;
  if (showSettings) {
    return /* @__PURE__ */ jsx(
      DrawingSettingsDialog,
      {
        drawing,
        currentTf,
        onPreview,
        onCommit: onUpdate,
        onClose: onCloseSettings
      }
    );
  }
  if (!toolbarAnchor || !toolbarBounds) return null;
  return /* @__PURE__ */ jsx(
    DrawingFloatingToolbar,
    {
      drawing,
      anchor: toolbarAnchor,
      bounds: toolbarBounds,
      onUpdate,
      onClone,
      onRemove,
      onOpenSettings
    }
  );
}
function ObjectTreeOverlay({
  drawings,
  selectedIds,
  pipDigits,
  currentTf,
  open,
  onToggle,
  onSelect,
  onUpdate,
  onRemove,
  onReorder
}) {
  if (drawings.length === 0) return null;
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        title: "Object tree (drawings)",
        onClick: onToggle,
        className: cn(
          "absolute bottom-2 left-2 z-10 p-1.5 rounded-md border border-border bg-card/90 shadow",
          open ? "text-primary" : "text-muted-foreground hover:text-foreground"
        ),
        children: /* @__PURE__ */ jsx(ListTree, { className: "h-3.5 w-3.5" })
      }
    ),
    open && /* @__PURE__ */ jsx(
      ObjectTreePanel,
      {
        drawings,
        selectedIds,
        pipDigits,
        currentTf,
        onSelect,
        onUpdate,
        onRemove,
        onReorder,
        onClose: onToggle
      }
    )
  ] });
}
function ChartPanel({
  candles,
  selectedSymbol,
  timeframe,
  isDark,
  activeIndicators,
  drawingTool,
  drawings,
  onAddDrawing,
  onUpdateDrawing,
  onRemoveDrawing,
  onDrawingComplete,
  onDrawingToolSelect,
  onUndoDrawing,
  onRedoDrawing,
  magnetMode = "none",
  stayInDrawingMode = false,
  positions,
  orders,
  tick,
  liveCandle,
  pipDigits,
  symbolInfo,
  onModifyPosition,
  replayTradeEvents,
  activePlugins = [],
  onTogglePlugin,
  accountEquity = 0,
  accountId,
  onQuickOrder,
  onClearDrawings,
  onClearIndicators,
  isReplaying = false,
  showNews = true,
  showLastPrice = false,
  onChartReady,
  keyboardEnabled = true,
  showDrawingTools = true,
  drawingRailHost,
  onMagnetToggle,
  onStayInDrawingModeToggle
}) {
  const queryClient = useQueryClient();
  const lastGapRefetchAtRef = useRef(0);
  const containerRef = useRef(null);
  const chartRef = useRef(null);
  const candleSeriesRef = useRef(null);
  const [historicalExtra, setHistoricalExtra] = useState({
    view: `${selectedSymbol}:${timeframe}`,
    bars: []
  });
  const loadMoreRef = useRef({
    loading: false,
    noMoreData: false,
    lastFetchedBeforeMs: 0,
    fetchFromMs: 0,
    emptyWindows: 0
  });
  const volumeSeriesRef = useRef(null);
  const priceLineRef = useRef([]);
  const drawingManagerRef = useRef(null);
  const timeframeRef = useRef(timeframe);
  const chartPluginsRef = useRef([]);
  const bidLineRef = useRef(null);
  const askLineRef = useRef(null);
  const midLineRef = useRef(null);
  const slTpLinesRef = useRef(/* @__PURE__ */ new Map());
  const [chartEpoch, setChartEpoch] = useState(0);
  const [legend, setLegend] = useState(null);
  const [countdown, setCountdown] = useState("");
  const countdownIntervalMs = TF_INTERVAL_MS[timeframe];
  const countdownText = !isReplaying && countdownIntervalMs && countdownIntervalMs < 864e5 ? countdown : "";
  const legendRestoredRef = useRef(true);
  const chartPrefs = useChartPreferences();
  const themeColors = isDark ? CHART_COLORS.dark : CHART_COLORS.light;
  const colors = useMemo(
    () => mergeChartColors(themeColors, chartPrefs),
    [themeColors, chartPrefs]
  );
  const candleSeriesSettings = useMemo(
    () => buildCandlestickSettingsOptions(
      chartPrefs,
      themeColors,
      pipDigits,
      getMinMove(pipDigits)
    ),
    [chartPrefs, themeColors, pipDigits]
  );
  const candleRenderColors = {
    bullBody: candleSeriesSettings.upColor ?? themeColors.up,
    bearBody: candleSeriesSettings.downColor ?? themeColors.down,
    bullBorder: candleSeriesSettings.borderUpColor ?? themeColors.up,
    bearBorder: candleSeriesSettings.borderDownColor ?? themeColors.down,
    bullWick: candleSeriesSettings.wickUpColor ?? themeColors.up,
    bearWick: candleSeriesSettings.wickDownColor ?? themeColors.down
  };
  useEffect(() => {
    const id = setTimeout(() => {
      loadMoreRef.current = {
        loading: false,
        noMoreData: false,
        lastFetchedBeforeMs: 0,
        fetchFromMs: 0,
        emptyWindows: 0
      };
      lastGapRefetchAtRef.current = 0;
    }, 0);
    return () => clearTimeout(id);
  }, [selectedSymbol, timeframe]);
  const [selectedDrawingIds, setSelectedDrawingIds] = useState([]);
  const [showDrawingSettings, setShowDrawingSettings] = useState(false);
  const [drawingToolbarGeometry, setDrawingToolbarGeometry] = useState(null);
  const [showObjectTree, setShowObjectTree] = useState(false);
  const [contextMenu, setContextMenu] = useState(null);
  const drawingMenuOpenedRef = useRef(false);
  const [chartMenu, setChartMenu] = useState(
    null
  );
  const [showChartSettings, setShowChartSettings] = useState(false);
  const selectedDrawing = useMemo(
    () => selectedDrawingIds.length === 1 ? drawings.find((d) => d.id === selectedDrawingIds[0]) ?? null : null,
    [drawings, selectedDrawingIds]
  );
  const visibleDrawings = useMemo(
    () => drawings.filter((d) => !d.hidden && isDrawingVisibleOnTimeframe(d, timeframe)),
    [drawings, timeframe]
  );
  const updateDrawingToolbarGeometry = useCallback(() => {
    const drawing = selectedDrawing;
    const container = containerRef.current;
    const chart = chartRef.current;
    const series = candleSeriesRef.current;
    if (!drawing || !container || !chart || !series) {
      setDrawingToolbarGeometry(null);
      return;
    }
    const rect = container.getBoundingClientRect();
    const xs = [drawing.time, drawing.time2].filter((value) => typeof value === "number").map((value) => chart.timeScale().timeToCoordinate(value)).flatMap((value) => value === null || !Number.isFinite(value) ? [] : [Number(value)]);
    const prices = [drawing.price, drawing.price2, drawing.price3, drawing.stopPrice, drawing.targetPrice].filter((value) => typeof value === "number" && Number.isFinite(value));
    const ys = prices.map((value) => series.priceToCoordinate(value)).flatMap((value) => value === null || !Number.isFinite(value) ? [] : [Number(value)]);
    const localX = xs.length > 0 ? (Math.min(...xs) + Math.max(...xs)) / 2 : rect.width / 2;
    const localY = ys.length > 0 ? Math.min(...ys) : Math.min(96, rect.height / 3);
    setDrawingToolbarGeometry({
      anchor: { x: rect.left + localX, y: rect.top + localY },
      bounds: { left: rect.left, top: rect.top, width: rect.width, height: rect.height }
    });
  }, [selectedDrawing]);
  useEffect(() => {
    updateDrawingToolbarGeometry();
    const container = containerRef.current;
    const chart = chartRef.current;
    if (!selectedDrawing || !container || !chart) return;
    const update = () => updateDrawingToolbarGeometry();
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(update);
    observer == null ? void 0 : observer.observe(container);
    chart.timeScale().subscribeVisibleLogicalRangeChange(update);
    window.addEventListener("resize", update);
    window.addEventListener("scroll", update, true);
    return () => {
      observer == null ? void 0 : observer.disconnect();
      chart.timeScale().unsubscribeVisibleLogicalRangeChange(update);
      window.removeEventListener("resize", update);
      window.removeEventListener("scroll", update, true);
    };
  }, [selectedDrawing, updateDrawingToolbarGeometry]);
  const drawingToolRef = useRef(drawingTool);
  const drawingsRef = useRef(visibleDrawings);
  const magnetRef = useRef(magnetMode);
  const stayInModeRef = useRef(stayInDrawingMode);
  const accountEquityRef = useRef(accountEquity);
  const styleDefaultsRef = useRef(getStyleDefaults());
  const onAddDrawingRef = useRef(onAddDrawing);
  const onUpdateDrawingRef = useRef(onUpdateDrawing);
  const onRemoveDrawingRef = useRef(onRemoveDrawing);
  const onDrawingCompleteRef = useRef(onDrawingComplete);
  const onDrawingToolSelectRef = useRef(onDrawingToolSelect);
  const onUndoDrawingRef = useRef(onUndoDrawing);
  const onRedoDrawingRef = useRef(onRedoDrawing);
  useEffect(() => {
    var _a;
    drawingToolRef.current = drawingTool;
    (_a = drawingManagerRef.current) == null ? void 0 : _a.setTool(drawingTool);
  }, [drawingTool]);
  useEffect(() => {
    var _a;
    drawingsRef.current = visibleDrawings;
    (_a = drawingManagerRef.current) == null ? void 0 : _a.setDrawings(visibleDrawings);
  }, [visibleDrawings]);
  useEffect(() => {
    var _a;
    magnetRef.current = magnetMode;
    (_a = drawingManagerRef.current) == null ? void 0 : _a.setMagnetMode(magnetMode);
  }, [magnetMode]);
  useEffect(() => {
    var _a;
    accountEquityRef.current = accountEquity;
    (_a = drawingManagerRef.current) == null ? void 0 : _a.setAccountEquity(accountEquity);
  }, [accountEquity]);
  useEffect(() => {
    const refresh = () => {
      var _a;
      styleDefaultsRef.current = getStyleDefaults();
      (_a = drawingManagerRef.current) == null ? void 0 : _a.setStyleDefaults(styleDefaultsRef.current);
    };
    window.addEventListener(DRAWING_STYLES_EVENT, refresh);
    return () => window.removeEventListener(DRAWING_STYLES_EVENT, refresh);
  }, []);
  useEffect(() => {
    var _a;
    stayInModeRef.current = stayInDrawingMode;
    (_a = drawingManagerRef.current) == null ? void 0 : _a.setStayInDrawingMode(stayInDrawingMode);
  }, [stayInDrawingMode]);
  useEffect(() => {
    onAddDrawingRef.current = onAddDrawing;
    onUpdateDrawingRef.current = onUpdateDrawing;
    onRemoveDrawingRef.current = onRemoveDrawing;
    onDrawingCompleteRef.current = onDrawingComplete;
    onDrawingToolSelectRef.current = onDrawingToolSelect;
    onUndoDrawingRef.current = onUndoDrawing;
    onRedoDrawingRef.current = onRedoDrawing;
  });
  const handleCloneDrawing = useCallback(() => {
    var _a;
    const d = selectedDrawing;
    if (!d) return;
    const offsetSec = (TF_INTERVAL_MS[timeframe] ?? 6e4) / 1e3 * 5;
    onAddDrawing({
      ...d,
      id: crypto.randomUUID(),
      time: d.time != null ? d.time + offsetSec : void 0,
      time2: d.time2 != null ? d.time2 + offsetSec : void 0,
      time3: d.time3 != null ? d.time3 + offsetSec : void 0,
      controlTime: d.controlTime != null ? d.controlTime + offsetSec : void 0,
      points: (_a = d.points) == null ? void 0 : _a.map((point) => ({ ...point, time: point.time + offsetSec }))
    });
  }, [selectedDrawing, timeframe, onAddDrawing]);
  const handleReorderDrawing = useCallback(
    (d, dir) => {
      const zs = drawings.map((x) => x.zIndex ?? 0);
      const zIndex = dir === "front" ? Math.max(...zs, 0) + 1 : Math.min(...zs, 0) - 1;
      onUpdateDrawing == null ? void 0 : onUpdateDrawing({ ...d, zIndex });
    },
    [drawings, onUpdateDrawing]
  );
  const handleObjectTreeSelect = useCallback((d) => {
    var _a;
    (_a = drawingManagerRef.current) == null ? void 0 : _a.setSelection([d.id]);
  }, []);
  const allCandles = useMemo(() => {
    const extra = historicalExtra.view === `${selectedSymbol}:${timeframe}` ? historicalExtra.bars : [];
    return extra.length === 0 ? candles : [...extra, ...candles];
  }, [historicalExtra, candles, selectedSymbol, timeframe]);
  const { chartData: safeChartData, volumeData } = useChartData(allCandles, colors);
  const chartData = useMemo(() => {
    return safeChartData.map((bar, index) => {
      var _a;
      const previousClose = ((_a = safeChartData[index - 1]) == null ? void 0 : _a.close) ?? null;
      const bullish = chartPrefs.colorBarsByPreviousClose ? bar.close >= (previousClose ?? bar.open) : bar.close >= bar.open;
      return {
        ...bar,
        color: bullish ? candleRenderColors.bullBody : candleRenderColors.bearBody,
        borderColor: bullish ? candleRenderColors.bullBorder : candleRenderColors.bearBorder,
        wickColor: bullish ? candleRenderColors.bullWick : candleRenderColors.bearWick
      };
    });
  }, [
    safeChartData,
    chartPrefs.colorBarsByPreviousClose,
    candleRenderColors.bullBody,
    candleRenderColors.bearBody,
    candleRenderColors.bullBorder,
    candleRenderColors.bearBorder,
    candleRenderColors.bullWick,
    candleRenderColors.bearWick
  ]);
  const {
    newsConfig,
    setNewsConfig,
    showNewsConfigDialog,
    setShowNewsConfigDialog,
    newsPopup,
    setNewsPopup
  } = useNewsOverlay(containerRef, chartRef, selectedSymbol, isDark, chartData);
  const dragPrice = useSlTpDrag(
    containerRef,
    chartRef,
    candleSeriesRef,
    slTpLinesRef,
    drawingTool,
    onModifyPosition,
    pipDigits,
    symbolInfo,
    chartEpoch
  );
  const challengeFlags = useMemo(
    () => ({
      enabled: chartPrefs.challengeOverlay && !!accountId,
      dailyLoss: chartPrefs.challengeDailyLossLine,
      maxDrawdown: chartPrefs.challengeMaxDrawdownLine,
      profitTarget: chartPrefs.challengeProfitTargetLine
    }),
    [
      chartPrefs.challengeOverlay,
      chartPrefs.challengeDailyLossLine,
      chartPrefs.challengeMaxDrawdownLine,
      chartPrefs.challengeProfitTargetLine,
      accountId
    ]
  );
  useChallengeLevels({
    accountId,
    selectedSymbol,
    positions,
    tick,
    contractSize: (symbolInfo == null ? void 0 : symbolInfo.contractSize) || 1e5,
    accountEquity,
    candleSeriesRef,
    flags: challengeFlags,
    chartEpoch
  });
  const handleChartContextMenu = useCallback((e) => {
    var _a;
    e.preventDefault();
    if (drawingMenuOpenedRef.current) {
      drawingMenuOpenedRef.current = false;
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const raw = (_a = candleSeriesRef.current) == null ? void 0 : _a.coordinateToPrice(e.clientY - rect.top);
    const price = typeof raw === "number" && Number.isFinite(raw) ? raw : null;
    setChartMenu({ x: e.clientX, y: e.clientY, price });
  }, []);
  const handleResetView = useCallback(() => {
    const chart = chartRef.current;
    if (!chart) return;
    chart.timeScale().resetTimeScale();
    chart.priceScale("right").applyOptions({ autoScale: true });
    chart.timeScale().scrollToRealTime();
  }, []);
  const handleCopyPrice = useCallback(
    (price) => {
      var _a;
      const text = price.toFixed(pipDigits);
      void ((_a = navigator.clipboard) == null ? void 0 : _a.writeText(text).then(() => toast.success("Copied", text)).catch(() => toast.error("Copy failed", "Clipboard unavailable")));
    },
    [pipDigits]
  );
  const handleAddAlert = useCallback(
    (price) => {
      const rounded = parseFloat(price.toFixed(pipDigits));
      onAddDrawing({
        id: crypto.randomUUID(),
        type: "horizontal",
        price: rounded,
        color: "#f0b90b",
        alertEnabled: true,
        createdTf: timeframe
      });
      toast.info("Alert set", `${selectedSymbol} at ${rounded}`);
    },
    [onAddDrawing, pipDigits, timeframe, selectedSymbol]
  );
  useIndicators(chartRef, candleSeriesRef, chartData, activeIndicators, isDark);
  useEffect(() => {
    const series = candleSeriesRef.current;
    if (!series) return;
    if (!replayTradeEvents || replayTradeEvents.length === 0) {
      series.setMarkers([]);
      return;
    }
    const markers = [];
    for (const ev of replayTradeEvents) {
      const marker = buildReplayMarker(ev, timeframe);
      if (marker) markers.push(marker);
    }
    markers.sort((a, b) => a.time - b.time);
    series.setMarkers(markers);
    return () => {
      series.setMarkers([]);
    };
  }, [replayTradeEvents, timeframe]);
  useEffect(() => {
    const intervalMs = TF_INTERVAL_MS[timeframe];
    if (!intervalMs || intervalMs >= 864e5) return;
    const tick2 = () => {
      const now = Date.now();
      const currentBucketStart = Math.floor(now / intervalMs) * intervalMs;
      const nextBucketStart = currentBucketStart + intervalMs;
      const remainingSec = Math.max(0, (nextBucketStart - now) / 1e3);
      setCountdown(formatCountdown$1(remainingSec));
    };
    tick2();
    const id = setInterval(tick2, 1e3);
    return () => clearInterval(id);
  }, [timeframe]);
  useEffect(() => {
    if (!containerRef.current) return;
    const chart = createChart(
      containerRef.current,
      chartOptionsForPanel(chartPrefs, themeColors, timeframeRef.current, selectedSymbol)
    );
    chartRef.current = chart;
    const candleSeries = chart.addCandlestickSeries({
      ...candleSeriesSettings,
      // Hide the candle's own last-value label and default close price-line.
      // Candle close is the mid price ((bid+ask)/2) — with a 1-pip spread that
      // sits half a pip below Ask, so the mid label stacks visually next to
      // the Ask label and rounds to the same 5-decimal string. The explicit
      // Bid/Ask price lines below are the authoritative right-edge prices for
      // trading; the mid label is redundant and creates the "misaligned" look.
      lastValueVisible: showLastPrice && chartPrefs.showLastValue,
      priceLineVisible: showLastPrice && chartPrefs.showPriceLine,
      priceLineWidth: 1,
      priceLineColor: "",
      priceLineStyle: LineStyle.Dotted
    });
    candleSeriesRef.current = candleSeries;
    const volumeSeries = chart.addHistogramSeries({
      priceFormat: { type: "volume" },
      priceScaleId: "volume"
    });
    chart.priceScale("volume").applyOptions({
      scaleMargins: { top: 0.85, bottom: 0 }
    });
    volumeSeriesRef.current = volumeSeries;
    chart.subscribeCrosshairMove((param) => {
      if (!(param == null ? void 0 : param.time)) {
        restoreLegendOnLeave(legendRestoredRef, lastCandleRef, legendVolRef, setLegend);
        return;
      }
      legendRestoredRef.current = false;
      const data = param.seriesData.get(candleSeries);
      if (data) {
        const vol = param.seriesData.get(volumeSeries);
        setLegend(candleToLegend(data, (vol == null ? void 0 : vol.value) || 0));
      }
    });
    const stopObservingSize = observeChartSize(containerRef.current, (width, height) => {
      chart.applyOptions({ width, height });
    });
    const drawingManager = new DrawingToolsManager({
      chart,
      series: candleSeries,
      container: containerRef.current,
      intervalSec: (TF_INTERVAL_MS[timeframeRef.current] ?? 6e4) / 1e3,
      timeframe: timeframeRef.current,
      accountEquity: accountEquityRef.current,
      callbacks: {
        onAdd: (d) => onAddDrawingRef.current(d),
        onUpdate: (d) => {
          var _a;
          return (_a = onUpdateDrawingRef.current) == null ? void 0 : _a.call(onUpdateDrawingRef, d);
        },
        onRemove: (id) => {
          var _a;
          return (_a = onRemoveDrawingRef.current) == null ? void 0 : _a.call(onRemoveDrawingRef, id);
        },
        onToolFinished: () => {
          var _a;
          return (_a = onDrawingCompleteRef.current) == null ? void 0 : _a.call(onDrawingCompleteRef);
        },
        onSelectionChange: (ids) => {
          setSelectedDrawingIds(ids);
          setShowDrawingSettings(false);
        },
        onRequestSettings: (id) => {
          setSelectedDrawingIds([id]);
          setShowDrawingSettings(true);
        },
        onContextMenu: (id, clientX, clientY) => {
          drawingMenuOpenedRef.current = true;
          setSelectedDrawingIds([id]);
          setContextMenu({ id, x: clientX, y: clientY });
        },
        onSelectTool: (t) => {
          var _a;
          return (_a = onDrawingToolSelectRef.current) == null ? void 0 : _a.call(onDrawingToolSelectRef, t);
        },
        onUndo: () => {
          var _a;
          return (_a = onUndoDrawingRef.current) == null ? void 0 : _a.call(onUndoDrawingRef);
        },
        onRedo: () => {
          var _a;
          return (_a = onRedoDrawingRef.current) == null ? void 0 : _a.call(onRedoDrawingRef);
        }
      }
    });
    drawingManager.setDrawings(drawingsRef.current);
    drawingManager.setTool(drawingToolRef.current);
    drawingManager.setMagnetMode(magnetRef.current);
    drawingManager.setStyleDefaults(styleDefaultsRef.current);
    drawingManager.setStayInDrawingMode(stayInModeRef.current);
    drawingManagerRef.current = drawingManager;
    let historyLoadCancelled = false;
    const handleRangeChange = makeHistoryLoader(
      selectedSymbol,
      timeframeRef,
      candleSeriesRef,
      loadMoreRef,
      (bars) => {
        if (historyLoadCancelled) return;
        const view = `${selectedSymbol}:${timeframeRef.current}`;
        setHistoricalExtra(
          (prev) => prev.view === view ? { view, bars: [...bars, ...prev.bars] } : { view, bars: [...bars] }
        );
      }
    );
    chart.timeScale().subscribeVisibleLogicalRangeChange(handleRangeChange);
    setChartEpoch((e) => e + 1);
    onChartReady == null ? void 0 : onChartReady({ chart, series: candleSeries });
    return () => {
      onChartReady == null ? void 0 : onChartReady(null);
      historyLoadCancelled = true;
      chart.timeScale().unsubscribeVisibleLogicalRangeChange(handleRangeChange);
      stopObservingSize();
      drawingManager.destroy();
      drawingManagerRef.current = null;
      setSelectedDrawingIds([]);
      setShowDrawingSettings(false);
      chart.remove();
      chartRef.current = null;
      candleSeriesRef.current = null;
      volumeSeriesRef.current = null;
      bidLineRef.current = null;
      askLineRef.current = null;
      midLineRef.current = null;
      chartPluginsRef.current = [];
      lastCandleRef.current = null;
      legendVolRef.current = 0;
      liveCandleTsRef.current = 0;
      loadMoreRef.current = {
        loading: false,
        noMoreData: false,
        emptyWindows: 0,
        lastFetchedBeforeMs: 0,
        fetchFromMs: 0
      };
      lastGapRefetchAtRef.current = 0;
    };
  }, [
    isDark,
    pipDigits,
    selectedSymbol
  ]);
  useEffect(() => {
    var _a;
    (_a = drawingManagerRef.current) == null ? void 0 : _a.setKeyboardEnabled(keyboardEnabled);
  }, [keyboardEnabled, chartEpoch]);
  useEffect(() => {
    var _a, _b;
    const chart = chartRef.current;
    if (!chart) return;
    chart.applyOptions(
      chartOptionsForPanel(chartPrefs, themeColors, timeframe, selectedSymbol)
    );
    (_a = candleSeriesRef.current) == null ? void 0 : _a.applyOptions(candleSeriesSettings);
    (_b = volumeSeriesRef.current) == null ? void 0 : _b.applyOptions({ visible: chartPrefs.showVolume });
  }, [
    chartPrefs,
    candleSeriesSettings,
    themeColors,
    timeframe,
    selectedSymbol,
    chartEpoch
  ]);
  useEffect(() => {
    var _a;
    timeframeRef.current = timeframe;
    (_a = drawingManagerRef.current) == null ? void 0 : _a.updateTimeframe(
      timeframe,
      (TF_INTERVAL_MS[timeframe] ?? 6e4) / 1e3
    );
  }, [timeframe]);
  const lastCandleRef = useRef(null);
  const previousCloseRef = useRef(null);
  const lastLoadKeyRef = useRef("");
  const latestLiveCandleRef = useRef(void 0);
  const liveCandleTsRef = useRef(0);
  const legendVolRef = useRef(0);
  const makeRtCtx = useCallback(
    (series) => ({
      series,
      volume: volumeSeriesRef.current,
      lastCandle: lastCandleRef,
      previousClose: previousCloseRef,
      colorBarsByPreviousClose: chartPrefs.colorBarsByPreviousClose,
      candleColors: candleRenderColors,
      liveCandleTs: liveCandleTsRef,
      legendVol: legendVolRef,
      gapAt: lastGapRefetchAtRef,
      bidLine: bidLineRef,
      askLine: askLineRef,
      midLine: midLineRef,
      colors,
      timeframe,
      symbol: selectedSymbol,
      qc: queryClient,
      setLegend
    }),
    [
      colors,
      timeframe,
      selectedSymbol,
      queryClient,
      chartPrefs.colorBarsByPreviousClose,
      candleRenderColors.bullBody,
      candleRenderColors.bearBody,
      candleRenderColors.bullBorder,
      candleRenderColors.bearBorder,
      candleRenderColors.bullWick,
      candleRenderColors.bearWick
    ]
  );
  useEffect(() => {
    latestLiveCandleRef.current = liveCandle;
  }, [liveCandle]);
  useEffect(() => {
    var _a, _b;
    const series = candleSeriesRef.current;
    if (!series || chartData.length === 0) return;
    const ctx = makeRtCtx(series);
    const loadKey = `${selectedSymbol}:${timeframe}`;
    const isNewChart = lastLoadKeyRef.current !== loadKey;
    series.setData(chartData);
    (_a = volumeSeriesRef.current) == null ? void 0 : _a.setData(volumeData);
    lastCandleRef.current = chartData[chartData.length - 1] ?? null;
    previousCloseRef.current = chartData.length > 1 ? ((_b = chartData[chartData.length - 2]) == null ? void 0 : _b.close) ?? null : null;
    setLegend(legendFromSeries(chartData, volumeData));
    const buffered = latestLiveCandleRef.current;
    if (!isNewChart) {
      reapplyLive(buffered, ctx);
      return;
    }
    scrollOrFit(chartRef.current, chartData.length);
    lastLoadKeyRef.current = loadKey;
    liveCandleTsRef.current = 0;
    replayBufferedLive(buffered, chartData, ctx);
    return scheduleStaleRefetch(chartData, ctx);
  }, [chartData, volumeData, selectedSymbol, timeframe, makeRtCtx]);
  useEffect(() => {
    const series = candleSeriesRef.current;
    if (!series || !liveCandle || !lastCandleRef.current) return;
    applyServerCandle(liveCandle, makeRtCtx(series));
  }, [liveCandle, makeRtCtx]);
  useEffect(() => {
    const series = candleSeriesRef.current;
    if (!series || !tick) return;
    applyTick(tick, makeRtCtx(series));
  }, [tick, makeRtCtx]);
  const alertMidRef = useRef(null);
  const alertFiredRef = useRef(/* @__PURE__ */ new Map());
  useEffect(() => {
    if (!tick) return;
    const mid = (tick.bid + tick.ask) / 2;
    const prev = alertMidRef.current;
    alertMidRef.current = mid;
    if (prev === null) return;
    const nowSec = Math.floor(tick.timestamp / 1e3);
    const crossed = detectCrossings(drawingsRef.current, prev, mid, nowSec, alertFiredRef.current);
    for (const d of crossed) {
      toast.info(
        "Price alert",
        d.alertMessage ?? `${selectedSymbol} crossed your ${d.type} @ ${mid.toFixed(pipDigits)}`
      );
      playAlertBeep();
    }
  }, [tick, selectedSymbol, pipDigits]);
  useEffect(() => {
    if (isReplaying) return;
    const intervalSec = (TF_INTERVAL_MS[timeframe] ?? 6e4) / 1e3;
    const id = setInterval(() => {
      if (!lastCandleRef.current) return;
      const staleSec = Date.now() / 1e3 - lastCandleRef.current.time;
      if (staleSec < intervalSec * 2) return;
      requestGapRefetch(lastGapRefetchAtRef, queryClient, selectedSymbol, timeframe);
    }, 3e4);
    return () => clearInterval(id);
  }, [selectedSymbol, timeframe, queryClient, isReplaying]);
  const symbolCategory = symbolInfo == null ? void 0 : symbolInfo.category;
  useEffect(() => {
    if (!candleSeriesRef.current) return;
    const series = candleSeriesRef.current;
    detachPlugins(series, chartPluginsRef.current);
    chartPluginsRef.current = [];
    attachPlugins(
      series,
      activePlugins,
      { isDark, timeframe, symbolCategory },
      chartPluginsRef.current
    );
  }, [activePlugins, isDark, selectedSymbol, timeframe, symbolCategory]);
  useEffect(() => {
    const series = candleSeriesRef.current;
    if (!series) return;
    applyBidAskLines(
      tick,
      { showBidLine: chartPrefs.showBidLine, showAskLine: chartPrefs.showAskLine },
      makeRtCtx(series)
    );
  }, [tick, chartPrefs.showBidLine, chartPrefs.showAskLine, makeRtCtx]);
  useEffect(() => {
    const series = candleSeriesRef.current;
    if (!series) return;
    const lines = priceLineRef.current;
    clearPriceLines(series, lines);
    priceLineRef.current = [];
    slTpLinesRef.current.clear();
    if (!chartPrefs.overlayPositionsOnChart) return;
    const opts = {
      symbol: selectedSymbol,
      colors,
      contractSize: (symbolInfo == null ? void 0 : symbolInfo.contractSize) || 1e5
    };
    for (const pos of positions) {
      addPositionOverlay(series, pos, opts, priceLineRef.current, slTpLinesRef.current);
    }
    for (const ord of orders) {
      addOrderOverlay(series, ord, selectedSymbol, colors.orderLine, priceLineRef.current);
    }
  }, [
    positions,
    orders,
    selectedSymbol,
    chartData,
    symbolInfo,
    colors,
    chartPrefs.overlayPositionsOnChart
  ]);
  return /* @__PURE__ */ jsxs("div", { className: "relative w-full h-full", children: [
    /* @__PURE__ */ jsx(
      ChartLegendHeader,
      {
        selectedSymbol,
        timeframe,
        legend,
        countdown: countdownText,
        tick,
        pipDigits,
        showOhlcLegend: chartPrefs.showOhlcLegend,
        showCountdown: chartPrefs.showCountdown,
        showSymbol: chartPrefs.showStatusLineSymbol,
        showMode: chartPrefs.showStatusLineMarketState,
        showChange: chartPrefs.showStatusLineChange,
        showVolume: chartPrefs.showStatusLineVolume,
        isReplaying
      }
    ),
    dragPrice && /* @__PURE__ */ jsx(
      "div",
      {
        className: "absolute left-1/2 -translate-x-1/2 z-20 pointer-events-none",
        style: { top: dragPrice.y - 32 },
        children: /* @__PURE__ */ jsxs(
          "div",
          {
            className: cn(
              "px-2 py-1 rounded text-[11px] font-mono font-bold shadow-lg border",
              dragPrice.field === "TP" ? "bg-[#0ecb81]/20 text-[#0ecb81] border-[#0ecb81]/40" : "bg-[#f6465d]/20 text-[#f6465d] border-[#f6465d]/40"
            ),
            children: [
              dragPrice.field,
              " → ",
              dragPrice.price.toFixed(pipDigits),
              /* @__PURE__ */ jsxs(
                "span",
                {
                  className: dragPrice.pnlUsd >= 0 ? "ml-1.5 text-[#0ecb81]" : "ml-1.5 text-[#f6465d]",
                  children: [
                    dragPrice.pnlUsd >= 0 ? "+" : "",
                    "$",
                    dragPrice.pnlUsd.toFixed(2)
                  ]
                }
              )
            ]
          }
        )
      }
    ),
    /* @__PURE__ */ jsx(
      DrawingOverlays,
      {
        drawing: selectedDrawing,
        toolbarAnchor: (drawingToolbarGeometry == null ? void 0 : drawingToolbarGeometry.anchor) ?? null,
        toolbarBounds: (drawingToolbarGeometry == null ? void 0 : drawingToolbarGeometry.bounds) ?? null,
        showSettings: showDrawingSettings,
        currentTf: timeframe,
        onPreview: (preview) => {
          var _a;
          (_a = drawingManagerRef.current) == null ? void 0 : _a.setDrawings(
            drawingsRef.current.map(
              (drawing) => drawing.id === preview.id ? preview : drawing
            )
          );
        },
        onUpdate: (d) => onUpdateDrawing == null ? void 0 : onUpdateDrawing(d),
        onClone: handleCloneDrawing,
        onRemove: () => selectedDrawing && (onRemoveDrawing == null ? void 0 : onRemoveDrawing(selectedDrawing.id)),
        onOpenSettings: () => setShowDrawingSettings(true),
        onCloseSettings: () => setShowDrawingSettings(false)
      }
    ),
    contextMenu && selectedDrawing && /* @__PURE__ */ jsx(
      DrawingContextMenu,
      {
        drawing: selectedDrawing,
        x: contextMenu.x,
        y: contextMenu.y,
        onClose: () => setContextMenu(null),
        onSettings: () => setShowDrawingSettings(true),
        onDuplicate: handleCloneDrawing,
        onReorder: (dir) => handleReorderDrawing(selectedDrawing, dir),
        onToggleLock: () => onUpdateDrawing == null ? void 0 : onUpdateDrawing({ ...selectedDrawing, locked: !selectedDrawing.locked }),
        onToggleAlert: () => onUpdateDrawing == null ? void 0 : onUpdateDrawing({ ...selectedDrawing, alertEnabled: !selectedDrawing.alertEnabled }),
        onRemove: () => onRemoveDrawing == null ? void 0 : onRemoveDrawing(selectedDrawing.id)
      }
    ),
    /* @__PURE__ */ jsx(
      ObjectTreeOverlay,
      {
        drawings,
        selectedIds: selectedDrawingIds,
        pipDigits,
        currentTf: timeframe,
        open: showObjectTree,
        onToggle: () => setShowObjectTree((v) => !v),
        onSelect: handleObjectTreeSelect,
        onUpdate: (d) => onUpdateDrawing == null ? void 0 : onUpdateDrawing(d),
        onRemove: (id) => onRemoveDrawing == null ? void 0 : onRemoveDrawing(id),
        onReorder: handleReorderDrawing
      }
    ),
    showNews && /* @__PURE__ */ jsx(
      NewsOverlay,
      {
        newsConfig,
        setNewsConfig,
        showNewsConfigDialog,
        setShowNewsConfigDialog,
        newsPopup,
        setNewsPopup,
        isDark,
        pipDigits,
        containerRef
      }
    ),
    chartMenu && /* @__PURE__ */ jsx(
      ChartContextMenu,
      {
        x: chartMenu.x,
        y: chartMenu.y,
        price: chartMenu.price,
        pipDigits,
        symbol: selectedSymbol,
        tick,
        drawingsCount: visibleDrawings.length,
        indicatorsCount: activeIndicators.length,
        onClose: () => setChartMenu(null),
        onResetView: handleResetView,
        onCopyPrice: handleCopyPrice,
        onAddAlert: handleAddAlert,
        onQuickOrder,
        onOpenObjectTree: () => setShowObjectTree(true),
        onRemoveAllDrawings: onClearDrawings,
        onClearIndicators,
        onOpenSettings: () => setShowChartSettings(true)
      }
    ),
    /* @__PURE__ */ jsx(
      ChartSettingsDialog,
      {
        open: showChartSettings,
        onClose: () => setShowChartSettings(false),
        prefs: chartPrefs,
        isDark,
        activePlugins,
        onTogglePlugin,
        onOpenNewsConfig: () => setShowNewsConfigDialog(true),
        hasAccount: !!accountId
      }
    ),
    /* @__PURE__ */ jsx("div", { ref: containerRef, className: "w-full h-full", onContextMenu: handleChartContextMenu }),
    showDrawingTools && (drawingRailHost ? createPortal(/* @__PURE__ */ jsx(DrawingToolRail, { drawingTool, onDrawingTool: (t) => onDrawingToolSelect == null ? void 0 : onDrawingToolSelect(t), magnetActive: magnetMode !== "none", onMagnetToggle, stayActive: stayInDrawingMode, onStayToggle: onStayInDrawingModeToggle }), drawingRailHost) : /* @__PURE__ */ jsx(DrawingToolRail, { drawingTool, onDrawingTool: (t) => onDrawingToolSelect == null ? void 0 : onDrawingToolSelect(t), magnetActive: magnetMode !== "none", onMagnetToggle, stayActive: stayInDrawingMode, onStayToggle: onStayInDrawingModeToggle }))
  ] });
}
function secOrMsToMs(v) {
  return v < 1e12 ? v * 1e3 : v;
}
function candleTimeSec(c) {
  let tMs = NaN;
  if (typeof c.time === "number" && c.time > 0) tMs = secOrMsToMs(c.time);
  else if (typeof c.timestamp === "number" && c.timestamp > 0) tMs = secOrMsToMs(c.timestamp);
  else if (typeof c.timestamp === "string") tMs = Date.parse(c.timestamp);
  return Number.isNaN(tMs) ? NaN : Math.floor(tMs / 1e3);
}
function toCandleRow(c) {
  return {
    time: candleTimeSec(c),
    open: Number(c.open),
    high: Number(c.high),
    low: Number(c.low),
    close: Number(c.close),
    volume: Number(c.volume) || 0
  };
}
function dedupeByTime(sorted) {
  const out = [];
  for (let i = 0; i < sorted.length; i++) {
    const cur = sorted[i];
    const next = sorted[i + 1];
    if (!next || cur.time !== next.time) out.push(cur);
  }
  return out;
}
function useChartData(candles, colors) {
  return useMemo(() => {
    const sorted = candles.map(toCandleRow).filter((c) => !Number.isNaN(c.time) && c.time > 0).sort((a, b) => a.time - b.time);
    const deduped = dedupeByTime(sorted);
    const chartData = deduped.map(({ volume: _v, ...rest }) => rest);
    const volumeData = deduped.map((c) => ({
      time: c.time,
      value: c.volume,
      color: c.close >= c.open ? colors.volumeUp : colors.volumeDown
    }));
    return { chartData, volumeData };
  }, [candles, colors.volumeUp, colors.volumeDown]);
}
const KEY = "oc_chart_templates";
function readAll() {
  try {
    return JSON.parse(safeStorage.getItem(KEY) ?? "[]");
  } catch {
    return [];
  }
}
function writeAll(list) {
  safeStorage.setItem(KEY, JSON.stringify(list));
}
const chartTemplatesApi = {
  list: () => Promise.resolve(readAll()),
  /** Upserts by name (unique per user). */
  save: (name, content, isDefault = false) => {
    const list = readAll().filter((t) => t.name !== name);
    const template = {
      id: crypto.randomUUID(),
      name,
      layoutType: "SINGLE",
      isDefault,
      panels: [content],
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    list.push(template);
    writeAll(list);
    return Promise.resolve(template);
  },
  remove: (id) => {
    writeAll(readAll().filter((t) => t.id !== id));
    return Promise.resolve({ deleted: true });
  }
};
const AUTOSAVE_DEBOUNCE_MS = 1500;
function snapshotContent(prefs, indicators, plugins) {
  const snapshot = {};
  for (const key of TEMPLATE_PREF_KEYS) {
    snapshot[key] = prefs[key];
  }
  return { version: 1, prefs: snapshot, indicators, plugins };
}
function contentToPrefsPatch(content) {
  const patch = {};
  for (const key of TEMPLATE_PREF_KEYS) {
    const value = content.prefs[key];
    if (value !== void 0) patch[key] = value;
  }
  return patch;
}
function useChartTemplates() {
  const queryClient = useQueryClient();
  const { data: templates = [] } = useQuery({
    queryKey: ["chart-templates"],
    queryFn: () => chartTemplatesApi.list(),
    staleTime: 6e4,
    retry: 1
  });
  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["chart-templates"] });
  const save = useMutation({
    mutationFn: (vars) => chartTemplatesApi.save(vars.name, vars.content),
    onSuccess: invalidate,
    onError: () => toast.error("Templates", "Failed to save template")
  });
  const remove = useMutation({
    mutationFn: (id) => chartTemplatesApi.remove(id),
    onSuccess: invalidate,
    onError: () => toast.error("Templates", "Failed to delete template")
  });
  return { templates, save, remove };
}
function useTemplateAutosave(enabled, activeName, content, saveFn) {
  const timerRef = useRef(null);
  const serialized = JSON.stringify(content);
  const skipFirstRef = useRef(true);
  useEffect(() => {
    if (!enabled || !activeName) return;
    if (skipFirstRef.current) {
      skipFirstRef.current = false;
      return;
    }
    if (timerRef.current !== null) window.clearTimeout(timerRef.current);
    timerRef.current = window.setTimeout(() => {
      saveFn({ name: activeName, content: JSON.parse(serialized) });
    }, AUTOSAVE_DEBOUNCE_MS);
    return () => {
      if (timerRef.current !== null) window.clearTimeout(timerRef.current);
    };
  }, [enabled, activeName, serialized, saveFn]);
  useEffect(() => {
    skipFirstRef.current = true;
  }, [activeName]);
}
function MenuRow({
  icon,
  label,
  disabled = false,
  onClick
}) {
  return /* @__PURE__ */ jsxs(
    "button",
    {
      onClick,
      disabled,
      className: "flex w-full items-center gap-2 px-3 py-1.5 text-left text-xs text-foreground hover:bg-secondary disabled:opacity-40 disabled:hover:bg-transparent",
      children: [
        /* @__PURE__ */ jsx("span", { className: "flex h-3.5 w-3.5 items-center justify-center text-muted-foreground", children: icon }),
        /* @__PURE__ */ jsx("span", { className: "truncate", children: label })
      ]
    }
  );
}
function AutosaveRow({ enabled, onToggle }) {
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-3 py-1.5", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-xs text-foreground", children: [
      /* @__PURE__ */ jsx(CloudUpload, { className: "h-3.5 w-3.5 text-muted-foreground" }),
      "Autosave"
    ] }),
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        role: "switch",
        "aria-checked": enabled,
        onClick: onToggle,
        className: cn(
          "inline-flex h-4 w-8 shrink-0 cursor-pointer items-center rounded-full border-0 p-0 transition-colors",
          enabled ? "bg-primary" : "bg-secondary"
        ),
        children: /* @__PURE__ */ jsx(
          "span",
          {
            className: cn(
              "inline-block h-3 w-3 rounded-full bg-white shadow transition-transform",
              enabled ? "translate-x-[18px]" : "translate-x-[2px]"
            )
          }
        )
      }
    )
  ] });
}
function AddTemplateRow({ onAdd }) {
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState("");
  if (!adding) {
    return /* @__PURE__ */ jsx(
      MenuRow,
      {
        icon: /* @__PURE__ */ jsx(Plus, { className: "h-3.5 w-3.5" }),
        label: "Add template",
        onClick: () => setAdding(true)
      }
    );
  }
  const commit = () => {
    const trimmed = name.trim();
    if (trimmed) onAdd(trimmed);
    setAdding(false);
    setName("");
  };
  return /* @__PURE__ */ jsx("div", { className: "px-3 py-1.5", children: /* @__PURE__ */ jsx(
    "input",
    {
      autoFocus: true,
      value: name,
      onChange: (e) => setName(e.target.value),
      onKeyDown: (e) => {
        if (e.key === "Enter") commit();
        if (e.key === "Escape") setAdding(false);
      },
      onBlur: commit,
      placeholder: "Template name…",
      className: "w-full rounded border border-border bg-transparent px-2 py-1 text-xs text-foreground outline-none focus:border-primary"
    }
  ) });
}
function TemplateList({
  templates,
  activeName,
  manageMode,
  onApply,
  onDelete
}) {
  if (templates.length === 0) {
    return /* @__PURE__ */ jsx("div", { className: "px-3 py-2 text-[11px] text-muted-foreground", children: "No templates yet" });
  }
  return /* @__PURE__ */ jsx(Fragment, { children: templates.map((t) => /* @__PURE__ */ jsxs("div", { className: "group flex items-center", children: [
    /* @__PURE__ */ jsxs(
      "button",
      {
        onClick: () => onApply(t),
        className: "flex min-w-0 flex-1 items-center gap-2 px-3 py-1.5 text-left text-xs text-foreground hover:bg-secondary",
        children: [
          /* @__PURE__ */ jsx("span", { className: "flex h-3.5 w-3.5 items-center justify-center text-primary", children: t.name === activeName && /* @__PURE__ */ jsx(Check, { className: "h-3.5 w-3.5" }) }),
          /* @__PURE__ */ jsx("span", { className: "truncate", children: t.name })
        ]
      }
    ),
    manageMode && /* @__PURE__ */ jsx(
      "button",
      {
        onClick: () => onDelete(t),
        title: `Delete "${t.name}"`,
        className: "px-2 text-red-400/70 hover:text-red-400",
        children: /* @__PURE__ */ jsx(Trash2, { className: "h-3.5 w-3.5" })
      }
    )
  ] }, t.id)) });
}
function ChartTemplatesMenu(props) {
  const { activeIndicators, onSetIndicators, activePlugins, onSetPlugins } = props;
  const prefs = useChartPreferences();
  const { templates, save, remove } = useChartTemplates();
  const [open, setOpen] = useState(false);
  const [manageMode, setManageMode] = useState(false);
  const activeName = prefs.activeChartTemplate;
  const autosave = prefs.chartTemplateAutosave;
  const content = snapshotContent(prefs, activeIndicators, activePlugins);
  const { mutate: saveMutate } = save;
  const saveFn = useCallback(
    (vars) => saveMutate(vars),
    [saveMutate]
  );
  useTemplateAutosave(autosave, activeName, content, saveFn);
  const applyTemplate = (t) => {
    const c = t.panels[0];
    if (!c) return;
    updateChartPreferences({ ...contentToPrefsPatch(c), activeChartTemplate: t.name });
    onSetIndicators(c.indicators ?? []);
    onSetPlugins(c.plugins ?? []);
    setOpen(false);
    toast.info("Templates", `Loaded "${t.name}"`);
  };
  const addTemplate = (name) => {
    save.mutate({ name, content });
    updateChartPreferences({ activeChartTemplate: name });
    toast.success("Templates", `Saved "${name}"`);
  };
  const deleteTemplate = (t) => {
    remove.mutate(t.id);
    if (t.name === activeName) updateChartPreferences({ activeChartTemplate: "" });
  };
  return /* @__PURE__ */ jsxs("div", { className: "relative hidden md:block", children: [
    /* @__PURE__ */ jsxs(
      "button",
      {
        onClick: () => setOpen((v) => !v),
        title: "Chart layout templates",
        className: cn(
          "flex items-center gap-1 rounded px-2 py-1 text-xs transition-colors",
          open ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"
        ),
        children: [
          /* @__PURE__ */ jsx(CloudUpload, { className: "h-3.5 w-3.5" }),
          /* @__PURE__ */ jsx("span", { className: "hidden max-w-[110px] truncate lg:inline", children: activeName || "Templates" }),
          /* @__PURE__ */ jsx(ChevronDown, { className: cn("h-3 w-3 transition-transform", open && "rotate-180") })
        ]
      }
    ),
    open && /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("div", { className: "fixed inset-0 z-40", onClick: () => setOpen(false) }),
      /* @__PURE__ */ jsxs("div", { className: "absolute right-0 top-full z-50 mt-1 w-60 rounded-lg border border-border bg-card/95 py-1 shadow-2xl backdrop-blur-xl", children: [
        /* @__PURE__ */ jsx("div", { className: "px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground", children: "Layout templates" }),
        /* @__PURE__ */ jsx(
          AutosaveRow,
          {
            enabled: autosave,
            onToggle: () => updateChartPreferences({ chartTemplateAutosave: !autosave })
          }
        ),
        /* @__PURE__ */ jsx(AddTemplateRow, { onAdd: addTemplate }),
        /* @__PURE__ */ jsx(
          MenuRow,
          {
            icon: /* @__PURE__ */ jsx(Save, { className: "h-3.5 w-3.5" }),
            label: activeName ? `Save "${activeName}"` : "Save template",
            disabled: !activeName || autosave,
            onClick: () => {
              save.mutate({ name: activeName, content });
              toast.success("Templates", `Saved "${activeName}"`);
            }
          }
        ),
        /* @__PURE__ */ jsx(
          MenuRow,
          {
            icon: /* @__PURE__ */ jsx(Trash2, { className: "h-3.5 w-3.5" }),
            label: manageMode ? "Done managing" : "Manage templates…",
            onClick: () => setManageMode((v) => !v)
          }
        ),
        /* @__PURE__ */ jsx("div", { className: "my-1 border-t border-border" }),
        /* @__PURE__ */ jsx("div", { className: "px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground", children: "Recently used" }),
        /* @__PURE__ */ jsx("div", { className: "max-h-48 overflow-y-auto", children: /* @__PURE__ */ jsx(
          TemplateList,
          {
            templates,
            activeName,
            manageMode,
            onApply: applyTemplate,
            onDelete: deleteTemplate
          }
        ) })
      ] })
    ] })
  ] });
}
const SPEED_OPTIONS = [0.5, 1, 2, 5, 10];
function formatReplayTime(epochMs) {
  return new Date(epochMs).toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  });
}
function ReplayHUD({ accountId }) {
  const { isReplaying, replayPaused, replaySpeed, replayCursorTimestamp, setReplaySessionDate } = useTradingStore();
  const storageKey = `replay_session_date_${accountId}`;
  const [sessionDate, setSessionDate] = useState(
    () => safeSession.getItem(storageKey) ?? toLocalDateString()
  );
  const handleDateChange = (date) => {
    setSessionDate(date);
    safeSession.setItem(storageKey, date);
  };
  const handleStart = () => {
    setReplaySessionDate(sessionDate);
    api.replayStart(accountId, sessionDate, replaySpeed).catch(() => null);
  };
  const handlePause = () => {
    api.replayPause(accountId, sessionDate).catch(() => null);
  };
  const handleResume = () => {
    api.replayResume(accountId, sessionDate).catch(() => null);
  };
  const handleStop = () => {
    api.replayStop(accountId, sessionDate).catch(() => null);
  };
  const handleSpeed = (speed) => {
    if (!isReplaying) return;
    api.replaySetSpeed(accountId, sessionDate, speed).catch(() => null);
  };
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-orange-500/10 border border-orange-500/30 shrink-0", children: [
    /* @__PURE__ */ jsx("span", { className: "text-orange-500 text-[10px] font-bold tracking-wider uppercase hidden sm:inline", children: "Replay" }),
    !isReplaying ? /* @__PURE__ */ jsx(
      "input",
      {
        type: "date",
        value: sessionDate,
        onChange: (e) => handleDateChange(e.target.value),
        max: toLocalDateString(),
        className: "text-[11px] bg-transparent border border-border rounded px-1 py-0 text-foreground w-[7.5rem] tabular-nums"
      }
    ) : replayCursorTimestamp != null && /* @__PURE__ */ jsx("span", { className: "text-[11px] font-mono text-orange-400 tabular-nums", children: formatReplayTime(replayCursorTimestamp) }),
    !isReplaying ? /* @__PURE__ */ jsx(
      "button",
      {
        onClick: handleStart,
        title: "Start Replay",
        className: "p-0.5 rounded hover:bg-orange-500/20 text-orange-500",
        children: /* @__PURE__ */ jsx(Play, { className: "h-3.5 w-3.5 fill-current" })
      }
    ) : replayPaused ? /* @__PURE__ */ jsx(
      "button",
      {
        onClick: handleResume,
        title: "Resume",
        className: "p-0.5 rounded hover:bg-orange-500/20 text-orange-500",
        children: /* @__PURE__ */ jsx(Play, { className: "h-3.5 w-3.5 fill-current" })
      }
    ) : /* @__PURE__ */ jsx(
      "button",
      {
        onClick: handlePause,
        title: "Pause",
        className: "p-0.5 rounded hover:bg-orange-500/20 text-orange-500",
        children: /* @__PURE__ */ jsx(Pause, { className: "h-3.5 w-3.5 fill-current" })
      }
    ),
    isReplaying && /* @__PURE__ */ jsx(
      "button",
      {
        onClick: handleStop,
        title: "Stop Replay",
        className: "p-0.5 rounded hover:bg-red-500/20 text-red-400",
        children: /* @__PURE__ */ jsx(Square, { className: "h-3.5 w-3.5 fill-current" })
      }
    ),
    /* @__PURE__ */ jsx("div", { className: "flex items-center gap-0.5", children: SPEED_OPTIONS.map((s) => /* @__PURE__ */ jsxs(
      "button",
      {
        onClick: () => handleSpeed(s),
        disabled: !isReplaying,
        className: cn(
          "px-1 py-0.5 rounded text-[10px] font-medium transition-all",
          replaySpeed === s ? "bg-orange-500 text-white" : "text-muted-foreground hover:bg-orange-500/20 hover:text-orange-500 disabled:opacity-40 disabled:cursor-default"
        ),
        children: [
          s,
          "x"
        ]
      },
      s
    )) })
  ] });
}
function ChartToolbar({
  selectedSymbol,
  symbols,
  onSymbolChange,
  timeframe,
  onTimeframeChange,
  activeIndicators,
  onToggleIndicator,
  showIndicatorMenu,
  onToggleIndicatorMenu,
  drawingTool,
  onDrawingTool,
  drawings,
  onClearDrawings,
  rightPanel,
  onRightPanel,
  showRightPanel,
  onToggleRightPanel,
  tick,
  symbolInfo,
  isReplaying = false,
  replayAccountId,
  activePlugins = [],
  onTogglePlugin,
  onSetIndicators,
  onSetPlugins,
  magnetMode = "none",
  onCycleMagnet,
  stayInDrawingMode = false,
  onToggleStayInDrawingMode
}) {
  var _a, _b;
  const [showSymbolSearch, setShowSymbolSearch] = useState(false);
  const [symbolFilter, setSymbolFilter] = useState("");
  const filteredSymbols = symbols.filter(
    (s) => s.name.toLowerCase().includes(symbolFilter.toLowerCase()) || (s.category || "").toLowerCase().includes(symbolFilter.toLowerCase())
  );
  const spread = tick ? ((tick.ask - tick.bid) * 10 ** getPipDigits(symbolInfo, selectedSymbol)).toFixed(1) : "--";
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 px-2 py-1 border-b border-border bg-card text-xs shrink-0 overflow-x-auto md:overflow-visible flex-nowrap md:flex-wrap no-scrollbar", children: [
    /* @__PURE__ */ jsxs("div", { className: "relative shrink-0", children: [
      /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: () => setShowSymbolSearch((v) => !v),
          className: "flex items-center gap-1.5 px-2.5 py-1.5 rounded-md hover:bg-secondary font-bold text-sm tracking-tight",
          children: [
            selectedSymbol,
            /* @__PURE__ */ jsx(ChevronDown, { className: "h-3 w-3 opacity-60" })
          ]
        }
      ),
      showSymbolSearch && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(
          "div",
          {
            className: "md:hidden fixed inset-0 z-[100] bg-black/60",
            onClick: () => setShowSymbolSearch(false),
            children: /* @__PURE__ */ jsxs(
              "div",
              {
                className: "fixed inset-x-0 top-0 bg-card border-b border-border shadow-2xl flex flex-col max-h-[85vh]",
                onClick: (e) => e.stopPropagation(),
                children: [
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 p-3 border-b border-border", children: [
                    /* @__PURE__ */ jsx(Search, { className: "h-4 w-4 text-muted-foreground shrink-0" }),
                    /* @__PURE__ */ jsx(
                      "input",
                      {
                        autoFocus: true,
                        placeholder: "Search symbols...",
                        value: symbolFilter,
                        onChange: (e) => setSymbolFilter(e.target.value),
                        className: "flex-1 bg-transparent text-base outline-none"
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      "button",
                      {
                        onClick: () => {
                          setShowSymbolSearch(false);
                          setSymbolFilter("");
                        },
                        className: "p-1.5 rounded-md hover:bg-secondary",
                        children: /* @__PURE__ */ jsx(X, { className: "h-4 w-4" })
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsx("div", { className: "flex-1 overflow-y-auto overscroll-contain", children: filteredSymbols.length === 0 ? /* @__PURE__ */ jsxs("div", { className: "px-4 py-8 text-center text-sm text-muted-foreground", children: [
                    "No symbols match “",
                    symbolFilter,
                    "”"
                  ] }) : filteredSymbols.map((s) => /* @__PURE__ */ jsxs(
                    "button",
                    {
                      onClick: () => {
                        onSymbolChange(s.name);
                        setShowSymbolSearch(false);
                        setSymbolFilter("");
                      },
                      className: cn(
                        "w-full flex items-center justify-between px-4 py-3 text-base hover:bg-secondary border-b border-border/40 active:bg-secondary",
                        s.name === selectedSymbol && "bg-secondary"
                      ),
                      children: [
                        /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-start", children: [
                          /* @__PURE__ */ jsx("span", { className: "font-semibold", children: s.name }),
                          s.displayName && s.displayName !== s.name && /* @__PURE__ */ jsx("span", { className: "text-xs text-muted-foreground", children: s.displayName })
                        ] }),
                        /* @__PURE__ */ jsx("span", { className: "text-muted-foreground text-xs uppercase tracking-wide", children: s.category || s.assetClass })
                      ]
                    },
                    s.id || s.name
                  )) })
                ]
              }
            )
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "hidden md:block absolute top-full left-0 z-50 mt-1 w-64 bg-card border border-border rounded-lg shadow-xl overflow-hidden", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              autoFocus: true,
              placeholder: "Search symbols...",
              value: symbolFilter,
              onChange: (e) => setSymbolFilter(e.target.value),
              className: "w-full px-3 py-2 text-sm border-b border-border bg-card"
            }
          ),
          /* @__PURE__ */ jsx("div", { className: "max-h-60 overflow-y-auto", children: filteredSymbols.map((s) => /* @__PURE__ */ jsxs(
            "button",
            {
              onClick: () => {
                onSymbolChange(s.name);
                setShowSymbolSearch(false);
                setSymbolFilter("");
              },
              className: cn(
                "w-full flex items-center justify-between px-3 py-1.5 text-sm hover:bg-secondary",
                s.name === selectedSymbol && "bg-secondary"
              ),
              children: [
                /* @__PURE__ */ jsx("span", { className: "font-medium", children: s.name }),
                /* @__PURE__ */ jsx("span", { className: "text-muted-foreground text-xs", children: s.category })
              ]
            },
            s.id || s.name
          )) })
        ] })
      ] })
    ] }),
    tick && /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 md:gap-1.5 px-1.5 md:px-2 border-l border-r border-border shrink-0", children: [
      /* @__PURE__ */ jsx("span", { className: "inline-flex items-center gap-1 px-1 md:px-1.5 py-0.5 rounded bg-[#0ecb81]/15 text-[#0ecb81] font-mono font-bold text-[12px] md:text-[13px] tabular-nums tracking-tight", children: formatNumber(
        tick.bid,
        (symbolInfo == null ? void 0 : symbolInfo.tickSize) ? ((_a = String(symbolInfo.tickSize).split(".")[1]) == null ? void 0 : _a.length) || 2 : 5
      ) }),
      /* @__PURE__ */ jsx("span", { className: "text-muted-foreground text-[10px] font-medium", children: "/" }),
      /* @__PURE__ */ jsx("span", { className: "inline-flex items-center gap-1 px-1 md:px-1.5 py-0.5 rounded bg-[#f6465d]/15 text-[#f6465d] font-mono font-bold text-[12px] md:text-[13px] tabular-nums tracking-tight", children: formatNumber(
        tick.ask,
        (symbolInfo == null ? void 0 : symbolInfo.tickSize) ? ((_b = String(symbolInfo.tickSize).split(".")[1]) == null ? void 0 : _b.length) || 2 : 5
      ) }),
      /* @__PURE__ */ jsxs("span", { className: "text-muted-foreground text-[10px] font-medium ml-0.5 hidden md:inline", children: [
        "Sprd: ",
        spread
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex items-center gap-0.5 ml-1 shrink-0", children: TIMEFRAMES.map((tf) => /* @__PURE__ */ jsx(
      "button",
      {
        onClick: () => onTimeframeChange(tf),
        disabled: isReplaying,
        title: isReplaying ? "Timeframe is fixed to 1m during replay" : void 0,
        className: cn(
          "px-2 py-1 rounded-md text-xs font-medium transition-all",
          tf === timeframe ? "bg-primary text-primary-foreground shadow-sm" : "hover:bg-secondary/80 text-muted-foreground hover:text-foreground",
          isReplaying && "opacity-40 cursor-default"
        ),
        children: tf
      },
      tf
    )) }),
    replayAccountId != null && /* @__PURE__ */ jsx(ReplayHUD, { accountId: replayAccountId }),
    onSetIndicators && onSetPlugins && /* @__PURE__ */ jsx(
      ChartTemplatesMenu,
      {
        activeIndicators,
        onSetIndicators,
        activePlugins,
        onSetPlugins
      }
    ),
    /* @__PURE__ */ jsx("div", { className: "h-4 border-l border-border mx-1 hidden md:block" }),
    /* @__PURE__ */ jsxs("div", { className: "relative hidden md:block", children: [
      /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: onToggleIndicatorMenu,
          className: cn(
            "flex items-center gap-1 px-2 py-1 rounded text-xs",
            activeIndicators.length > 0 ? "bg-primary/20 text-primary" : "hover:bg-secondary text-muted-foreground"
          ),
          children: [
            /* @__PURE__ */ jsx(BarChart3, { className: "h-3 w-3" }),
            "Indicators",
            activeIndicators.length > 0 && /* @__PURE__ */ jsx("span", { className: "bg-primary text-primary-foreground rounded-full px-1 text-[9px]", children: activeIndicators.length })
          ]
        }
      ),
      showIndicatorMenu && /* @__PURE__ */ jsx("div", { className: "absolute top-full left-0 z-50 mt-1 w-64 bg-card border border-border rounded-lg shadow-xl p-2 space-y-0.5", children: INDICATOR_REGISTRY.map((ind) => /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: () => onToggleIndicator(ind.type),
          className: cn(
            "w-full flex items-center gap-2 px-2 py-1.5 rounded text-sm hover:bg-secondary text-left",
            activeIndicators.includes(ind.type) && "bg-secondary"
          ),
          children: [
            /* @__PURE__ */ jsx(
              "span",
              {
                className: "w-2 h-2 rounded-full shrink-0",
                style: { backgroundColor: ind.color }
              }
            ),
            /* @__PURE__ */ jsx("span", { className: "flex-1", children: ind.label }),
            /* @__PURE__ */ jsx("span", { className: "text-[10px] text-muted-foreground", children: ind.pane })
          ]
        },
        ind.type
      )) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "hidden md:flex items-center gap-0.5", children: [
      /* @__PURE__ */ jsx(
        DrawingToolsDropdown,
        {
          drawingTool,
          onDrawingTool,
          drawings,
          onClearDrawings,
          magnetMode,
          onCycleMagnet,
          stayInDrawingMode,
          onToggleStayInDrawingMode
        }
      ),
      onTogglePlugin && /* @__PURE__ */ jsx(PluginsDropdown, { activePlugins, onTogglePlugin })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex-1 hidden md:block" }),
    /* @__PURE__ */ jsxs("div", { className: "hidden md:flex items-center gap-0.5", children: [
      /* @__PURE__ */ jsx(
        ToolButton,
        {
          icon: ArrowUpDown,
          tooltip: "Order Panel",
          active: showRightPanel && rightPanel === "order",
          onClick: () => onRightPanel("order")
        }
      ),
      /* @__PURE__ */ jsx(
        ToolButton,
        {
          icon: Layers,
          tooltip: "Depth of Market",
          active: showRightPanel && rightPanel === "dom",
          onClick: () => onRightPanel("dom")
        }
      ),
      /* @__PURE__ */ jsx(
        ToolButton,
        {
          icon: BarChart3,
          tooltip: "Watchlist",
          active: showRightPanel && rightPanel === "watchlist",
          onClick: () => onRightPanel("watchlist")
        }
      ),
      /* @__PURE__ */ jsx(
        ToolButton,
        {
          icon: Newspaper,
          tooltip: "News",
          active: showRightPanel && rightPanel === "news",
          onClick: () => onRightPanel("news")
        }
      ),
      /* @__PURE__ */ jsx(
        ToolButton,
        {
          icon: Star,
          tooltip: "TradingView Analysis",
          active: showRightPanel && rightPanel === "tv-analysis",
          onClick: () => onRightPanel("tv-analysis")
        }
      ),
      /* @__PURE__ */ jsx("div", { className: "h-4 border-l border-border mx-1" }),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: onToggleRightPanel,
          className: "px-1.5 py-1 rounded hover:bg-secondary text-muted-foreground",
          children: /* @__PURE__ */ jsx(Maximize2, { className: "h-3 w-3" })
        }
      )
    ] })
  ] });
}
function ToolButton({
  icon: Icon,
  tooltip,
  active,
  onClick
}) {
  return /* @__PURE__ */ jsx(
    "button",
    {
      onClick,
      title: tooltip,
      className: cn(
        "px-1.5 py-1 rounded",
        active ? "bg-primary/20 text-primary" : "hover:bg-secondary text-muted-foreground"
      ),
      children: /* @__PURE__ */ jsx(Icon, { className: "h-3.5 w-3.5" })
    }
  );
}
const CHART_PLUGIN_ITEMS = [
  { id: "crosshair", icon: Crosshair, label: "Crosshair Highlight" },
  { id: "session", icon: Clock, label: "Session Highlighting" },
  { id: "session-breaks", icon: CalendarDays, label: "Session Breaks" },
  { id: "bands", icon: AlignCenter, label: "Bands Indicator" },
  { id: "tooltip", icon: Info, label: "OHLCV Tooltip" },
  { id: "delta-tooltip", icon: Activity, label: "Delta Tooltip" }
];
function PluginsDropdown({
  activePlugins,
  onTogglePlugin
}) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef(null);
  useEffect(() => {
    if (!open) return;
    const handler = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);
  const isActive = activePlugins.length > 0;
  return /* @__PURE__ */ jsxs("div", { ref: containerRef, className: "relative", children: [
    /* @__PURE__ */ jsxs(
      "button",
      {
        onClick: () => setOpen((v) => !v),
        title: "Chart Plugins",
        className: cn(
          "flex items-center gap-1 px-1.5 py-1 rounded",
          isActive ? "bg-primary/20 text-primary" : "hover:bg-secondary text-muted-foreground"
        ),
        children: [
          /* @__PURE__ */ jsx(SlidersHorizontal, { className: "h-3.5 w-3.5" }),
          isActive && /* @__PURE__ */ jsx("span", { className: "bg-primary text-primary-foreground rounded-full px-1 text-[9px]", children: activePlugins.length })
        ]
      }
    ),
    open && /* @__PURE__ */ jsx("div", { className: "absolute top-full left-0 z-50 mt-1 bg-card border border-border rounded-lg shadow-xl py-1 min-w-[190px]", children: CHART_PLUGIN_ITEMS.map(({ id, icon: Icon, label }) => {
      const isOn = activePlugins.includes(id);
      return /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: () => onTogglePlugin(id),
          className: cn(
            "w-full flex items-center gap-2.5 px-3 py-1.5 text-sm hover:bg-secondary text-left",
            isOn && "bg-secondary text-primary"
          ),
          children: [
            /* @__PURE__ */ jsx(Icon, { className: "h-3.5 w-3.5 shrink-0" }),
            /* @__PURE__ */ jsx("span", { className: "flex-1", children: label }),
            isOn && /* @__PURE__ */ jsx("span", { className: "text-[10px] text-primary font-medium", children: "ON" })
          ]
        },
        id
      );
    }) })
  ] });
}
const DRAWING_SHORTCUTS = {
  horizontal: "Alt+H",
  trendline: "Alt+T",
  fibonacci: "Alt+F",
  rectangle: "Alt+R",
  measure: "Alt+M"
};
const DRAWING_TOOLS = DRAWING_TOOL_GROUPS.flatMap(
  (group) => group.tools.map((tool) => ({ ...tool, shortcut: DRAWING_SHORTCUTS[tool.tool] ?? "" }))
);
function DrawingOptionToggle({
  icon: Icon,
  label,
  enabled,
  onToggle
}) {
  if (!onToggle) return null;
  return /* @__PURE__ */ jsxs(
    "button",
    {
      type: "button",
      onClick: onToggle,
      className: cn(
        "w-full flex items-center gap-2.5 px-3 py-1.5 text-sm hover:bg-secondary text-left",
        enabled && "text-primary"
      ),
      children: [
        /* @__PURE__ */ jsx(Icon, { className: "h-3.5 w-3.5 shrink-0" }),
        /* @__PURE__ */ jsx("span", { className: "flex-1", children: label }),
        enabled && /* @__PURE__ */ jsx("span", { className: "text-[10px] text-primary font-medium", children: "ON" })
      ]
    }
  );
}
function DrawingToolsDropdown({
  drawingTool,
  onDrawingTool,
  drawings,
  onClearDrawings,
  magnetMode,
  onCycleMagnet,
  stayInDrawingMode,
  onToggleStayInDrawingMode
}) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef(null);
  useEffect(() => {
    if (!open) return;
    const handler = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);
  const isActive = drawingTool !== "none";
  const handleSelect = (t) => {
    onDrawingTool(drawingTool === t ? "none" : t);
    setOpen(false);
  };
  const handleClear = () => {
    onClearDrawings();
    setOpen(false);
  };
  return /* @__PURE__ */ jsxs("div", { ref: containerRef, className: "relative", children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        onClick: () => setOpen((v) => !v),
        title: "Drawing Tools",
        className: cn(
          "px-1.5 py-1 rounded",
          isActive ? "bg-primary/20 text-primary" : "hover:bg-secondary text-muted-foreground"
        ),
        children: /* @__PURE__ */ jsx(Pencil, { className: "h-3.5 w-3.5" })
      }
    ),
    open && /* @__PURE__ */ jsxs("div", { className: "absolute top-full left-0 z-50 mt-1 bg-card border border-border rounded-lg shadow-xl py-1 min-w-[190px]", children: [
      DRAWING_TOOLS.map(({ tool, icon: Icon, label, shortcut }) => /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: () => handleSelect(tool),
          className: cn(
            "w-full flex items-center gap-2.5 px-3 py-1.5 text-sm hover:bg-secondary text-left",
            drawingTool === tool && "bg-secondary text-primary"
          ),
          children: [
            /* @__PURE__ */ jsx(Icon, { className: "h-3.5 w-3.5 shrink-0" }),
            /* @__PURE__ */ jsx("span", { className: "flex-1", children: label }),
            /* @__PURE__ */ jsx("span", { className: "text-[10px] text-muted-foreground/60", children: shortcut })
          ]
        },
        tool
      )),
      /* @__PURE__ */ jsx("div", { className: "my-1 border-t border-border" }),
      /* @__PURE__ */ jsx(
        DrawingOptionToggle,
        {
          icon: Magnet,
          label: magnetMode === "strong" ? "Magnet: strong" : magnetMode === "weak" ? "Magnet: weak" : "Magnet: off",
          enabled: magnetMode !== "none",
          onToggle: onCycleMagnet
        }
      ),
      /* @__PURE__ */ jsx(
        DrawingOptionToggle,
        {
          icon: Repeat,
          label: "Stay in drawing mode",
          enabled: stayInDrawingMode,
          onToggle: onToggleStayInDrawingMode
        }
      ),
      drawings.length > 0 && /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx("div", { className: "my-1 border-t border-border" }),
        /* @__PURE__ */ jsxs(
          "button",
          {
            onClick: handleClear,
            className: "w-full flex items-center gap-2.5 px-3 py-1.5 text-sm hover:bg-secondary text-muted-foreground text-left",
            children: [
              /* @__PURE__ */ jsx(Trash2, { className: "h-3.5 w-3.5 shrink-0" }),
              "Clear All"
            ]
          }
        )
      ] })
    ] })
  ] });
}
function depthAt(symbol, price, spread, base, range) {
  const bucket = spread > 0 ? Math.round(price / spread) : Math.round(price);
  let hash = 2166136261 ^ bucket;
  for (let i = 0; i < symbol.length; i += 1) {
    hash = Math.imul(hash ^ symbol.charCodeAt(i), 16777619);
  }
  const unit = (hash >>> 0) % 1e3 / 1e3;
  return Math.floor(unit * range + base);
}
function DOMPanel({
  symbol,
  tick
}) {
  const levels = useMemo(() => {
    if (!tick) return [];
    const mid = (tick.bid + tick.ask) / 2;
    const step = tick.ask - tick.bid || 1e-4;
    const result = [];
    for (let i = 10; i >= 1; i--) {
      const price = mid + step * i;
      result.push({
        price,
        bidSize: 0,
        askSize: depthAt(symbol, price, step, 5, 50),
        type: "ask"
      });
    }
    result.push({
      price: tick.ask,
      bidSize: 0,
      askSize: depthAt(symbol, tick.ask, step, 20, 100),
      type: "ask"
    });
    result.push({
      price: tick.bid,
      bidSize: depthAt(symbol, tick.bid, step, 20, 100),
      askSize: 0,
      type: "bid"
    });
    for (let i = 1; i <= 10; i++) {
      const price = mid - step * i;
      result.push({
        price,
        bidSize: depthAt(symbol, price, step, 5, 50),
        askSize: 0,
        type: "bid"
      });
    }
    return result;
  }, [symbol, tick]);
  const maxSize = Math.max(...levels.map((l) => Math.max(l.bidSize, l.askSize)), 1);
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col h-full", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-3 py-2 border-b border-border bg-secondary", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "Depth of Market" }),
      /* @__PURE__ */ jsx("span", { className: "text-xs font-semibold", children: symbol })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex-1 overflow-y-auto", children: /* @__PURE__ */ jsxs("table", { className: "w-full text-[11px]", children: [
      /* @__PURE__ */ jsx("thead", { className: "sticky top-0 bg-card z-10", children: /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx("th", { className: "text-right w-[30%]", children: "Bid Size" }),
        /* @__PURE__ */ jsx("th", { className: "text-center w-[40%]", children: "Price" }),
        /* @__PURE__ */ jsx("th", { className: "text-left w-[30%]", children: "Ask Size" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { children: levels.map((l, i) => /* @__PURE__ */ jsxs("tr", { className: "relative hover:bg-secondary/50", children: [
        /* @__PURE__ */ jsx("td", { className: "text-right relative", children: l.bidSize > 0 && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(
            "div",
            {
              className: "absolute inset-y-0 right-0 bg-buy/20",
              style: { width: `${l.bidSize / maxSize * 100}%` }
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "relative text-buy", children: l.bidSize })
        ] }) }),
        /* @__PURE__ */ jsx(
          "td",
          {
            className: cn(
              "text-center font-mono",
              l.type === "ask" ? "text-sell" : "text-buy"
            ),
            children: formatNumber(l.price, 5)
          }
        ),
        /* @__PURE__ */ jsx("td", { className: "text-left relative", children: l.askSize > 0 && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(
            "div",
            {
              className: "absolute inset-y-0 left-0 bg-sell/20",
              style: { width: `${l.askSize / maxSize * 100}%` }
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "relative text-sell", children: l.askSize })
        ] }) })
      ] }, i)) })
    ] }) })
  ] });
}
const LIVE_TICK_GRACE_MS = 3 * 6e4;
const STARTUP_HOLDOFF_MS = 1e4;
const DAY_MAP = {
  Sun: 0,
  Mon: 1,
  Tue: 2,
  Wed: 3,
  Thu: 4,
  Fri: 5,
  Sat: 6
};
function getTimeInZone(date, timezone) {
  var _a, _b, _c, _d, _e;
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: timezone,
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  }).formatToParts(date);
  const day = DAY_MAP[((_a = parts.find((p) => p.type === "weekday")) == null ? void 0 : _a.value) ?? ""] ?? date.getUTCDay();
  const h = ((_c = (_b = parts.find((p) => p.type === "hour")) == null ? void 0 : _b.value) == null ? void 0 : _c.padStart(2, "0")) ?? "00";
  const m = ((_e = (_d = parts.find((p) => p.type === "minute")) == null ? void 0 : _d.value) == null ? void 0 : _e.padStart(2, "0")) ?? "00";
  return { day, time: `${h}:${m}` };
}
function isInWindow(windows, tz, date) {
  const { day: currentDay, time: currentTime } = getTimeInZone(date, tz);
  for (const w of windows) {
    const crossesMidnight = w.closeTime <= w.openTime;
    if (crossesMidnight) {
      if (w.dayOfWeek === currentDay && currentTime >= w.openTime) return true;
      const prev = (currentDay + 6) % 7;
      if (w.dayOfWeek === prev && currentTime < w.closeTime) return true;
    } else {
      if (w.dayOfWeek === currentDay && currentTime >= w.openTime && (w.closeTime === "24:00" || currentTime < w.closeTime))
        return true;
    }
  }
  return false;
}
function isForexDefaultOpen(date) {
  const day = date.getUTCDay();
  const hour = date.getUTCHours();
  if (day === 6) return false;
  if (day === 0 && hour < 22) return false;
  if (day === 5 && hour >= 22) return false;
  return true;
}
function msUntilNextOpen(windows, tz, category, now) {
  if ((category == null ? void 0 : category.toUpperCase()) === "CRYPTO") return null;
  for (let m = 1; m <= 10080; m++) {
    const candidate = new Date(now.getTime() + m * 6e4);
    const open = windows.length > 0 ? isInWindow(windows, tz, candidate) : isForexDefaultOpen(candidate);
    if (open) return m * 6e4;
  }
  return null;
}
function formatCountdown(ms) {
  const totalSeconds = Math.floor(ms / 1e3);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor(totalSeconds % 86400 / 3600);
  const minutes = Math.floor(totalSeconds % 3600 / 60);
  const seconds = totalSeconds % 60;
  const parts = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0 || days > 0) parts.push(`${hours}h`);
  if (days === 0) parts.push(`${minutes}m ${seconds.toString().padStart(2, "0")}s`);
  return parts.join(" ");
}
function MarketClosedBanner({ symbolInfo }) {
  const [now, setNow] = useState(() => /* @__PURE__ */ new Date());
  const [mountedAt] = useState(() => Date.now());
  const ticks = useTradingStore((s) => s.ticks);
  useEffect(() => {
    const id = setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
    return () => clearInterval(id);
  }, []);
  if (!symbolInfo) return null;
  const category = symbolInfo.category ?? "";
  if (category.toUpperCase() === "CRYPTO") return null;
  const nowMs = now.getTime();
  const symbolTick = ticks[symbolInfo.name ?? ""];
  if (symbolTick && nowMs - symbolTick.timestamp < LIVE_TICK_GRACE_MS) return null;
  if (!symbolTick && nowMs - mountedAt < STARTUP_HOLDOFF_MS) return null;
  const tradingHours = symbolInfo.tradingHours ?? [];
  const tz = symbolInfo.sessionTimezone ?? "UTC";
  const isOpen = tradingHours.length > 0 ? isInWindow(tradingHours, tz, now) : isForexDefaultOpen(now);
  if (isOpen) return null;
  const msUntilOpen = msUntilNextOpen(tradingHours, tz, category, now);
  return /* @__PURE__ */ jsxs(
    "div",
    {
      role: "status",
      "aria-live": "polite",
      className: "flex items-center justify-center gap-2 px-3 py-1.5 bg-amber-500/10 border-b border-amber-500/20 text-amber-600 dark:text-amber-400 text-xs font-medium",
      children: [
        /* @__PURE__ */ jsx(Clock, { className: "h-3 w-3 shrink-0" }),
        /* @__PURE__ */ jsxs("span", { children: [
          "Market closed",
          msUntilOpen != null && /* @__PURE__ */ jsxs(Fragment, { children: [
            " ",
            "· Opens in",
            " ",
            /* @__PURE__ */ jsx("span", { className: "font-mono tabular-nums", children: formatCountdown(msUntilOpen - ((/* @__PURE__ */ new Date()).getTime() - now.getTime())) })
          ] })
        ] })
      ]
    }
  );
}
function OrderPanel({
  symbol,
  symbolInfo,
  tick,
  accountId,
  oneClick,
  onToggleOneClick,
  onConfirmOrder,
  accountBalance,
  isFeedConnected = true,
  soundMuted,
  onToggleMute,
  onOrderSuccess
}) {
  var _a, _b;
  const isDemo = useAuthStore((s) => s.isDemo);
  const [side, setSide] = useState("BUY");
  const [orderType, setOrderType] = useState("MARKET");
  const [quantity, setQuantity] = useState(() => {
    const prefs = readTraderPrefs$1();
    const raw = prefs.defaultQty;
    if (raw) {
      const n = parseFloat(raw);
      if (Number.isFinite(n) && n > 0) return String(Math.round(n * 100) / 100);
    }
    return "0.1";
  });
  const [price, setPrice] = useState("");
  const [stopPrice, setStopPrice] = useState("");
  const [takeProfit, setTakeProfit] = useState("");
  const [stopLoss, setStopLoss] = useState("");
  const placeOrder = usePlaceOrder();
  const handleSubmit = () => {
    if (!isFeedConnected) {
      toast.warning("No Data Feed", "Cannot place orders while disconnected from the data feed");
      return;
    }
    if (!accountId) {
      toast.warning("No Account", "Please select a trading account first");
      return;
    }
    const qty = parseFloat(quantity);
    if (isNaN(qty) || qty <= 0) {
      toast.warning("Invalid Quantity", "Quantity must be a positive number");
      return;
    }
    if (qty > 1e3) {
      toast.warning("Invalid Quantity", "Maximum quantity is 1000 lots");
      return;
    }
    if (orderType === "LIMIT" && (!price || isNaN(parseFloat(price)) || parseFloat(price) <= 0)) {
      toast.warning("Missing Price", "Limit orders require a valid price");
      return;
    }
    if (orderType === "STOP" && (!stopPrice || isNaN(parseFloat(stopPrice)) || parseFloat(stopPrice) <= 0)) {
      toast.warning("Missing Stop Price", "Stop orders require a valid stop price");
      return;
    }
    const effectiveType = orderType;
    const input = {
      accountId,
      symbol,
      side,
      type: effectiveType,
      quantity: qty
    };
    if (orderType === "LIMIT" && price) input.price = parseFloat(price);
    if (orderType === "STOP" && stopPrice) input.stopPrice = parseFloat(stopPrice);
    if (takeProfit) input.takeProfit = parseFloat(takeProfit) || void 0;
    if (stopLoss) input.stopLoss = parseFloat(stopLoss) || void 0;
    const doSubmit = () => placeOrder.mutateAsync(input, {
      onSuccess: () => {
        toast.success("Order Sent", `${side} ${qty} ${symbol} (${effectiveType})`);
        onOrderSuccess == null ? void 0 : onOrderSuccess();
      },
      onError: (err) => {
        var _a2, _b2;
        const e = err;
        const code = ((_a2 = e == null ? void 0 : e.error) == null ? void 0 : _a2.code) ?? (e == null ? void 0 : e.code);
        const msg = ((_b2 = e == null ? void 0 : e.error) == null ? void 0 : _b2.message) || (e == null ? void 0 : e.message) || "Failed to place order";
        if (code === "ACCOUNT_PASSED") {
          toast.success("Account Passed!", msg);
        } else if (code === "ACCOUNT_FAILED") {
          toast.error("Account Failed", msg);
        } else if (code === "REQUEST_TIMEOUT") {
          toast.error(
            "Order Timed Out",
            "The server didn't respond in time. Check your connection and try again."
          );
        } else {
          toast.error("Order Failed", msg);
        }
      }
    });
    if (oneClick && orderType === "MARKET") {
      doSubmit().catch(() => {
      });
      return;
    }
    if (onConfirmOrder) {
      onConfirmOrder({
        accountId,
        symbol,
        side,
        type: effectiveType,
        quantity: qty,
        price: input.price,
        stopPrice: input.stopPrice,
        takeProfit: input.takeProfit,
        stopLoss: input.stopLoss,
        _submit: doSubmit
      });
      return;
    }
    doSubmit().catch(() => {
    });
  };
  const quickQty = [0.01, 0.05, 0.1, 0.5, 1];
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col h-full", "data-testid": "order-form", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-3 py-2 border-b border-border bg-secondary", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "New Order" }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: onToggleMute,
            className: cn(
              "flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-medium border transition-colors",
              !soundMuted ? "bg-accent/15 text-accent border-accent/30" : "text-muted-foreground border-border hover:bg-secondary"
            ),
            title: soundMuted ? "Unmute trade sounds" : "Mute trade sounds",
            children: soundMuted ? /* @__PURE__ */ jsx(VolumeX, { className: "h-2.5 w-2.5" }) : /* @__PURE__ */ jsx(Volume2, { className: "h-2.5 w-2.5" })
          }
        ),
        /* @__PURE__ */ jsxs(
          "button",
          {
            onClick: onToggleOneClick,
            className: cn(
              "flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-medium border transition-colors",
              oneClick ? "bg-buy/15 text-buy border-buy/30" : "text-muted-foreground border-border hover:bg-secondary"
            ),
            title: "One-click trading: skip confirmation for market orders",
            children: [
              /* @__PURE__ */ jsx(Zap, { className: "h-2.5 w-2.5" }),
              "1-Click"
            ]
          }
        ),
        /* @__PURE__ */ jsx("span", { className: "text-xs font-semibold", children: symbol })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex-1 overflow-y-auto p-3 space-y-3", children: [
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-1", children: [
        /* @__PURE__ */ jsxs(
          Button,
          {
            variant: side === "BUY" ? "buy" : "outline",
            size: "sm",
            onClick: () => setSide("BUY"),
            className: "text-xs",
            children: [
              /* @__PURE__ */ jsx(TrendingUp, { className: "h-3 w-3 mr-1" }),
              "BUY ",
              tick ? formatNumber(tick.ask, 5) : ""
            ]
          }
        ),
        /* @__PURE__ */ jsxs(
          Button,
          {
            variant: side === "SELL" ? "sell" : "outline",
            size: "sm",
            onClick: () => setSide("SELL"),
            className: "text-xs",
            children: [
              /* @__PURE__ */ jsx(TrendingDown, { className: "h-3 w-3 mr-1" }),
              "SELL ",
              tick ? formatNumber(tick.bid, 5) : ""
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground uppercase tracking-wider", children: "Order Type" }),
        /* @__PURE__ */ jsx("div", { className: "grid grid-cols-3 gap-1 mt-1", children: ["MARKET", "LIMIT", "STOP"].map((t) => /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => setOrderType(t),
            className: cn(
              "px-1 py-1 text-[10px] rounded border border-border",
              t === orderType ? "bg-primary text-primary-foreground border-primary" : "hover:bg-secondary"
            ),
            children: t.replace("_", " ")
          },
          t
        )) })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground uppercase tracking-wider", children: "Volume (lots)" }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 mt-1", children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => setQuantity((v) => String(Math.max(0.01, parseFloat(v) - 0.01).toFixed(2))),
              className: "px-2 py-1 rounded bg-secondary hover:bg-border",
              children: /* @__PURE__ */ jsx(Minus, { className: "h-3 w-3" })
            }
          ),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "number",
              value: quantity,
              onChange: (e) => setQuantity(e.target.value),
              className: "flex-1 text-center text-sm font-mono",
              step: "0.01",
              min: "0.01"
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => setQuantity((v) => String((parseFloat(v) + 0.01).toFixed(2))),
              className: "px-2 py-1 rounded bg-secondary hover:bg-border",
              children: /* @__PURE__ */ jsx(Plus, { className: "h-3 w-3" })
            }
          )
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex gap-1 mt-1", children: quickQty.map((q) => /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => setQuantity(String(q)),
            className: cn(
              "flex-1 text-[10px] py-0.5 rounded border border-border",
              parseFloat(quantity) === q ? "bg-secondary" : "hover:bg-secondary/50"
            ),
            children: q
          },
          q
        )) })
      ] }),
      orderType === "LIMIT" && /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground uppercase tracking-wider", children: "Price" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "number",
            value: price,
            onChange: (e) => setPrice(e.target.value),
            placeholder: tick ? formatNumber(side === "BUY" ? tick.ask : tick.bid, 5) : "",
            className: "w-full mt-1 text-sm font-mono",
            step: "0.00001"
          }
        )
      ] }),
      orderType === "STOP" && /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground uppercase tracking-wider", children: "Stop Price" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "number",
            value: stopPrice,
            onChange: (e) => setStopPrice(e.target.value),
            className: "w-full mt-1 text-sm font-mono",
            step: "0.00001"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-2", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground uppercase tracking-wider", children: "Take Profit" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "number",
              value: takeProfit,
              onChange: (e) => setTakeProfit(e.target.value),
              className: "w-full mt-1 text-sm font-mono",
              step: "0.00001"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("label", { className: "text-[10px] text-muted-foreground uppercase tracking-wider", children: "Stop Loss" }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "number",
              value: stopLoss,
              onChange: (e) => setStopLoss(e.target.value),
              className: "w-full mt-1 text-sm font-mono",
              step: "0.00001"
            }
          )
        ] })
      ] }),
      (() => {
        const slVal = parseFloat(stopLoss);
        const tpVal = parseFloat(takeProfit);
        const qtyVal = parseFloat(quantity) || 0;
        const contractSize = (symbolInfo == null ? void 0 : symbolInfo.contractSize) || 1e5;
        const currentPrice = tick ? side === "BUY" ? tick.ask : tick.bid : null;
        if (!currentPrice || !slVal || qtyVal <= 0) return null;
        const slDistance = Math.abs(currentPrice - slVal);
        const riskDollar = slDistance * qtyVal * contractSize;
        const balance = accountBalance || 0;
        const riskPct = balance > 0 ? riskDollar / balance * 100 : 0;
        const tpDollar = tpVal ? Math.abs(tpVal - currentPrice) * qtyVal * contractSize : null;
        const rrRatio = tpDollar && riskDollar > 0 ? tpDollar / riskDollar : null;
        const riskColor = riskPct > 5 ? "text-destructive" : riskPct > 2 ? "text-warning" : "text-buy";
        return /* @__PURE__ */ jsxs("div", { className: "bg-secondary/50 rounded p-2 text-[10px] space-y-1 border border-border/50", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 mb-1", children: [
            /* @__PURE__ */ jsx(AlertTriangle, { className: cn("h-3 w-3", riskColor) }),
            /* @__PURE__ */ jsx("span", { className: "font-semibold text-[10px] uppercase tracking-wider text-muted-foreground", children: "Risk Analysis" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Risk Amount" }),
            /* @__PURE__ */ jsx("span", { className: cn("font-mono font-semibold", riskColor), children: formatCurrency(riskDollar) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Risk % of Balance" }),
            /* @__PURE__ */ jsxs("span", { className: cn("font-mono font-semibold", riskColor), children: [
              riskPct.toFixed(2),
              "%"
            ] })
          ] }),
          tpDollar != null && /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Reward" }),
            /* @__PURE__ */ jsx("span", { className: "font-mono text-buy", children: formatCurrency(tpDollar) })
          ] }),
          rrRatio != null && /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "R:R Ratio" }),
            /* @__PURE__ */ jsxs(
              "span",
              {
                className: cn(
                  "font-mono font-semibold",
                  rrRatio >= 2 ? "text-buy" : rrRatio >= 1 ? "text-foreground" : "text-sell"
                ),
                children: [
                  "1:",
                  rrRatio.toFixed(2)
                ]
              }
            )
          ] }),
          riskPct > 5 && /* @__PURE__ */ jsxs("div", { className: "text-destructive text-[9px] flex items-center gap-1 mt-1", children: [
            /* @__PURE__ */ jsx(AlertTriangle, { className: "h-2.5 w-2.5" }),
            "High risk — exceeds 5% of balance"
          ] })
        ] });
      })(),
      symbolInfo && tick && /* @__PURE__ */ jsxs("div", { className: "bg-secondary rounded p-2 text-[10px] space-y-1", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
          /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Contract Size" }),
          /* @__PURE__ */ jsx("span", { children: (_a = symbolInfo.contractSize) == null ? void 0 : _a.toLocaleString() })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
          /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Margin Required" }),
          /* @__PURE__ */ jsx("span", { children: formatCurrency(
            (parseFloat(quantity) || 0) * (symbolInfo.contractSize ?? 0) * (side === "BUY" ? tick.ask : tick.bid) * ((symbolInfo.marginPercent ?? 0) / 100)
          ) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex justify-between", children: [
          /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "Commission" }),
          /* @__PURE__ */ jsx("span", { children: formatCurrency((symbolInfo.commission ?? 0) * (parseFloat(quantity) || 0)) })
        ] })
      ] }),
      isDemo && /* @__PURE__ */ jsxs("div", { className: "bg-amber-500/10 border border-amber-500/30 rounded p-2 text-center", children: [
        /* @__PURE__ */ jsx("p", { className: "text-amber-400 text-[10px] font-semibold uppercase tracking-wider", children: "Demo Mode" }),
        /* @__PURE__ */ jsx("p", { className: "text-muted-foreground text-[10px] mt-0.5", children: "Trading is disabled in demo mode" })
      ] }),
      !isDemo && !isFeedConnected && /* @__PURE__ */ jsx(DisconnectedTradingBanner, {}),
      /* @__PURE__ */ jsx(
        Button,
        {
          variant: side === "BUY" ? "buy" : "sell",
          className: "w-full",
          onClick: handleSubmit,
          loading: placeOrder.isPending,
          disabled: !accountId || placeOrder.isPending || isDemo || !isFeedConnected,
          children: isDemo ? "Demo — Trading Disabled" : !isFeedConnected ? "Disconnected — Trading Disabled" : placeOrder.isPending ? "Placing…" : `${side === "BUY" ? "Buy" : "Sell"} ${quantity} ${symbol}`
        }
      ),
      placeOrder.isError && /* @__PURE__ */ jsx("p", { className: "text-destructive text-xs mt-1 p-1.5 bg-destructive/10 rounded", children: ((_b = placeOrder.error) == null ? void 0 : _b.message) || "Order failed" }),
      placeOrder.isSuccess && /* @__PURE__ */ jsx("p", { className: "text-buy text-xs mt-1 p-1.5 bg-buy/10 rounded", children: "Order placed successfully" })
    ] })
  ] });
}
function formatTime(epochMs) {
  return new Date(epochMs).toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  });
}
function ReplayScrubber({ accountId }) {
  var _a, _b;
  const { replayCursorTimestamp, replaySessionDate } = useTradingStore();
  const selectedSymbol = useTradingStore((s) => s.selectedSymbol);
  const { data } = useReplaySession(accountId, replaySessionDate, selectedSymbol);
  const barRef = useRef(null);
  const tickBuffer = (data == null ? void 0 : data.tickBuffer) ?? [];
  const tradeEvents = (data == null ? void 0 : data.tradeEvents) ?? [];
  const sessionDate = replaySessionDate;
  const startMs = ((_a = tickBuffer[0]) == null ? void 0 : _a.t) ?? null;
  const endMs = ((_b = tickBuffer[tickBuffer.length - 1]) == null ? void 0 : _b.t) ?? null;
  const rangeMs = startMs != null && endMs != null ? endMs - startMs : 0;
  const thumbPct = replayCursorTimestamp != null && startMs != null && rangeMs > 0 ? Math.max(0, Math.min(100, (replayCursorTimestamp - startMs) / rangeMs * 100)) : null;
  const seekToX = useCallback(
    (clientX) => {
      if (!barRef.current || !sessionDate || startMs == null || rangeMs <= 0) return;
      const rect = barRef.current.getBoundingClientRect();
      const pct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
      const ts = new Date(startMs + pct * rangeMs).toISOString();
      api.replaySeek(accountId, sessionDate, ts).catch(() => null);
    },
    [accountId, sessionDate, startMs, rangeMs]
  );
  const handlePointerDown = useCallback(
    (e) => {
      e.currentTarget.setPointerCapture(e.pointerId);
      seekToX(e.clientX);
    },
    [seekToX]
  );
  const handlePointerMove = useCallback(
    (e) => {
      if (e.buttons !== 1) return;
      seekToX(e.clientX);
    },
    [seekToX]
  );
  if (!replaySessionDate || tickBuffer.length === 0) return null;
  return /* @__PURE__ */ jsxs("div", { className: "h-7 px-3 flex items-center gap-2 bg-card border-t border-border shrink-0 select-none", children: [
    startMs != null && /* @__PURE__ */ jsx("span", { className: "text-[10px] text-muted-foreground font-mono tabular-nums shrink-0", children: formatTime(startMs) }),
    /* @__PURE__ */ jsxs(
      "div",
      {
        ref: barRef,
        onPointerDown: handlePointerDown,
        onPointerMove: handlePointerMove,
        className: "relative flex-1 h-1.5 rounded-full bg-secondary cursor-pointer",
        children: [
          thumbPct != null && /* @__PURE__ */ jsx(
            "div",
            {
              className: "absolute left-0 top-0 h-full rounded-full bg-orange-500/60",
              style: { width: `${thumbPct}%` }
            }
          ),
          startMs != null && rangeMs > 0 && tradeEvents.map((ev) => {
            const evMs = new Date(ev.timestamp).getTime();
            const pct = (evMs - startMs) / rangeMs * 100;
            if (pct < 0 || pct > 100) return null;
            return /* @__PURE__ */ jsx(
              "div",
              {
                title: ev.type === "violation" ? ev.ruleCode : `${ev.type} ${ev.symbolName ?? ""}`,
                className: `absolute top-1/2 -translate-y-1/2 w-1 h-1 rounded-full ${ev.type === "violation" ? "bg-red-500" : ev.type === "exit" ? "bg-green-400" : "bg-blue-400"}`,
                style: { left: `${pct}%` }
              },
              ev.id
            );
          }),
          thumbPct != null && /* @__PURE__ */ jsx(
            "div",
            {
              className: "absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-orange-500 border-2 border-background shadow",
              style: { left: `${thumbPct}%` }
            }
          )
        ]
      }
    ),
    endMs != null && /* @__PURE__ */ jsx("span", { className: "text-[10px] text-muted-foreground font-mono tabular-nums shrink-0", children: formatTime(endMs) })
  ] });
}
function WatchlistPanel({
  symbols,
  ticks,
  selectedSymbol,
  onSelect,
  oneClick,
  accountId,
  isFeedConnected = true
}) {
  const [filter, setFilter] = useState("");
  const placeOrder = usePlaceOrder();
  const [favorites, setFavorites] = useState(() => {
    try {
      const saved = safeStorage.getItem("watchlist_favorites");
      return saved ? new Set(JSON.parse(saved)) : /* @__PURE__ */ new Set();
    } catch {
      return /* @__PURE__ */ new Set();
    }
  });
  const toggleFavorite = useCallback((name) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      safeStorage.setItem("watchlist_favorites", JSON.stringify([...next]));
      return next;
    });
  }, []);
  const categories = useMemo(() => {
    const cats = new Set(symbols.map((s) => s.category || "Other"));
    return Array.from(cats).sort();
  }, [symbols]);
  const [selectedCat, setSelectedCat] = useState(null);
  const filtered = useMemo(() => {
    return symbols.filter((s) => {
      if (filter && !s.name.toLowerCase().includes(filter.toLowerCase())) return false;
      if (selectedCat === "★") return favorites.has(s.name);
      if (selectedCat && selectedCat !== "★" && s.category !== selectedCat) return false;
      return s.isActive !== false;
    }).sort((a, b) => {
      const aFav = favorites.has(a.name) ? 0 : 1;
      const bFav = favorites.has(b.name) ? 0 : 1;
      if (aFav !== bFav) return aFav - bFav;
      return a.name.localeCompare(b.name);
    });
  }, [symbols, filter, selectedCat, favorites]);
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col h-full", children: [
    /* @__PURE__ */ jsxs("div", { className: "px-3 py-2 border-b border-border bg-secondary", children: [
      /* @__PURE__ */ jsx("h3", { className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5", children: "Watchlist" }),
      /* @__PURE__ */ jsx(
        "input",
        {
          placeholder: "Search...",
          value: filter,
          onChange: (e) => setFilter(e.target.value),
          className: "w-full text-xs"
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex gap-1 px-2 py-1 border-b border-border overflow-x-auto text-[10px]", children: [
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => setSelectedCat(null),
          className: cn(
            "px-2 py-0.5 rounded whitespace-nowrap",
            !selectedCat ? "bg-primary text-primary-foreground" : "hover:bg-secondary"
          ),
          children: "All"
        }
      ),
      /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: () => setSelectedCat("★"),
          className: cn(
            "px-2 py-0.5 rounded whitespace-nowrap flex items-center gap-0.5",
            selectedCat === "★" ? "bg-primary text-primary-foreground" : "hover:bg-secondary text-yellow-400"
          ),
          children: [
            /* @__PURE__ */ jsx(Star, { className: "h-2.5 w-2.5", fill: "currentColor" }),
            favorites.size > 0 && /* @__PURE__ */ jsx("span", { className: "text-[9px]", children: favorites.size })
          ]
        }
      ),
      categories.map((c) => /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => setSelectedCat(c),
          className: cn(
            "px-2 py-0.5 rounded whitespace-nowrap",
            selectedCat === c ? "bg-primary text-primary-foreground" : "hover:bg-secondary"
          ),
          children: c
        },
        c
      ))
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex-1 overflow-y-auto", children: filtered.map((s) => {
      const t = ticks[s.name];
      const isFav = favorites.has(s.name);
      const handleQuickTrade = (side) => {
        if (!isFeedConnected) {
          toast.warning("No Data Feed", "Cannot trade while disconnected");
          return;
        }
        if (!accountId) {
          toast.warning("No Account", "Select an account first");
          return;
        }
        placeOrder.mutate(
          {
            accountId,
            symbol: s.name,
            side,
            type: "MARKET",
            quantity: 0.1
          },
          {
            onSuccess: () => toast.success("Quick Trade", `${side} 0.1 ${s.name}`),
            onError: (err) => toast.error("Trade Failed", (err == null ? void 0 : err.message) || "Failed")
          }
        );
      };
      return /* @__PURE__ */ jsxs(
        "div",
        {
          className: cn(
            "w-full flex items-center justify-between px-3 py-1.5 text-xs hover:bg-secondary border-b border-border/30 group",
            s.name === selectedSymbol && "bg-secondary"
          ),
          children: [
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: (e) => {
                  e.stopPropagation();
                  toggleFavorite(s.name);
                },
                className: cn(
                  "shrink-0 mr-1",
                  isFav ? "text-yellow-400" : "text-muted-foreground/20 hover:text-yellow-400/60"
                ),
                children: /* @__PURE__ */ jsx(Star, { className: "h-3 w-3", fill: isFav ? "currentColor" : "none" })
              }
            ),
            /* @__PURE__ */ jsxs("button", { onClick: () => onSelect(s.name), className: "text-left flex-1 min-w-0", children: [
              /* @__PURE__ */ jsx("div", { className: "font-semibold", children: s.name }),
              /* @__PURE__ */ jsx("div", { className: "text-[10px] text-muted-foreground", children: s.category })
            ] }),
            t ? /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsxs("div", { className: "text-right font-mono", children: [
                /* @__PURE__ */ jsx("div", { className: "text-buy", children: formatNumber(t.bid, 5) }),
                /* @__PURE__ */ jsx("div", { className: "text-sell", children: formatNumber(t.ask, 5) })
              ] }),
              oneClick && /* @__PURE__ */ jsxs("div", { className: "hidden group-hover:flex flex-col gap-0.5 ml-1", children: [
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    onClick: () => handleQuickTrade("BUY"),
                    className: "px-1 py-0.5 text-[8px] rounded bg-buy/20 text-buy hover:bg-buy/30 font-semibold",
                    children: "B"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    onClick: () => handleQuickTrade("SELL"),
                    className: "px-1 py-0.5 text-[8px] rounded bg-sell/20 text-sell hover:bg-sell/30 font-semibold",
                    children: "S"
                  }
                )
              ] })
            ] }) : /* @__PURE__ */ jsx("span", { className: "text-muted-foreground", children: "--" })
          ]
        },
        s.id || s.name
      );
    }) })
  ] });
}
function TradingPage() {
  const {
    selectedSymbol,
    setSelectedSymbol,
    symbols,
    symbolInfo,
    pipDigits,
    tick,
    isDark,
    timeframe,
    setTimeframe: handleTimeframeChange,
    candles,
    liveCandle,
    replayCandles,
    replayTradeEvents,
    isReplaying,
    chartPrefs,
    activeIndicators,
    toggleIndicator,
    clearIndicators: handleClearIndicators,
    activePlugins,
    togglePlugin: handleTogglePlugin,
    setPlugins: handleSetPlugins,
    cycleMagnetMode,
    drawingTool,
    setDrawingTool,
    drawings,
    addDrawing,
    updateDrawing,
    removeDrawing,
    clearDrawings,
    undoDrawing,
    redoDrawing,
    activeAccountId,
    account,
    positions,
    orders,
    positionPnl,
    chartPositions,
    chartOrders,
    isFeedConnected,
    oneClick,
    toggleOneClick,
    soundMuted,
    toggleSoundMute,
    onOrderSuccess,
    requestOrderConfirmation: setConfirmOrder,
    submitOrderDirect,
    quickOrder: handleQuickOrder,
    modifyPositionLevels: handleChartModifyPosition,
    editPosition: setModifyingPosition,
    editOrder: setModifyingOrder,
    journalEntries,
    journalLoading,
    createJournal,
    updateJournal,
    deleteJournal
  } = useTerminal();
  const [showIndicatorMenu, setShowIndicatorMenu] = useState(false);
  const [bottomTab, setBottomTab] = useState("positions");
  const [rightPanel, setRightPanel] = useState("order");
  const [showRightPanel, setShowRightPanel] = useState(true);
  const [mobilePanelOpen, setMobilePanelOpen] = useState(false);
  const [bottomPanelHeight, setBottomPanelHeight] = useState(() => {
    const saved = safeStorage.getItem("bottomPanelHeight");
    return saved ? parseInt(saved, 10) : 220;
  });
  const resizingRef = useRef(false);
  const resizeStartY = useRef(0);
  const resizeStartH = useRef(0);
  const handleResizeStart = useCallback(
    (e) => {
      e.preventDefault();
      resizingRef.current = true;
      const clientY = "touches" in e ? e.touches[0].clientY : e.clientY;
      resizeStartY.current = clientY;
      resizeStartH.current = bottomPanelHeight;
      const onMove = (ev) => {
        if (!resizingRef.current) return;
        const y = "touches" in ev ? ev.touches[0].clientY : ev.clientY;
        const delta = resizeStartY.current - y;
        const newH = Math.max(100, Math.min(600, resizeStartH.current + delta));
        setBottomPanelHeight(newH);
      };
      const onUp = () => {
        resizingRef.current = false;
        setBottomPanelHeight((h) => {
          safeStorage.setItem("bottomPanelHeight", String(h));
          return h;
        });
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onUp);
        window.removeEventListener("touchmove", onMove);
        window.removeEventListener("touchend", onUp);
      };
      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
      window.addEventListener("touchmove", onMove, { passive: false });
      window.addEventListener("touchend", onUp);
    },
    [bottomPanelHeight]
  );
  const setIndicators = useCallback(
    (next) => {
      for (const type of next) if (!activeIndicators.includes(type)) toggleIndicator(type);
      for (const type of activeIndicators) if (!next.includes(type)) toggleIndicator(type);
    },
    [activeIndicators, toggleIndicator]
  );
  const ticks = useTradingStore((s) => s.ticks);
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col h-full overflow-hidden", children: [
    /* @__PURE__ */ jsx("div", { className: "md:hidden", children: /* @__PURE__ */ jsx(
      MobileAccountBar,
      {
        balance: (account == null ? void 0 : account.balance) ?? 0,
        equity: (account == null ? void 0 : account.equity) ?? (account == null ? void 0 : account.balance) ?? 0,
        margin: (account == null ? void 0 : account.margin) ?? 0,
        pnl: positionPnl
      }
    ) }),
    /* @__PURE__ */ jsx(
      ChartToolbar,
      {
        selectedSymbol,
        symbols,
        onSymbolChange: setSelectedSymbol,
        timeframe,
        onTimeframeChange: handleTimeframeChange,
        activeIndicators,
        onToggleIndicator: toggleIndicator,
        showIndicatorMenu,
        onToggleIndicatorMenu: () => setShowIndicatorMenu((v) => !v),
        drawingTool,
        onDrawingTool: setDrawingTool,
        drawings,
        onClearDrawings: clearDrawings,
        rightPanel,
        onRightPanel: setRightPanel,
        showRightPanel,
        onToggleRightPanel: () => setShowRightPanel((v) => !v),
        tick,
        symbolInfo,
        isReplaying,
        replayAccountId: activeAccountId,
        activePlugins,
        onTogglePlugin: handleTogglePlugin,
        onSetIndicators: setIndicators,
        onSetPlugins: handleSetPlugins,
        magnetMode: chartPrefs.magnetMode,
        onCycleMagnet: cycleMagnetMode,
        stayInDrawingMode: chartPrefs.stayInDrawingMode,
        onToggleStayInDrawingMode: () => updateChartPreferences({ stayInDrawingMode: !chartPrefs.stayInDrawingMode })
      }
    ),
    /* @__PURE__ */ jsx(MarketClosedBanner, { symbolInfo }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row flex-1 overflow-hidden", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col flex-1 min-w-0", children: [
        /* @__PURE__ */ jsx("div", { className: "flex-1 min-h-[200px] relative", children: /* @__PURE__ */ jsx(
          ChartPanel,
          {
            candles: replayCandles ?? candles ?? [],
            selectedSymbol,
            timeframe: replayCandles ? "1m" : timeframe,
            isDark,
            activeIndicators,
            drawingTool,
            drawings,
            onAddDrawing: addDrawing,
            onUpdateDrawing: updateDrawing,
            onRemoveDrawing: removeDrawing,
            onDrawingComplete: () => setDrawingTool("none"),
            onDrawingToolSelect: setDrawingTool,
            onUndoDrawing: undoDrawing,
            onRedoDrawing: redoDrawing,
            magnetMode: chartPrefs.magnetMode,
            stayInDrawingMode: chartPrefs.stayInDrawingMode,
            positions: chartPositions,
            orders: chartOrders,
            tick: replayCandles ? void 0 : tick,
            liveCandle: replayCandles ? void 0 : liveCandle,
            pipDigits,
            symbolInfo,
            onModifyPosition: handleChartModifyPosition,
            replayTradeEvents,
            isReplaying,
            activePlugins,
            onTogglePlugin: handleTogglePlugin,
            accountEquity: (account == null ? void 0 : account.equity) ?? (account == null ? void 0 : account.balance) ?? 0,
            accountId: activeAccountId,
            onQuickOrder: handleQuickOrder,
            onClearDrawings: clearDrawings,
            onClearIndicators: handleClearIndicators
          }
        ) }),
        isReplaying && activeAccountId != null && /* @__PURE__ */ jsx(ReplayScrubber, { accountId: activeAccountId }),
        /* @__PURE__ */ jsx(
          "div",
          {
            onMouseDown: handleResizeStart,
            onTouchStart: handleResizeStart,
            className: "hidden md:flex h-1.5 cursor-row-resize items-center justify-center hover:bg-primary/20 active:bg-primary/30 transition-colors group border-t border-border bg-secondary/40 touch-none",
            children: /* @__PURE__ */ jsx("div", { className: "w-8 h-0.5 rounded-full bg-border group-hover:bg-primary/50 transition-colors" })
          }
        ),
        /* @__PURE__ */ jsx(
          BottomPanel,
          {
            tab: bottomTab,
            onTabChange: setBottomTab,
            positions,
            orders,
            accountId: activeAccountId,
            onModifyPosition: setModifyingPosition,
            onModifyOrder: setModifyingOrder,
            onSelectPositionSymbol: setSelectedSymbol,
            onSelectOrderSymbol: setSelectedSymbol,
            height: bottomPanelHeight,
            isFeedConnected,
            journalEntries,
            journalLoading,
            onCreateJournal: createJournal,
            onUpdateJournal: updateJournal,
            onDeleteJournal: deleteJournal
          }
        )
      ] }),
      showRightPanel && /* @__PURE__ */ jsxs("div", { className: "hidden md:flex w-full md:w-[280px] xl:w-[320px] border-t md:border-t-0 md:border-l border-border flex-col bg-card overflow-hidden shrink-0 md:max-h-none", children: [
        rightPanel === "order" && /* @__PURE__ */ jsx(
          OrderPanel,
          {
            symbol: selectedSymbol,
            symbolInfo,
            tick,
            accountId: activeAccountId,
            oneClick,
            onToggleOneClick: toggleOneClick,
            onConfirmOrder: setConfirmOrder,
            accountBalance: account == null ? void 0 : account.balance,
            isFeedConnected,
            soundMuted,
            onToggleMute: toggleSoundMute,
            onOrderSuccess
          }
        ),
        rightPanel === "dom" && /* @__PURE__ */ jsx(DOMPanel, { symbol: selectedSymbol, tick }),
        rightPanel === "watchlist" && /* @__PURE__ */ jsx(
          WatchlistPanel,
          {
            symbols,
            ticks,
            selectedSymbol,
            onSelect: setSelectedSymbol,
            oneClick,
            accountId: activeAccountId,
            isFeedConnected
          }
        ),
        rightPanel === "news" && /* @__PURE__ */ jsx("div", { className: "flex-1 overflow-y-auto p-2 space-y-2", children: /* @__PURE__ */ jsx(NewsFeed$1, { symbol: selectedSymbol }) }),
        rightPanel === "tv-analysis" && /* @__PURE__ */ jsx("div", { className: "flex-1 overflow-hidden", children: /* @__PURE__ */ jsx(
          TradingViewTechnicalAnalysis,
          {
            symbol: selectedSymbol,
            theme: isDark ? "dark" : "light",
            interval: timeframe,
            width: "100%",
            height: "100%"
          }
        ) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "md:hidden", children: [
      !mobilePanelOpen && /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => setMobilePanelOpen(true),
          className: "fixed bottom-20 right-4 z-40 bg-primary text-primary-foreground rounded-full w-14 h-14 flex items-center justify-center shadow-lg active:scale-95 transition-transform",
          children: /* @__PURE__ */ jsx("span", { className: "text-2xl font-bold", children: "$" })
        }
      ),
      mobilePanelOpen && /* @__PURE__ */ jsxs("div", { className: "fixed inset-x-0 bottom-0 z-50 max-h-[70vh] overflow-y-auto bg-card border-t border-border rounded-t-2xl shadow-2xl safe-area-bottom", children: [
        /* @__PURE__ */ jsx("div", { className: "flex justify-center py-1", children: /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => setMobilePanelOpen(false),
            className: "w-10 h-1.5 rounded-full bg-muted-foreground/30"
          }
        ) }),
        /* @__PURE__ */ jsx(
          MobileTradingPanel,
          {
            symbol: selectedSymbol,
            bid: tick == null ? void 0 : tick.bid,
            ask: tick == null ? void 0 : tick.ask,
            positions: positions || [],
            onPlaceOrder: (order) => {
              if (oneClick) {
                void submitOrderDirect({
                  ...order,
                  accountId: activeAccountId
                }).then(onOrderSuccess).catch(() => {
                });
                setMobilePanelOpen(false);
                return;
              }
              setConfirmOrder({
                ...order,
                accountId: activeAccountId,
                _submit: () => submitOrderDirect({
                  ...order,
                  accountId: activeAccountId
                })
              });
              setMobilePanelOpen(false);
            }
          }
        )
      ] })
    ] })
  ] });
}
function Terminal() {
  return /* @__PURE__ */ jsx(TerminalProvider, { children: /* @__PURE__ */ jsx(TradingPage, {}) });
}
function Chart() {
  var _a, _b;
  const t = useTerminal();
  return /* @__PURE__ */ jsx(
    ChartPanel,
    {
      candles: t.replayCandles ?? t.candles ?? [],
      selectedSymbol: t.selectedSymbol,
      timeframe: t.replayCandles ? "1m" : t.timeframe,
      isDark: t.isDark,
      activeIndicators: t.activeIndicators,
      drawingTool: t.drawingTool,
      drawings: t.drawings,
      onAddDrawing: t.addDrawing,
      onUpdateDrawing: t.updateDrawing,
      onRemoveDrawing: t.removeDrawing,
      onDrawingComplete: () => t.setDrawingTool("none"),
      onDrawingToolSelect: t.setDrawingTool,
      onUndoDrawing: t.undoDrawing,
      onRedoDrawing: t.redoDrawing,
      magnetMode: t.chartPrefs.magnetMode,
      stayInDrawingMode: t.chartPrefs.stayInDrawingMode,
      positions: t.chartPositions,
      orders: t.chartOrders,
      tick: t.replayCandles ? void 0 : t.tick,
      liveCandle: t.replayCandles ? void 0 : t.liveCandle,
      pipDigits: t.pipDigits,
      symbolInfo: t.symbolInfo,
      onModifyPosition: t.modifyPositionLevels,
      replayTradeEvents: t.replayTradeEvents,
      isReplaying: t.isReplaying,
      activePlugins: t.activePlugins,
      onTogglePlugin: t.togglePlugin,
      accountEquity: ((_a = t.account) == null ? void 0 : _a.equity) ?? ((_b = t.account) == null ? void 0 : _b.balance) ?? 0,
      accountId: t.activeAccountId,
      onQuickOrder: t.quickOrder,
      onClearDrawings: t.clearDrawings,
      onClearIndicators: t.clearIndicators
    }
  );
}
function OrderTicket() {
  var _a;
  const t = useTerminal();
  return /* @__PURE__ */ jsx(
    OrderPanel,
    {
      symbol: t.selectedSymbol,
      symbolInfo: t.symbolInfo,
      tick: t.tick,
      accountId: t.activeAccountId,
      oneClick: t.oneClick,
      onToggleOneClick: t.toggleOneClick,
      onConfirmOrder: t.requestOrderConfirmation,
      accountBalance: (_a = t.account) == null ? void 0 : _a.balance,
      isFeedConnected: t.isFeedConnected,
      soundMuted: t.soundMuted,
      onToggleMute: t.toggleSoundMute,
      onOrderSuccess: t.onOrderSuccess
    }
  );
}
function DepthLadder() {
  const t = useTerminal();
  return /* @__PURE__ */ jsx(DOMPanel, { symbol: t.selectedSymbol, tick: t.tick });
}
function Watchlist() {
  const t = useTerminal();
  return /* @__PURE__ */ jsx(
    WatchlistPanel,
    {
      symbols: t.symbols,
      ticks: t.ticks,
      selectedSymbol: t.selectedSymbol,
      onSelect: t.setSelectedSymbol,
      accountId: t.activeAccountId,
      oneClick: t.oneClick,
      isFeedConnected: t.isFeedConnected
    }
  );
}
function Positions() {
  const t = useTerminal();
  return /* @__PURE__ */ jsx(
    PositionsTable,
    {
      positions: t.positions,
      onClose: (id) => t.closePosition(id),
      onPartialClose: (id, quantity) => t.closePosition(id, quantity),
      onModify: (row) => t.editPosition(t.positions.find((p) => p.id === row.id) ?? null),
      onSelectSymbol: t.setSelectedSymbol
    }
  );
}
function Orders() {
  const t = useTerminal();
  return /* @__PURE__ */ jsx(
    OrdersTable,
    {
      orders: t.orders.filter((o) => o.status === "PENDING" || o.status === "NEW"),
      onCancel: (id) => t.cancelOrder(id),
      onModify: (row) => t.editOrder(t.orders.find((o) => o.id === row.id) ?? null),
      onSelectSymbol: t.setSelectedSymbol
    }
  );
}
function onNotification(listener) {
  return toast.subscribe(listener);
}
export {
  CHART_COLORS,
  Chart,
  ChartPanel,
  ChartSettingsDialog,
  DRAWING_TOOL_GROUPS,
  DepthLadder,
  OpenChartsProvider,
  OrderTicket,
  Orders,
  Positions,
  Terminal,
  TerminalProvider,
  TradingViewColorPicker,
  Watchlist,
  atr,
  bollingerBands,
  buildCandlestickSettingsOptions,
  buildChartSettingsOptions,
  ema,
  formatChartTimeLabel,
  getAdapter,
  hasAdapter,
  macd,
  observeChartSize,
  onAdapterChange,
  onNotification,
  rsi,
  setAdapter,
  sma,
  stochastic,
  updateChartPreferences,
  useChartPreferences,
  useTerminal,
  vwap
};
//# sourceMappingURL=index.js.map
