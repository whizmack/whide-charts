import { OpenChartsAdapter } from './types.ts';
/**
 * A conformance suite for OpenCharts adapters.
 *
 * Point it at your adapter and it checks the parts of the contract the
 * terminal actually relies on — the ones that fail quietly if you get them
 * wrong, like returning bars newest-first or ignoring the `fromMs`/`toMs`
 * window the chart's scroll-back pagination sends.
 *
 * ```ts
 * import { runAdapterConformance } from "opencharts/adapter/conformance";
 *
 * runAdapterConformance("my-broker", () => createMyAdapter(), {
 *   symbol: "BTCUSD",
 *   timeframe: "1m",
 * });
 * ```
 *
 * **Trading checks place and close orders**, so they are off by default. Only
 * enable them against a paper or sandbox gateway — never a funded account.
 */
export interface ConformanceOptions {
    /** A symbol the adapter can serve. Defaults to the first one it reports. */
    symbol?: string;
    /** Timeframe used for candle checks. */
    timeframe?: string;
    /** How long to wait for a live tick before skipping the streaming checks. */
    tickTimeoutMs?: number;
    /**
     * Run trading checks, which SUBMIT AND CLOSE ORDERS. Paper/sandbox only.
     */
    allowTrading?: boolean;
    /** Order size used by the trading checks. */
    testQuantity?: number;
}
export declare function runAdapterConformance(name: string, createAdapter: () => OpenChartsAdapter | Promise<OpenChartsAdapter>, options?: ConformanceOptions): void;
