import { OpenChartsAdapter } from './types.ts';
/** Install the adapter. Returns a function restoring the previous one. */
export declare function setAdapter(adapter: OpenChartsAdapter): () => void;
/**
 * The active adapter.
 *
 * Throws when nothing is installed, because the alternative — silently
 * resolving to empty data — turns a wiring mistake into a blank chart with no
 * explanation.
 */
export declare function getAdapter(): OpenChartsAdapter;
/** Whether an adapter is installed, for code that must not throw. */
export declare function hasAdapter(): boolean;
/** Notified whenever the adapter is replaced. */
export declare function onAdapterChange(listener: (adapter: OpenChartsAdapter) => void): () => void;
/** Test seam. */
export declare function __clearAdapter(): void;
