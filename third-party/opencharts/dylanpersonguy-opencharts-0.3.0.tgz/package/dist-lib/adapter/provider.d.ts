import { QueryClient } from '@tanstack/react-query';
import { CSSProperties, ReactNode } from 'react';
import { OpenChartsAdapter } from './types.ts';
/**
 * The OpenCharts runtime.
 *
 * ```tsx
 * <OpenChartsProvider adapter={myAdapter}>
 *   <Terminal />
 * </OpenChartsProvider>
 * ```
 *
 * That is the whole integration. The provider installs the adapter, opens the
 * market-data stream, loads instruments (and accounts, when the adapter trades),
 * and supplies everything the panels depend on — a query cache, tooltips, the
 * bridge that turns stream events into state, notifications and an error
 * boundary. None of it has to be assembled by the host.
 *
 * It also renders the `.opencharts` element every stylesheet rule is scoped
 * to, so the terminal's styles cannot leak onto the host page.
 */
export interface OpenChartsProviderProps {
    adapter: OpenChartsAdapter;
    children: ReactNode;
    /** Shown while the adapter's instruments and accounts load. */
    fallback?: ReactNode;
    /** Extra classes for the scoping element, e.g. to size it. */
    className?: string;
    style?: CSSProperties;
    /**
     * Use an existing TanStack Query client. By default the terminal keeps its
     * own, so its cache never mixes with the host application's.
     */
    queryClient?: QueryClient;
    /**
     * Render the built-in notifications. Turn off to route them into your own
     * notification system via `onNotification()`.
     */
    showNotifications?: boolean;
}
export declare function OpenChartsProvider({ adapter, children, fallback, className, style, queryClient, showNotifications, }: OpenChartsProviderProps): import('react').JSX.Element;
