import { OpenChartsAdapter } from './types.ts';
export declare function createDemoAdapter(): OpenChartsAdapter;
