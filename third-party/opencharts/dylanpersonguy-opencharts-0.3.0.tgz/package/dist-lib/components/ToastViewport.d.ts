export declare function ToastViewport(): import('react').JSX.Element | null;
