export declare function NewsFeed({ symbol }: {
    symbol: string;
}): import('react').JSX.Element;
