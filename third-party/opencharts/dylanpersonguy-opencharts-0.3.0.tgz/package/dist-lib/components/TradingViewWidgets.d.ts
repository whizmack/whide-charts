export declare function safeClear(container: HTMLDivElement): void;
declare const TV_SYMBOL_MAP: Record<string, string>;
declare function mapSymbol(symbol: string): string;
interface TradingViewTickerTapeProps {
    symbols?: {
        proName: string;
        title: string;
    }[];
    theme: "dark" | "light";
    className?: string;
}
export declare const TradingViewTickerTape: import('react').NamedExoticComponent<TradingViewTickerTapeProps>;
interface TradingViewTechnicalAnalysisProps {
    symbol: string;
    theme: "dark" | "light";
    interval?: string;
    width?: string | number;
    height?: string | number;
    className?: string;
}
export declare const TradingViewTechnicalAnalysis: import('react').NamedExoticComponent<TradingViewTechnicalAnalysisProps>;
interface TradingViewEconomicCalendarProps {
    theme: "dark" | "light";
    width?: string | number;
    height?: string | number;
    className?: string;
}
export declare const TradingViewEconomicCalendar: import('react').NamedExoticComponent<TradingViewEconomicCalendarProps>;
interface TradingViewMiniChartProps {
    symbol: string;
    theme: "dark" | "light";
    width?: string | number;
    height?: string | number;
    className?: string;
}
export declare const TradingViewMiniChart: import('react').NamedExoticComponent<TradingViewMiniChartProps>;
export { mapSymbol, TV_SYMBOL_MAP };
