import { ReactNode } from 'react';
export interface TradingViewColorPickerProps {
    label: string;
    value: string;
    onChange: (value: string) => void;
    name?: string;
    opacity?: number;
    onOpacity?: (opacity: number) => void;
    className?: string;
    popoverFooter?: ReactNode;
}
export declare function TradingViewColorPicker({ label, value, onChange, name, opacity, onOpacity, className, popoverFooter, }: TradingViewColorPickerProps): import('react').JSX.Element;
