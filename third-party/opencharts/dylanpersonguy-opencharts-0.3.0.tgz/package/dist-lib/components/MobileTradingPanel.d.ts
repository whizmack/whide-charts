interface MobilePosition {
    id: string;
    symbol?: string;
    symbolName?: string;
    side?: "LONG" | "SHORT" | "BUY" | "SELL";
    pnl?: number;
    unrealizedPnl?: number;
    quantity?: number;
    entryPrice?: number;
    [key: string]: unknown;
}
interface MobileTradingPanelProps {
    symbol: string;
    bid?: number;
    ask?: number;
    spread?: number;
    accountBalance?: number;
    onPlaceOrder: (order: {
        side: "BUY" | "SELL";
        quantity: number;
        type: "MARKET" | "LIMIT" | "STOP";
        price?: number;
        stopLoss?: number;
        takeProfit?: number;
        symbol: string;
        accountId?: string;
    }) => void;
    positions: MobilePosition[];
    onClosePosition?: (positionId: string) => void;
    onCloseAllPositions?: () => void;
    /** ID of the position currently being closed — disables that row's Close button */
    closingPositionId?: string | null;
    /** True while close-all is in flight — disables the Close All button */
    closingAll?: boolean;
}
export declare function MobileTradingPanel({ symbol, bid, ask, spread: spreadProp, accountBalance, onPlaceOrder, positions, onClosePosition, onCloseAllPositions, closingPositionId, closingAll, }: MobileTradingPanelProps): import('react').JSX.Element;
/**
 * Mobile-optimized account summary strip shown at top of trading page.
 */
export declare function MobileAccountBar({ balance, equity, margin, pnl, }: {
    balance: number;
    equity: number;
    margin: number;
    pnl: number;
}): import('react').JSX.Element;
/**
 * Touch-friendly symbol selector with larger tap targets.
 */
export declare function MobileSymbolSelector({ symbols, selected, onSelect, }: {
    symbols: Array<{
        symbol: string;
        bid?: number;
        ask?: number;
        change?: number;
    }>;
    selected: string;
    onSelect: (symbol: string) => void;
}): import('react').JSX.Element;
export {};
