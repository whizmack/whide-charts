import { InputHTMLAttributes } from 'react';
export declare function formatSettingsNumber(value: number | undefined): string;
export declare function FormattedNumberInput({ value, onNumberChange, ...inputProps }: Omit<InputHTMLAttributes<HTMLInputElement>, "type" | "value" | "onChange" | "onFocus" | "onBlur"> & {
    value: number | undefined;
    onNumberChange: (value: number) => void;
}): import('react').JSX.Element;
