import { ConnectionState } from '../services/ws';
export declare function useConnectionState(): ConnectionState;
/** True only when the WebSocket is fully authenticated and streaming data */
export declare function useIsFeedConnected(): boolean;
export declare function useStaleData(): boolean;
export declare function ConnectionIndicator({ className }: {
    className?: string;
}): import('react').JSX.Element;
export declare function StaleDataBanner(): import('react').JSX.Element | null;
export declare function DisconnectedTradingBanner({ className }: {
    className?: string;
}): import('react').JSX.Element;
