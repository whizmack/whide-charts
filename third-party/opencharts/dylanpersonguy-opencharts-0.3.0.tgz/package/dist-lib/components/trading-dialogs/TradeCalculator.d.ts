interface TradeCalcProps {
    tick?: {
        bid: number;
        ask: number;
    };
    symbolInfo?: {
        digits?: number;
        pip?: number;
        contractSize?: number;
        [key: string]: unknown;
    } | null;
}
export declare function TradeCalculator({ tick: _tick, symbolInfo }: TradeCalcProps): import('react').JSX.Element;
export {};
