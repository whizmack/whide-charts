interface OrderConfirmDialogProps {
    isOpen: boolean;
    onConfirm: () => void;
    onCancel: () => void;
    order: {
        symbol: string;
        side: "BUY" | "SELL";
        type: string;
        quantity: number;
        price?: number;
        stopPrice?: number;
        takeProfit?: number;
        stopLoss?: number;
    } | null;
    tick?: {
        bid: number;
        ask: number;
    };
    symbolInfo?: {
        digits?: number;
        pip?: number;
        contractSize?: number;
        marginPercent?: number;
        commission?: number;
        [key: string]: unknown;
    } | null;
    loading?: boolean;
}
export declare function OrderConfirmDialog({ isOpen, onConfirm, onCancel, order, tick, symbolInfo, loading, }: OrderConfirmDialogProps): import('react').JSX.Element | null;
export {};
