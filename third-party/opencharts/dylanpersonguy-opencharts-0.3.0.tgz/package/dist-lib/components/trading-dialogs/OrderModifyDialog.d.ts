interface OrderModifyDialogProps {
    order: {
        id: string;
        symbolName: string;
        side: string;
        type: string;
        quantity: number;
        price?: number | null;
        stopPrice?: number | null;
        takeProfit?: number | null;
        stopLoss?: number | null;
    } | null;
    onClose: () => void;
    onSaved: () => void;
    tick?: {
        bid: number;
        ask: number;
    };
}
/**
 * The parent mounts this with `key={order.id}`, so each order gets a fresh
 * instance and the form initialises straight from props. That replaces an
 * effect that copied the order into state on every change — one render cycle
 * shorter, and no window where the fields show the previous order's values.
 */
export declare function OrderModifyDialog({ order, onClose, onSaved, tick }: OrderModifyDialogProps): import('react').JSX.Element | null;
export {};
