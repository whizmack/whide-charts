export declare function MarketDataBridge(): null;
