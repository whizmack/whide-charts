/**
 * Collision-resistant id that works outside secure contexts.
 *
 * `crypto.randomUUID()` is only defined on HTTPS and localhost. Serving the
 * built terminal from a plain-HTTP host (a LAN IP, an internal box) leaves it
 * `undefined`, which used to throw at module load and blank the whole app, so
 * fall back to `getRandomValues` and finally to `Math.random`.
 */
export declare function uid(): string;
