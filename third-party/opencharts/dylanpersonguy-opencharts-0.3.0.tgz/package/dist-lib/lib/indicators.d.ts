/**
 * Technical Indicator Calculations
 * Pure functions for computing chart indicators from OHLCV candle data.
 */
export interface CandleData {
    time: number;
    open: number;
    high: number;
    low: number;
    close: number;
    volume?: number;
}
export interface IndicatorPoint {
    time: number;
    value: number;
}
export declare function sma(candles: CandleData[], period: number): IndicatorPoint[];
export declare function ema(candles: CandleData[], period: number): IndicatorPoint[];
export declare function rsi(candles: CandleData[], period?: number): IndicatorPoint[];
export interface MACDResult {
    macd: IndicatorPoint[];
    signal: IndicatorPoint[];
    histogram: IndicatorPoint[];
}
export declare function macd(candles: CandleData[], fastPeriod?: number, slowPeriod?: number, signalPeriod?: number): MACDResult;
export interface BollingerResult {
    upper: IndicatorPoint[];
    middle: IndicatorPoint[];
    lower: IndicatorPoint[];
}
export declare function bollingerBands(candles: CandleData[], period?: number, stdDevMultiplier?: number): BollingerResult;
export declare function atr(candles: CandleData[], period?: number): IndicatorPoint[];
export interface StochasticResult {
    k: IndicatorPoint[];
    d: IndicatorPoint[];
}
export declare function stochastic(candles: CandleData[], kPeriod?: number, dPeriod?: number): StochasticResult;
export declare function vwap(candles: CandleData[]): IndicatorPoint[];
export type IndicatorType = "SMA" | "EMA" | "RSI" | "MACD" | "BOLL" | "ATR" | "STOCH" | "VWAP";
export type IndicatorPane = "overlay" | "below";
export interface IndicatorConfig {
    type: IndicatorType;
    label: string;
    pane: IndicatorPane;
    defaultParams: Record<string, number>;
    color: string;
}
export declare const INDICATOR_REGISTRY: IndicatorConfig[];
