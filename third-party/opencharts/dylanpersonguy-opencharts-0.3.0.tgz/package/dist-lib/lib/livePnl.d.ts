import { Position } from '../services/schemas';
export interface LiveTick {
    bid: number;
    ask: number;
    timestamp: number;
}
export declare function computeLivePnl(p: Position, tick?: LiveTick): number;
export declare function computeLivePrice(p: Position, tick?: LiveTick): number;
