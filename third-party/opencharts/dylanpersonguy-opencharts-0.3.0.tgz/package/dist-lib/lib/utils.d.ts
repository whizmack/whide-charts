import { ClassValue } from 'clsx';
export declare function cn(...inputs: ClassValue[]): string;
export declare function formatCurrency(value: number, decimals?: number): string;
export declare function formatNumber(value: number, decimals?: number): string;
export declare function formatDate(date: string | Date): string;
export declare function formatDateFull(date: string | Date): string;
export declare function pnlClass(value: number): string;
/**
 * Local calendar date as YYYY-MM-DD.
 *
 * `toISOString().slice(0, 10)` returns the UTC date, which is a different day
 * from the user's for most of the world — a date picker defaulting to it can
 * land on a day the app has no data for.
 */
export declare function toLocalDateString(date?: Date): string;
