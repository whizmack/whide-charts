/** Defer chart layout writes until after ResizeObserver delivery and coalesce bursts. */
export declare function observeChartSize(target: HTMLElement, resize: (width: number, height: number) => void): () => void;
