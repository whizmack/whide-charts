/**
 * Web Storage that cannot crash the app.
 *
 * Every accessor guarded here is a real failure mode, not defensive padding:
 * Safari in private mode throws on `setItem`, Chrome throws `SecurityError` on
 * any access when site data is blocked (the terminal is commonly embedded in an
 * iframe), quota exhaustion throws `QuotaExceededError` once enough drawings
 * accumulate, and a corrupt value makes `JSON.parse` throw at module load.
 *
 * Reads degrade to a fallback and writes degrade to a no-op that reports
 * failure, so the terminal keeps running with in-memory state.
 */
export interface SafeStorage {
    getItem(key: string): string | null;
    /** Returns false when the value could not be persisted (quota, private mode). */
    setItem(key: string, value: string): boolean;
    removeItem(key: string): boolean;
    /** Parse a JSON value, falling back when it is missing or corrupt. */
    getJSON<T>(key: string, fallback: T): T;
    setJSON(key: string, value: unknown): boolean;
}
export declare const safeStorage: SafeStorage;
export declare const safeSession: SafeStorage;
