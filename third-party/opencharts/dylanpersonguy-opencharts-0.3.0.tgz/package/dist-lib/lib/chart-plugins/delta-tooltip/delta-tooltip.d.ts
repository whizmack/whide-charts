import { ISeriesPrimitive, SeriesAttachedParameter, LineData, WhitespaceData, CandlestickData, LineStyleOptions, AreaStyleOptions, ISeriesPrimitivePaneView, Time } from 'lightweight-charts';
import { ISubscription } from '../helpers/delegate';
import { MultiTouchCrosshairPaneView, TooltipCrosshairLineData } from './crosshair-line-pane';
import { DeltaTooltipData, DeltaTooltipPaneView } from './delta-tooltip-pane';
import { MultiTouchChartEvents } from './multi-touch-chart-events';
export interface TooltipPrimitiveOptions {
    lineColor: string;
    priceExtractor: <T extends WhitespaceData>(dataPoint: T) => [number, string];
    showTime: boolean;
    topOffset: number;
}
export interface ActiveRange {
    from: number;
    to: number;
    positive: boolean;
}
export declare class DeltaTooltipPrimitive implements ISeriesPrimitive<Time> {
    private _options;
    _crosshairPaneView: MultiTouchCrosshairPaneView;
    _deltaTooltipPaneView: DeltaTooltipPaneView;
    _paneViews: ISeriesPrimitivePaneView[];
    _crosshairData: TooltipCrosshairLineData[];
    _tooltipData: Partial<DeltaTooltipData>;
    _attachedParams: SeriesAttachedParameter<Time> | undefined;
    _touchChartEvents: MultiTouchChartEvents | null;
    private _activeRange;
    constructor(options: Partial<TooltipPrimitiveOptions>);
    attached(param: SeriesAttachedParameter<Time>): void;
    detached(): void;
    paneViews(): ISeriesPrimitivePaneView[];
    updateAllViews(): void;
    setData(crosshairData: TooltipCrosshairLineData[], tooltipData: Partial<DeltaTooltipData>): void;
    currentColor(): string;
    chart(): import('lightweight-charts').IChartApiBase<Time> | undefined;
    series(): import('lightweight-charts').ISeriesApi<keyof import('lightweight-charts').SeriesOptionsMap, Time, CandlestickData<Time> | WhitespaceData<Time> | import('lightweight-charts').BarData<Time> | import('lightweight-charts').AreaData<Time> | import('lightweight-charts').BaselineData<Time> | LineData<Time> | import('lightweight-charts').HistogramData<Time> | import('lightweight-charts').CustomData<Time> | import('lightweight-charts').CustomSeriesWhitespaceData<Time>, import('lightweight-charts').BarSeriesOptions | import('lightweight-charts').CandlestickSeriesOptions | import('lightweight-charts').AreaSeriesOptions | import('lightweight-charts').BaselineSeriesOptions | import('lightweight-charts').LineSeriesOptions | import('lightweight-charts').HistogramSeriesOptions | import('lightweight-charts').CustomSeriesOptions, import('lightweight-charts').DeepPartial<import('lightweight-charts').BarStyleOptions & import('lightweight-charts').SeriesOptionsCommon> | import('lightweight-charts').DeepPartial<import('lightweight-charts').CandlestickStyleOptions & import('lightweight-charts').SeriesOptionsCommon> | import('lightweight-charts').DeepPartial<AreaStyleOptions & import('lightweight-charts').SeriesOptionsCommon> | import('lightweight-charts').DeepPartial<import('lightweight-charts').BaselineStyleOptions & import('lightweight-charts').SeriesOptionsCommon> | import('lightweight-charts').DeepPartial<LineStyleOptions & import('lightweight-charts').SeriesOptionsCommon> | import('lightweight-charts').DeepPartial<import('lightweight-charts').HistogramStyleOptions & import('lightweight-charts').SeriesOptionsCommon> | import('lightweight-charts').DeepPartial<import('lightweight-charts').CustomStyleOptions & import('lightweight-charts').SeriesOptionsCommon>> | undefined;
    applyOptions(options: Partial<TooltipPrimitiveOptions>): void;
    activeRange(): ISubscription<ActiveRange | null>;
    private _setCrosshairMode;
    private _hideTooltip;
    private _hideCrosshair;
    private _chartBackgroundColor;
    private _seriesLineColor;
    private _showTooltip;
}
