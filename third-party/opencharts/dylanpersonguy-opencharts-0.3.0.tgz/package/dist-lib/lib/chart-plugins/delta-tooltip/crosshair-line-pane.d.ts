import { ISeriesPrimitivePaneRenderer, ISeriesPrimitivePaneView, SeriesPrimitivePaneViewZOrder } from 'lightweight-charts';
export declare class MultiTouchCrosshairPaneView implements ISeriesPrimitivePaneView {
    _data: TooltipCrosshairLineData[];
    constructor(data: TooltipCrosshairLineData[]);
    update(data: TooltipCrosshairLineData[]): void;
    renderer(): ISeriesPrimitivePaneRenderer | null;
    zOrder(): SeriesPrimitivePaneViewZOrder;
}
export interface TooltipCrosshairLineData {
    x: number;
    visible: boolean;
    color: string;
    topMargin: number;
    priceY: number;
    markerColor: string;
    markerBorderColor: string;
}
