import { Coordinate, IChartApi, Logical } from 'lightweight-charts';
import { ISubscription } from '../helpers/delegate';
export interface TouchPoint {
    x: number;
    index: Logical;
    y: Coordinate;
}
export interface MultiTouchInteraction {
    points: TouchPoint[];
}
interface MouseState {
    drawing: boolean;
    startLogical: number | null;
    startCoordinate: number | null;
    startX: number | null;
}
interface MultiTouchChartOptions {
    simulateMultiTouchUsingMouseDrag: boolean;
}
type UnSubscriber = () => void;
export declare class MultiTouchChartEvents {
    _chartElement: HTMLDivElement;
    _chart: IChartApi;
    _options: MultiTouchChartOptions;
    _mouseState: MouseState;
    private _touchLeave;
    private _touchInteraction;
    _unSubscribers: UnSubscriber[];
    constructor(chart: IChartApi, options: MultiTouchChartOptions);
    destroy(): void;
    leave(): ISubscription;
    move(): ISubscription<MultiTouchInteraction>;
    _addMouseEventListener(target: HTMLDivElement, eventType: "mouseleave" | "mousemove" | "mousedown" | "mouseup", handler: (event: MouseEvent) => void): void;
    _addTouchEventListener(target: HTMLDivElement, eventType: "touchstart" | "touchend" | "touchmove" | "touchcancel", handler: (event: TouchEvent) => void): void;
    _mouseLeave(): void;
    _mouseMove(event: MouseEvent): void;
    _mouseDown(event: MouseEvent): void;
    _mouseUp(): void;
    _touchMove(event: TouchEvent): void;
    _touchFinish(event: TouchEvent): void;
    _touchOther(event: TouchEvent): void;
}
export {};
