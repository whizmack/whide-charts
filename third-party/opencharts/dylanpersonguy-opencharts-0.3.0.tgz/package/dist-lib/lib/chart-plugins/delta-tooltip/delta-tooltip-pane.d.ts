import { ISeriesPrimitivePaneRenderer, ISeriesPrimitivePaneView, SeriesPrimitivePaneViewZOrder } from 'lightweight-charts';
export declare class DeltaTooltipPaneView implements ISeriesPrimitivePaneView {
    _data: DeltaTooltipData;
    constructor(data: Partial<DeltaTooltipData>);
    update(data: Partial<DeltaTooltipData>): void;
    renderer(): ISeriesPrimitivePaneRenderer | null;
    zOrder(): SeriesPrimitivePaneViewZOrder;
}
export interface DeltaSingleTooltipData {
    x: number;
    lineContent: string[];
}
export interface DeltaTooltipData {
    deltaTopLine: string;
    deltaBottomLine: string;
    deltaBackgroundColor: string;
    deltaTextColor: string;
    topSpacing: number;
    tooltips: DeltaSingleTooltipData[];
}
