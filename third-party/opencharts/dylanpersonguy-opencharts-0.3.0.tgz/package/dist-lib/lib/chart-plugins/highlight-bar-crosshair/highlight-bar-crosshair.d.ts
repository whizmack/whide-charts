import { ISeriesPrimitivePaneRenderer, ISeriesPrimitivePaneView, SeriesPrimitivePaneViewZOrder, ISeriesPrimitive, SeriesAttachedParameter, Time } from 'lightweight-charts';
declare class CrosshairHighlightPaneView implements ISeriesPrimitivePaneView {
    _data: CrosshairHighlightData;
    constructor(data: CrosshairHighlightData);
    update(data: CrosshairHighlightData): void;
    renderer(): ISeriesPrimitivePaneRenderer | null;
    zOrder(): SeriesPrimitivePaneViewZOrder;
}
interface CrosshairHighlightData {
    x: number;
    visible: boolean;
    color: string;
    barSpacing: number;
}
export interface HighlightBarCrosshairOptions {
    color: string;
}
export declare class CrosshairHighlightPrimitive implements ISeriesPrimitive<Time> {
    private _options;
    _paneViews: CrosshairHighlightPaneView[];
    _data: CrosshairHighlightData;
    _attachedParams: SeriesAttachedParameter<Time> | undefined;
    constructor(options: Partial<HighlightBarCrosshairOptions>);
    attached(param: SeriesAttachedParameter<Time>): void;
    detached(): void;
    paneViews(): CrosshairHighlightPaneView[];
    updateAllViews(): void;
    setData(data: CrosshairHighlightData): void;
    currentColor(): string;
    chart(): import('lightweight-charts').IChartApiBase<Time> | undefined;
    _setCrosshairMode(): void;
    private _moveHandler;
    private _barSpacing;
    private _onMouseMove;
}
export {};
