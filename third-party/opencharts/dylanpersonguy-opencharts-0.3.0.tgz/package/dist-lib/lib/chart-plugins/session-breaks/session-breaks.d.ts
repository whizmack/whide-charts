import { DataChangedScope, ISeriesPrimitivePaneView } from 'lightweight-charts';
import { PluginBase } from '../plugin-base';
/**
 * Session Breaks — TradingView-style vertical dashed lines at the first bar
 * of each new trading session, separating one trading day's price action
 * from the next on intraday charts.
 *
 * Session reset rules:
 * - "utc-midnight": new session at 00:00 UTC (forex, crypto, metals, …)
 * - "ny-0930":      new session at 09:30 America/New_York (US equities RTH);
 *                   DST-aware via Intl, pre-market bars belong to the prior
 *                   session so the break lands exactly on the 09:30 bar.
 */
export type SessionStartRule = "utc-midnight" | "ny-0930";
export interface SessionBreaksOptions {
    color: string;
    /** Line width in media px. */
    width: number;
    /** Dash pattern in media px. */
    dash: number[];
    sessionStart: SessionStartRule;
}
export declare class SessionBreaks extends PluginBase {
    private readonly _options;
    private readonly _paneViews;
    private _breakTimes;
    private _nyFormatter;
    private _lastBarTime;
    private _lastSessionKey;
    constructor(options?: Partial<SessionBreaksOptions>);
    options(): SessionBreaksOptions;
    breakTimes(): readonly number[];
    attached(param: Parameters<PluginBase["attached"]>[0]): void;
    protected dataUpdated(scope: DataChangedScope): void;
    updateAllViews(): void;
    paneViews(): readonly ISeriesPrimitivePaneView[];
    private _recomputeAll;
    /** O(1) handling of live bar updates — only the newest bar can add a break. */
    private _appendLatest;
    /** Bars with the same key belong to the same trading session. */
    private _sessionKey;
    private _nySessionKey;
    private _nyParts;
}
