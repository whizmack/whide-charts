import { DrawingLine } from '../../../pages/trading/constants';
/** Price of an alert-enabled line at `timeSec`, or null if it can't cross now. */
export declare function linePriceAt(d: DrawingLine, timeSec: number): number | null;
/**
 * Drawings whose line the mid price just crossed (between `prevMid` and `mid`),
 * debounced per drawing via `firedAt` (mutated in place).
 */
export declare function detectCrossings(drawings: readonly DrawingLine[], prevMid: number, mid: number, nowSec: number, firedAt: Map<string, number>): DrawingLine[];
/** Short WebAudio beep for a fired alert (best-effort; silent if unavailable). */
export declare function playAlertBeep(): void;
