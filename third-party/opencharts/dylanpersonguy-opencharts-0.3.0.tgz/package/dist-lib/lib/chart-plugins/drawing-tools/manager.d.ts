import { IChartApi, ISeriesApi, SeriesType } from 'lightweight-charts';
import { DrawingLine, DrawingTool, MagnetMode } from '../../../pages/trading/constants';
import { DrawingCallbacks } from './types';
export interface DrawingToolsManagerOptions {
    chart: IChartApi;
    series: ISeriesApi<SeriesType>;
    container: HTMLElement;
    /** Chart timeframe interval in seconds — used for whitespace extrapolation. */
    intervalSec: number;
    /** Current timeframe label, stamped on new drawings as createdTf. */
    timeframe: string;
    /** Account equity — drives the position tool's $-risk / size readout. */
    accountEquity?: number;
    callbacks: DrawingCallbacks;
}
/**
 * TradingView-style interaction layer for chart drawings.
 *
 * Placement: arm a tool, then click-move-click or press-drag-release with a
 * live preview. Editing: hover highlights, drag anchors or bodies (Shift =
 * 45° snap, magnet = OHLC snap), shift-click multi-selects and body drags
 * move the whole group, Delete removes the selection, Escape cancels. Touch
 * gets scaled hit targets, drag support, and long-press for settings.
 * Pointer-down events that land on a drawing are stopped in the capture
 * phase so the chart never pans underneath a drag.
 */
export declare class DrawingToolsManager {
    private readonly chart;
    private readonly series;
    private readonly container;
    private readonly cb;
    private readonly primitive;
    private intervalSec;
    private timeframe;
    private tool;
    private drawings;
    private placing;
    private drag;
    private selectedIds;
    private hoveredId;
    private keyboardEnabled;
    setKeyboardEnabled(enabled: boolean): void;
    private magnetMode;
    private lastPointer;
    private previewing;
    private stayInMode;
    private longPress;
    private measureResult;
    private clipboard;
    private styleDefaults;
    constructor(opts: DrawingToolsManagerOptions);
    destroy(): void;
    setTool(tool: DrawingTool): void;
    setMagnetMode(mode: MagnetMode): void;
    setStyleDefaults(defaults: Record<string, Partial<DrawingLine>>): void;
    setStayInDrawingMode(enabled: boolean): void;
    setAccountEquity(equity: number): void;
    /**
     * Re-point the manager at a new timeframe without recreating it. The chart
     * and drawing primitive stay alive (so drawings never blink out on a TF
     * switch); only the interval used for whitespace extrapolation and the
     * createdTf stamped on new drawings change.
     */
    updateTimeframe(timeframe: string, intervalSec: number): void;
    /** External selection (e.g. object tree row click). Unknown ids are dropped. */
    setSelection(ids: string[]): void;
    setDrawings(drawings: DrawingLine[]): void;
    private ctx;
    /** Pointer position relative to the chart pane, or null when outside it. */
    private posFromClient;
    private eventPos;
    private toPoint;
    private resolveAll;
    private makeNew;
    private buildNew;
    private makePosition;
    private handleMouseDown;
    private handleMouseMove;
    private handleMouseUp;
    private handleDblClick;
    private handleContextMenu;
    private handleTouchStart;
    private handleTouchMove;
    private handleTouchEnd;
    private startLongPress;
    private cancelLongPressIfMoved;
    private clearLongPress;
    private handleKeyDown;
    /** Ctrl/Cmd+Z undo, Ctrl/Cmd+Shift+Z or Ctrl/Cmd+Y redo. */
    private handleHistoryShortcut;
    /** Alt+T/H/F/R arms the matching drawing tool. */
    private handleToolShortcut;
    /** Ctrl/Cmd+C copy, +V paste, +D duplicate the current selection. */
    private handleClipboardShortcut;
    /** Arrow keys nudge the selection 1px (10px with Shift). */
    private handleArrowNudge;
    private copySelected;
    private pasteClipboard;
    private offsetCopy;
    private nudgeSelected;
    private handleEscape;
    private placementStart;
    private commitPlacement;
    private finishMeasure;
    private clearMeasure;
    private placingMove;
    private maybeCommitPlacement;
    private commitDrawing;
    private cancelPlacement;
    private selectionStart;
    private toggleSelection;
    private beginDrag;
    /** Other selected, unlocked drawings that ride along on a body drag. */
    private groupFor;
    private dragMove;
    private computeDragUpdates;
    private dragPoint;
    /** Move a whole drawing by a pixel delta (body / group drag). */
    private shiftDrawing;
    private shiftChannel;
    private shiftPosition;
    private shiftPoint;
    private endDrag;
    private refreshSnapPreview;
    private forgetPointer;
    private handleBlur;
    /**
     * Resolve a cursor position to a data point, applying Shift angle-snap
     * (trendlines, when an opposite anchor exists) or magnet OHLC snapping.
     */
    private pointFor;
    private snapToNearbyAnchor;
    private anchorPoints;
    /** Pixel position of the first anchor while placing a trendline. */
    private placementAnchorPx;
    /** Pixel position of the anchor opposite the one being dragged. */
    private dragAnchorPx;
    private magnetSnap;
    /** Binary search the series data for the bar at the given unix time. */
    private candleAt;
    private removeSelected;
    private select;
    private hoverHit;
    private applyCursor;
}
