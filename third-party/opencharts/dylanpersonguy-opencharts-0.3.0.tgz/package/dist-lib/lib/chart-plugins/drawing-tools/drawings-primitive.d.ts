import { ISeriesPrimitiveAxisView, ISeriesPrimitivePaneView } from 'lightweight-charts';
import { DrawingLine } from '../../../pages/trading/constants';
import { PluginBase } from '../plugin-base';
import { DrawCtxInfo, ResolvedEntry } from './types';
export declare function shouldAppendAxisViews(drawing: DrawingLine, selected: boolean): boolean;
export declare function sortDrawingsForRender(drawings: readonly DrawingLine[]): DrawingLine[];
/**
 * Single series primitive that renders every user drawing (plus the in-flight
 * preview) on one canvas pass. Interaction state (hover/selection) is pushed
 * in by DrawingToolsManager.
 */
export declare class DrawingsPrimitive extends PluginBase {
    private _drawings;
    private _preview;
    private _selectedIds;
    private _hoveredId;
    private _intervalSec;
    private _accountEquity;
    private readonly _paneViews;
    private _axisViews;
    setDrawings(drawings: DrawingLine[]): void;
    setPreview(d: DrawingLine | null): void;
    setSelected(ids: readonly string[]): void;
    setHovered(id: string | null): void;
    setAccountEquity(equity: number): void;
    /** Account context the position tool reads for its $-risk / size readout. */
    drawInfo(): DrawCtxInfo;
    setIntervalSec(intervalSec: number): void;
    updateAllViews(): void;
    paneViews(): readonly ISeriesPrimitivePaneView[];
    priceAxisViews(): readonly ISeriesPrimitiveAxisView[];
    resolveEntries(): ResolvedEntry[];
    private _stateFor;
    private _rebuildAxisViews;
}
