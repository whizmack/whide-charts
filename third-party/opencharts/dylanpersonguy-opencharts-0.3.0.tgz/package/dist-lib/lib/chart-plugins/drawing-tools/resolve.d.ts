import { IChartApi, ISeriesApi, SeriesOptionsMap, Time } from 'lightweight-charts';
import { DrawingLine } from '../../../pages/trading/constants';
import { EntryState, ResolvedEntry } from './types';
export declare const FIB_LEVELS: readonly [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1];
export declare const FIB_EXT_LEVELS: readonly [0, 0.618, 1, 1.618, 2.618];
export declare const FIB_COLORS: string[];
export type AnySeries = ISeriesApi<keyof SeriesOptionsMap>;
/**
 * Shared per-pass conversion context. Drawings store unix-second anchors that
 * may not fall on this timeframe's bar grid (drawn on another TF) or may sit
 * beyond the loaded data (future anchors) — both need interpolation /
 * extrapolation, which needs the series data and the TF interval.
 */
export interface ResolveCtx {
    chart: IChartApi;
    series: AnySeries;
    intervalSec: number;
    data: readonly {
        time: Time;
    }[];
}
export declare function makeResolveCtx(chart: IChartApi, series: AnySeries, intervalSec: number): ResolveCtx;
/**
 * Time → x coordinate. Falls back to logical-index interpolation for times
 * between bars (cross-timeframe anchors) and extrapolation past either end of
 * the data (future anchors / unloaded history).
 */
export declare function timeToX(ctx: ResolveCtx, time: number): number | null;
/**
 * X coordinate → time. Falls back to bar-interval extrapolation in the
 * whitespace beyond the loaded data so anchors can be placed in the future.
 */
export declare function xToTime(ctx: ResolveCtx, x: number): number | null;
/** Convert a drawing's data-space anchors into pane pixel coordinates. */
export declare function resolveEntry(d: DrawingLine, ctx: ResolveCtx, state: EntryState): ResolvedEntry;
