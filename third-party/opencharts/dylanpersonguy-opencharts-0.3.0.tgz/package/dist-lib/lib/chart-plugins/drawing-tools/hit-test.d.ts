import { Pt } from './geometry';
import { Hit, ResolvedEntry } from './types';
/**
 * Topmost (last-drawn) drawing wins, matching visual stacking order.
 * `scale` multiplies hit tolerances — pass ~2 for touch input.
 */
export declare function hitTest(entries: ResolvedEntry[], p: Pt, scale?: number): Hit | null;
