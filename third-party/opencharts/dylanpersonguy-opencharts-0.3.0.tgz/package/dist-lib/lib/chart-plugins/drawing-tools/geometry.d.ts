export interface Pt {
    x: number;
    y: number;
}
export declare function dist(a: Pt, b: Pt): number;
/** Distance from point p to the line segment a→b. */
export declare function distToSegment(p: Pt, a: Pt, b: Pt): number;
/** Constrain p to the nearest 45° increment around anchor (Shift-snap). */
export declare function snapAngle(anchor: Pt, p: Pt): Pt;
/** True if p is inside the box spanned by two corners, expanded by tolerance. */
export declare function pointInBox(p: Pt, x1: number, y1: number, x2: number, y2: number, tolerance: number): boolean;
