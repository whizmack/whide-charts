import { BitmapCoordinatesRenderingScope } from 'fancy-canvas';
import { DrawCtxInfo, ResolvedEntry } from './types';
export declare function renderEntry(scope: BitmapCoordinatesRenderingScope, e: ResolvedEntry, info: DrawCtxInfo): void;
