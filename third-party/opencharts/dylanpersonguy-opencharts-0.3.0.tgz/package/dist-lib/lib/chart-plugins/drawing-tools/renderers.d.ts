import { BitmapCoordinatesRenderingScope } from 'fancy-canvas';
import { DrawingLine } from '../../../pages/trading/constants';
import { DrawCtxInfo, ResolvedEntry } from './types';
export interface DrawingPresentation {
    strokeColor: string;
    fillColor: string;
    textAlign: CanvasTextAlign;
    textPlacement: "inside" | "outside" | "above" | "below";
    positiveColor: string;
    negativeColor: string;
    labelColor: string;
    stopColor: string;
    targetColor: string;
    stopFillOpacity: number;
    targetFillOpacity: number;
}
export interface PositionLinePresentation {
    color: string;
    width: number;
    dash?: readonly number[];
}
export declare function drawingPresentation(d: DrawingLine): DrawingPresentation;
export declare function positionLinePresentation(d: DrawingLine): PositionLinePresentation;
export declare function shouldRenderPositionReadout(d: DrawingLine, state: ResolvedEntry["state"]): boolean;
export declare function renderEntry(scope: BitmapCoordinatesRenderingScope, e: ResolvedEntry, info: DrawCtxInfo): void;
export declare function positionReadout(d: DrawingLine, info: Pick<DrawCtxInfo, "accountEquity" | "priceFormat">): string[];
