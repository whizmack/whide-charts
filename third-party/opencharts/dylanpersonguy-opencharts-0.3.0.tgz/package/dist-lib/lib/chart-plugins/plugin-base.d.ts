import { DataChangedScope, IChartApi, ISeriesApi, ISeriesPrimitive, SeriesAttachedParameter, SeriesOptionsMap, Time } from 'lightweight-charts';
export declare abstract class PluginBase implements ISeriesPrimitive<Time> {
    private _chart;
    private _series;
    protected dataUpdated?(scope: DataChangedScope): void;
    protected requestUpdate(): void;
    private _requestUpdate?;
    attached({ chart, series, requestUpdate }: SeriesAttachedParameter<Time>): void;
    detached(): void;
    get chart(): IChartApi;
    get series(): ISeriesApi<keyof SeriesOptionsMap>;
    private _fireDataUpdated;
}
