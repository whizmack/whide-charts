import { ISeriesPrimitivePaneRenderer, ISeriesPrimitivePaneView, SeriesPrimitivePaneViewZOrder, ISeriesPrimitive, SeriesAttachedParameter, LineData, WhitespaceData, CandlestickData, Time } from 'lightweight-charts';
import { TooltipOptions } from './tooltip-element';
declare class MultiTouchCrosshairPaneView implements ISeriesPrimitivePaneView {
    _data: TooltipCrosshairLineData;
    constructor(data: TooltipCrosshairLineData);
    update(data: TooltipCrosshairLineData): void;
    renderer(): ISeriesPrimitivePaneRenderer | null;
    zOrder(): SeriesPrimitivePaneViewZOrder;
}
interface TooltipCrosshairLineData {
    x: number;
    visible: boolean;
    color: string;
    topMargin: number;
}
export interface TooltipPrimitiveOptions {
    lineColor: string;
    tooltip?: Partial<TooltipOptions>;
    priceExtractor: <T extends WhitespaceData>(dataPoint: T) => string;
}
export declare class TooltipPrimitive implements ISeriesPrimitive<Time> {
    private _options;
    private _tooltip;
    _paneViews: MultiTouchCrosshairPaneView[];
    _data: TooltipCrosshairLineData;
    _attachedParams: SeriesAttachedParameter<Time> | undefined;
    constructor(options: Partial<TooltipPrimitiveOptions>);
    attached(param: SeriesAttachedParameter<Time>): void;
    detached(): void;
    paneViews(): MultiTouchCrosshairPaneView[];
    updateAllViews(): void;
    setData(data: TooltipCrosshairLineData): void;
    currentColor(): string;
    chart(): import('lightweight-charts').IChartApiBase<Time> | undefined;
    series(): import('lightweight-charts').ISeriesApi<keyof import('lightweight-charts').SeriesOptionsMap, Time, CandlestickData<Time> | WhitespaceData<Time> | import('lightweight-charts').BarData<Time> | import('lightweight-charts').AreaData<Time> | import('lightweight-charts').BaselineData<Time> | LineData<Time> | import('lightweight-charts').HistogramData<Time> | import('lightweight-charts').CustomData<Time> | import('lightweight-charts').CustomSeriesWhitespaceData<Time>, import('lightweight-charts').BarSeriesOptions | import('lightweight-charts').CandlestickSeriesOptions | import('lightweight-charts').AreaSeriesOptions | import('lightweight-charts').BaselineSeriesOptions | import('lightweight-charts').LineSeriesOptions | import('lightweight-charts').HistogramSeriesOptions | import('lightweight-charts').CustomSeriesOptions, import('lightweight-charts').DeepPartial<import('lightweight-charts').BarStyleOptions & import('lightweight-charts').SeriesOptionsCommon> | import('lightweight-charts').DeepPartial<import('lightweight-charts').CandlestickStyleOptions & import('lightweight-charts').SeriesOptionsCommon> | import('lightweight-charts').DeepPartial<import('lightweight-charts').AreaStyleOptions & import('lightweight-charts').SeriesOptionsCommon> | import('lightweight-charts').DeepPartial<import('lightweight-charts').BaselineStyleOptions & import('lightweight-charts').SeriesOptionsCommon> | import('lightweight-charts').DeepPartial<import('lightweight-charts').LineStyleOptions & import('lightweight-charts').SeriesOptionsCommon> | import('lightweight-charts').DeepPartial<import('lightweight-charts').HistogramStyleOptions & import('lightweight-charts').SeriesOptionsCommon> | import('lightweight-charts').DeepPartial<import('lightweight-charts').CustomStyleOptions & import('lightweight-charts').SeriesOptionsCommon>> | undefined;
    applyOptions(options: Partial<TooltipPrimitiveOptions>): void;
    private _setCrosshairMode;
    private _moveHandler;
    private _hideTooltip;
    private _hideCrosshair;
    private _onMouseMove;
    private _createTooltipElement;
}
export {};
