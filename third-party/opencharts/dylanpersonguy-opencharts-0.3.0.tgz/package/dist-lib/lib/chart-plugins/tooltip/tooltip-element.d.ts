import { IChartApi } from 'lightweight-charts';
export interface TooltipOptions {
    title: string;
    followMode: "top" | "tracking";
    /** fallback horizontal deadzone width */
    horizontalDeadzoneWidth: number;
    verticalDeadzoneHeight: number;
    verticalSpacing: number;
    /** topOffset is the vertical spacing when followMode is 'top' */
    topOffset: number;
}
export interface TooltipContentData {
    title?: string;
    price: string;
    date: string;
    time: string;
}
export interface TooltipPosition {
    visible: boolean;
    paneX: number;
    paneY: number;
}
export declare class TooltipElement {
    private _chart;
    private _element;
    private _titleElement;
    private _priceElement;
    private _dateElement;
    private _timeElement;
    private _options;
    private _lastTooltipWidth;
    constructor(chart: IChartApi, options: Partial<TooltipOptions>);
    destroy(): void;
    applyOptions(options: Partial<TooltipOptions>): void;
    options(): TooltipOptions;
    updateTooltipContent(tooltipContentData: TooltipContentData): void;
    updatePosition(positionData: TooltipPosition): void;
    private _calculateXPosition;
    private _calculateYPosition;
}
