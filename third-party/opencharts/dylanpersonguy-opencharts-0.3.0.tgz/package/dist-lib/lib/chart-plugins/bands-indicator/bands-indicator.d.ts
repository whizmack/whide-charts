import { CanvasRenderingTarget2D } from 'fancy-canvas';
import { AutoscaleInfo, Coordinate, DataChangedScope, ISeriesPrimitive, ISeriesPrimitivePaneRenderer, ISeriesPrimitivePaneView, Logical, SeriesAttachedParameter, SeriesDataItemTypeMap, SeriesType, Time } from 'lightweight-charts';
import { PluginBase } from '../plugin-base';
import { ClosestTimeIndexFinder } from '../helpers/closest-index';
import { UpperLowerInRange } from '../helpers/min-max-in-range';
interface BandRendererData {
    x: Coordinate | number;
    upper: Coordinate | number;
    lower: Coordinate | number;
}
declare class BandsIndicatorPaneRenderer implements ISeriesPrimitivePaneRenderer {
    _viewData: BandViewData;
    constructor(data: BandViewData);
    draw(): void;
    drawBackground(target: CanvasRenderingTarget2D): void;
}
interface BandViewData {
    data: BandRendererData[];
    options: Required<BandsIndicatorOptions>;
}
declare class BandsIndicatorPaneView implements ISeriesPrimitivePaneView {
    _source: BandsIndicator;
    _data: BandViewData;
    constructor(source: BandsIndicator);
    update(): void;
    renderer(): BandsIndicatorPaneRenderer;
}
interface BandData {
    time: Time;
    upper: number;
    lower: number;
}
export interface BandsIndicatorOptions {
    lineColor?: string;
    fillColor?: string;
    lineWidth?: number;
}
export declare class BandsIndicator extends PluginBase implements ISeriesPrimitive<Time> {
    _paneViews: BandsIndicatorPaneView[];
    _seriesData: SeriesDataItemTypeMap[SeriesType][];
    _bandsData: BandData[];
    _options: Required<BandsIndicatorOptions>;
    _timeIndices: ClosestTimeIndexFinder<{
        time: number;
    }>;
    _upperLower: UpperLowerInRange<BandData>;
    constructor(options?: BandsIndicatorOptions);
    updateAllViews(): void;
    paneViews(): BandsIndicatorPaneView[];
    attached(p: SeriesAttachedParameter<Time>): void;
    dataUpdated(scope: DataChangedScope): void;
    _minValue: number;
    _maxValue: number;
    calculateBands(): void;
    autoscaleInfo(startTimePoint: Logical, endTimePoint: Logical): AutoscaleInfo;
}
export {};
