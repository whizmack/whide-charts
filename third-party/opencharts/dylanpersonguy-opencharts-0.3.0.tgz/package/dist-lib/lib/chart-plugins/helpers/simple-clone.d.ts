type Mutable<T extends object> = {
    -readonly [K in keyof T]: T[K];
};
export declare function cloneReadonly<T extends object>(obj: T): Mutable<T>;
export {};
