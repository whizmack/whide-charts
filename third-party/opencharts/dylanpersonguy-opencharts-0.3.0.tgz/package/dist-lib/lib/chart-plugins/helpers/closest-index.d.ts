export type SearchDirection = "left" | "right";
export declare class ClosestTimeIndexFinder<T extends {
    time: number;
}> {
    private numbers;
    private cache;
    constructor(sortedNumbers: T[]);
    findClosestIndex(target: number, direction: SearchDirection): number;
    private _performSearch;
}
