import { Time } from 'lightweight-charts';
export declare function convertTime(t: Time): number;
export declare function displayTime(time: Time): string;
export declare function formattedDateAndTime(timestamp: number | undefined): [string, string];
