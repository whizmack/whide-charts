interface UpperLowerData {
    upper: number;
    lower: number;
}
export declare class UpperLowerInRange<T extends UpperLowerData> {
    private _arr;
    private _chunkSize;
    private _cache;
    constructor(arr: T[], chunkSize?: number);
    getMinMax(startIndex: number, endIndex: number): UpperLowerData;
    private _check;
}
export {};
