export type Callback<T1 = void> = (param1: T1) => void;
export interface ISubscription<T1 = void> {
    subscribe(callback: Callback<T1>, linkedObject?: unknown, singleshot?: boolean): void;
    unsubscribe(callback: Callback<T1>): void;
    unsubscribeAll(linkedObject: unknown): void;
}
export declare class Delegate<T1 = void> implements ISubscription<T1> {
    private _listeners;
    subscribe(callback: Callback<T1>, linkedObject?: unknown, singleshot?: boolean): void;
    unsubscribe(callback: Callback<T1>): void;
    unsubscribeAll(linkedObject: unknown): void;
    fire(param1: T1): void;
    hasListeners(): boolean;
    destroy(): void;
}
