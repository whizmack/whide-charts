import { CanvasRenderingTarget2D } from 'fancy-canvas';
import { Coordinate, DataChangedScope, ISeriesPrimitive, ISeriesPrimitivePaneRenderer, ISeriesPrimitivePaneView, SeriesAttachedParameter, SeriesDataItemTypeMap, SeriesPrimitivePaneViewZOrder, SeriesType, Time } from 'lightweight-charts';
import { PluginBase } from '../plugin-base';
interface SessionHighlightingRendererData {
    x: Coordinate | number;
    color: string;
}
declare class SessionHighlightingPaneRenderer implements ISeriesPrimitivePaneRenderer {
    _viewData: SessionHighlightingViewData;
    constructor(data: SessionHighlightingViewData);
    draw(target: CanvasRenderingTarget2D): void;
}
interface SessionHighlightingViewData {
    data: SessionHighlightingRendererData[];
    options: Required<SessionHighlightingOptions>;
    barWidth: number;
}
declare class SessionHighlightingPaneView implements ISeriesPrimitivePaneView {
    _source: SessionHighlighting;
    _data: SessionHighlightingViewData;
    constructor(source: SessionHighlighting);
    update(): void;
    renderer(): SessionHighlightingPaneRenderer;
    zOrder(): SeriesPrimitivePaneViewZOrder;
}
/** The plugin takes no options today; the alias keeps the public API stable. */
export type SessionHighlightingOptions = Record<string, never>;
interface BackgroundData {
    time: Time;
    color: string;
}
export type SessionHighlighter = (date: Time) => string;
export declare class SessionHighlighting extends PluginBase implements ISeriesPrimitive<Time> {
    _paneViews: SessionHighlightingPaneView[];
    _seriesData: SeriesDataItemTypeMap[SeriesType][];
    _backgroundColors: BackgroundData[];
    _options: Required<SessionHighlightingOptions>;
    _highlighter: SessionHighlighter;
    constructor(highlighter: SessionHighlighter, options?: SessionHighlightingOptions);
    updateAllViews(): void;
    paneViews(): SessionHighlightingPaneView[];
    attached(p: SeriesAttachedParameter<Time>): void;
    dataUpdated(_scope: DataChangedScope): void;
}
export {};
