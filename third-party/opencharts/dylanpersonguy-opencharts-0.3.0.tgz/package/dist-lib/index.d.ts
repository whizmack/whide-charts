/**
 * OpenCharts — an embeddable trading terminal.
 *
 * ```tsx
 * import { OpenChartsProvider, Terminal } from "@dylanpersonguy/opencharts";
 * import { createDemoAdapter } from "@dylanpersonguy/opencharts/demo";
 * import "@dylanpersonguy/opencharts/style.css";
 *
 * <OpenChartsProvider adapter={createDemoAdapter()}>
 *   <Terminal />
 * </OpenChartsProvider>;
 * ```
 *
 * Point it at your own backend by implementing `OpenChartsAdapter`, and compose
 * your own layout from the individual panels. Neither requires forking.
 */
export * from './adapter/index.ts';
export * from './terminal/index.ts';
export type { OpenChartsProviderProps } from './adapter/provider.tsx';
export { onNotification, type Notification } from './notifications.ts';
export type { Candle, Order, Position, Symbol, PlaceOrderInput } from './services/schemas.ts';
export { ChartPanel, type ChartPanelProps } from './pages/trading/ChartPanel.tsx';
export { ChartSettingsDialog } from './pages/trading/ChartSettingsDialog.tsx';
export { TradingViewColorPicker, type TradingViewColorPickerProps } from './components/TradingViewColorPicker.tsx';
export { updateChartPreferences, useChartPreferences } from './hooks/useChartPreferences.ts';
export type { ChartPreferences, PricePrecision, PriceScaleModePreference, PriceScaleSidePreference, TimeScaleDateFormat, TimeScaleTimeFormat, WatermarkMode, CrosshairLineStyle } from './hooks/useChartPreferences.ts';
export { CHART_COLORS } from './pages/trading/constants.ts';
export type { ChartColors, Timeframe } from './pages/trading/constants.ts';
export { buildChartSettingsOptions, buildCandlestickSettingsOptions, formatChartTimeLabel } from './pages/trading/chartSettingsOptions.ts';
export type { DrawingLine, DrawingTool } from './pages/trading/constants.ts';
export { DRAWING_TOOL_GROUPS } from './pages/trading/drawingToolCatalog.tsx';
export type { DrawingToolDefinition, DrawingToolGroup } from './pages/trading/drawingToolCatalog.tsx';
export type { IndicatorType } from './lib/indicators.ts';
export { sma, ema, rsi, macd, bollingerBands, atr, stochastic, vwap } from './lib/indicators.ts';
export { observeChartSize } from './lib/chart-resize.ts';
